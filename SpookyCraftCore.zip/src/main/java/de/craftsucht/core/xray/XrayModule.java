package de.craftsucht.core.xray;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * /xray - Staff-Werkzeug: macht Stein, Erde &amp; Co. um dich herum nur fuer dich durchsichtig (Glas),
 * sodass Erze durch die Waende sichtbar sind. Alles rein clientseitig (sendBlockChange),
 * die Welt wird nicht veraendert. /xray [radius] schaltet ein/aus.
 */
public class XrayModule implements Module, CommandExecutor, Listener {

    private static final Set<Material> HIDE = Set.of(
            Material.STONE, Material.DEEPSLATE, Material.COBBLESTONE, Material.COBBLED_DEEPSLATE,
            Material.DIRT, Material.COARSE_DIRT, Material.GRASS_BLOCK, Material.PODZOL, Material.MYCELIUM,
            Material.GRAVEL, Material.SAND, Material.RED_SAND, Material.SANDSTONE, Material.RED_SANDSTONE,
            Material.GRANITE, Material.DIORITE, Material.ANDESITE, Material.TUFF, Material.CALCITE,
            Material.DRIPSTONE_BLOCK, Material.CLAY, Material.NETHERRACK, Material.BASALT, Material.SMOOTH_BASALT,
            Material.BLACKSTONE, Material.END_STONE, Material.MAGMA_BLOCK, Material.SOUL_SAND, Material.SOUL_SOIL,
            Material.TERRACOTTA, Material.MOSSY_COBBLESTONE, Material.ROOTED_DIRT, Material.MUD);

    private final SpookyCraftCore plugin;
    private final Map<UUID, Set<Long>> active = new HashMap<>();
    private final Map<UUID, long[]> lastPos = new HashMap<>();
    private final Map<UUID, Integer> radius = new HashMap<>();
    private BukkitTask task;
    private BlockData glass;

    public XrayModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "xray";
    }

    @Override
    public void enable() {
        String mode = plugin.getConfig().getString("xray.mode", "grid");
        if ("air".equalsIgnoreCase(mode)) {
            glass = Material.AIR.createBlockData();
        } else if ("glass".equalsIgnoreCase(mode)) {
            glass = Material.GLASS.createBlockData();
        } else {
            // grid: Azalea-Blaetter im Zustand distance=7/persistent/waterlogged -> Pack zeigt dort ein Linien-Gitter
            org.bukkit.block.data.type.Leaves lv = (org.bukkit.block.data.type.Leaves) Material.AZALEA_LEAVES.createBlockData();
            lv.setDistance(7);
            lv.setPersistent(true);
            lv.setWaterlogged(true);
            glass = lv;
        }
        hideAll = plugin.getConfig().getBoolean("xray.hide-all", true);
        nightVision = plugin.getConfig().getBoolean("xray.night-vision", true);
        plugin.getCommand("xray").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 10L, 10L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        for (UUID id : new HashSet<>(active.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) { restore(p); nv(p, false); }
        }
        active.clear();
        lastPos.clear();
        radius.clear();
    }

    private boolean hideAll;
    private boolean nightVision;
    private final Set<UUID> gaveNv = new HashSet<>();

    private static boolean keep(Material m) {
        String n = m.name();
        return n.endsWith("_ORE") || n.endsWith("SHULKER_BOX") || m == Material.ANCIENT_DEBRIS
                || m == Material.SPAWNER || m == Material.TRIAL_SPAWNER || m == Material.CHEST
                || m == Material.TRAPPED_CHEST || m == Material.ENDER_CHEST || m == Material.BARREL
                || m == Material.NETHER_PORTAL || m == Material.END_PORTAL_FRAME;
    }

    private boolean shouldHide(Material m) {
        if (hideAll) return m.isSolid() && !m.isAir() && !keep(m);
        return HIDE.contains(m);
    }

    private void nv(Player p, boolean on) {
        if (!nightVision) return;
        if (on) {
            if (!p.hasPotionEffect(org.bukkit.potion.PotionEffectType.NIGHT_VISION)) {
                p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.NIGHT_VISION,
                        Integer.MAX_VALUE, 0, false, false, false));
                gaveNv.add(p.getUniqueId());
            }
        } else if (gaveNv.remove(p.getUniqueId())) {
            p.removePotionEffect(org.bukkit.potion.PotionEffectType.NIGHT_VISION);
        }
    }

    private boolean isAdmin(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin") || s.hasPermission("spookycraft.xray");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur für Spieler!");
            return true;
        }
        if (!isAdmin(p)) {
            plugin.getMessageUtil().send(p, "&cDafür hast du keine Rechte.");
            return true;
        }
        int max = plugin.getConfig().getInt("xray.max-radius", 16);
        int r = plugin.getConfig().getInt("xray.radius", 10);
        if (args.length > 0) {
            try {
                r = Math.max(2, Math.min(max, Integer.parseInt(args[0])));
            } catch (NumberFormatException ignored) {
            }
        }
        boolean on = active.containsKey(p.getUniqueId());
        boolean newRadius = args.length > 0 && on && radius.getOrDefault(p.getUniqueId(), r) != r;
        if (on && !newRadius) {
            restore(p);
            nv(p, false);
            active.remove(p.getUniqueId());
            lastPos.remove(p.getUniqueId());
            radius.remove(p.getUniqueId());
            plugin.getMessageUtil().send(p, "&7XRay &cdeaktiviert&7.");
        } else {
            if (on) restore(p);
            active.put(p.getUniqueId(), new HashSet<>());
            nv(p, true);
            lastPos.remove(p.getUniqueId());
            radius.put(p.getUniqueId(), r);
            plugin.getMessageUtil().send(p, "&7XRay &aaktiviert&7 (Radius &e" + r + "&7). Erneut &e/xray&7 zum Ausschalten.");
            update(p);
        }
        return true;
    }

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }

    private void tick() {
        for (UUID id : new HashSet<>(active.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline()) {
                active.remove(id);
                lastPos.remove(id);
                radius.remove(id);
                continue;
            }
            Location l = p.getLocation();
            long[] last = lastPos.get(id);
            if (last != null && last[0] == l.getBlockX() && last[1] == l.getBlockY() && last[2] == l.getBlockZ()) continue;
            update(p);
        }
    }

    private void update(Player p) {
        UUID id = p.getUniqueId();
        Set<Long> faked = active.get(id);
        if (faked == null) return;
        World w = p.getWorld();
        Location l = p.getLocation();
        int cx = l.getBlockX(), cy = l.getBlockY(), cz = l.getBlockZ();
        lastPos.put(id, new long[]{cx, cy, cz});
        int r = radius.getOrDefault(id, 10);
        Set<Long> now = new HashSet<>();
        for (int x = cx - r; x <= cx + r; x++) {
            for (int z = cz - r; z <= cz + r; z++) {
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int y = Math.max(w.getMinHeight(), cy - r); y <= Math.min(w.getMaxHeight() - 1, cy + r); y++) {
                    Block b = w.getBlockAt(x, y, z);
                    if (shouldHide(b.getType())) {
                        long k = key(x, y, z);
                        now.add(k);
                        if (!faked.contains(k)) p.sendBlockChange(b.getLocation(), glass);
                    }
                }
            }
        }
        for (long k : faked) {
            if (now.contains(k)) continue;
            int y = (int) (k & 0xFFF);
            if (y >= 0x800) y -= 0x1000;
            int z = (int) ((k >> 12) & 0x3FFFFFF);
            if (z >= 0x2000000) z -= 0x4000000;
            int x = (int) ((k >> 38) & 0x3FFFFFF);
            if (x >= 0x2000000) x -= 0x4000000;
            Block b = w.getBlockAt(x, y, z);
            p.sendBlockChange(b.getLocation(), b.getBlockData());
        }
        faked.clear();
        faked.addAll(now);
    }

    private void restore(Player p) {
        Set<Long> faked = active.get(p.getUniqueId());
        if (faked == null) return;
        World w = p.getWorld();
        for (long k : faked) {
            int y = (int) (k & 0xFFF);
            if (y >= 0x800) y -= 0x1000;
            int z = (int) ((k >> 12) & 0x3FFFFFF);
            if (z >= 0x2000000) z -= 0x4000000;
            int x = (int) ((k >> 38) & 0x3FFFFFF);
            if (x >= 0x2000000) x -= 0x4000000;
            Block b = w.getBlockAt(x, y, z);
            p.sendBlockChange(b.getLocation(), b.getBlockData());
        }
        faked.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        nv(e.getPlayer(), false);
        active.remove(e.getPlayer().getUniqueId());
        lastPos.remove(e.getPlayer().getUniqueId());
        radius.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Set<Long> f = active.get(e.getPlayer().getUniqueId());
        if (f != null) {
            f.clear();
            lastPos.remove(e.getPlayer().getUniqueId());
        }
    }
}
