package de.craftsucht.core.itemdb;

import org.bukkit.inventory.ItemStack;

public class DBEntry {

    private final int id;
    private final String name;
    private final ItemStack item;
    private final String addedBy;

    public DBEntry(int id, String name, ItemStack item, String addedBy) {
        this.id = id;
        this.name = name;
        this.item = item;
        this.addedBy = addedBy;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ItemStack getItem() {
        return item;
    }

    public String getAddedBy() {
        return addedBy;
    }
}
