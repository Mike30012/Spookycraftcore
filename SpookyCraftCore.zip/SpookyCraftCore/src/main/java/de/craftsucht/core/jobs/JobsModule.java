package de.craftsucht.core.jobs;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

/** Jobs: alle Spieler sind automatisch in jedem konfigurierten Job. */
public class JobsModule implements Module {

    final SpookyCraftCore plugin;
    private JobManager jobManager;
    private JobsPlayerDataManager playerDataManager;
    private RewardManager rewardManager;
    private PrefixColorManager prefixColorManager;
    private JobListener listener;
    private PrefixGuiListener prefixGuiListener;
    private PrefixCommand prefixCommand;
    private JobsBar jobsBar;

    public JobsModule(SpookyCraftCore plugin) { this.plugin = plugin; }

    @Override
    public String getId() { return "jobs"; }

    @Override
    public void enable() {
        // JobManager zuerst laden, damit der PlayerDataManager alle Jobs kennt.
        this.jobManager = new JobManager(plugin);
        this.playerDataManager = new JobsPlayerDataManager(plugin, jobManager);
        this.rewardManager = new RewardManager(plugin);
        this.prefixColorManager = new PrefixColorManager(plugin);

        this.listener = new JobListener(this);
        Bukkit.getPluginManager().registerEvents(listener, plugin);

        JobsCommand command = new JobsCommand(this);
        plugin.getCommand("jobs").setExecutor(command);
        plugin.getCommand("jobs").setTabCompleter(new JobsTabCompleter(this));

        this.prefixGuiListener = new PrefixGuiListener(this);
        Bukkit.getPluginManager().registerEvents(prefixGuiListener, plugin);
        this.prefixCommand = new PrefixCommand(this, prefixGuiListener);
        plugin.getCommand("prefix").setExecutor(prefixCommand);
        plugin.getCommand("prefix").setTabCompleter(prefixCommand);

        this.jobsBar = new JobsBar(this);
        this.jobsBar.start();

        // Jobgeld wird ausschließlich bei passenden Tätigkeiten ausgezahlt.
    }

    @Override
    public void disable() {
        if (jobsBar != null) jobsBar.stop();
        if (playerDataManager != null) playerDataManager.shutdown();
        if (listener != null) HandlerList.unregisterAll(listener);
        if (prefixGuiListener != null) HandlerList.unregisterAll(prefixGuiListener);
    }

    public JobManager getJobManager() { return jobManager; }
    public JobsBar getJobsBar() { return jobsBar; }
    public JobsPlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public RewardManager getRewardManager() { return rewardManager; }
    public PrefixColorManager getPrefixColorManager() { return prefixColorManager; }

    public EconomyManager getEconomyManager() {
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        return economyModule != null ? economyModule.getManager() : null;
    }
}
