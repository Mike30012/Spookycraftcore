package de.craftsucht.core.games;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;

import java.util.Locale;

/** Kleine Helfer fuer die Spiel-Module (Lotto, Chat-Spiele, Coinflip). */
final class GameUtil {

    private GameUtil() {
    }

    static EconomyManager eco(SpookyCraftCore plugin) {
        return plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
    }

    static String money(double v) {
        return String.format(Locale.GERMANY, "%,.0f", v) + "$";
    }

    /** Parst Betraege wie 500, 2.5k, 1m. Gibt -1 bei Fehler zurueck. */
    static double parseAmount(String s) {
        if (s == null || s.isBlank()) return -1;
        String t = s.trim().toLowerCase(Locale.ROOT).replace(",", ".");
        double mult = 1;
        if (t.endsWith("k")) {
            mult = 1_000;
            t = t.substring(0, t.length() - 1);
        } else if (t.endsWith("m")) {
            mult = 1_000_000;
            t = t.substring(0, t.length() - 1);
        }
        try {
            double v = Double.parseDouble(t) * mult;
            if (Double.isNaN(v) || Double.isInfinite(v) || v <= 0) return -1;
            return Math.floor(v);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
