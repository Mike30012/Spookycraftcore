package de.craftsucht.core.bank;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public class BankCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final BankManager bankManager;
    private final ZinsManager zinsManager;

    public BankCommand(SpookyCraftCore plugin, BankManager bankManager, ZinsManager zinsManager) {
        this.plugin = plugin;
        this.bankManager = bankManager;
        this.zinsManager = zinsManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur für Spieler!");
            return true;
        }
        if (!player.isOp() && !player.hasPermission("banksystem.use")) {
            send(player, "&cDu hast keine Berechtigung.");
            return true;
        }
        if (args.length == 0) {
            BankGUI.open(plugin, bankManager, player);
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!player.isOp() && !player.hasPermission("banksystem.admin") && !player.hasPermission("craftsucht.core.admin")) {
                send(player, "&cDu hast keine Berechtigung.");
                return true;
            }
            bankManager.saveAll();
            zinsManager.restart();
            send(player, "&aBankSystem erfolgreich neu geladen.");
            return true;
        }
        if (args[0].equalsIgnoreCase("einzahlen")) {
            handleEinzahlen(player, args);
            return true;
        }
        if (args[0].equalsIgnoreCase("auszahlen")) {
            handleAuszahlen(player, args);
            return true;
        }
        send(player, "&7/bank &e– GUI öffnen");
        send(player, "&7/bank einzahlen &e[betrag|*]");
        send(player, "&7/bank auszahlen &e[betrag|*]");
        return true;
    }

    private void handleEinzahlen(Player player, String[] args) {
        double betrag;
        if (args.length < 2 || args[1].equals("*")) {
            de.craftsucht.core.economy.EconomyModule economyModule =
                    (de.craftsucht.core.economy.EconomyModule) plugin.getModuleManager().get("economy");
            betrag = economyModule != null ? economyModule.getManager().getBalance(player.getUniqueId()) : 0.0;
        } else {
            Double parsed = parse(args[1]);
            if (parsed == null) {
                send(player, "&cBitte gib eine gültige Zahl ein.");
                return;
            }
            betrag = parsed;
        }
        if (betrag <= 0.0) {
            send(player, "&cBitte gib eine gültige Zahl ein.");
            return;
        }
        if (!bankManager.einzahlen(player, betrag)) {
            send(player, "&cDu hast nicht genug Geld!");
            return;
        }
        send(player, "&aErfolgreich &e" + String.format("%.2f", betrag) + "$ &aauf dein Bankkonto eingezahlt.");
    }

    private void handleAuszahlen(Player player, String[] args) {
        double betrag;
        if (args.length < 2 || args[1].equals("*")) {
            betrag = bankManager.getGuthaben(player.getUniqueId());
        } else {
            Double parsed = parse(args[1]);
            if (parsed == null) {
                send(player, "&cBitte gib eine gültige Zahl ein.");
                return;
            }
            betrag = parsed;
        }
        if (betrag <= 0.0) {
            send(player, "&cBitte gib eine gültige Zahl ein.");
            return;
        }
        if (!bankManager.auszahlen(player, betrag)) {
            send(player, "&cDein Bankkonto hat nicht genug Guthaben!");
            return;
        }
        send(player, "&aErfolgreich &e" + String.format("%.2f", betrag) + "$ &avon deinem Bankkonto abgehoben.");
    }

    private Double parse(String input) {
        try {
            return Double.parseDouble(input.replace(",", "."));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void send(Player player, String msg) {
        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8[&6Bank&8] " + msg));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            return List.of("einzahlen", "auszahlen", "reload");
        }
        if (args.length == 2) {
            return List.of("*", "100", "500", "1000");
        }
        return List.of();
    }
}
