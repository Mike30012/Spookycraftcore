package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.Set;

/**
 * Entfernt abgeschaffte Spezial-Items (config special-items.remove, Standard: admin_hacke) aus den Inventaren
 * (Rucksack, Ruestung, Zweithand, Endertruhe) - beim Join und danach regelmaessig.
 */
public class RemovedItemsCleaner implements Listener {

    private final SpookyCraftCore plugin;
    private BukkitTask task;

    public RemovedItemsCleaner(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) clean(p);
        }, 200L, 200L);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private Set<String> removed() {
        List<String> l = plugin.getConfig().getStringList("special-items.remove");
        return l.isEmpty() ? Set.of("admin_hacke") : Set.copyOf(l);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> clean(p), 20L);
    }

    private boolean isRemoved(ItemStack it, Set<String> ids) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return false;
        ItemMeta meta = it.getItemMeta();
        String sp = meta.getPersistentDataContainer().get(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING);
        return sp != null && ids.contains(sp);
    }

    private int sweep(Inventory inv, Set<String> ids) {
        int n = 0;
        for (int i = 0; i < inv.getSize(); i++) {
            if (isRemoved(inv.getItem(i), ids)) {
                inv.setItem(i, null);
                n++;
            }
        }
        return n;
    }

    private void clean(Player p) {
        if (!p.isOnline()) return;
        Set<String> ids = removed();
        int n = sweep(p.getInventory(), ids) + sweep(p.getEnderChest(), ids);
        if (n > 0) plugin.getLogger().info("Abgeschaffte Spezial-Items bei " + p.getName() + " entfernt: " + n);
    }
}
