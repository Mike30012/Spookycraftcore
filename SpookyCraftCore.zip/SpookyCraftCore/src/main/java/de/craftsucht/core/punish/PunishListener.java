package de.craftsucht.core.punish;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

public class PunishListener implements Listener {

    private final PunishManager manager;

    public PunishListener(PunishManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        PunishManager.BanRecord ban = manager.getActiveBan(event.getUniqueId());
        if (ban != null) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, manager.buildBanScreen(ban));
        }
    }

    /** Blockt den Chat komplett für gemutete Spieler, noch vor Clan-Chat & Co. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onChatMuteCheck(AsyncPlayerChatEvent event) {
        String reason = manager.getActiveMuteReason(event.getPlayer().getUniqueId());
        if (reason != null) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&cDu bist stummgeschaltet: &7" + reason));
        }
    }
}
