package de.craftsucht.core.hexe;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Witch;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Hexen-Haendler: Nachts erscheint die Hexe "Morgana" am gesetzten Ort (/hexe set), tags verschwindet sie.
 * Sie verkauft 5 taeglich wechselnde Angebote gegen Kristalle (jedes Angebot 1x pro Spieler und Tag).
 */
public class HexeModule implements Module, CommandExecutor, TabCompleter, Listener {

    private record Offer(Material mat, int amount, long price) {
    }

    private static final Offer[] POOL = {
            new Offer(Material.DIAMOND, 8, 25), new Offer(Material.NETHERITE_SCRAP, 2, 40),
            new Offer(Material.GOLDEN_APPLE, 8, 20), new Offer(Material.EXPERIENCE_BOTTLE, 32, 30),
            new Offer(Material.NAME_TAG, 3, 15), new Offer(Material.ENCHANTED_GOLDEN_APPLE, 1, 120),
            new Offer(Material.TOTEM_OF_UNDYING, 1, 60), new Offer(Material.SHULKER_BOX, 1, 50),
            new Offer(Material.ENDER_PEARL, 16, 20), new Offer(Material.WITHER_SKELETON_SKULL, 1, 70),
            new Offer(Material.BEACON, 1, 150), new Offer(Material.EMERALD_BLOCK, 4, 35),
            new Offer(Material.ANCIENT_DEBRIS, 2, 55), new Offer(Material.TRIDENT, 1, 90)
    };

    private final SpookyCraftCore plugin;
    private final NamespacedKey key;
    private File file;
    private YamlConfiguration data;
    private BukkitTask task;
    private Witch witch;
    private final Set<String> bought = new HashSet<>();

    public HexeModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "hexe");
    }

    @Override
    public String getId() {
        return "hexe";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "hexe.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("hexe").setExecutor(this);
        plugin.getCommand("hexe").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 60L, 100L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        org.bukkit.event.HandlerList.unregisterAll(this);
        removeWitch();
    }

    private static class ShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private Location loc() {
        if (!data.contains("world")) return null;
        org.bukkit.World w = Bukkit.getWorld(data.getString("world", ""));
        if (w == null) return null;
        return new Location(w, data.getDouble("x"), data.getDouble("y"), data.getDouble("z"), (float) data.getDouble("yaw"), 0f);
    }

    private void removeWitch() {
        if (witch != null && witch.isValid()) {
            witch.getWorld().spawnParticle(Particle.POOF, witch.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.03);
            witch.remove();
        }
        witch = null;
    }

    private void tick() {
        Location l = loc();
        if (l == null) return;
        long t = l.getWorld().getTime();
        boolean night = (t >= 13000 && t <= 23000) || l.getWorld().isThundering();
        if (night && (witch == null || !witch.isValid())) {
            if (!l.getChunk().isLoaded()) return;
            Entity e = l.getWorld().spawnEntity(l, EntityType.WITCH);
            if (e instanceof Witch w) {
                w.setAI(false);
                w.setSilent(true);
                w.setInvulnerable(true);
                w.setPersistent(false);
                w.setRemoveWhenFarAway(false);
                w.setCustomName(c("&5☠ &dHexe Morgana &5☠"));
                w.setCustomNameVisible(true);
                w.setCanPickupItems(false);
                w.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
                witch = w;
                l.getWorld().spawnParticle(Particle.WITCH, l.clone().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.05);
                for (Player p : l.getWorld().getPlayers()) {
                    if (p.getLocation().distanceSquared(l) < 80 * 80)
                        p.sendMessage(c("&5☠ &dEine Hexe ist aus dem Nebel aufgetaucht... &7(Spawn)"));
                }
            }
        } else if (!night && witch != null) {
            removeWitch();
        }
        if (witch != null && witch.isValid()) {
            witch.getWorld().spawnParticle(Particle.WITCH, witch.getLocation().add(0, 1.2, 0), 3, 0.4, 0.5, 0.4, 0.0);
        }
    }

    private long dayNumber() {
        return System.currentTimeMillis() / 86_400_000L;
    }

    private List<Offer> todays() {
        List<Offer> all = new ArrayList<>(List.of(POOL));
        Random r = new Random(dayNumber() * 7919L + 13);
        java.util.Collections.shuffle(all, r);
        return all.subList(0, 5);
    }

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(new ShopHolder(), 27, c("&5☠ &dHexe Morgana"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        List<Offer> offers = todays();
        long crystals = crystalsOf(p);
        for (int i = 0; i < offers.size(); i++) {
            Offer o = offers.get(i);
            ItemStack it = new ItemStack(o.mat(), o.amount());
            ItemMeta m = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(c("&7Preis: &b" + o.price() + " Kristalle"));
            boolean done = bought.contains(p.getUniqueId() + ":" + dayNumber() + ":" + i);
            lore.add(c(done ? "&c✖ Heute schon gekauft" : "&aKlicken zum Kaufen"));
            lore.add(c("&8Angebot #" + i));
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(11 + i - (i > 1 ? 0 : 0), it);
        }
        // Positionen: 10,11,12,14,15 wirken zentriert - einfach nacheinander ab Slot 11
        ItemStack info = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&bDeine Kristalle: &f" + crystals));
        im.setLore(List.of(c("&7Das Angebot wechselt täglich.")));
        info.setItemMeta(im);
        inv.setItem(22, info);
        p.openInventory(inv);
        p.playSound(p.getLocation(), "entity.witch.ambient", 0.8f, 1.0f);
    }

    private long crystalsOf(Player p) {
        if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null)
            return cm.getCrystals().get(p.getUniqueId());
        return 0;
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        Entity en = e.getRightClicked();
        if (en.getPersistentDataContainer().has(key, PersistentDataType.BYTE)) {
            e.setCancelled(true);
            open(e.getPlayer());
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ShopHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        int idx = slot - 11;
        List<Offer> offers = todays();
        if (idx < 0 || idx >= offers.size()) return;
        Offer o = offers.get(idx);
        String id = p.getUniqueId() + ":" + dayNumber() + ":" + idx;
        if (bought.contains(id)) {
            plugin.getMessageUtil().send(p, "&cDas hast du heute schon gekauft, Sterblicher.");
            return;
        }
        if (!(plugin.getModuleManager().get("crates") instanceof CratesModule cm) || cm.getCrystals() == null) return;
        if (!cm.getCrystals().take(p.getUniqueId(), o.price())) {
            plugin.getMessageUtil().send(p, "&cDir fehlen Kristalle für diesen Handel.");
            return;
        }
        bought.add(id);
        java.util.HashMap<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(o.mat(), o.amount()));
        for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
        p.playSound(p.getLocation(), "entity.witch.celebrate", 0.8f, 1.0f);
        plugin.getMessageUtil().send(p, "&5☠ &dMorgana grinst: &7\"Ein guter Handel... hihihi!\"");
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        boolean staff = p.isOp() || p.hasPermission("spookycraft.core.admin");
        if (args.length == 0 || !staff) {
            Location l = loc();
            if (witch == null || !witch.isValid()) {
                plugin.getMessageUtil().send(p, "&7Die Hexe zeigt sich nur nachts am Spawn...");
            } else if (l != null && p.getWorld().equals(l.getWorld()) && p.getLocation().distanceSquared(l) < 25) {
                open(p);
            } else {
                plugin.getMessageUtil().send(p, "&7Geh zur Hexe, um zu handeln.");
            }
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "set" -> {
                Location l = p.getLocation();
                data.set("world", l.getWorld().getName());
                data.set("x", l.getX());
                data.set("y", l.getY());
                data.set("z", l.getZ());
                data.set("yaw", l.getYaw());
                save();
                removeWitch();
                plugin.getMessageUtil().send(p, "&aOrt der Hexe gesetzt. Sie erscheint nachts.");
            }
            case "remove" -> {
                data.set("world", null);
                save();
                removeWitch();
                plugin.getMessageUtil().send(p, "&aHexe entfernt.");
            }
            case "show" -> {
                tick();
                open(p);
            }
            default -> plugin.getMessageUtil().send(p, "&cNutzung: /hexe [set|remove|show]");
        }
        return true;
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("hexe.yml speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && (sender.isOp() || sender.hasPermission("spookycraft.core.admin")))
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "set", "remove", "show");
        return List.of();
    }
}
