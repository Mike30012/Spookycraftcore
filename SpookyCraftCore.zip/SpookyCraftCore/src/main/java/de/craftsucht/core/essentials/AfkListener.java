package de.craftsucht.core.essentials;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.Map;
import java.util.UUID;

/** Removes AFK status on movement. */
public class AfkListener implements Listener {

    private final Map<UUID, Long> afkPlayers;
    private final SpookyCraftCore plugin;

    public AfkListener(Map<UUID, Long> afkPlayers, SpookyCraftCore plugin) {
        this.afkPlayers = afkPlayers;
        this.plugin = plugin;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (afkPlayers.remove(uuid) != null) {
            plugin.getMessageUtil().sendRaw(event.getPlayer(), "&7Du bist nicht mehr AFK.");
        }
    }
}
