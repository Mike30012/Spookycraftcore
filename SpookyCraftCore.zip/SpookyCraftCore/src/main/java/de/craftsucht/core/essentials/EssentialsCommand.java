package de.craftsucht.core.essentials;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class EssentialsCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final Map<UUID, UUID> pendingTpa;
    private final Map<UUID, Long> afkPlayers;
    private final Map<UUID, UUID> lastMessaged;

    public EssentialsCommand(SpookyCraftCore plugin, Map<UUID, UUID> pendingTpa, Map<UUID, Long> afkPlayers, Map<UUID, UUID> lastMessaged) {
        this.plugin = plugin;
        this.pendingTpa = pendingTpa;
        this.afkPlayers = afkPlayers;
        this.lastMessaged = lastMessaged;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player = (sender instanceof Player p) ? p : null;
        if (player == null && !label.equalsIgnoreCase("mail")) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        switch (label.toLowerCase()) {
            case "heal" -> heal(player);
            case "feed" -> feed(player);
            case "fly" -> fly(player);
            case "speed" -> speed(player, args);
            case "gm" -> gamemode(player, args);
            case "tpa" -> tpa(player, args);
            case "tpahere" -> tpahere(player, args);
            case "tpcancel" -> tpcancel(player);
            case "tpaccept" -> tpaccept(player);
            case "tpdeny" -> tpdeny(player);
            case "home" -> home(player, args);
            case "sethome" -> sethome(player, args);
            case "warp" -> warp(player, args);
            case "setwarp" -> setwarp(player, args);
            case "mail" -> mail(sender, args);
            case "afk" -> afk(player);
            case "msg" -> msg(sender, args);
            case "r" -> reply(sender, args);
        }
        return true;
    }

    private void heal(Player p) {
        if (!p.isOp() && !p.hasPermission("spookycraft.essentials.heal")) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue());
        plugin.getMessageUtil().send(p, "&aDu wurdest geheilt.");
    }

    private void feed(Player p) {
        if (!p.isOp() && !p.hasPermission("spookycraft.essentials.feed")) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        p.setFoodLevel(20);
        plugin.getMessageUtil().send(p, "&aDu bist satt.");
    }

    private void fly(Player p) {
        if (!p.isOp() && !p.hasPermission("spookycraft.essentials.fly")) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        p.setAllowFlight(!p.getAllowFlight());
        p.setFlying(p.getAllowFlight());
        plugin.getMessageUtil().send(p, p.getAllowFlight() ? "&aFlug aktiviert." : "&cFlug deaktiviert.");
    }

    private void speed(Player p, String[] args) {
        if (!p.isOp() && !p.hasPermission("spookycraft.essentials.speed")) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&cNutzung: /speed <1-10>");
            return;
        }
        try {
            int level = Math.max(1, Math.min(10, Integer.parseInt(args[0])));
            float speed = level / 10f;
            if (p.isFlying()) p.setFlySpeed(speed); else p.setWalkSpeed(speed);
            plugin.getMessageUtil().send(p, "&aGeschwindigkeit auf " + level + " gesetzt.");
        } catch (NumberFormatException e) {
            plugin.getMessageUtil().send(p, "&cDas ist keine gültige Zahl, Sterblicher.");
        }
    }

    private void gamemode(Player p, String[] args) {
        if (!p.isOp() && !p.hasPermission("spookycraft.essentials.gamemode")) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&cNutzung: /gm <survival|creative|adventure|spectator|0|1|2|3>");
            return;
        }
        GameMode mode = parseGameMode(args[0]);
        if (mode == null) {
            plugin.getMessageUtil().send(p, "&cUnbekannter Gamemode.");
            return;
        }
        p.setGameMode(mode);
        plugin.getMessageUtil().send(p, "&aGamemode geändert zu " + mode.name());
    }

    /** Accepts both names (survival/creative/...) and the classic 0-3 shortcuts. */
    private GameMode parseGameMode(String input) {
        switch (input) {
            case "0": return GameMode.SURVIVAL;
            case "1": return GameMode.CREATIVE;
            case "2": return GameMode.ADVENTURE;
            case "3": return GameMode.SPECTATOR;
        }
        try {
            return GameMode.valueOf(input.toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Ziel-UUIDs, deren offene Anfrage ein /tpahere ist (der Empfänger geht dann zum Anfragenden). */
    private static final java.util.Set<UUID> HERE_REQUESTS = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Long> REQUEST_TIME = new java.util.concurrent.ConcurrentHashMap<>();
    private static final long REQUEST_TIMEOUT_MS = 120_000L;

    private void tpa(Player p, String[] args) {
        request(p, args, false);
    }

    private void tpahere(Player p, String[] args) {
        request(p, args, true);
    }

    private void request(Player p, String[] args, boolean here) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&cNutzung: /" + (here ? "tpahere" : "tpa") + " <spieler>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.getMessageUtil().send(p, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
            return;
        }
        if (target.equals(p)) {
            plugin.getMessageUtil().send(p, "&cDu kannst dir selbst keine Anfrage schicken.");
            return;
        }
        if (de.craftsucht.core.basics.BasicsModule.isTpBlocked(target.getUniqueId())
                && !p.isOp() && !p.hasPermission("spookycraft.core.admin") && !p.hasPermission("essentials.tpo")) {
            plugin.getMessageUtil().send(p, "&c" + target.getName() + " nimmt keine Teleport-Anfragen an.");
            return;
        }
        pendingTpa.put(target.getUniqueId(), p.getUniqueId());
        REQUEST_TIME.put(target.getUniqueId(), System.currentTimeMillis());
        if (here) HERE_REQUESTS.add(target.getUniqueId()); else HERE_REQUESTS.remove(target.getUniqueId());
        plugin.getMessageUtil().send(target, "&b" + p.getName() + (here ? " &7möchte, dass du zu ihm teleportierst." : " &7möchte zu dir teleportieren.")
                + " &7/tpaccept oder /tpdeny");
        plugin.getMessageUtil().send(p, "&aAnfrage gesendet.");
    }

    private void tpcancel(Player p) {
        boolean removed = pendingTpa.entrySet().removeIf(e -> e.getValue().equals(p.getUniqueId()));
        plugin.getMessageUtil().send(p, removed ? "&aDeine Teleport-Anfrage wurde abgebrochen." : "&cDu hast keine offene Anfrage.");
    }

    private void tpaccept(Player p) {
        UUID requesterId = pendingTpa.remove(p.getUniqueId());
        boolean here = HERE_REQUESTS.remove(p.getUniqueId());
        Long time = REQUEST_TIME.remove(p.getUniqueId());
        if (requesterId == null) {
            plugin.getMessageUtil().send(p, "&cKeine offene Anfrage.");
            return;
        }
        if (time != null && System.currentTimeMillis() - time > REQUEST_TIMEOUT_MS) {
            plugin.getMessageUtil().send(p, "&cDie Anfrage ist abgelaufen.");
            return;
        }
        Player requester = Bukkit.getPlayer(requesterId);
        if (requester == null) {
            plugin.getMessageUtil().send(p, "&cSpieler nicht mehr online.");
            return;
        }
        if (here) {
            p.teleport(requester.getLocation());
            plugin.getMessageUtil().send(p, "&aTeleportiert zu " + requester.getName());
        } else {
            requester.teleport(p.getLocation());
            plugin.getMessageUtil().send(requester, "&aTeleportiert zu " + p.getName());
        }
        plugin.getMessageUtil().send(p, "&aAnfrage akzeptiert.");
    }

    private void tpdeny(Player p) {
        HERE_REQUESTS.remove(p.getUniqueId());
        REQUEST_TIME.remove(p.getUniqueId());
        if (pendingTpa.remove(p.getUniqueId()) == null) {
            plugin.getMessageUtil().send(p, "&cKeine offene Anfrage.");
            return;
        }
        plugin.getMessageUtil().send(p, "&cAnfrage abgelehnt.");
    }

    private void home(Player p, String[] args) {
        String name = args.length > 0 ? args[0] : "home";
        String sql = "SELECT world,x,y,z,yaw,pitch FROM homes WHERE uuid=? AND name=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            ps.setString(2, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    plugin.getMessageUtil().send(p, "&cKein Home mit diesem Namen.");
                    return;
                }
                Location loc = new Location(Bukkit.getWorld(rs.getString("world")), rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"), rs.getFloat("yaw"), rs.getFloat("pitch"));
                p.teleport(loc);
                plugin.getMessageUtil().send(p, "&aTeleportiert zu Home '" + name + "'.");
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Laden des Homes.");
        }
    }

    private void sethome(Player p, String[] args) {
        String name = args.length > 0 ? args[0] : "home";
        Location loc = p.getLocation();
        String sql = "INSERT INTO homes (uuid,name,world,x,y,z,yaw,pitch) VALUES (?,?,?,?,?,?,?,?) " +
                "ON CONFLICT(uuid,name) DO UPDATE SET world=excluded.world,x=excluded.x,y=excluded.y,z=excluded.z,yaw=excluded.yaw,pitch=excluded.pitch";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            ps.setString(2, name);
            ps.setString(3, loc.getWorld().getName());
            ps.setDouble(4, loc.getX());
            ps.setDouble(5, loc.getY());
            ps.setDouble(6, loc.getZ());
            ps.setFloat(7, loc.getYaw());
            ps.setFloat(8, loc.getPitch());
            ps.executeUpdate();
            plugin.getMessageUtil().send(p, "&aHome '" + name + "' gesetzt.");
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Speichern des Homes.");
        }
    }

    private void warp(Player p, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&cNutzung: /warp <name>");
            return;
        }
        String sql = "SELECT world,x,y,z,yaw,pitch FROM warps WHERE name=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, args[0]);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    plugin.getMessageUtil().send(p, "&cWarp existiert nicht.");
                    return;
                }
                Location loc = new Location(Bukkit.getWorld(rs.getString("world")), rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"), rs.getFloat("yaw"), rs.getFloat("pitch"));
                p.teleport(loc);
                plugin.getMessageUtil().send(p, "&aTeleportiert zu Warp '" + args[0] + "'.");
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Laden des Warps.");
        }
    }

    private void setwarp(Player p, String[] args) {
        if (!p.isOp() && !p.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&cNutzung: /setwarp <name>");
            return;
        }
        Location loc = p.getLocation();
        String sql = "INSERT INTO warps (name,world,x,y,z,yaw,pitch) VALUES (?,?,?,?,?,?,?) " +
                "ON CONFLICT(name) DO UPDATE SET world=excluded.world,x=excluded.x,y=excluded.y,z=excluded.z,yaw=excluded.yaw,pitch=excluded.pitch";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, args[0]);
            ps.setString(2, loc.getWorld().getName());
            ps.setDouble(3, loc.getX());
            ps.setDouble(4, loc.getY());
            ps.setDouble(5, loc.getZ());
            ps.setFloat(6, loc.getYaw());
            ps.setFloat(7, loc.getPitch());
            ps.executeUpdate();
            plugin.getMessageUtil().send(p, "&aWarp '" + args[0] + "' gesetzt.");
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Speichern des Warps.");
        }
    }

    private void mail(CommandSender sender, String[] args) {
        if (args.length == 0) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /mail send <spieler> <nachricht> | /mail read");
            return;
        }
        if (args[0].equalsIgnoreCase("send") && sender instanceof Player p) {
            if (args.length < 3) {
                plugin.getMessageUtil().send(p, "&cNutzung: /mail send <spieler> <nachricht>");
                return;
            }
            var target = Bukkit.getOfflinePlayer(args[1]);
            String message = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
            String sql = "INSERT INTO mail (uuid, sender, message, sent_at, read) VALUES (?,?,?,?,0)";
            try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, target.getUniqueId().toString());
                ps.setString(2, p.getName());
                ps.setString(3, message);
                ps.setLong(4, System.currentTimeMillis());
                ps.executeUpdate();
                plugin.getMessageUtil().send(p, "&aMail gesendet an " + target.getName() + ".");
            } catch (SQLException e) {
                plugin.getMessageUtil().send(p, "&cFehler beim Senden.");
            }
        } else if (args[0].equalsIgnoreCase("read") && sender instanceof Player p) {
            String sql = "SELECT sender, message FROM mail WHERE uuid=? AND read=0";
            try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, p.getUniqueId().toString());
                try (ResultSet rs = ps.executeQuery()) {
                    boolean any = false;
                    while (rs.next()) {
                        any = true;
                        plugin.getMessageUtil().sendRaw(p, "&7Von &b" + rs.getString("sender") + "&7: " + rs.getString("message"));
                    }
                    if (!any) plugin.getMessageUtil().send(p, "&7Keine neuen Mails.");
                }
            } catch (SQLException e) {
                plugin.getMessageUtil().send(p, "&cFehler beim Lesen.");
            }
            try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE mail SET read=1 WHERE uuid=?")) {
                ps.setString(1, p.getUniqueId().toString());
                ps.executeUpdate();
            } catch (SQLException ignored) {
            }
        }
    }

    private void afk(Player p) {
        if (afkPlayers.containsKey(p.getUniqueId())) {
            afkPlayers.remove(p.getUniqueId());
            plugin.getMessageUtil().send(p, "&7Du bist nicht mehr AFK.");
        } else {
            afkPlayers.put(p.getUniqueId(), System.currentTimeMillis());
            plugin.getMessageUtil().send(p, "&7Du bist jetzt AFK.");
        }
    }

    private void msg(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return;
        }
        if (args.length < 2) {
            plugin.getMessageUtil().send(player, "&cNutzung: /msg <spieler> <nachricht>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.getMessageUtil().send(player, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            plugin.getMessageUtil().send(player, "&cDu kannst dir nicht selbst schreiben.");
            return;
        }
        String message = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        sendPrivateMessage(player, target, message);
    }

    private void reply(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return;
        }
        if (args.length < 1) {
            plugin.getMessageUtil().send(player, "&cNutzung: /r <nachricht>");
            return;
        }
        UUID partnerId = lastMessaged.get(player.getUniqueId());
        if (partnerId == null) {
            plugin.getMessageUtil().send(player, "&cEs gibt niemanden zum Antworten.");
            return;
        }
        Player target = Bukkit.getPlayer(partnerId);
        if (target == null || !target.isOnline()) {
            plugin.getMessageUtil().send(player, "&cDer Spieler ist nicht mehr online.");
            return;
        }
        String message = String.join(" ", args);
        sendPrivateMessage(player, target, message);
    }

    private void sendPrivateMessage(Player from, Player to, String message) {
        plugin.getMessageUtil().send(from, "&d[Du -> " + to.getName() + "]&f: " + message);
        plugin.getMessageUtil().send(to, "&d[" + from.getName() + " -> Dich]&f: " + message);
        lastMessaged.put(from.getUniqueId(), to.getUniqueId());
        lastMessaged.put(to.getUniqueId(), from.getUniqueId());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            switch (label.toLowerCase()) {
                case "gm": return TabCompleteUtil.filter(args[0], "survival", "creative", "adventure", "spectator", "0", "1", "2", "3");
                case "speed": return TabCompleteUtil.filter(args[0], "1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
                case "msg": return TabCompleteUtil.onlinePlayers(args[0]);
                case "tpa": return TabCompleteUtil.onlinePlayers(args[0]);
                case "mail": return TabCompleteUtil.filter(args[0], "send", "read");
                case "warp": return TabCompleteUtil.filter(args[0], getWarpNames().toArray(new String[0]));
                case "home": return sender instanceof Player p
                        ? TabCompleteUtil.filter(args[0], getHomeNames(p.getUniqueId()).toArray(new String[0]))
                        : Collections.emptyList();
            }
        }
        if (label.equalsIgnoreCase("mail") && args.length == 2 && args[0].equalsIgnoreCase("send")) {
            return TabCompleteUtil.onlinePlayers(args[1]);
        }
        return Collections.emptyList();
    }

    private List<String> getWarpNames() {
        List<String> names = new java.util.ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT name FROM warps")) {
            while (rs.next()) names.add(rs.getString("name"));
        } catch (SQLException ignored) {
        }
        return names;
    }

    private List<String> getHomeNames(UUID uuid) {
        List<String> names = new java.util.ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT name FROM homes WHERE uuid=?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) names.add(rs.getString("name"));
            }
        } catch (SQLException ignored) {
        }
        return names;
    }
}
