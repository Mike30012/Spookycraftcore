package de.craftsucht.core.rank;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;

import java.util.UUID;

/** Duenne Bruecke zu LuckPerms. Diese Klasse wird nur geladen, wenn LuckPerms auf dem Server liegt. */
final class LuckPermsBridge {

    private LuckPermsBridge() {
    }

    private static LuckPerms lp() {
        return LuckPermsProvider.get();
    }

    /** Primaerer Rang (Gruppe) des Spielers, null wenn nicht geladen. */
    static String primaryGroup(UUID uuid) {
        User u = lp().getUserManager().getUser(uuid);
        return u == null ? null : u.getPrimaryGroup();
    }

    /** Prefix des Spielers (LuckPerms-Meta, '&'-Codes), leer wenn keiner. */
    static String prefix(UUID uuid) {
        User u = lp().getUserManager().getUser(uuid);
        if (u == null) return "";
        String p = u.getCachedData().getMetaData().getPrefix();
        return p == null ? "" : p;
    }

    /** {prefix, weight} der Gruppe, null wenn es sie nicht gibt. */
    static Object[] group(String name) {
        Group g = lp().getGroupManager().getGroup(name.toLowerCase());
        if (g == null) return null;
        String p = g.getCachedData().getMetaData().getPrefix();
        return new Object[]{g.getName(), p == null ? "" : p, g.getWeight().orElse(0)};
    }
}
