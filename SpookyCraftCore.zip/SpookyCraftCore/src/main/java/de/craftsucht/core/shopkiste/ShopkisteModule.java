package de.craftsucht.core.shopkiste;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.HandlerList;

/**
 * Shopkisten (ChestShop) nach OPSUCHT-Vorbild - komplett im Plugin, ohne Fremd-Plugin.
 * Kiste + Schild; Rechtsklick kaufen, Linksklick verkaufen, Sneak+Rechtsklick eigene Anzahl.
 */
public class ShopkisteModule implements Module {

    private final SpookyCraftCore plugin;
    private ShopListener listener;

    public ShopkisteModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "shopkiste";
    }

    @Override
    public void enable() {
        ShopRepository repo = new ShopRepository(plugin);
        repo.init();
        ShopService service = new ShopService(plugin, repo);
        this.listener = new ShopListener(plugin, repo, service);
        Bukkit.getPluginManager().registerEvents(listener, plugin);

        ShopCommands commands = new ShopCommands(plugin, repo, service);
        for (String name : new String[]{"shopinfo", "shoptransactions", "cstoggle", "iteminfo", "shopcreate"}) {
            PluginCommand command = plugin.getCommand(name);
            if (command != null) {
                command.setExecutor(commands);
                command.setTabCompleter(commands);
            }
        }
    }

    @Override
    public void disable() {
        if (listener != null) HandlerList.unregisterAll(listener);
    }
}
