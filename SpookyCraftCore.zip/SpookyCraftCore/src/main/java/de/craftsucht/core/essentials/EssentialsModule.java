package de.craftsucht.core.essentials;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EssentialsModule implements Module {

    private final SpookyCraftCore plugin;
    private final Map<UUID, UUID> pendingTpaRequests = new HashMap<>(); // target -> requester
    private final Map<UUID, Long> afkPlayers = new HashMap<>();
    private final Map<UUID, UUID> lastMessaged = new HashMap<>(); // wer hat wem zuletzt geschrieben -> für /r
    private AfkListener afkListener;

    public EssentialsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "essentials";
    }

    @Override
    public void enable() {
        EssentialsCommand command = new EssentialsCommand(plugin, pendingTpaRequests, afkPlayers, lastMessaged);
        for (String cmd : new String[]{"heal", "feed", "fly", "speed", "gm", "tpa", "tpahere", "tpcancel", "tpaccept", "tpdeny",
                "home", "sethome", "warp", "setwarp", "mail", "afk", "msg", "r"}) {
            plugin.getCommand(cmd).setExecutor(command);
            plugin.getCommand(cmd).setTabCompleter(command);
        }
        this.afkListener = new AfkListener(afkPlayers, plugin);
        Bukkit.getPluginManager().registerEvents(afkListener, plugin);
    }

    @Override
    public void disable() {
        if (afkListener != null) {
            HandlerList.unregisterAll(afkListener);
        }
    }
}
