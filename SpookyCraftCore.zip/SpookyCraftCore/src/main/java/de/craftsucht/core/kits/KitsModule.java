package de.craftsucht.core.kits;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

/** Simple time-based kits. Kit contents are hardcoded here for now; move to config.yml if you want them editable. */
public class KitsModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter {

    private final SpookyCraftCore plugin;
    private final Map<String, ItemStack[]> kits = new LinkedHashMap<>();
    private final Map<String, Long> cooldownsMillis = new LinkedHashMap<>();

    public KitsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "kits";
    }

    @Override
    public void enable() {
        kits.put("starter", new ItemStack[]{new ItemStack(Material.BREAD, 16), new ItemStack(Material.STONE_SWORD)});
        kits.put("daily", new ItemStack[]{new ItemStack(Material.GOLDEN_APPLE, 2)});
        cooldownsMillis.put("starter", 0L);
        cooldownsMillis.put("daily", 86_400_000L);
        plugin.getCommand("kit").setExecutor(this);
        plugin.getCommand("kit").setTabCompleter(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            return new java.util.ArrayList<>(kits.keySet()).stream()
                    .filter(k -> k.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&7Verfügbare Kits: &b" + String.join(", ", kits.keySet()));
            return true;
        }
        String kitName = args[0].toLowerCase();
        ItemStack[] items = kits.get(kitName);
        if (items == null) {
            plugin.getMessageUtil().send(p, "&cUnbekanntes Kit.");
            return true;
        }
        long cooldown = cooldownsMillis.getOrDefault(kitName, 0L);
        if (cooldown > 0) {
            Long lastUsed = getLastUsed(p.getUniqueId().toString(), kitName);
            if (lastUsed != null && System.currentTimeMillis() - lastUsed < cooldown) {
                long remaining = (cooldown - (System.currentTimeMillis() - lastUsed)) / 60000;
                plugin.getMessageUtil().send(p, "&cNoch " + remaining + " Minuten Cooldown.");
                return true;
            }
        }
        for (ItemStack item : items) p.getInventory().addItem(item.clone());
        setLastUsed(p.getUniqueId().toString(), kitName);
        plugin.getMessageUtil().send(p, "&aKit '" + kitName + "' erhalten.");
        return true;
    }

    private Long getLastUsed(String uuid, String kit) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT last_used FROM kit_cooldowns WHERE uuid=? AND kit_name=?")) {
            ps.setString(1, uuid);
            ps.setString(2, kit);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getLong("last_used");
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    private void setLastUsed(String uuid, String kit) {
        String sql = "INSERT INTO kit_cooldowns (uuid, kit_name, last_used) VALUES (?,?,?) " +
                "ON CONFLICT(uuid, kit_name) DO UPDATE SET last_used=excluded.last_used";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, kit);
            ps.setLong(3, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }
}
