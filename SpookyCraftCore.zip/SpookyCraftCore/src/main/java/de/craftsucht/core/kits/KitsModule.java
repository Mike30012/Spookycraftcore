package de.craftsucht.core.kits;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Kits mit Cooldown. Die Kits liegen in plugins/SpookyCraftCore/kits.yml und lassen sich ingame verwalten:
 * /kit create <name> [wartezeit]  - nimmt den Inhalt deines Inventars (+ Rüstung) als Kit
 * /kit delete <name>              - löscht ein Kit (auch /delkit, /deletekit)
 * /kit setperm <name> <recht|none>- optionales Recht pro Kit
 * /kit list, /kit <name>          - Kits ansehen und abholen
 * Wartezeit: 0, 30m, 12h, 1d, 7d ...
 */
public class KitsModule implements Module, CommandExecutor, TabCompleter {

    private static final String[] COMMANDS = {"kit", "kitcreate", "delkit", "deletekit"};

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration config;

    public KitsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "kits";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "kits.yml");
        boolean fresh = !file.exists();
        config = YamlConfiguration.loadConfiguration(file);
        if (fresh) {
            // Die beiden bisherigen Standard-Kits
            store("starter", 0L, null, List.of(new ItemStack(Material.BREAD, 16), new ItemStack(Material.STONE_SWORD)));
            store("daily", 86_400L, null, List.of(new ItemStack(Material.GOLDEN_APPLE, 2)));
            save();
        }
        for (String name : COMMANDS) {
            if (plugin.getCommand(name) != null) {
                plugin.getCommand(name).setExecutor(this);
                plugin.getCommand(name).setTabCompleter(this);
            }
        }
    }

    @Override
    public void disable() {
    }

    // ------------------------------------------------------------------ Speicher

    private void store(String name, long cooldownSeconds, String permission, List<ItemStack> items) {
        String base = "kits." + name;
        config.set(base + ".cooldown-seconds", cooldownSeconds);
        config.set(base + ".permission", permission == null ? "" : permission);
        config.set(base + ".items", items);
    }

    private void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("kits.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private ConfigurationSection kits() {
        return config.getConfigurationSection("kits");
    }

    private List<String> kitNames() {
        ConfigurationSection section = kits();
        return section == null ? new ArrayList<>() : new ArrayList<>(section.getKeys(false));
    }

    private List<ItemStack> itemsOf(String name) {
        List<ItemStack> result = new ArrayList<>();
        List<?> raw = config.getList("kits." + name + ".items");
        if (raw != null) {
            for (Object o : raw) if (o instanceof ItemStack stack) result.add(stack);
        }
        return result;
    }

    // ------------------------------------------------------------------ Hilfen

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    private boolean isManager(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin") || s.hasPermission("essentials.createkit");
    }

    private boolean mayUse(CommandSender s, String kit) {
        String perm = config.getString("kits." + kit + ".permission", "");
        return perm.isEmpty() || isManager(s) || s.hasPermission(perm);
    }

    /** "0", "30m", "12h", "1d", "1w", "90s" -> Sekunden; -1 bei Fehler. */
    private long parseDelay(String text) {
        text = text.toLowerCase(Locale.ROOT).trim();
        if (text.equals("0") || text.equals("none") || text.equals("-")) return 0;
        try {
            char unit = text.charAt(text.length() - 1);
            if (Character.isDigit(unit)) return Long.parseLong(text);
            long value = Long.parseLong(text.substring(0, text.length() - 1));
            return switch (unit) {
                case 's' -> value;
                case 'm' -> value * 60;
                case 'h' -> value * 3600;
                case 'd' -> value * 86400;
                case 'w' -> value * 604800;
                default -> -1;
            };
        } catch (NumberFormatException | StringIndexOutOfBoundsException e) {
            return -1;
        }
    }

    private String formatSeconds(long seconds) {
        if (seconds <= 0) return "keine";
        long d = seconds / 86400, h = (seconds % 86400) / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append(" Tg. ");
        if (h > 0) sb.append(h).append(" Std. ");
        if (m > 0) sb.append(m).append(" Min. ");
        if (s > 0 && d == 0 && h == 0) sb.append(s).append(" Sek.");
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase();
        switch (cmd) {
            case "kitcreate" -> create(sender, args);
            case "delkit", "deletekit" -> delete(sender, args);
            default -> {
                if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
                    list(sender);
                    return true;
                }
                switch (args[0].toLowerCase()) {
                    case "create" -> create(sender, Arrays.copyOfRange(args, 1, args.length));
                    case "delete", "remove" -> delete(sender, Arrays.copyOfRange(args, 1, args.length));
                    case "setperm" -> setPerm(sender, Arrays.copyOfRange(args, 1, args.length));
                    default -> claim(sender, args[0].toLowerCase());
                }
            }
        }
        return true;
    }

    private void list(CommandSender sender) {
        List<String> names = new ArrayList<>();
        for (String name : kitNames()) if (mayUse(sender, name)) names.add(name);
        msg(sender, names.isEmpty() ? "&7Es gibt keine Kits für dich." : "&7Verfügbare Kits: &b" + String.join("&7, &b", names));
        if (isManager(sender)) msg(sender, "&5☠ &8Zauberformeln: &7/kit create <name> [wartezeit] &8| &7/kit delete <name> &8| &7/kit setperm <name> <recht|none>");
    }

    private void create(CommandSender sender, String[] args) {
        if (!isManager(sender)) {
            msg(sender, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (!(sender instanceof Player p)) {
            msg(sender, "&cDas geht nur ingame, denn das Kit wird aus deinem Inventar erstellt.");
            return;
        }
        if (args.length < 1) {
            msg(p, "&cNutzung: /kit create <name> [wartezeit z.B. 0, 30m, 12h, 1d]");
            return;
        }
        String name = args[0].toLowerCase();
        if (!name.matches("[a-z0-9_\\-]{1,32}")) {
            msg(p, "&cDer Name darf nur Buchstaben, Zahlen, _ und - enthalten (max. 32 Zeichen).");
            return;
        }
        long delay = 0;
        if (args.length > 1) {
            delay = parseDelay(args[1]);
            if (delay < 0) {
                msg(p, "&cUngültige Wartezeit. Beispiele: 0, 30m, 12h, 1d, 7d");
                return;
            }
        }
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack stack : p.getInventory().getStorageContents()) if (stack != null && !stack.getType().isAir()) items.add(stack.clone());
        for (ItemStack stack : p.getInventory().getArmorContents()) if (stack != null && !stack.getType().isAir()) items.add(stack.clone());
        ItemStack off = p.getInventory().getItemInOffHand();
        if (!off.getType().isAir()) items.add(off.clone());
        if (items.isEmpty()) {
            msg(p, "&cDein Inventar ist leer. Lege die Items für das Kit in dein Inventar.");
            return;
        }
        boolean existed = config.contains("kits." + name);
        String oldPerm = existed ? config.getString("kits." + name + ".permission", "") : "";
        store(name, delay, oldPerm.isEmpty() ? null : oldPerm, items);
        save();
        msg(p, "&aKit '&e" + name + "&a' " + (existed ? "überschrieben" : "erstellt") + " (&e" + items.size() + " &aStacks, Wartezeit: &e" + formatSeconds(delay) + "&a).");
    }

    private void delete(CommandSender sender, String[] args) {
        if (!isManager(sender)) {
            msg(sender, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (args.length < 1) {
            msg(sender, "&cNutzung: /kit delete <name>");
            return;
        }
        String name = args[0].toLowerCase();
        if (!config.contains("kits." + name)) {
            msg(sender, "&cUnbekanntes Kit.");
            return;
        }
        config.set("kits." + name, null);
        save();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM kit_cooldowns WHERE kit_name=?")) {
            ps.setString(1, name);
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
        msg(sender, "&aKit '&e" + name + "&a' gelöscht.");
    }

    private void setPerm(CommandSender sender, String[] args) {
        if (!isManager(sender)) {
            msg(sender, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (args.length < 2) {
            msg(sender, "&cNutzung: /kit setperm <name> <recht|none>");
            return;
        }
        String name = args[0].toLowerCase();
        if (!config.contains("kits." + name)) {
            msg(sender, "&cUnbekanntes Kit.");
            return;
        }
        String perm = args[1].equalsIgnoreCase("none") ? "" : args[1];
        config.set("kits." + name + ".permission", perm);
        save();
        msg(sender, perm.isEmpty() ? "&aKit '&e" + name + "&a' ist jetzt für alle." : "&aKit '&e" + name + "&a' braucht jetzt das Recht &e" + perm + "&a.");
    }

    private void claim(CommandSender sender, String name) {
        if (!(sender instanceof Player p)) {
            msg(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return;
        }
        if (!config.contains("kits." + name) || !mayUse(p, name)) {
            msg(p, "&cUnbekanntes Kit.");
            return;
        }
        long cooldownMillis = config.getLong("kits." + name + ".cooldown-seconds", 0L) * 1000L;
        if (cooldownMillis > 0 && !isManager(p)) {
            Long lastUsed = getLastUsed(p.getUniqueId().toString(), name);
            if (lastUsed != null && System.currentTimeMillis() - lastUsed < cooldownMillis) {
                long remaining = (cooldownMillis - (System.currentTimeMillis() - lastUsed)) / 1000L;
                msg(p, "&cDu kannst dieses Kit erst in &e" + formatSeconds(remaining) + " &cwieder abholen.");
                return;
            }
        }
        for (ItemStack item : itemsOf(name)) {
            for (ItemStack left : p.getInventory().addItem(item.clone()).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), left);
            }
        }
        if (cooldownMillis > 0) setLastUsed(p.getUniqueId().toString(), name);
        msg(p, "&aKit '" + name + "' erhalten.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmd = command.getName().toLowerCase();
        if (cmd.equals("delkit") || cmd.equals("deletekit")) {
            return args.length == 1 ? filter(kitNames(), args[0]) : Collections.emptyList();
        }
        if (cmd.equals("kitcreate")) {
            return args.length == 2 ? filter(List.of("0", "30m", "12h", "1d", "7d"), args[1]) : Collections.emptyList();
        }
        if (args.length == 1) {
            List<String> options = new ArrayList<>();
            for (String name : kitNames()) if (mayUse(sender, name)) options.add(name);
            options.add("list");
            if (isManager(sender)) options.addAll(List.of("create", "delete", "setperm"));
            return filter(options, args[0]);
        }
        String sub = args[0].toLowerCase();
        if (args.length == 2 && (sub.equals("delete") || sub.equals("remove") || sub.equals("setperm"))) return filter(kitNames(), args[1]);
        if (args.length == 3 && sub.equals("create")) return filter(List.of("0", "30m", "12h", "1d", "7d"), args[2]);
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        List<String> result = new ArrayList<>();
        for (String o : options) if (o.toLowerCase().startsWith(input.toLowerCase())) result.add(o);
        return result;
    }

    // ------------------------------------------------------------------ Cooldowns (Datenbank)

    private Long getLastUsed(String uuid, String kit) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT last_used FROM kit_cooldowns WHERE uuid=? AND kit_name=?")) {
            ps.setString(1, uuid);
            ps.setString(2, kit);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getLong("last_used");
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    private void setLastUsed(String uuid, String kit) {
        String sql = "INSERT INTO kit_cooldowns (uuid, kit_name, last_used) VALUES (?,?,?) " +
                "ON CONFLICT(uuid, kit_name) DO UPDATE SET last_used=excluded.last_used";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, kit);
            ps.setLong(3, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }
}
