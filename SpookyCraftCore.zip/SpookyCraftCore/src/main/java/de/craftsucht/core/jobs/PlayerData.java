package de.craftsucht.core.jobs;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Alle Jobs eines Spielers. Spieler sind automatisch in jedem konfigurierten
 * Job; currentJob ist nur der aktuell angezeigte Job für GUI/Scoreboard.
 */
public class PlayerData {
    private final UUID uuid;
    private final Map<String, JobData> jobs = new LinkedHashMap<>();
    private String currentJob;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() { return uuid; }

    public String getCurrentJob() { return currentJob; }

    /** Nur Auswahl für Anzeige, kein Join/Leave mehr. */
    public void setCurrentJob(String job) {
        this.currentJob = job;
    }

    public void ensureJob(String jobId) {
        if (jobId == null) return;
        jobs.computeIfAbsent(jobId.toLowerCase(), JobData::new);
        if (currentJob == null) currentJob = jobId.toLowerCase();
    }

    public JobData getJob(String jobId) {
        if (jobId == null) return null;
        return jobs.get(jobId.toLowerCase());
    }

    public JobData getOrCreateJob(String jobId) {
        ensureJob(jobId);
        return jobs.get(jobId.toLowerCase());
    }

    public Collection<JobData> getJobs() { return jobs.values(); }
    public Map<String, JobData> getJobMap() { return jobs; }

    public boolean hasJob() {
        return currentJob != null && jobs.containsKey(currentJob);
    }

    public int getJobLevel() { return getCurrentJobData().getLevel(); }
    public void setJobLevel(int level) { getCurrentJobData().setLevel(level); }
    public int getJobXp() { return getCurrentJobData().getXp(); }
    public void setJobXp(int xp) { getCurrentJobData().setXp(xp); }
    public long getTotalEarned() {
        long total = 0;
        for (JobData data : jobs.values()) total += data.getTotalEarned();
        return total;
    }
    public int getXpForNextLevel() { return getCurrentJobData().getXpForNextLevel(); }
    public double getLevelMultiplier() { return getCurrentJobData().getLevelMultiplier(); }

    private JobData getCurrentJobData() {
        if (currentJob == null) {
            throw new IllegalStateException("Kein aktueller Job gesetzt");
        }
        return getOrCreateJob(currentJob);
    }
}
