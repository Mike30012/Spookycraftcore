package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

/** LuckPerms-style internal rank/permission system: groups, inheritance, prefixes, per-rank permissions. */
public class RankModule implements Module {

    private final SpookyCraftCore plugin;
    private RankManager manager;
    private RankListener listener;

    public RankModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "rank";
    }

    @Override
    public void enable() {
        this.manager = new RankManager(plugin);
        manager.ensureDefaultRank();
        // Team-Raenge Dev / Builder / Content anlegen, falls sie noch fehlen (bestehende bleiben unveraendert)
        if (manager.getRank("dev") == null) manager.createRank("dev", "&b&lDev", 85, null);
        if (manager.getRank("builder") == null) manager.createRank("builder", "&a&lBuilder", 55, null);
        if (manager.getRank("content") == null) manager.createRank("content", "&d&lContent", 35, null);
        manager.migrateLegacyPermissions();

        RankCommand command = new RankCommand(plugin, manager);
        plugin.getCommand("rank").setExecutor(command);
        plugin.getCommand("rank").setTabCompleter(command);

        this.listener = new RankListener(plugin, manager);
        Bukkit.getPluginManager().registerEvents(listener, plugin);

        for (var p : Bukkit.getOnlinePlayers()) {
            manager.apply(p);
        }
    }

    @Override
    public void disable() {
        if (listener != null) HandlerList.unregisterAll(listener);
        if (manager != null) {
            for (var p : Bukkit.getOnlinePlayers()) manager.remove(p);
        }
        manager = null;
    }

    public RankManager getManager() {
        return manager;
    }
}
