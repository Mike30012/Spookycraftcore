package de.craftsucht.core.perf;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Item;

import java.util.List;
import java.util.Locale;

/**
 * /perf - kleine eingebaute Leistungsanzeige: TPS, Tick-Zeit (MSPT), RAM, Entities/Chunks pro Welt und
 * die Zeit, die Area-Spitzhacken pro Schlag brauchen. Hilft herauszufinden, ob/was den Server bremst.
 */
public class PerfModule implements Module, CommandExecutor, TabCompleter {

    // --- Messwerte der Area-Spitzhacken (werden von AreaMiningListener gefüllt)
    private static long areaCount;
    private static long areaTotalNanos;
    private static long areaMaxNanos;
    private static long areaLastNanos;
    private static int areaLastBlocks;

    public static synchronized void recordAreaBreak(long nanos, int blocks) {
        areaCount++;
        areaTotalNanos += nanos;
        areaLastNanos = nanos;
        areaLastBlocks = blocks;
        if (nanos > areaMaxNanos) areaMaxNanos = nanos;
    }

    private static synchronized void resetArea() {
        areaCount = 0;
        areaTotalNanos = 0;
        areaMaxNanos = 0;
        areaLastNanos = 0;
        areaLastBlocks = 0;
    }

    private final SpookyCraftCore plugin;

    public PerfModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "perf";
    }

    @Override
    public void enable() {
        var cmd = plugin.getCommand("perf");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    @Override
    public void disable() {
    }

    private static String color(double tps) {
        return tps >= 19.0 ? "§a" : tps >= 15.0 ? "§e" : "§c";
    }

    private static String ms(long nanos) {
        return String.format(Locale.GERMANY, "%.1f ms", nanos / 1_000_000.0);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.core.admin")) {
            sender.sendMessage("§cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reset")) {
            resetArea();
            sender.sendMessage("§a☠ Die Messwerte wurden in den Nebel gelöst.");
            return true;
        }

        double[] tps = Bukkit.getTPS();
        sender.sendMessage("§8--- §6☠ Pulsschlag der Geisterwelt §8---");
        sender.sendMessage("§7TPS (1m/5m/15m): " + color(tps[0]) + String.format(Locale.GERMANY, "%.1f", Math.min(20.0, tps[0]))
                + "§7 / " + color(tps[1]) + String.format(Locale.GERMANY, "%.1f", Math.min(20.0, tps[1]))
                + "§7 / " + color(tps[2]) + String.format(Locale.GERMANY, "%.1f", Math.min(20.0, tps[2])));
        double mspt = Bukkit.getAverageTickTime();
        sender.sendMessage("§7Tick-Zeit (MSPT): " + (mspt < 40 ? "§a" : mspt < 50 ? "§e" : "§c")
                + String.format(Locale.GERMANY, "%.1f ms", mspt) + " §8(unter 50 ms ist gut)");

        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long max = rt.maxMemory() / (1024 * 1024);
        sender.sendMessage("§7RAM: §f" + used + " MB §7von §f" + max + " MB §7| Spieler: §f" + Bukkit.getOnlinePlayers().size());

        for (World w : Bukkit.getWorlds()) {
            int items = w.getEntitiesByClass(Item.class).size();
            sender.sendMessage("§8» §7" + w.getName() + ": §f" + w.getEntityCount() + " §7Entities (§f" + items
                    + " §7Items), §f" + w.getChunkCount() + " §7Chunks");
        }

        synchronized (PerfModule.class) {
            if (areaCount == 0) {
                sender.sendMessage("§7Bohrer: §8noch keine Messung (einmal abbauen, dann /perf)");
            } else {
                sender.sendMessage("§7Bohrer: letzter Schlag §f" + ms(areaLastNanos) + " §7(" + areaLastBlocks
                        + " Blöcke), Ø §f" + ms(areaTotalNanos / areaCount) + "§7, max §f" + ms(areaMaxNanos)
                        + " §7bei §f" + areaCount + " §7Schlägen");
            }
        }
        sender.sendMessage("§8/perf reset §7setzt die Area-Messung zurück.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return TabCompleteUtil.filter(args[0], "reset");
        return List.of();
    }
}
