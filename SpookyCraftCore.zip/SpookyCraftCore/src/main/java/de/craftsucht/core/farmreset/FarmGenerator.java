package de.craftsucht.core.farmreset;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.util.noise.SimplexOctaveGenerator;

import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.BlockPopulator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Eigene Gelaende-Form fuer die Farmwelt. Hier wird nur die Grundform (Stein + Wasser) erzeugt;
 * Oberflaeche, Hoehlen, Erze, Baeume, Biome, Dungeons und Mobs macht weiter Minecraft selbst.
 * Stile: "inseln" (Inseln im Ozean) und "gebirge" (hohe Berge mit Taelern).
 */
public class FarmGenerator extends ChunkGenerator {

    public static final String INSELN = "inseln";
    public static final String GEBIRGE = "gebirge";
    private static final int SEA = 62;

    private final String style;
    private SimplexOctaveGenerator base;
    private SimplexOctaveGenerator detail;
    private long seed = Long.MIN_VALUE;

    public FarmGenerator(String style) {
        this.style = style == null ? INSELN : style.toLowerCase(Locale.ROOT);
    }

    /** true, wenn der Stil ein eigener Generator ist (alles ausser "default"/leer). */
    public static boolean isCustom(String style) {
        if (style == null) return false;
        String s = style.toLowerCase(Locale.ROOT).trim();
        return s.equals(INSELN) || s.equals(GEBIRGE);
    }

    public String getStyle() {
        return style;
    }

    synchronized void init(long worldSeed) {
        if (base != null && seed == worldSeed) return;
        seed = worldSeed;
        base = new SimplexOctaveGenerator(worldSeed, 4);
        base.setScale(style.equals(GEBIRGE) ? 1.0 / 260.0 : 1.0 / 420.0);
        detail = new SimplexOctaveGenerator(worldSeed + 7919L, 3);
        detail.setScale(1.0 / 38.0);
    }

    int height(int wx, int wz) {
        double m = base.noise(wx, wz, 0.5, 0.5, true);      // ca. -1 .. 1
        double d = detail.noise(wx, wz, 0.5, 0.5, true);
        if (style.equals(GEBIRGE)) {
            double ridge = 1.0 - Math.abs(m);                // Kaemme dort, wo der Wert 0 ist
            return 66 + (int) (ridge * ridge * 95) + (int) (d * 6);
        }
        // Inseln: m > 0 = Land, sonst Ozean
        if (m > 0.0) return 62 + (int) (Math.pow(m, 0.75) * 60) + (int) (d * 5);
        return 36 + (int) ((m + 1.0) * 24.0);                // Meeresboden
    }

    @Override
    public void generateNoise(WorldInfo info, Random random, int chunkX, int chunkZ, ChunkData data) {
        init(info.getSeed());
        int minY = info.getMinHeight();
        int maxY = info.getMaxHeight();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int h = height(chunkX * 16 + x, chunkZ * 16 + z);
                h = Math.max(minY + 6, Math.min(maxY - 3, h));
                data.setRegion(x, minY, z, x + 1, h + 1, z + 1, Material.STONE);
                for (int y = h + 1; y <= SEA; y++) data.setBlock(x, y, z, Material.WATER);
            }
        }
    }

    // ---- Biome: echte Vanilla-Biome, aber nach eigenem Gelaende verteilt ----
    private SimplexOctaveGenerator temp;
    private SimplexOctaveGenerator wet;
    private long biomeSeed = Long.MIN_VALUE;

    private synchronized void initBiomes(long worldSeed) {
        if (temp != null && biomeSeed == worldSeed) return;
        biomeSeed = worldSeed;
        temp = new SimplexOctaveGenerator(worldSeed + 101L, 3);
        temp.setScale(1.0 / 300.0);
        wet = new SimplexOctaveGenerator(worldSeed + 202L, 3);
        wet.setScale(1.0 / 260.0);
    }

    Biome biomeAt(long worldSeed, int wx, int y, int wz) {
        init(worldSeed);
        initBiomes(worldSeed);
        int h = height(wx, wz);
        // Tiefe Hoehlen-Biome (nur unter der Oberflaeche, selten)
        if (y < 40 && y < h - 12) {
            double c = detail.noise(wx * 0.5, wz * 0.5, 0.5, 0.5, true);
            if (y > 0 && c > 0.55) return Biome.LUSH_CAVES;
            if (y > 0 && c < -0.55) return Biome.DRIPSTONE_CAVES;
        }
        double t = temp.noise(wx, wz, 0.5, 0.5, true);   // kalt .. warm
        double w = wet.noise(wx, wz, 0.5, 0.5, true);    // trocken .. nass
        if (h < SEA - 6) return t < -0.45 ? Biome.FROZEN_OCEAN : (t > 0.45 ? Biome.WARM_OCEAN : (h < 44 ? Biome.DEEP_OCEAN : Biome.OCEAN));
        if (h <= SEA - 1) return t < -0.45 ? Biome.FROZEN_OCEAN : (t > 0.45 ? Biome.WARM_OCEAN : Biome.OCEAN);
        if (h <= SEA + 2) return t < -0.4 ? Biome.SNOWY_BEACH : Biome.BEACH;
        if (h > 135) return t < 0 ? Biome.FROZEN_PEAKS : Biome.STONY_PEAKS;
        if (h > 118) return t < 0 ? Biome.SNOWY_SLOPES : Biome.JAGGED_PEAKS;
        if (h > 100) return t < -0.2 ? Biome.GROVE : Biome.WINDSWEPT_HILLS;
        if (t < -0.35) return w > 0 ? Biome.SNOWY_TAIGA : Biome.SNOWY_PLAINS;
        if (t < -0.05) return w > 0.15 ? Biome.TAIGA : (w > -0.2 ? Biome.FOREST : Biome.MEADOW);
        if (t < 0.3) {
            if (w > 0.45) return Biome.DARK_FOREST;
            if (w > 0.15) return Biome.BIRCH_FOREST;
            if (w > -0.2) return Biome.PLAINS;
            return Biome.CHERRY_GROVE;
        }
        if (w > 0.4) return Biome.JUNGLE;
        if (w > 0.0) return Biome.SWAMP;
        if (w > -0.3) return Biome.SAVANNA;
        return Biome.DESERT;
    }

    @Override
    public BiomeProvider getDefaultBiomeProvider(WorldInfo info) {
        final FarmGenerator self = this;
        return new BiomeProvider() {
            @Override
            public Biome getBiome(WorldInfo wi, int x, int y, int z) {
                return self.biomeAt(wi.getSeed(), x, y, z);
            }

            @Override
            public List<Biome> getBiomes(WorldInfo wi) {
                return List.of(Biome.OCEAN, Biome.DEEP_OCEAN, Biome.WARM_OCEAN, Biome.FROZEN_OCEAN, Biome.BEACH,
                        Biome.SNOWY_BEACH, Biome.FROZEN_PEAKS, Biome.STONY_PEAKS, Biome.SNOWY_SLOPES, Biome.JAGGED_PEAKS,
                        Biome.GROVE, Biome.WINDSWEPT_HILLS, Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS, Biome.TAIGA,
                        Biome.FOREST, Biome.MEADOW, Biome.DARK_FOREST, Biome.BIRCH_FOREST, Biome.PLAINS,
                        Biome.CHERRY_GROVE, Biome.JUNGLE, Biome.SWAMP, Biome.SAVANNA, Biome.DESERT,
                        Biome.LUSH_CAVES, Biome.DRIPSTONE_CAVES);
            }
        };
    }

    @Override
    public List<BlockPopulator> getDefaultPopulators(World world) {
        return List.of(new DungeonPopulator(this));
    }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        init(world.getSeed());
        for (int r = 0; r <= 4000; r += 24) {
            for (int a = 0; a < 8; a++) {
                int wx = (int) Math.round(Math.cos(a * Math.PI / 4) * r);
                int wz = (int) Math.round(Math.sin(a * Math.PI / 4) * r);
                int h = height(wx, wz);
                if (h >= SEA + 3 && h < 120) return new Location(world, wx + 0.5, h + 3, wz + 0.5);
            }
        }
        return null;
    }

    @Override
    public boolean shouldGenerateSurface() {
        return true;
    }

    @Override
    public boolean shouldGenerateBedrock() {
        return true;
    }

    @Override
    public boolean shouldGenerateCaves() {
        return true;
    }

    @Override
    public boolean shouldGenerateDecorations() {
        return true;
    }

    @Override
    public boolean shouldGenerateMobs() {
        return true;
    }

    @Override
    public boolean shouldGenerateStructures() {
        return true;
    }
}
