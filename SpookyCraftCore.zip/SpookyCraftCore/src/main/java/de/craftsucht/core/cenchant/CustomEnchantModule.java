package de.craftsucht.core.cenchant;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.Compat;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Geister-Verzauberungen: eigene Enchants als Buecher (/ce = Shop). Buch in der Inventar-Ansicht auf ein Item ziehen (Klick),
 * dann wird es verzaubert. Preise: config cenchants.prices.<id> = [Stufe1, Stufe2, ...].
 */
public class CustomEnchantModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V"};

    private record Def(String id, String name, int max, String target, String desc) {
    }

    private final List<Def> defs = List.of(
            new Def("seelenfaenger", "Seelenfänger", 3, "weapon", "Mobs droppen beim Töten extra Geld"),
            new Def("geisterklinge", "Geisterklinge", 3, "weapon", "Chance, Gegner mit Wither zu verfluchen"),
            new Def("blutdurst", "Blutdurst", 3, "weapon", "Chance, beim Treffen Leben zu stehlen"),
            new Def("eilgeist", "Eilgeist", 2, "tool", "Eile, solange du das Werkzeug hältst"),
            new Def("federschritt", "Federschritt", 1, "boots", "Kein Fallschaden"),
            new Def("katzenauge", "Katzenauge", 1, "helmet", "Nachtsicht, solange du den Helm trägst")
    );

    private final SpookyCraftCore plugin;
    private NamespacedKey enchKey;
    private NamespacedKey bookKey;
    private BukkitTask task;

    public CustomEnchantModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "cenchant";
    }

    @Override
    public void enable() {
        enchKey = new NamespacedKey(plugin, "ce");
        bookKey = new NamespacedKey(plugin, "cebook");
        plugin.getCommand("cenchant").setExecutor(this);
        plugin.getCommand("cenchant").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 40L);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        if (task != null) task.cancel();
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private Def def(String id) {
        for (Def d : defs) if (d.id().equalsIgnoreCase(id)) return d;
        return null;
    }

    // ------------------------------------------------------------------ Item-Daten

    private boolean applies(Def d, Material m) {
        String n = m.name();
        return switch (d.target()) {
            case "weapon" -> n.endsWith("_SWORD") || n.endsWith("_AXE");
            case "tool" -> n.endsWith("_PICKAXE") || n.endsWith("_AXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE");
            case "boots" -> n.endsWith("_BOOTS");
            case "helmet" -> n.endsWith("_HELMET");
            default -> false;
        };
    }

    private String targetText(Def d) {
        return switch (d.target()) {
            case "weapon" -> "Schwerter und Äxte";
            case "tool" -> "Spitzhacken, Äxte, Schaufeln, Hacken";
            case "boots" -> "Stiefel";
            case "helmet" -> "Helme";
            default -> "?";
        };
    }

    /** Liest die Enchants eines Items: id -> Stufe. */
    private Map<String, Integer> read(ItemStack it) {
        Map<String, Integer> out = new LinkedHashMap<>();
        if (it == null || !it.hasItemMeta()) return out;
        String raw = it.getItemMeta().getPersistentDataContainer().get(enchKey, PersistentDataType.STRING);
        if (raw == null || raw.isBlank()) return out;
        for (String part : raw.split(",")) {
            String[] kv = part.split(":");
            if (kv.length != 2) continue;
            try {
                out.put(kv[0], Integer.parseInt(kv[1]));
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    private int level(ItemStack it, String id) {
        return read(it).getOrDefault(id, 0);
    }

    private void write(ItemStack it, Map<String, Integer> ench) {
        ItemMeta meta = it.getItemMeta();
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : ench.entrySet()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append(':').append(e.getValue());
        }
        meta.getPersistentDataContainer().set(enchKey, PersistentDataType.STRING, sb.toString());
        List<String> lore = new ArrayList<>();
        if (meta.getLore() != null) for (String l : meta.getLore()) if (!l.startsWith("§d☠ ")) lore.add(l);
        List<String> mine = new ArrayList<>();
        for (Map.Entry<String, Integer> e : ench.entrySet()) {
            Def d = def(e.getKey());
            if (d != null) mine.add("§d☠ " + d.name() + " " + ROMAN[Math.min(5, e.getValue())]);
        }
        mine.addAll(lore);
        meta.setLore(mine);
        it.setItemMeta(meta);
    }

    private ItemStack book(Def d, int lvl) {
        ItemStack it = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(c("&5☠ &dGeister-Buch: " + d.name() + " " + ROMAN[lvl]));
        meta.setLore(List.of(c("&7" + d.desc()), c("&8Passt auf: " + targetText(d)), "",
                c("&eZiehe das Buch im Inventar auf das Item,"), c("&eum es zu verzaubern.")));
        meta.getPersistentDataContainer().set(bookKey, PersistentDataType.STRING, d.id() + ":" + lvl);
        it.setItemMeta(meta);
        return it;
    }

    private String[] bookOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String raw = it.getItemMeta().getPersistentDataContainer().get(bookKey, PersistentDataType.STRING);
        return raw == null ? null : raw.split(":");
    }

    private int price(Def d, int lvl) {
        List<Integer> list = plugin.getConfig().getIntegerList("cenchants.prices." + d.id());
        if (lvl - 1 < list.size()) return list.get(lvl - 1);
        return 5000 * lvl * lvl;
    }

    // ------------------------------------------------------------------ Befehle + Shop

    private static class ShopHolder implements InventoryHolder {
        final List<Object[]> entries = new ArrayList<>();   // {Def, level}

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private void openShop(Player p) {
        ShopHolder h = new ShopHolder();
        Inventory inv = Bukkit.createInventory(h, 36, c("&5☠ &dGeister-Verzauberungen"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < 36; i++) inv.setItem(i, filler);
        int slot = 0;
        for (Def d : defs) {
            for (int lvl = 1; lvl <= d.max() && slot < 27; lvl++) {
                ItemStack b = book(d, lvl);
                ItemMeta m = b.getItemMeta();
                List<String> lore = new ArrayList<>(m.getLore());
                lore.add(0, c("&7Preis: &e" + String.format(Locale.GERMANY, "%,d", price(d, lvl)) + "$"));
                m.setLore(lore);
                b.setItemMeta(m);
                inv.setItem(slot, b);
                h.entries.add(new Object[]{d, lvl});
                slot++;
            }
        }
        EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
        ItemStack info = new ItemStack(Material.GOLD_INGOT);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&eDein Geld: &f" + String.format(Locale.GERMANY, "%,.0f", eco == null ? 0 : eco.getBalance(p.getUniqueId())) + "$"));
        info.setItemMeta(im);
        inv.setItem(31, info);
        p.openInventory(inv);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("give")) {
            if (!(sender.isOp() || sender.hasPermission("spookycraft.core.admin") || !(sender instanceof Player))) {
                plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
                return true;
            }
            Player t = args.length >= 2 ? Bukkit.getPlayerExact(args[1]) : null;
            Def d = args.length >= 3 ? def(args[2]) : null;
            if (t == null || d == null) {
                plugin.getMessageUtil().send(sender, "&cNutzung: /ce give <spieler> <id> [stufe]");
                return true;
            }
            int lvl = 1;
            if (args.length >= 4) {
                try {
                    lvl = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    plugin.getMessageUtil().send(sender, "&cDas ist keine gültige Zahl, Sterblicher.");
                    return true;
                }
            }
            lvl = Math.max(1, Math.min(d.max(), lvl));
            for (ItemStack left : t.getInventory().addItem(book(d, lvl)).values()) t.getWorld().dropItemNaturally(t.getLocation(), left);
            plugin.getMessageUtil().send(sender, "&aBuch " + d.name() + " " + ROMAN[lvl] + " an " + t.getName() + " übergeben.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("list")) {
            for (Def d : defs) {
                plugin.getMessageUtil().sendRaw(sender, "&8 - &f" + d.id() + " &8| &d" + d.name() + " &8(max. " + d.max() + ") &7" + d.desc());
            }
            return true;
        }
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        openShop(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return TabCompleteUtil.filter(args[0], "give", "list");
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) return TabCompleteUtil.onlinePlayers(args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            List<String> out = new ArrayList<>();
            for (Def d : defs) if (d.id().startsWith(args[2].toLowerCase(Locale.ROOT))) out.add(d.id());
            return out;
        }
        return Collections.emptyList();
    }

    @EventHandler
    public void onShopClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder h) {
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
            int slot = e.getSlot();
            if (slot < 0 || slot >= h.entries.size()) return;
            Def d = (Def) h.entries.get(slot)[0];
            int lvl = (Integer) h.entries.get(slot)[1];
            EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
            if (eco == null || !eco.withdraw(p.getUniqueId(), price(d, lvl))) {
                plugin.getMessageUtil().send(p, "&cDeine Taschen sind zu leer – nicht genug Geld!");
                return;
            }
            for (ItemStack left : p.getInventory().addItem(book(d, lvl)).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
            p.playSound(p.getLocation(), "entity.witch.celebrate", 0.7f, 1.2f);
            plugin.getMessageUtil().send(p, "&5☠ &dDie Geister überreichen dir das Buch &f" + d.name() + " " + ROMAN[lvl] + "&d.");
            openShop(p);
            return;
        }
        // Buch auf Item ziehen: Cursor = Buch, angeklicktes Item = Ziel
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack cursor = e.getCursor();
        String[] b = bookOf(cursor);
        if (b == null || b.length != 2) return;
        ItemStack target = e.getCurrentItem();
        if (target == null || target.getType().isAir() || target.getType() == Material.ENCHANTED_BOOK) return;
        e.setCancelled(true);
        Def d = def(b[0]);
        int lvl;
        try {
            lvl = Integer.parseInt(b[1]);
        } catch (NumberFormatException ex) {
            return;
        }
        if (d == null) return;
        if (!applies(d, target.getType())) {
            plugin.getMessageUtil().send(p, "&c" + d.name() + " passt nur auf: " + targetText(d) + ".");
            return;
        }
        Map<String, Integer> ench = read(target);
        if (ench.getOrDefault(d.id(), 0) >= lvl) {
            plugin.getMessageUtil().send(p, "&cDas Item hat diese Verzauberung bereits in gleicher oder höherer Stufe.");
            return;
        }
        ench.put(d.id(), lvl);
        write(target, ench);
        e.setCurrentItem(target);
        if (cursor.getAmount() > 1) {
            cursor.setAmount(cursor.getAmount() - 1);
            e.getView().setCursor(cursor);
        } else {
            e.getView().setCursor(null);
        }
        p.playSound(p.getLocation(), "block.enchantment_table.use", 0.9f, 1.0f);
        plugin.getMessageUtil().send(p, "&5☠ &dDein Item trägt nun &f" + d.name() + " " + ROMAN[Math.min(5, lvl)] + "&d!");
    }

    @EventHandler
    public void onShopDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ Wirkung

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity victim)) return;
        ItemStack hand = p.getInventory().getItemInMainHand();
        Map<String, Integer> ench = read(hand);
        if (ench.isEmpty()) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int gk = ench.getOrDefault("geisterklinge", 0);
        if (gk > 0 && r.nextDouble() < 0.12 * gk) {
            victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 20 * (2 + gk), 0));
        }
        int bd = ench.getOrDefault("blutdurst", 0);
        if (bd > 0 && r.nextDouble() < 0.15 * bd) {
            AttributeInstance inst = Compat.attr("max_health") == null ? null : p.getAttribute(Compat.attr("max_health"));
            double max = inst == null ? 20 : inst.getValue();
            p.setHealth(Math.min(max, p.getHealth() + bd));
        }
    }

    @EventHandler
    public void onKill(EntityDeathEvent e) {
        Player killer = e.getEntity().getKiller();
        if (killer == null || e.getEntity() instanceof Player) return;
        int lvl = level(killer.getInventory().getItemInMainHand(), "seelenfaenger");
        if (lvl <= 0) return;
        double each = plugin.getConfig().getDouble("cenchants.seelenfaenger-money-per-level", 25);
        EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
        if (eco == null) return;
        double amount = each * lvl;
        eco.deposit(killer.getUniqueId(), amount);
        killer.sendActionBar(net.kyori.adventure.text.Component.text("☠ +" + (long) amount + "$ (Seelenfänger)",
                net.kyori.adventure.text.format.NamedTextColor.LIGHT_PURPLE));
    }

    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        if (level(p.getInventory().getBoots(), "federschritt") > 0) e.setCancelled(true);
    }

    private void tick() {
        PotionEffectType haste = PotionEffectType.getByKey(NamespacedKey.minecraft("haste"));
        PotionEffectType night = PotionEffectType.getByKey(NamespacedKey.minecraft("night_vision"));
        for (Player p : Bukkit.getOnlinePlayers()) {
            int e = level(p.getInventory().getItemInMainHand(), "eilgeist");
            if (e > 0 && haste != null) p.addPotionEffect(new PotionEffect(haste, 100, e - 1, true, false, false));
            if (level(p.getInventory().getHelmet(), "katzenauge") > 0 && night != null) {
                p.addPotionEffect(new PotionEffect(night, 260, 0, true, false, false));
            }
        }
    }
}
