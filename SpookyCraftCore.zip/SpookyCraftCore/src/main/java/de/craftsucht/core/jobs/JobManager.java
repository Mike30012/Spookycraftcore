package de.craftsucht.core.jobs;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class JobManager {

    private final SpookyCraftCore plugin;
    private final List<String> availableJobs = new ArrayList<>();
    private YamlConfiguration jobsConfig;
    private final Map<UUID, Map<String, Deque<EarnEvent>>> payoutHistory = new HashMap<>();

    private record EarnEvent(long timestamp, double amount) {}

    public JobManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
        loadJobs();
    }

    private void loadJobs() {
        File file = new File(plugin.getDataFolder(), "jobs.yml");
        if (!file.exists()) plugin.saveResource("jobs.yml", false);
        jobsConfig = YamlConfiguration.loadConfiguration(file);
        availableJobs.clear();
        ConfigurationSection jobs = jobsConfig.getConfigurationSection("jobs");
        if (jobs != null) availableJobs.addAll(jobs.getKeys(false));
    }

    public void reload() { loadJobs(); }
    public List<String> getAvailableJobs() { return availableJobs; }
    public boolean isValidJob(String jobId) { return jobId != null && availableJobs.contains(jobId.toLowerCase()); }
    public String getJobDisplayName(String jobId) { return jobsConfig.getString("jobs." + jobId + ".display-name", jobId); }
    public String getJobDescription(String jobId) { return jobsConfig.getString("jobs." + jobId + ".description", ""); }

    public double getBlockPay(String jobId, Material material, JobData data) {
        double base = jobsConfig.getDouble("jobs." + jobId + ".blocks." + material.name(), -1.0);
        return base < 0.0 ? 0.0 : base * data.getLevelMultiplier();
    }

    /** Grundvergütung ohne Level-Multiplikator (-1 = zahlt nicht). */
    public double getBlockBasePay(String jobId, Material material) {
        return jobsConfig.getDouble("jobs." + jobId + ".blocks." + material.name(), -1.0);
    }

    /** Zahlt irgendein Job für diesen Block? */
    public boolean paysForBlock(Material material) {
        for (String jobId : availableJobs) {
            if (getBlockBasePay(jobId, material) >= 0.0) return true;
        }
        return false;
    }

    /** Optional pro Job: "worlds: [farmwelt, ...]" in der jobs.yml. Leer/fehlt = überall. */
    public boolean isJobAllowedIn(String jobId, org.bukkit.World world) {
        java.util.List<String> worlds = jobsConfig.getStringList("jobs." + jobId + ".worlds");
        return worlds.isEmpty() || worlds.contains(world.getName());
    }

    /** Zahlen Mobs aus Spawnern / Zucht? (Standard: nein, sonst Spawner-Farmen = Geld-Exploit) */
    public boolean paysForArtificialMobs() {
        return jobsConfig.getBoolean("settings.pay-spawner-and-bred-mobs", false);
    }

    public double getMobPay(String jobId, EntityType type, JobData data) {
        double base = jobsConfig.getDouble("jobs." + jobId + ".mobs." + type.name(), -1.0);
        return base < 0.0 ? 0.0 : base * data.getLevelMultiplier();
    }

    public double getFishPay(String jobId, String fishType, JobData data) {
        double base = jobsConfig.getDouble("jobs." + jobId + ".fish." + fishType, -1.0);
        return base < 0.0 ? 0.0 : base * data.getLevelMultiplier();
    }

    public int getXpPerAction() { return jobsConfig.getInt("settings.xp-per-action", 10); }
    public String getCurrencySymbol() { return jobsConfig.getString("settings.currency-symbol", "$"); }
    public double getPayoutCapPerHour() { return jobsConfig.getDouble("settings.payout-cap-per-job-60min", 1_500_000.0); }

    public int getMaxLevelForJob(String jobId) {
        if (jobId == null) return 1;
        int jobMax = jobsConfig.getInt("jobs." + jobId + ".max-level", -1);
        return jobMax > 0 ? jobMax : jobsConfig.getInt("settings.max-level", 10);
    }

    /** Levelt genau den angegebenen Job, unabhängig davon, welche anderen Jobs aktiv sind. */
    public void giveXp(Player player, PlayerData playerData, String jobId, int xpAmount) {
        if (!isValidJob(jobId) || xpAmount <= 0) return;
        JobData data = playerData.getOrCreateJob(jobId);
        int maxLevel = getMaxLevelForJob(jobId);
        if (data.getLevel() >= maxLevel) return;

        data.setXp(data.getXp() + xpAmount);
        while (data.getXp() >= data.getXpForNextLevel() && data.getLevel() < maxLevel) {
            data.setXp(data.getXp() - data.getXpForNextLevel());
            data.setLevel(data.getLevel() + 1);
            onLevelUp(player, playerData, jobId, data);
            if (plugin.getModuleManager().isEnabled("crates")
                    && plugin.getModuleManager().get("crates") instanceof de.craftsucht.core.crates.CratesModule crates) {
                crates.onJobLevel(player, data.getLevel());
            }
            module().getRewardManager().checkAndGiveReward(player, jobId, data.getLevel());
        }
    }

    /** Kompatibilitäts-Overload: levelt den aktuell angezeigten Job. */
    public void giveXp(Player player, PlayerData data, int xpAmount) {
        if (data.getCurrentJob() != null) giveXp(player, data, data.getCurrentJob(), xpAmount);
    }

    private JobsModule module() { return (JobsModule) plugin.getModuleManager().get("jobs"); }

    private void onLevelUp(Player player, PlayerData playerData, String jobId, JobData data) {
        String symbol = getCurrencySymbol();
        double multiplier = data.getLevelMultiplier();
        int maxLevel = getMaxLevelForJob(jobId);
        boolean isMaxLevel = data.getLevel() >= maxLevel;
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "☠ ══════════════════════════ ☠");
        if (isMaxLevel) {
            player.sendMessage(ChatColor.GOLD + " ✦ ☠ DU HAST DIE MACHT DER GEISTER ERREICHT! " + getJobDisplayName(jobId) + " §6§lLevel " + data.getLevel());
        } else {
            player.sendMessage(ChatColor.YELLOW + " ☠ DIE GEISTER ERHEBEN DICH! " + getJobDisplayName(jobId) + " ist jetzt Level §6§l" + data.getLevel() + ChatColor.GRAY + "/" + maxLevel);
        }
        player.sendMessage(ChatColor.GREEN + " Macht der Münzen: §a§l" + String.format("%.2fx", multiplier));
        int nextReward = nextRewardLevel(data.getLevel());
        if (nextReward > 0) player.sendMessage(ChatColor.LIGHT_PURPLE + " Nächste Weihe bei Level: §d§l" + nextReward);
        player.sendMessage(ChatColor.GOLD + "☠ ══════════════════════════ ☠");
        player.sendMessage("");
    }

    private int nextRewardLevel(int currentLevel) { return module().getRewardManager().getNextRewardLevel(currentLevel); }

    /**
     * Zahlt Jobgeld pro passender Tätigkeit. Pro Job gilt ein gleitendes
     * 60-Minuten-Limit, analog zum öffentlich dokumentierten OPSUCHT-System.
     */
    public double pay(Player player, PlayerData playerData, String jobId, double amount) {
        if (amount <= 0.0 || !isValidJob(jobId)) return 0.0;
        var economy = module().getEconomyManager();
        if (economy == null) return 0.0;

        long now = System.currentTimeMillis();
        long cutoff = now - 60L * 60L * 1000L;
        UUID uuid = player.getUniqueId();
        Map<String, Deque<EarnEvent>> byJob = payoutHistory.computeIfAbsent(uuid, k -> new HashMap<>());
        Deque<EarnEvent> history = byJob.computeIfAbsent(jobId, k -> new ArrayDeque<>());
        while (!history.isEmpty() && history.peekFirst().timestamp() < cutoff) history.removeFirst();

        double earnedLastHour = 0.0;
        for (EarnEvent event : history) earnedLastHour += event.amount();
        double cap = jobsConfig.getDouble("settings.payout-cap-per-job-60min", 1_500_000.0);
        double remaining = Math.max(0.0, cap - earnedLastHour);
        double payout = Math.min(amount, remaining);
        if (payout <= 0.0) return 0.0;

        economy.deposit(uuid, payout);
        history.addLast(new EarnEvent(now, payout));
        playerData.getOrCreateJob(jobId).addTotalEarned((long) payout);
        return payout;
    }

    /** Nur für die Anzeige/GUI: Join/Leave gibt es nicht mehr. */
    public boolean selectJob(Player player, String jobId) {
        if (!isValidJob(jobId)) return false;
        PlayerData data = module().getPlayerDataManager().get(player.getUniqueId());
        data.ensureJob(jobId);
        data.setCurrentJob(jobId);
        module().getPlayerDataManager().save(player.getUniqueId());
        return true;
    }

    public void showJobInfo(Player player, String jobId) {
        if (!isValidJob(jobId)) {
            player.sendMessage(ChatColor.RED + "Dieser Job ist den Geistern unbekannt.");
            return;
        }
        PlayerData data = module().getPlayerDataManager().get(player.getUniqueId());
        JobData jd = data.getOrCreateJob(jobId);
        int maxLevel = getMaxLevelForJob(jobId);
        player.sendMessage(ChatColor.GOLD + "════════════════════");
        player.sendMessage(ChatColor.YELLOW + getJobDisplayName(jobId));
        player.sendMessage(ChatColor.GRAY + getJobDescription(jobId));
        player.sendMessage(ChatColor.GREEN + "Level: §f" + jd.getLevel() + " §7| XP: §f" + jd.getXp() + "/" + jd.getXpForNextLevel());
        player.sendMessage(ChatColor.AQUA + "Max. Level: §f" + maxLevel);
        player.sendMessage(ChatColor.GOLD + "Macht der Münzen: §e" + String.format("%.2fx", jd.getLevelMultiplier()) + ChatColor.GRAY + " (Bezahlung pro Tätigkeit)");
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Die Geister weihen dich alle 10 Level mit einem neuen Titel!");
        player.sendMessage(ChatColor.GOLD + "════════════════════");
    }
}
