package de.craftsucht.core.jobs;

/** Persistenter Fortschritt eines einzelnen Jobs. */
public class JobData {
    private final String jobId;
    private int level;
    private int xp;
    private long totalEarned;

    public JobData(String jobId) {
        this.jobId = jobId;
        this.level = 1;
        this.xp = 0;
        this.totalEarned = 0L;
    }

    public String getJobId() { return jobId; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = Math.max(1, level); }
    public int getXp() { return xp; }
    public void setXp(int xp) { this.xp = Math.max(0, xp); }
    public long getTotalEarned() { return totalEarned; }
    public void addTotalEarned(long amount) { this.totalEarned += Math.max(0L, amount); }
    public int getXpForNextLevel() { return level * 100; }
    public double getLevelMultiplier() { return level; }
}
