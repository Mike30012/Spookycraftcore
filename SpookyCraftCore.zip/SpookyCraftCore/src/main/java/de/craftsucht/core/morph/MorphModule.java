package de.craftsucht.core.morph;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.rank.RankModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /morph - Spieler verwandelt sich in ein Tier. Ohne Fremd-Plugin: Der Spieler wird unsichtbar, ein
 * KI-loses Tier folgt ihm jeden Tick (fuer den Spieler selbst versteckt). Schlaege auf das Tier gehen an den Spieler.
 */
public class MorphModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static final Map<String, Object[]> ANIMALS = new LinkedHashMap<>();

    static {
        ANIMALS.put("schwein", new Object[]{EntityType.PIG, Material.PIG_SPAWN_EGG, "Schwein"});
        ANIMALS.put("kuh", new Object[]{EntityType.COW, Material.COW_SPAWN_EGG, "Kuh"});
        ANIMALS.put("schaf", new Object[]{EntityType.SHEEP, Material.SHEEP_SPAWN_EGG, "Schaf"});
        ANIMALS.put("huhn", new Object[]{EntityType.CHICKEN, Material.CHICKEN_SPAWN_EGG, "Huhn"});
        ANIMALS.put("wolf", new Object[]{EntityType.WOLF, Material.WOLF_SPAWN_EGG, "Wolf"});
        ANIMALS.put("katze", new Object[]{EntityType.CAT, Material.CAT_SPAWN_EGG, "Katze"});
        ANIMALS.put("fuchs", new Object[]{EntityType.FOX, Material.FOX_SPAWN_EGG, "Fuchs"});
        ANIMALS.put("hase", new Object[]{EntityType.RABBIT, Material.RABBIT_SPAWN_EGG, "Hase"});
        ANIMALS.put("papagei", new Object[]{EntityType.PARROT, Material.PARROT_SPAWN_EGG, "Papagei"});
        ANIMALS.put("panda", new Object[]{EntityType.PANDA, Material.PANDA_SPAWN_EGG, "Panda"});
        ANIMALS.put("eisbaer", new Object[]{EntityType.POLAR_BEAR, Material.POLAR_BEAR_SPAWN_EGG, "Eisbär"});
        ANIMALS.put("biene", new Object[]{EntityType.BEE, Material.BEE_SPAWN_EGG, "Biene"});
        ANIMALS.put("frosch", new Object[]{EntityType.FROG, Material.FROG_SPAWN_EGG, "Frosch"});
        ANIMALS.put("pferd", new Object[]{EntityType.HORSE, Material.HORSE_SPAWN_EGG, "Pferd"});
        ANIMALS.put("fledermaus", new Object[]{EntityType.BAT, Material.BAT_SPAWN_EGG, "Fledermaus"});
        ANIMALS.put("ocelot", new Object[]{EntityType.OCELOT, Material.OCELOT_SPAWN_EGG, "Ozelot"});
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, Mob> disguises = new HashMap<>();
    private final Map<UUID, UUID> mobOwner = new HashMap<>();
    private BukkitTask task;

    public MorphModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "morph";
    }

    @Override
    public void enable() {
        plugin.getCommand("morph").setExecutor(this);
        plugin.getCommand("morph").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::follow, 1L, 1L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        org.bukkit.event.HandlerList.unregisterAll(this);
        for (UUID id : new ArrayList<>(disguises.keySet())) {
            Player p = Bukkit.getPlayer(id);
            unmorph(id, p);
        }
    }

    private static class MorphHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private boolean allowed(Player p) {
        if (p.isOp() || p.hasPermission("spookycraft.morph") || p.hasPermission("spookycraft.core.admin")) return true;
        if (plugin.getModuleManager().get("rank") instanceof RankModule rm && rm.getManager() != null) {
            String r = rm.getManager().getUserRank(p.getUniqueId());
            if (r != null) {
                for (String a : plugin.getConfig().getStringList("morph.ranks")) if (a.equalsIgnoreCase(r)) return true;
            }
        }
        return false;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!allowed(p)) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length == 0) {
            openMenu(p);
            return true;
        }
        String a = args[0].toLowerCase();
        if (a.equals("off") || a.equals("aus") || a.equals("reset")) {
            if (disguises.containsKey(p.getUniqueId()) || libsMorphed.contains(p.getUniqueId())) {
                unmorph(p.getUniqueId(), p);
                plugin.getMessageUtil().send(p, "&5☠ &dDu bist wieder du selbst.");
            } else {
                plugin.getMessageUtil().send(p, "&7Du bist gerade nicht verwandelt.");
            }
            return true;
        }
        Object[] def = ANIMALS.get(a);
        if (def == null) {
            plugin.getMessageUtil().send(p, "&cUnbekanntes Tier. Tiere: &f" + String.join(", ", ANIMALS.keySet()));
            return true;
        }
        morph(p, a);
        return true;
    }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(new MorphHolder(), 27, c("&5☠ &dMorph – Tier wählen"));
        int slot = 0;
        for (Map.Entry<String, Object[]> e : ANIMALS.entrySet()) {
            ItemStack it = new ItemStack((Material) e.getValue()[1]);
            ItemMeta m = it.getItemMeta();
            m.setDisplayName(c("&d" + e.getValue()[2]));
            m.setLore(List.of(c("&7Klicken zum Verwandeln"), c("&8" + e.getKey())));
            it.setItemMeta(m);
            inv.setItem(slot++, it);
        }
        ItemStack off = new ItemStack(Material.BARRIER);
        ItemMeta om = off.getItemMeta();
        om.setDisplayName(c("&cZurück verwandeln"));
        off.setItemMeta(om);
        inv.setItem(26, off);
        p.openInventory(inv);
    }

    private boolean libs() {
        return Bukkit.getPluginManager().isPluginEnabled("LibsDisguises");
    }

    private final java.util.Set<UUID> libsMorphed = new java.util.HashSet<>();

    private void morph(Player p, String key) {
        unmorph(p.getUniqueId(), p);
        Object[] def = ANIMALS.get(key);
        EntityType type = (EntityType) def[0];
        if (libs()) {
            // Echte Verwandlung ueber LibsDisguises (Rüstung/Item verschwinden mit)
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "disguiseplayer " + p.getName() + " " + type.name().toLowerCase());
            libsMorphed.add(p.getUniqueId());
            p.getWorld().spawnParticle(Particle.POOF, p.getLocation().add(0, 1, 0), 25, 0.4, 0.5, 0.4, 0.03);
            plugin.getMessageUtil().send(p, "&5☠ &dDu bist jetzt ein &5&l" + def[2] + "&d! &7(/morph off zum Zurückverwandeln)");
            return;
        }
        Entity ent = p.getWorld().spawnEntity(p.getLocation(), type);
        if (!(ent instanceof Mob mob)) {
            ent.remove();
            return;
        }
        mob.setAI(false);
        mob.setSilent(true);
        mob.setInvulnerable(true);
        mob.setCollidable(false);
        mob.setGravity(false);
        mob.setPersistent(false);
        mob.setRemoveWhenFarAway(false);
        if (mob instanceof org.bukkit.entity.Ageable ag) ag.setAdult();
        p.hideEntity(plugin, mob);
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        disguises.put(p.getUniqueId(), mob);
        mobOwner.put(mob.getUniqueId(), p.getUniqueId());
        p.getWorld().spawnParticle(Particle.POOF, p.getLocation().add(0, 1, 0), 25, 0.4, 0.5, 0.4, 0.03);
        plugin.getMessageUtil().send(p, "&5☠ &dDu bist jetzt ein &5&l" + def[2] + "&d! &7(/morph off zum Zurückverwandeln)");
    }

    private void unmorph(UUID id, Player p) {
        if (libsMorphed.remove(id) && p != null) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "undisguiseplayer " + p.getName());
        }
        Mob mob = disguises.remove(id);
        if (mob != null) {
            mobOwner.remove(mob.getUniqueId());
            if (mob.isValid()) {
                mob.getWorld().spawnParticle(Particle.POOF, mob.getLocation().add(0, 0.5, 0), 20, 0.3, 0.3, 0.3, 0.03);
                mob.remove();
            }
        }
        if (p != null && p.isOnline()) p.removePotionEffect(PotionEffectType.INVISIBILITY);
    }

    private void follow() {
        if (disguises.isEmpty()) return;
        for (Map.Entry<UUID, Mob> e : new ArrayList<>(disguises.entrySet())) {
            Player p = Bukkit.getPlayer(e.getKey());
            Mob mob = e.getValue();
            if (p == null || !p.isOnline() || p.isDead()) {
                unmorph(e.getKey(), p);
                continue;
            }
            if (!mob.isValid()) {
                // z.B. Chunk entladen: Tier neu erzeugen
                String key = keyOf(mob.getType());
                disguises.remove(e.getKey());
                mobOwner.remove(mob.getUniqueId());
                if (key != null) morph(p, key);
                continue;
            }
            Location l = p.getLocation();
            if (!mob.getWorld().equals(l.getWorld()) || mob.getLocation().distanceSquared(l) > 0.0001
                    || mob.getLocation().getYaw() != l.getYaw()) {
                mob.teleport(l);
                mob.setRotation(l.getYaw(), l.getPitch());
                mob.setBodyYaw(l.getYaw());
            }
            if (p.isInvisible() == false && p.getActivePotionEffects().stream().noneMatch(x -> x.getType().equals(PotionEffectType.INVISIBILITY))) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, PotionEffect.INFINITE_DURATION, 0, false, false, false));
            }
        }
    }

    private String keyOf(EntityType t) {
        for (Map.Entry<String, Object[]> e : ANIMALS.entrySet()) if (e.getValue()[0] == t) return e.getKey();
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        UUID owner = mobOwner.get(e.getEntity().getUniqueId());
        if (owner == null) return;
        e.setCancelled(true);
        Player p = Bukkit.getPlayer(owner);
        if (p != null && !e.getDamager().getUniqueId().equals(owner)) p.damage(e.getFinalDamage(), e.getDamager());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        unmorph(e.getPlayer().getUniqueId(), e.getPlayer());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        unmorph(e.getEntity().getUniqueId(), e.getEntity());
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Mob mob = disguises.get(e.getPlayer().getUniqueId());
        if (mob == null) return;
        String key = keyOf(mob.getType());
        unmorph(e.getPlayer().getUniqueId(), e.getPlayer());
        if (key != null) Bukkit.getScheduler().runTask(plugin, () -> morph(e.getPlayer(), key));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof MorphHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || !it.hasItemMeta()) return;
        if (it.getType() == Material.BARRIER) {
            p.closeInventory();
            unmorph(p.getUniqueId(), p);
            plugin.getMessageUtil().send(p, "&5☠ &dDu bist wieder du selbst.");
            return;
        }
        List<String> lore = it.getItemMeta().getLore();
        if (lore == null || lore.size() < 2) return;
        String key = ChatColor.stripColor(lore.get(1));
        if (ANIMALS.containsKey(key)) {
            p.closeInventory();
            morph(p, key);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MorphHolder) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> l = new ArrayList<>(ANIMALS.keySet());
            l.add("off");
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], l.toArray(new String[0]));
        }
        return List.of();
    }
}
