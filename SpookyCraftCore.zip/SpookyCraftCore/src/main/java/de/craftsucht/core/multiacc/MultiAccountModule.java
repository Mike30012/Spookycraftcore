package de.craftsucht.core.multiacc;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.StaffCheck;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.net.InetAddress;
import java.net.InetSocketAddress;

/**
 * Verhindert Zweitaccounts: von derselben IP duerfen nur X Spieler gleichzeitig online sein
 * (config multiaccount.max-per-ip). Wirkt auch auf Cracked-Servern. Ausnahme: Recht
 * spookycraft.multiacc.bypass oder OP. Localhost/Proxy-Adressen werden ignoriert.
 */
public class MultiAccountModule implements Module, Listener {

    private final SpookyCraftCore plugin;

    public MultiAccountModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "multiaccount";
    }

    @Override
    public void enable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
    }

    private static String ip(Player p) {
        InetSocketAddress a = p.getAddress();
        if (a == null) return null;
        InetAddress addr = a.getAddress();
        if (addr == null) return null;
        if (addr.isLoopbackAddress() || addr.isAnyLocalAddress()) return null;
        return addr.getHostAddress();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (StaffCheck.isStaff(plugin, p) || p.hasPermission("spookycraft.multiacc.bypass")) return;
        String myIp = ip(p);
        if (myIp == null) return;
        int max = Math.max(1, plugin.getConfig().getInt("multiaccount.max-per-ip", 1));
        int count = 0;
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.getUniqueId().equals(p.getUniqueId())) continue;
            if (!myIp.equals(ip(o))) continue;
            // Gehoert die IP einem Owner/Admin, darf er mit Zweitaccounts spielen
            if (StaffCheck.isStaff(plugin, o)) return;
            count++;
        }
        if (count < max) return;
        e.joinMessage(null);
        String reason = plugin.getConfig().getString("multiaccount.ban-reason", "Zweitaccount (Multi-Account)");
        if (plugin.getConfig().getBoolean("multiaccount.ip-ban", true)) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban-ip " + myIp + " " + reason);
        }
        plugin.getLogger().warning("Zweitaccount " + p.getName() + " (" + myIp + ") gesperrt.");
        p.kickPlayer("§8§l☠ §cDie Geister dulden keine Zweitseelen!\n§7Du wurdest wegen eines Zweitaccounts gebannt.");
    }
}
