package de.craftsucht.core.games;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Chat-Spiele: alle chatgames.interval-minutes Minuten erscheint eine Rechenaufgabe, ein Buchstabensalat
 * oder ein Tipp-Wort. Wer zuerst richtig antwortet, bekommt Geld (chatgames.reward-min bis reward-max).
 */
public class ChatGamesModule implements Module, Listener {

    private final SpookyCraftCore plugin;
    private BukkitTask loop;
    private BukkitTask timeout;
    private volatile String answer;       // null = kein Spiel aktiv
    private volatile long startedAt;

    private static final String[] WORDS = {
            "gespenst", "friedhof", "kuerbis", "vampir", "fledermaus", "geisterstunde", "zauberer", "spinnennetz", "grabstein",
            "hexenkessel", "nebel", "dunkelheit", "skelett", "werwolf", "albtraum", "irrlicht", "totenkopf", "spukhaus", "mitternacht",
            "blutmond", "zombie", "schatten", "fluch", "gruselig", "kerzenlicht", "kristall", "dungeon", "citybuild", "diamant", "farmwelt"
    };

    public ChatGamesModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "chatgames";
    }

    @Override
    public void enable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
        long ticks = 20L * 60 * Math.max(1, plugin.getConfig().getInt("chatgames.interval-minutes", 10));
        loop = Bukkit.getScheduler().runTaskTimer(plugin, this::startGame, ticks, ticks);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        if (loop != null) loop.cancel();
        if (timeout != null) timeout.cancel();
        answer = null;
    }

    private void startGame() {
        if (answer != null) return;
        if (Bukkit.getOnlinePlayers().size() < Math.max(1, plugin.getConfig().getInt("chatgames.min-players", 2))) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        String question;
        String correct;
        switch (r.nextInt(3)) {
            case 0 -> {
                int a = r.nextInt(5, 60), b = r.nextInt(2, 40);
                int kind = r.nextInt(3);
                if (kind == 0) {
                    question = "&f" + a + " + " + b + " &d= ?";
                    correct = String.valueOf(a + b);
                } else if (kind == 1) {
                    int hi = Math.max(a, b), lo = Math.min(a, b);
                    question = "&f" + hi + " - " + lo + " &d= ?";
                    correct = String.valueOf(hi - lo);
                } else {
                    int x = r.nextInt(3, 13), y = r.nextInt(3, 13);
                    question = "&f" + x + " × " + y + " &d= ?";
                    correct = String.valueOf(x * y);
                }
                announce("Löse die Rechnung: " + question);
            }
            case 1 -> {
                String w = WORDS[r.nextInt(WORDS.length)];
                List<Character> chars = new ArrayList<>();
                for (char ch : w.toCharArray()) chars.add(ch);
                String scrambled;
                int guard = 0;
                do {
                    Collections.shuffle(chars);
                    StringBuilder sb = new StringBuilder();
                    for (char ch : chars) sb.append(ch);
                    scrambled = sb.toString();
                } while (scrambled.equals(w) && ++guard < 10);
                correct = w;
                announce("Entwirre das Wort: &f" + scrambled);
            }
            default -> {
                String w = WORDS[r.nextInt(WORDS.length)];
                correct = w;
                announce("Tippe als Erster das Wort: &f" + w);
            }
        }
        startedAt = System.currentTimeMillis();
        answer = correct.toLowerCase(Locale.ROOT);
        final String shown = correct;
        timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (answer != null) {
                answer = null;
                Bukkit.broadcastMessage(plugin.getMessageUtil().color("&5☠ &dNiemand wusste es... Die Antwort war &f" + shown + "&d."));
            }
        }, 20L * Math.max(10, plugin.getConfig().getInt("chatgames.time-seconds", 30)));
    }

    private void announce(String text) {
        Bukkit.broadcastMessage(plugin.getMessageUtil().color("&5☠ &d&lGeister-Rätsel &8» &d" + text));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        String a = answer;
        if (a == null) return;
        if (!e.getMessage().trim().toLowerCase(Locale.ROOT).equals(a)) return;
        // nur ein Gewinner: Antwort atomar "abholen"
        synchronized (this) {
            if (answer == null) return;
            answer = null;
        }
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (timeout != null) timeout.cancel();
            int min = plugin.getConfig().getInt("chatgames.reward-min", 200);
            int max = Math.max(min, plugin.getConfig().getInt("chatgames.reward-max", 1000));
            int reward = ThreadLocalRandom.current().nextInt(min, max + 1);
            EconomyManager eco = GameUtil.eco(plugin);
            if (eco != null) eco.deposit(p.getUniqueId(), reward);
            double secs = (System.currentTimeMillis() - startedAt) / 1000.0;
            Bukkit.broadcastMessage(plugin.getMessageUtil().color("&5☠ &f" + p.getName() + " &dwar der Schnellste (&f"
                    + String.format(Locale.GERMANY, "%.1f", secs) + " s&d) und erhält &e" + GameUtil.money(reward) + "&d!"));
            p.playSound(p.getLocation(), "entity.player.levelup", 0.8f, 1.2f);
        });
    }
}
