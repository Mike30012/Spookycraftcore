package de.craftsucht.core.economy;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;

public class EconomyModule implements Module {

    private final SpookyCraftCore plugin;
    private EconomyManager manager;
    private EconomyCommand command;

    public EconomyModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "economy";
    }

    @Override
    public void enable() {
        this.manager = new EconomyManager(plugin);
        this.command = new EconomyCommand(plugin, manager);
        plugin.getCommand("balance").setExecutor(command);
        plugin.getCommand("balance").setTabCompleter(command);
        plugin.getCommand("pay").setExecutor(command);
        plugin.getCommand("pay").setTabCompleter(command);
        plugin.getCommand("baltop").setExecutor(command);
        plugin.getCommand("eco").setExecutor(command);
        plugin.getCommand("eco").setTabCompleter(command);
    }

    @Override
    public void disable() {
        // command executors are cheap to leave registered; state lives in `manager`
        if (manager != null) manager.shutdown();
    }

    public EconomyManager getManager() {
        return manager;
    }
}
