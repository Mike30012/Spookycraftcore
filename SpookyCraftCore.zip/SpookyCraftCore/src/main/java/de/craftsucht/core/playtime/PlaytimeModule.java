package de.craftsucht.core.playtime;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.perks.PerksModule;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Spielzeit-Belohnungen: Meilensteine aus playtime.rewards (Stunden online) geben automatisch Geld, Kristalle oder einen Perk.
 * /spielzeit zeigt die eigene Zeit und den naechsten Meilenstein. Gemessen wird die Minecraft-Statistik "Spielzeit".
 */
public class PlaytimeModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private BukkitTask task;

    public PlaytimeModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "playtime";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "playtime.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("spielzeit").setExecutor(this);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L * 60, 20L * 60);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        save();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("playtime.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    /** Die Spielzeit-Statistik heisst je nach Version PLAY_ONE_MINUTE oder PLAY_TIME - deshalb per Name suchen. */
    private static final Statistic PLAY_STAT = findStat();

    private static Statistic findStat() {
        for (String n : new String[]{"PLAY_ONE_MINUTE", "PLAY_TIME"}) {
            try {
                return Statistic.valueOf(n);
            } catch (IllegalArgumentException ignored) {
            }
        }
        return null;
    }

    private static double hoursOf(Player p) {
        if (PLAY_STAT == null) return 0;
        return p.getStatistic(PLAY_STAT) / 72000.0;   // Ticks -> Stunden
    }

    private List<Map<?, ?>> rewards() {
        return plugin.getConfig().getMapList("playtime.rewards");
    }

    private static double num(Map<?, ?> m, String k) {
        try {
            return Double.parseDouble(String.valueOf(m.get(k)));
        } catch (Exception e) {
            return 0;
        }
    }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) check(p);
    }

    private void check(Player p) {
        double h = hoursOf(p);
        List<String> done = new ArrayList<>(data.getStringList(p.getUniqueId().toString()));
        boolean changed = false;
        for (Map<?, ?> r : rewards()) {
            String key = String.valueOf(r.get("hours"));
            if (h + 1e-9 < num(r, "hours") || done.contains(key)) continue;
            done.add(key);
            changed = true;
            give(p, r);
        }
        if (changed) {
            data.set(p.getUniqueId().toString(), done);
            save();
        }
    }

    private void give(Player p, Map<?, ?> r) {
        List<String> parts = new ArrayList<>();
        long money = (long) num(r, "money");
        if (money > 0 && plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
            em.getManager().deposit(p.getUniqueId(), money);
            parts.add("&e" + String.format(java.util.Locale.GERMANY, "%,d", money) + "$");
        }
        long crystals = (long) num(r, "crystals");
        if (crystals > 0 && plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
            cm.getCrystals().add(p.getUniqueId(), crystals);
            parts.add("&b" + crystals + " Kristalle");
        }
        Object perk = r.get("perk");
        if (perk != null && plugin.getModuleManager().get("perks") instanceof PerksModule pm) {
            pm.grantPerk(p, String.valueOf(perk));
            parts.add("&dPerk &f" + perk);
        }
        p.playSound(p.getLocation(), "entity.player.levelup", 0.9f, 1.0f);
        plugin.getMessageUtil().send(p, "&5☠ &dDie Geister belohnen deine Treue (&f" + r.get("hours") + " Std.&d): "
                + (parts.isEmpty() ? "&7ein Dank aus der Geisterwelt" : String.join("&7, ", parts)));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        double h = hoursOf(p);
        List<String> done = data.getStringList(p.getUniqueId().toString());
        plugin.getMessageUtil().sendRaw(p, "&8--- &5☠ &dDeine Spielzeit &8---");
        plugin.getMessageUtil().sendRaw(p, "&8» &7Online: &f" + String.format(java.util.Locale.GERMANY, "%.1f", h) + " Stunden");
        Map<?, ?> next = null;
        for (Map<?, ?> r : rewards()) {
            if (done.contains(String.valueOf(r.get("hours")))) continue;
            if (next == null || num(r, "hours") < num(next, "hours")) next = r;
        }
        if (next == null) {
            plugin.getMessageUtil().sendRaw(p, "&8» &7Du hast alle Meilensteine erreicht – die Geister sind stolz auf dich!");
        } else {
            double left = Math.max(0, num(next, "hours") - h);
            plugin.getMessageUtil().sendRaw(p, "&8» &7Nächster Meilenstein: &f" + next.get("hours") + " Std. &8(noch &f"
                    + String.format(java.util.Locale.GERMANY, "%.1f", left) + " Std.&8)");
        }
        return true;
    }
}
