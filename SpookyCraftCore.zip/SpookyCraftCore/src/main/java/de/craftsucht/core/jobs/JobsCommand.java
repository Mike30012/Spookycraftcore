package de.craftsucht.core.jobs;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class JobsCommand implements CommandExecutor {

    private final JobsModule jobs;

    public JobsCommand(JobsModule jobs) { this.jobs = jobs; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            showOverview(player);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "info" -> {
                if (args.length < 2) showOverview(player);
                else jobs.getJobManager().showJobInfo(player, args[1].toLowerCase());
            }
            case "reload" -> {
                if (!player.isOp() && !player.hasPermission("spookycraft.core.admin")) {
                    player.sendMessage(ChatColor.RED + "Die Geister verwehren dir den Zutritt!");
                    return true;
                }
                jobs.getJobManager().reload();
                player.sendMessage(ChatColor.GREEN + "Die Geister haben jobs.yml neu geschrieben.");
            }
            default -> showOverview(player);
        }
        return true;
    }

    private void showOverview(Player player) {
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        player.sendMessage("");
        player.sendMessage(ChatColor.GOLD + "  ⛏ §6§lMinecraftJobs");
        player.sendMessage(ChatColor.GOLD + "  ══════════════════════════════");
        player.sendMessage(ChatColor.GRAY + "  Die Geister haben dich in alle Jobs geweiht.");
        player.sendMessage("");
        for (String jobId : jobs.getJobManager().getAvailableJobs()) {
            JobData jd = data.getOrCreateJob(jobId);
            String display = jobs.getJobManager().getJobDisplayName(jobId);
            player.sendMessage(ChatColor.YELLOW + "  " + display + ChatColor.GRAY + " → Level §e" + jd.getLevel()
                    + ChatColor.GRAY + " | XP §f" + jd.getXp() + "/" + jd.getXpForNextLevel()
                    + ChatColor.GRAY + " | §a" + String.format("%.2fx", jd.getLevelMultiplier()) + ChatColor.GRAY + " Multiplikator");
        }
        player.sendMessage("");
        player.sendMessage(ChatColor.GRAY + "  /jobs info <job>  |  /prefix");
        player.sendMessage(ChatColor.GOLD + "  ══════════════════════════════");
        player.sendMessage("");
    }
}
