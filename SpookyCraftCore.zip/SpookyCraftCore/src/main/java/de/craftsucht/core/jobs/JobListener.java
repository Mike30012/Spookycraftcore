package de.craftsucht.core.jobs;

import de.craftsucht.core.booster.BoosterAPI;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.Set;

public class JobListener implements Listener {

    /** Spawn-Gründe, bei denen Mobs kein Jobgeld geben (Spawner-/Zucht-Farmen wären ein Geld-Exploit). */
    private static final Set<String> ARTIFICIAL_SPAWNS = Set.of(
            "SPAWNER", "TRIAL_SPAWNER", "SPAWNER_EGG", "DISPENSE_EGG", "EGG", "BREEDING");

    private final JobsModule jobs;
    private final NamespacedKey placedKey;
    private final NamespacedKey noPayKey;

    public JobListener(JobsModule jobs) {
        this.jobs = jobs;
        this.placedKey = new NamespacedKey(jobs.plugin, "jobs_placed");
        this.noPayKey = new NamespacedKey(jobs.plugin, "jobs_nopay");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        jobs.getPlayerDataManager().get(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        jobs.getPlayerDataManager().unload(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Exploit-Schutz: selbst gesetzte Blöcke

    private static long pack(Block b) {
        return ((long) (b.getY() + 64) << 8) | ((b.getX() & 15) << 4) | (b.getZ() & 15);
    }

    /** Merkt sich (im Chunk, übersteht Neustarts), dass ein Spieler diesen bezahlten Block gesetzt hat. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Block block = event.getBlockPlaced();
        if (!jobs.getJobManager().paysForBlock(block.getType())) return;
        PersistentDataContainer pdc = block.getChunk().getPersistentDataContainer();
        long[] old = pdc.get(placedKey, PersistentDataType.LONG_ARRAY);
        long id = pack(block);
        if (old == null) {
            pdc.set(placedKey, PersistentDataType.LONG_ARRAY, new long[]{id});
            return;
        }
        for (long l : old) {
            if (l == id) return;
        }
        if (old.length >= 60_000) return; // Schutz vor unbegrenztem Wachstum
        long[] grown = Arrays.copyOf(old, old.length + 1);
        grown[old.length] = id;
        pdc.set(placedKey, PersistentDataType.LONG_ARRAY, grown);
    }

    /** @return true, wenn der Block von einem Spieler gesetzt wurde (Markierung wird dabei entfernt) */
    private boolean consumePlaced(Block block) {
        PersistentDataContainer pdc = block.getChunk().getPersistentDataContainer();
        long[] old = pdc.get(placedKey, PersistentDataType.LONG_ARRAY);
        if (old == null) return false;
        long id = pack(block);
        int idx = -1;
        for (int i = 0; i < old.length; i++) {
            if (old[i] == id) {
                idx = i;
                break;
            }
        }
        if (idx < 0) return false;
        if (old.length == 1) {
            pdc.remove(placedKey);
        } else {
            long[] shrunk = new long[old.length - 1];
            System.arraycopy(old, 0, shrunk, 0, idx);
            System.arraycopy(old, idx + 1, shrunk, idx, old.length - idx - 1);
            pdc.set(placedKey, PersistentDataType.LONG_ARRAY, shrunk);
        }
        return true;
    }

    // ------------------------------------------------------------------ Exploit-Schutz: Spawner-/Zucht-Mobs

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (jobs.getJobManager().paysForArtificialMobs()) return;
        if (ARTIFICIAL_SPAWNS.contains(event.getSpawnReason().name())) {
            event.getEntity().getPersistentDataContainer().set(noPayKey, PersistentDataType.BYTE, (byte) 1);
        }
    }

    // ------------------------------------------------------------------ Bezahlung

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;
        Block block = event.getBlock();
        Material type = block.getType();
        if (!jobs.getJobManager().paysForBlock(type)) return;
        if (consumePlaced(block)) return; // selbst gesetzter Block: kein Geld, keine XP
        if (de.craftsucht.core.booster.AreaMiningListener.isExtraBreak()
                && !jobs.plugin.getConfig().getBoolean("area-mining.pay-jobs-for-extra-blocks", true)) {
            return; // Zusatzblöcke von Area-Spitzhacken zahlen nur, wenn das in der config erlaubt ist
        }

        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());

        // Ein Block bezahlt nur EINEN Job (den mit der höchsten Grundvergütung), z.B. SAND/KIES = Gräber.
        String bestJob = null;
        double bestBase = 0.0;
        for (String jobId : jobs.getJobManager().getAvailableJobs()) {
            if (!jobs.getJobManager().isJobAllowedIn(jobId, block.getWorld())) continue;
            double base = jobs.getJobManager().getBlockBasePay(jobId, type);
            if (base > bestBase) {
                bestBase = base;
                bestJob = jobId;
            }
        }
        if (bestJob == null) return;
        JobData jd = data.getOrCreateJob(bestJob);
        double pay = jobs.getJobManager().getBlockPay(bestJob, type, jd);
        if (pay <= 0.0) return;
        payOut(player, data, bestJob, pay);
        jobs.getPlayerDataManager().save(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        Player player = event.getEntity().getKiller();
        if (player == null) return;
        if (event.getEntity().getPersistentDataContainer().has(noPayKey, PersistentDataType.BYTE)) return;
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        String jobId = "hunter";
        if (!jobs.getJobManager().isValidJob(jobId)) return;
        if (!jobs.getJobManager().isJobAllowedIn(jobId, player.getWorld())) return;
        JobData jd = data.getOrCreateJob(jobId);
        double pay = jobs.getJobManager().getMobPay(jobId, event.getEntity().getType(), jd);
        if (pay <= 0.0) return;
        payOut(player, data, jobId, pay);
        jobs.getPlayerDataManager().save(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        Player player = event.getPlayer();
        String jobId = "fisher";
        if (!jobs.getJobManager().isValidJob(jobId)) return;
        if (!jobs.getJobManager().isJobAllowedIn(jobId, player.getWorld())) return;
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        String fishType = "JUNK";
        if (event.getCaught() != null) {
            String name = event.getCaught().getType().name();
            if (name.equals("FISHING_ROD") || name.equals("BOW") || name.equals("BOOK")
                    || name.equals("NAME_TAG") || name.equals("SADDLE") || name.equals("NAUTILUS_SHELL")) {
                fishType = "TREASURE";
            } else if (name.equals("COD") || name.equals("SALMON") || name.equals("TROPICAL_FISH") || name.equals("PUFFERFISH")) {
                fishType = name;
            }
        }
        JobData jd = data.getOrCreateJob(jobId);
        double pay = jobs.getJobManager().getFishPay(jobId, fishType, jd);
        if (pay <= 0.0) return;
        payOut(player, data, jobId, pay);
        jobs.getPlayerDataManager().save(player.getUniqueId());
    }

    private void payOut(Player player, PlayerData data, String jobId, double basePay) {
        BoosterAPI.BoosterResult boost = BoosterAPI.getBoost(jobs.plugin, player, jobId);
        int xp = (int) Math.round(jobs.getJobManager().getXpPerAction() * boost.xpMultiplier());
        double finalPay = basePay * boost.moneyMultiplier();
        double paid = jobs.getJobManager().pay(player, data, jobId, finalPay);
        jobs.getJobManager().giveXp(player, data, jobId, xp);
        jobs.getJobsBar().notifyAction(player, jobId, xp, paid); // Bar zeigt nur den Job, den man gerade ausübt
    }
}
