package de.craftsucht.core.economy;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class EconomyCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final EconomyManager manager;
    private final String symbol;

    public EconomyCommand(SpookyCraftCore plugin, EconomyManager manager) {
        this.plugin = plugin;
        this.manager = manager;
        this.symbol = plugin.getConfig().getString("economy.currency-symbol", "$");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (label.toLowerCase()) {
            case "balance": return handleBalance(sender, args);
            case "pay": return handlePay(sender, args);
            case "baltop": return handleBaltop(sender);
            case "eco": return handleEco(sender, args);
        }
        return false;
    }

    private boolean handleBalance(CommandSender sender, String[] args) {
        OfflinePlayer target = args.length > 0 ? Bukkit.getOfflinePlayer(args[0]) : (sender instanceof Player p ? p : null);
        if (target == null) {
            plugin.getMessageUtil().send(sender, "&cSpieler angeben: /balance <spieler>");
            return true;
        }
        double bal = manager.getBalance(target.getUniqueId());
        plugin.getMessageUtil().send(sender, "&7Kontostand von &b" + target.getName() + "&7: &a" + symbol + String.format("%.2f", bal));
        return true;
    }

    private boolean handlePay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cNur als Spieler nutzbar.");
            return true;
        }
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /pay <spieler> <betrag>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        double amount;
        try {
            amount = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            plugin.getMessageUtil().send(sender, "&cUngültiger Betrag.");
            return true;
        }
        if (amount <= 0) {
            plugin.getMessageUtil().send(sender, "&cBetrag muss positiv sein.");
            return true;
        }
        if (!manager.withdraw(player.getUniqueId(), amount)) {
            plugin.getMessageUtil().send(sender, "&cNicht genug Geld.");
            return true;
        }
        manager.deposit(target.getUniqueId(), amount);
        plugin.getMessageUtil().send(sender, "&aDu hast " + target.getName() + " " + symbol + formatAmount(amount) + " gegeben.");
        if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(), "&a" + player.getName() + " hat dir " + symbol + formatAmount(amount) + " gegeben.");
        }
        return true;
    }

    private boolean handleBaltop(CommandSender sender) {
        Map<String, Double> top = manager.getTop(10);
        plugin.getMessageUtil().sendRaw(sender, "&8--- &bTop 10 Kontostände &8---");
        int i = 1;
        for (Map.Entry<String, Double> entry : top.entrySet()) {
            plugin.getMessageUtil().sendRaw(sender, "&7#" + i++ + " &b" + entry.getKey() + " &7- &a" + symbol + String.format("%.2f", entry.getValue()));
        }
        return true;
    }

    private boolean handleEco(CommandSender sender, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("craftsucht.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cKeine Berechtigung.");
            return true;
        }
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /eco <give|take|set> <spieler> <betrag>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            plugin.getMessageUtil().send(sender, "&cUngültiger Betrag.");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give" -> {
                manager.deposit(target.getUniqueId(), amount);
                if (sender instanceof Player p && p.getUniqueId().equals(target.getUniqueId())) {
                    plugin.getMessageUtil().send(sender, "&aDu hast dir selber " + symbol + formatAmount(amount) + " zum Konto hinzugefügt.");
                } else {
                    plugin.getMessageUtil().send(sender, "&aDu hast &b" + target.getName() + " &a"
                            + symbol + formatAmount(amount) + " zum Konto hinzugefügt.");
                }
            }
            case "take" -> {
                manager.withdraw(target.getUniqueId(), amount);
                plugin.getMessageUtil().send(sender, "&aDu hast " + target.getName() + " " + symbol + formatAmount(amount) + " abgezogen.");
            }
            case "set" -> {
                manager.setBalance(target.getUniqueId(), amount);
                plugin.getMessageUtil().send(sender, "&aKontostand von " + target.getName() + " auf " + symbol + formatAmount(amount) + " gesetzt.");
                if (target.isOnline() && target.getPlayer() != null) {
                    plugin.getMessageUtil().send(target.getPlayer(), "&aDein Kontostand wurde auf " + symbol + formatAmount(amount) + " gesetzt.");
                }
            }
            default -> {
                plugin.getMessageUtil().send(sender, "&cUnbekannte Aktion.");
                return true;
            }
        }
        return true;
    }

    private String formatAmount(double amount) {
        return amount == Math.floor(amount) ? String.valueOf((long) amount) : String.format("%.2f", amount);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("balance") && args.length == 1) {
            return TabCompleteUtil.onlinePlayers(args[0]);
        }
        if (label.equalsIgnoreCase("pay") && args.length == 1) {
            return TabCompleteUtil.onlinePlayers(args[0]);
        }
        if (label.equalsIgnoreCase("eco")) {
            if (args.length == 1) return TabCompleteUtil.filter(args[0], "give", "take", "set");
            if (args.length == 2) return TabCompleteUtil.onlinePlayers(args[1]);
        }
        return Collections.emptyList();
    }
}
