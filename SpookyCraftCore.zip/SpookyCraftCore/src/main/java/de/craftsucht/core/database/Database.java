package de.craftsucht.core.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import de.craftsucht.core.SpookyCraftCore;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Shared SQLite database layer used by every module instead of separate
 * YAML files per plugin. Each module creates its own table(s) in migrate().
 */
public class Database {

    private final SpookyCraftCore plugin;
    private HikariDataSource dataSource;

    public Database(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void connect() {
        File dbFile = new File(plugin.getDataFolder(), "blockcity.db");
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }

        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
        config.setMaximumPoolSize(2);
        // Gegen "database is locked": parallele Zugriffe warten statt abzubrechen
        config.addDataSourceProperty("journal_mode", "WAL");
        config.addDataSourceProperty("synchronous", "NORMAL");
        config.addDataSourceProperty("busy_timeout", "15000");
        config.setPoolName("SpookyCraft-Pool");
        this.dataSource = new HikariDataSource(config);
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    /** Creates all module tables. Safe to call repeatedly (IF NOT EXISTS). */
    public void migrate() {
        String[] statements = {
            "CREATE TABLE IF NOT EXISTS economy (uuid TEXT PRIMARY KEY, balance REAL NOT NULL DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS punishments (id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, type TEXT, reason TEXT, staff TEXT, created_at INTEGER, expires_at INTEGER, active INTEGER DEFAULT 1)",
            "CREATE TABLE IF NOT EXISTS homes (uuid TEXT, name TEXT, world TEXT, x REAL, y REAL, z REAL, yaw REAL, pitch REAL, PRIMARY KEY (uuid, name))",
            "CREATE TABLE IF NOT EXISTS warps (name TEXT PRIMARY KEY, world TEXT, x REAL, y REAL, z REAL, yaw REAL, pitch REAL)",
            "CREATE TABLE IF NOT EXISTS mail (id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT, sender TEXT, message TEXT, sent_at INTEGER, read INTEGER DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS nicknames (uuid TEXT PRIMARY KEY, nickname TEXT)",
            "CREATE TABLE IF NOT EXISTS friends (uuid TEXT, friend_uuid TEXT, since INTEGER, PRIMARY KEY (uuid, friend_uuid))",
            "CREATE TABLE IF NOT EXISTS clans (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, tag TEXT, color TEXT, owner TEXT, created_at INTEGER)",
            "CREATE TABLE IF NOT EXISTS clan_members (clan_id INTEGER, uuid TEXT PRIMARY KEY, rank TEXT)",
            "CREATE TABLE IF NOT EXISTS stats (uuid TEXT PRIMARY KEY, playtime_seconds INTEGER DEFAULT 0, blocks_broken INTEGER DEFAULT 0, kills INTEGER DEFAULT 0, deaths INTEGER DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS kit_cooldowns (uuid TEXT, kit_name TEXT, last_used INTEGER, PRIMARY KEY (uuid, kit_name))",
            "CREATE TABLE IF NOT EXISTS auctions (id INTEGER PRIMARY KEY AUTOINCREMENT, seller TEXT, item_data TEXT, price REAL, listed_at INTEGER, sold INTEGER DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY AUTOINCREMENT, reporter TEXT, target TEXT, reason TEXT, created_at INTEGER, handled INTEGER DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS ranks (name TEXT PRIMARY KEY, prefix TEXT, weight INTEGER DEFAULT 0, parent TEXT)",
            "CREATE TABLE IF NOT EXISTS rank_permissions (rank TEXT, permission TEXT, value INTEGER, PRIMARY KEY (rank, permission))",
            "CREATE TABLE IF NOT EXISTS user_ranks (uuid TEXT PRIMARY KEY, rank TEXT)",
            "CREATE TABLE IF NOT EXISTS itemdb_items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, search_name TEXT NOT NULL, item_data TEXT NOT NULL, added_by TEXT NOT NULL, added_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS jobs_players (uuid TEXT PRIMARY KEY, job TEXT, level INTEGER NOT NULL DEFAULT 1, xp INTEGER NOT NULL DEFAULT 0, total_earned INTEGER NOT NULL DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS jobs_player_jobs (uuid TEXT NOT NULL, job TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1, xp INTEGER NOT NULL DEFAULT 0, total_earned INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (uuid, job))",
            "CREATE TABLE IF NOT EXISTS player_prefix_color (uuid TEXT PRIMARY KEY, color TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS bank_accounts (uuid TEXT PRIMARY KEY, balance REAL NOT NULL DEFAULT 0)"
        };

        try (Connection connection = getConnection(); Statement statement = connection.createStatement()) {
            for (String sql : statements) {
                statement.execute(sql);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Datenbank-Migration fehlgeschlagen: " + e.getMessage());
        }
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
