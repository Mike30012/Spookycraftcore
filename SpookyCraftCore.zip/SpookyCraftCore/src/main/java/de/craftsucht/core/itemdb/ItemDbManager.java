package de.craftsucht.core.itemdb;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class ItemDbManager {

    private final SpookyCraftCore plugin;

    public ItemDbManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    /**
     * Fügt ein Item (immer amount=1) der Datenbank hinzu.
     */
    public boolean addItem(String displayName, ItemStack item, String addedBy) {
        String sql = "INSERT INTO itemdb_items (name, search_name, item_data, added_by, added_at) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = plugin.getDatabase().getConnection()) {
            String base64 = ItemSerializer.toBase64(item);
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, displayName);
                ps.setString(2, stripForSearch(displayName));
                ps.setString(3, base64);
                ps.setString(4, addedBy);
                ps.setString(5, java.time.LocalDateTime.now().toString());
                ps.executeUpdate();
            }
            return true;
        } catch (IOException | SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Konnte Item nicht speichern", e);
            return false;
        }
    }

    /**
     * Sucht Items, deren Name den Suchbegriff enthält.
     */
    public List<DBEntry> search(String query) {
        List<DBEntry> results = new ArrayList<>();
        String sql = "SELECT id, name, item_data, added_by FROM itemdb_items WHERE search_name LIKE ? ORDER BY id DESC";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%" + stripForSearch(query) + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    addRowToList(rs, results);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Fehler bei der Item-Suche", e);
        }
        return results;
    }

    /**
     * Gibt alle gespeicherten Items zurück (für /db see).
     */
    public List<DBEntry> getAll() {
        List<DBEntry> results = new ArrayList<>();
        String sql = "SELECT id, name, item_data, added_by FROM itemdb_items ORDER BY id DESC";
        try (Connection c = plugin.getDatabase().getConnection();
             Statement statement = c.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {
            while (rs.next()) {
                addRowToList(rs, results);
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Fehler beim Laden aller Items", e);
        }
        return results;
    }

    private void addRowToList(ResultSet rs, List<DBEntry> results) throws SQLException {
        try {
            int id = rs.getInt("id");
            String name = rs.getString("name");
            String addedBy = rs.getString("added_by");
            ItemStack item = ItemSerializer.fromBase64(rs.getString("item_data"));
            results.add(new DBEntry(id, name, item, addedBy));
        } catch (IOException | ClassNotFoundException e) {
            plugin.getLogger().log(Level.WARNING, "Konnte gespeichertes Item nicht laden (Eintrag übersprungen)", e);
        }
    }

    private String stripForSearch(String input) {
        return org.bukkit.ChatColor.stripColor(input).toLowerCase();
    }

    /** Einzelne Wörter aus allen gespeicherten Item-Namen, gefiltert nach Präfix - für Tab-Completion bei /db search. */
    public List<String> getKnownWords(String prefix) {
        java.util.Set<String> words = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        String sql = "SELECT DISTINCT name FROM itemdb_items";
        try (Connection c = plugin.getDatabase().getConnection();
             Statement statement = c.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {
            while (rs.next()) {
                for (String word : rs.getString("name").split("\\s+")) {
                    if (!word.isBlank()) {
                        words.add(ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', word)));
                    }
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.WARNING, "Fehler beim Laden der Item-Namen für Tab-Completion", e);
        }
        String lower = prefix.toLowerCase();
        List<String> result = new ArrayList<>();
        for (String word : words) {
            if (word.toLowerCase().startsWith(lower)) {
                result.add(word);
            }
        }
        return result;
    }
}
