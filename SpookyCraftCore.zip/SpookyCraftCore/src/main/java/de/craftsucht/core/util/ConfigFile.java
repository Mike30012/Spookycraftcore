package de.craftsucht.core.util;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ändert einen einzelnen Wert in der config.yml direkt im Text - so bleiben alle Kommentare erhalten
 * (anders als bei saveConfig(), das die Datei komplett neu schreibt).
 */
public final class ConfigFile {

    private ConfigFile() {
    }

    private static int indent(String line) {
        int i = 0;
        while (i < line.length() && line.charAt(i) == ' ') i++;
        return i;
    }

    /**
     * Setzt "key: rawValue" direkt unterhalb der Section (z.B. section "modules", key "anticheat").
     * rawValue wird 1:1 geschrieben (Strings also bereits in Anführungszeichen übergeben).
     * Danach wird die Config neu geladen. @return false, wenn die Datei nicht angepasst werden konnte.
     */
    public static boolean setValue(JavaPlugin plugin, String section, String key, String rawValue) {
        File file = new File(plugin.getDataFolder(), "config.yml");
        try {
            List<String> lines = new ArrayList<>(Files.readAllLines(file.toPath(), StandardCharsets.UTF_8));
            int sectionIdx = -1;
            int sectionIndent = 0;
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).trim().equals(section + ":")) {
                    sectionIdx = i;
                    sectionIndent = indent(lines.get(i));
                    break;
                }
            }
            if (sectionIdx < 0) return false;

            Pattern keyPattern = Pattern.compile("^(\\s+)" + Pattern.quote(key) + ":.*$");
            boolean done = false;
            for (int i = sectionIdx + 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String trimmed = line.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;
                if (indent(line) <= sectionIndent) break; // Section zu Ende
                Matcher m = keyPattern.matcher(line);
                if (m.matches()) {
                    lines.set(i, m.group(1) + key + ": " + rawValue);
                    done = true;
                    break;
                }
            }
            if (!done) {
                lines.add(sectionIdx + 1, " ".repeat(sectionIndent + 2) + key + ": " + rawValue);
            }
            Files.write(file.toPath(), lines, StandardCharsets.UTF_8);
            plugin.reloadConfig();
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
