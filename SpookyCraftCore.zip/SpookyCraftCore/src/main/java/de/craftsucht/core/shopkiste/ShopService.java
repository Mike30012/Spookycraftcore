package de.craftsucht.core.shopkiste;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Shopkisten nach OPSUCHT-Vorbild:
 * Schild-Zeilen: 1 Besitzer (leer lassen), 2 Menge pro Transaktion, 3 "B <Kaufpreis> : <Ankaufspreis> S", 4 Item oder "?".
 * Rechtsklick auf das Schild = kaufen, Linksklick = verkaufen, Sneak+Rechtsklick = eigene Anzahl wählen.
 * Pro erfolgreicher Transaktion zahlt der Shop-Besitzer 1 % des Transaktionswerts als Gebühr.
 */
public class ShopService {

    public static final int MAX_AMOUNT = 2304; // 36 Stacks à 64

    private static final Pattern PRICE_BS = Pattern.compile("^(?:B(\\d+(?:[.,]\\d+)?))?(?::?(\\d+(?:[.,]\\d+)?)S)?$");
    private static final Pattern PRICE_COLON = Pattern.compile("^(\\d+(?:[.,]\\d+)?):(\\d+(?:[.,]\\d+)?)$");

    private final SpookyCraftCore plugin;
    private final ShopRepository repo;
    private final NamespacedKey notifyOffKey;

    public ShopService(SpookyCraftCore plugin, ShopRepository repo) {
        this.plugin = plugin;
        this.repo = repo;
        this.notifyOffKey = new NamespacedKey(plugin, "cs_notify_off");
    }

    // ------------------------------------------------------------------ Hilfen

    private EconomyManager eco() {
        EconomyModule module = (EconomyModule) plugin.getModuleManager().get("economy");
        return module != null ? module.getManager() : null;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    private double feeRate() {
        return Math.max(0.0, plugin.getConfig().getDouble("shopkiste.fee-percent", 1.0)) / 100.0;
    }

    public static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    public static String fmt(double v) {
        return String.format(Locale.GERMANY, "%,.2f", v);
    }

    private static double num(String s) {
        return Double.parseDouble(s.replace(',', '.'));
    }

    /** @return {kaufpreis, ankaufspreis} (-1 = nicht vorhanden) oder null, wenn die Zeile kein gültiges Preisformat ist */
    public static double[] parsePrices(String raw) {
        if (raw == null) return null;
        String line = raw.replace(" ", "").toUpperCase(Locale.ROOT);
        if (line.isEmpty()) return null;
        Matcher m = PRICE_BS.matcher(line);
        if (m.matches() && (m.group(1) != null || m.group(2) != null)) {
            return new double[]{m.group(1) != null ? num(m.group(1)) : -1, m.group(2) != null ? num(m.group(2)) : -1};
        }
        Matcher c = PRICE_COLON.matcher(line);
        if (c.matches()) {
            return new double[]{num(c.group(1)), num(c.group(2))};
        }
        return null;
    }

    private static String number(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.2f", v);
    }

    public static String priceLine(double buy, double sell) {
        String text;
        if (buy >= 0 && sell >= 0) {
            text = "B " + number(buy) + " : " + number(sell) + " S";
            if (text.length() > 15) text = "B" + number(buy) + ":" + number(sell) + "S";
        } else if (buy >= 0) {
            text = "B " + number(buy);
        } else {
            text = number(sell) + " S";
        }
        return text;
    }

    public static String itemName(ItemStack item) {
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            return org.bukkit.ChatColor.stripColor(item.getItemMeta().getDisplayName());
        }
        StringBuilder sb = new StringBuilder();
        for (String part : item.getType().name().toLowerCase().split("_")) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    public static String signItemLine(ItemStack item) {
        String name = itemName(item);
        return name.length() > 15 ? name.substring(0, 15) : name;
    }

    // ------------------------------------------------------------------ Inventar-Helfer (nur Storage-Slots)

    public static int countSimilar(Inventory inv, ItemStack template) {
        int count = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            if (stack != null && stack.isSimilar(template)) count += stack.getAmount();
        }
        return count;
    }

    public static int freeSpace(Inventory inv, ItemStack template) {
        int max = Math.max(1, template.getMaxStackSize());
        int space = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            if (stack == null || stack.getType().isAir()) {
                space += max;
            } else if (stack.isSimilar(template)) {
                space += Math.max(0, max - stack.getAmount());
            }
        }
        return space;
    }

    public static boolean removeSimilar(Inventory inv, ItemStack template, int count) {
        if (countSimilar(inv, template) < count) return false;
        ItemStack[] contents = inv.getStorageContents();
        int left = count;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack stack = contents[i];
            if (stack == null || !stack.isSimilar(template)) continue;
            int take = Math.min(left, stack.getAmount());
            if (take == stack.getAmount()) {
                contents[i] = null;
            } else {
                stack.setAmount(stack.getAmount() - take);
            }
            left -= take;
        }
        inv.setStorageContents(contents);
        return true;
    }

    public static boolean addSimilar(Inventory inv, ItemStack template, int count) {
        if (freeSpace(inv, template) < count) return false;
        int max = Math.max(1, template.getMaxStackSize());
        ItemStack[] contents = inv.getStorageContents();
        int left = count;
        for (int i = 0; i < contents.length && left > 0; i++) { // erst vorhandene Stacks auffüllen
            ItemStack stack = contents[i];
            if (stack == null || !stack.isSimilar(template) || stack.getAmount() >= max) continue;
            int add = Math.min(left, max - stack.getAmount());
            stack.setAmount(stack.getAmount() + add);
            left -= add;
        }
        for (int i = 0; i < contents.length && left > 0; i++) { // dann leere Slots
            if (contents[i] != null && !contents[i].getType().isAir()) continue;
            int add = Math.min(left, max);
            ItemStack fresh = template.clone();
            fresh.setAmount(add);
            contents[i] = fresh;
            left -= add;
        }
        inv.setStorageContents(contents);
        return true;
    }

    // ------------------------------------------------------------------ Shop-Daten

    public Container containerOf(ShopRecord shop) {
        World world = Bukkit.getWorld(shop.world());
        if (world == null) return null;
        Block block = world.getBlockAt(shop.cx(), shop.cy(), shop.cz());
        return block.getState() instanceof Container c ? c : null;
    }

    public int stockOf(ShopRecord shop) {
        Container container = containerOf(shop);
        return container == null ? 0 : countSimilar(container.getInventory(), shop.item());
    }

    public boolean isNotifyEnabled(Player p) {
        return !p.getPersistentDataContainer().has(notifyOffKey, PersistentDataType.BYTE);
    }

    public boolean toggleNotify(Player p) {
        if (isNotifyEnabled(p)) {
            p.getPersistentDataContainer().set(notifyOffKey, PersistentDataType.BYTE, (byte) 1);
            return false;
        }
        p.getPersistentDataContainer().remove(notifyOffKey);
        return true;
    }

    public boolean isAdmin(Player p) {
        return p.isOp() || p.hasPermission("spookycraft.core.admin") || p.hasPermission("spookycraft.shopkiste.admin");
    }

    // ------------------------------------------------------------------ Kaufen / Verkaufen

    /**
     * @param buying true = der Spieler KAUFT aus der Kiste, false = der Spieler VERKAUFT in die Kiste
     * @param count  Anzahl Items (Preis wird anteilig zum Schildpreis berechnet)
     */
    public boolean transact(Player player, ShopRecord shop, boolean buying, int count) {
        EconomyManager eco = eco();
        if (eco == null) {
            msg(player, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        if (count < 1 || count > MAX_AMOUNT) {
            msg(player, "&cUngültige Anzahl (1 bis " + MAX_AMOUNT + ").");
            return false;
        }
        UUID uuid = player.getUniqueId();
        if (uuid.equals(shop.owner())) {
            msg(player, "&cDu kannst nicht in deinem eigenen Shop handeln.");
            return false;
        }
        double price = buying ? shop.buy() : shop.sell();
        if (price < 0) {
            msg(player, buying ? "&cDieser Shop verkauft nichts - hier kann man nur verkaufen (Linksklick)."
                    : "&cDieser Shop kauft nichts an - hier kann man nur kaufen (Rechtsklick).");
            return false;
        }
        Container container = containerOf(shop);
        if (container == null) {
            msg(player, "&cDie Kiste dieses Shops existiert nicht mehr.");
            return false;
        }
        Inventory chest = container.getInventory();
        ItemStack template = shop.item();
        double total = round2(price * count / shop.amount());
        double fee = round2(total * feeRate());
        String what = count + "x " + itemName(template);

        if (buying) {
            if (countSimilar(chest, template) < count) {
                msg(player, "&cDer Shop hat nicht genug auf Lager.");
                return false;
            }
            if (freeSpace(player.getInventory(), template) < count) {
                msg(player, "&cDein Inventar ist zu voll.");
                return false;
            }
            if (!eco.withdraw(uuid, total)) {
                msg(player, "&cDir fehlen &f$" + fmt(total - eco.getBalance(uuid)) + "&c (Preis $" + fmt(total) + ").");
                return false;
            }
            removeSimilar(chest, template, count);
            addSimilar(player.getInventory(), template, count);
            eco.deposit(shop.owner(), round2(total - fee)); // Besitzer bekommt den Preis abzüglich 1 % Gebühr
            msg(player, "&a" + what + " gekauft für &f$" + fmt(total));
        } else {
            if (countSimilar(player.getInventory(), template) < count) {
                msg(player, "&cDu hast nicht genug davon im Inventar (" + what + ").");
                return false;
            }
            if (freeSpace(chest, template) < count) {
                msg(player, "&cDie Shopkiste ist voll.");
                return false;
            }
            if (!eco.withdraw(shop.owner(), round2(total + fee))) {
                msg(player, "&cDer Shop-Besitzer hat nicht genug Geld für diesen Ankauf.");
                return false;
            }
            removeSimilar(player.getInventory(), template, count);
            addSimilar(chest, template, count);
            eco.deposit(uuid, total); // Verkäufer bekommt den vollen Preis
            msg(player, "&a" + what + " verkauft für &f$" + fmt(total));
        }

        repo.logTransaction(shop.id(), player.getName(), buying ? "BUY" : "SELL", count, total, fee);
        Player owner = Bukkit.getPlayer(shop.owner());
        if (owner != null && isNotifyEnabled(owner)) {
            msg(owner, "&6Shopkiste: &f" + player.getName() + (buying ? " &akaufte " : " &6verkaufte ") + "&f" + what
                    + " &7für &f$" + fmt(total) + " &8(Gebühr $" + fmt(fee) + ")");
        }
        return true;
    }
}
