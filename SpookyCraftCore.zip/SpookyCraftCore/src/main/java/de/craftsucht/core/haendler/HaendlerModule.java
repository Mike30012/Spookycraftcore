package de.craftsucht.core.haendler;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.StaffCheck;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Witch;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Hexen-Haendler: eine Hexe am Spawn (/haendler set), taeglich wechselndes Angebot gegen Kristalle. */
public class HaendlerModule implements Module, CommandExecutor, TabCompleter, Listener {

    private record Offer(Material mat, int amount, String name, long price) {
    }

    private static final Offer[] POOL = {
            new Offer(Material.ENCHANTED_GOLDEN_APPLE, 1, "Verzauberter Goldapfel", 40),
            new Offer(Material.TOTEM_OF_UNDYING, 1, "Totem der Unsterblichkeit", 60),
            new Offer(Material.NETHERITE_INGOT, 1, "Netherit-Barren", 120),
            new Offer(Material.DIAMOND_BLOCK, 2, "Diamantblock", 50),
            new Offer(Material.EXPERIENCE_BOTTLE, 32, "Erfahrungsfläschchen", 25),
            new Offer(Material.ENDER_PEARL, 16, "Enderperlen", 20),
            new Offer(Material.GOLDEN_CARROT, 32, "Goldene Karotten", 10),
            new Offer(Material.SPECTRAL_ARROW, 32, "Leuchtpfeile", 8),
            new Offer(Material.WITHER_SKELETON_SKULL, 1, "Wither-Schädel", 70),
            new Offer(Material.SHULKER_SHELL, 2, "Schulkerschalen", 45),
            new Offer(Material.TRIDENT, 1, "Dreizack", 90),
            new Offer(Material.ELYTRA, 1, "Elytra", 250),
            new Offer(Material.BEACON, 1, "Leuchtfeuer", 160),
            new Offer(Material.PUMPKIN_PIE, 16, "Kürbiskuchen", 6),
            new Offer(Material.JACK_O_LANTERN, 16, "Kürbislaternen", 6),
            new Offer(Material.SCULK_SENSOR, 4, "Sculk-Sensoren", 15)
    };
    private static final int OFFERS_PER_DAY = 5;

    private final SpookyCraftCore plugin;
    private NamespacedKey key;

    public HaendlerModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "haendler";
    }

    @Override
    public void enable() {
        key = new NamespacedKey(plugin, "hexenhaendler");
        plugin.getCommand("haendler").setExecutor(this);
        plugin.getCommand("haendler").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        org.bukkit.event.HandlerList.unregisterAll(this);
    }

    private static class ShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private List<Offer> today() {
        Random r = new Random(LocalDate.now().toEpochDay() * 7919L + 13);
        List<Offer> all = new ArrayList<>(List.of(POOL));
        java.util.Collections.shuffle(all, r);
        return all.subList(0, OFFERS_PER_DAY);
    }

    private boolean isTrader(Entity e) {
        return e.getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(new ShopHolder(), 27, c("&5☠ &dHexen-Händler"));
        ItemStack fill = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = fill.getItemMeta();
        fm.setDisplayName(" ");
        fill.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, fill);
        long have = 0;
        if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null)
            have = cm.getCrystals().get(p.getUniqueId());
        List<Offer> offers = today();
        int[] slots = {10, 11, 13, 15, 16};
        for (int i = 0; i < offers.size(); i++) {
            Offer o = offers.get(i);
            ItemStack it = new ItemStack(o.mat(), o.amount());
            ItemMeta m = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(c("&7Preis: &b" + o.price() + " Kristalle"));
            lore.add(c(have >= o.price() ? "&aKlicken zum Kaufen" : "&cDir fehlen &b" + (o.price() - have) + " Kristalle"));
            lore.add(c("&8#" + i));
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(slots[i], it);
        }
        ItemStack info = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&bDeine Kristalle: &f" + have));
        im.setLore(List.of(c("&7Das Angebot wechselt jeden Tag!")));
        info.setItemMeta(im);
        inv.setItem(22, info);
        p.openInventory(inv);
        p.playSound(p.getLocation(), "entity.witch.celebrate", 0.7f, 0.9f);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!isTrader(e.getRightClicked())) return;
        e.setCancelled(true);
        open(e.getPlayer());
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (isTrader(e.getEntity())) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ShopHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || !it.hasItemMeta() || it.getItemMeta().getLore() == null) return;
        List<String> lore = it.getItemMeta().getLore();
        String last = ChatColor.stripColor(lore.get(lore.size() - 1));
        if (!last.startsWith("#")) return;
        int idx;
        try {
            idx = Integer.parseInt(last.substring(1));
        } catch (NumberFormatException ex) {
            return;
        }
        List<Offer> offers = today();
        if (idx < 0 || idx >= offers.size()) return;
        Offer o = offers.get(idx);
        if (!(plugin.getModuleManager().get("crates") instanceof CratesModule cm) || cm.getCrystals() == null) return;
        if (!cm.getCrystals().take(p.getUniqueId(), o.price())) {
            plugin.getMessageUtil().send(p, "&cDie Hexe lacht: &7Dir fehlen Kristalle für &f" + o.name() + "&7!");
            p.playSound(p.getLocation(), "entity.villager.no", 1f, 0.8f);
            return;
        }
        var left = p.getInventory().addItem(new ItemStack(o.mat(), o.amount()));
        for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
        plugin.getMessageUtil().send(p, "&5☠ &dDie Hexe reicht dir &f" + o.amount() + "x " + o.name() + "&d. &7(-" + o.price() + " Kristalle)");
        p.playSound(p.getLocation(), "entity.witch.drink", 1f, 1f);
        p.getWorld().spawnParticle(Particle.WITCH, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.02);
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        String sub = args.length == 0 ? "" : args[0].toLowerCase();
        if (sub.equals("set") || sub.equals("remove")) {
            if (!StaffCheck.isStaff(plugin, p)) {
                plugin.getMessageUtil().send(p, "&cKeine Berechtigung.");
                return true;
            }
            if (sub.equals("set")) {
                Witch w = p.getWorld().spawn(p.getLocation(), Witch.class, t -> {
                    t.setAI(false);
                    t.setInvulnerable(true);
                    t.setSilent(true);
                    t.setPersistent(true);
                    t.setRemoveWhenFarAway(false);
                    t.setCanPickupItems(false);
                    t.customName(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize("&5&lHexen-Händler"));
                    t.setCustomNameVisible(true);
                    t.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
                });
                plugin.getMessageUtil().send(p, "&aHexen-Händler aufgestellt.");
            } else {
                int n = 0;
                for (Entity e : p.getNearbyEntities(6, 6, 6)) {
                    if (isTrader(e)) {
                        e.remove();
                        n++;
                    }
                }
                plugin.getMessageUtil().send(p, n > 0 ? "&aHändler entfernt." : "&7Kein Händler im Umkreis von 6 Blöcken.");
            }
            return true;
        }
        open(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && StaffCheck.isStaff(plugin, sender))
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "set", "remove");
        return List.of();
    }
}
