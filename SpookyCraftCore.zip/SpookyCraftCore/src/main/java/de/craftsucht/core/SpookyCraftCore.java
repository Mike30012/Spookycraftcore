package de.craftsucht.core;

import de.craftsucht.core.database.Database;
import de.craftsucht.core.module.ModuleManager;
import de.craftsucht.core.util.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import de.craftsucht.core.util.ConfigFile;
import de.craftsucht.core.util.TabCompleteUtil;

import java.util.Collections;
import java.util.List;
import org.bukkit.plugin.java.JavaPlugin;

public final class SpookyCraftCore extends JavaPlugin {

    private static SpookyCraftCore instance;
    private Database database;
    private ModuleManager moduleManager;
    private MessageUtil messageUtil;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.messageUtil = new MessageUtil(this);
        this.database = new Database(this);
        this.database.connect();
        this.database.migrate();

        this.moduleManager = new ModuleManager(this);
        this.moduleManager.registerAll();
        this.moduleManager.enableEnabled();

        getServer().getPluginManager().registerEvents(new de.craftsucht.core.util.SpookyMessages(), this);
        getLogger().info("SpookyCraftCore aktiviert - " + moduleManager.getEnabledCount() + " Module geladen.");
    }

    /** Fuer Multiverse/bukkit.yml: "generator: SpookyCraftCore:inseln" oder ":gebirge". */
    @Override
    public org.bukkit.generator.ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        String style = (id == null || id.isBlank()) ? de.craftsucht.core.farmreset.FarmGenerator.INSELN : id;
        return de.craftsucht.core.farmreset.FarmGenerator.isCustom(style)
                ? new de.craftsucht.core.farmreset.FarmGenerator(style) : null;
    }

    @Override
    public void onDisable() {
        if (moduleManager != null) {
            moduleManager.disableAll();
        }
        if (database != null) {
            database.close();
        }
        getLogger().info("SpookyCraftCore deaktiviert.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("bccore")) {
            if (!sender.isOp() && !sender.hasPermission("spookycraft.core.admin")) {
                messageUtil.send(sender, "&cKeine Berechtigung.");
                return true;
            }
            if (args.length == 0) {
                messageUtil.send(sender, "&7/bccore reload | modules | enable <modul> | disable <modul> | discord [link]");
                return true;
            }
            if (args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                moduleManager.reloadAll();
                messageUtil.send(sender, "&aSpookyCraftCore neu geladen.");
                return true;
            }
            if (args[0].equalsIgnoreCase("modules")) {
                moduleManager.listModules(sender);
                return true;
            }
            if (args[0].equalsIgnoreCase("enable") || args[0].equalsIgnoreCase("disable")) {
                if (args.length < 2) {
                    messageUtil.send(sender, "&cNutzung: /bccore " + args[0].toLowerCase() + " <modul>  (Module siehe /bccore modules)");
                    return true;
                }
                boolean on = args[0].equalsIgnoreCase("enable");
                String id = args[1].toLowerCase();
                String error = moduleManager.setEnabled(id, on);
                if (error != null) {
                    messageUtil.send(sender, "&c" + error);
                } else {
                    messageUtil.send(sender, "&aModul &e" + id + " &awurde " + (on ? "aktiviert" : "deaktiviert") + " und in der config.yml gespeichert.");
                }
                return true;
            }
            if (args[0].equalsIgnoreCase("discord")) {
                if (args.length < 2) {
                    String current = getConfig().getString("punishment.ban-screen.discord", "");
                    messageUtil.send(sender, "&7Discord-Link im Ban-Screen: " + (current.isEmpty() ? "&cnicht gesetzt" : "&f" + current));
                    messageUtil.send(sender, "&7Setzen: &e/bccore discord <link> &7| Entfernen: &e/bccore discord off");
                    return true;
                }
                String link = args[1];
                if (link.equalsIgnoreCase("off") || link.equals("-")) {
                    link = "";
                } else if (!link.startsWith("http") || link.contains("\"") || link.contains("\\")) {
                    messageUtil.send(sender, "&cBitte einen gültigen Link angeben, z.B. https://discord.gg/deinlink");
                    return true;
                }
                if (!ConfigFile.setValue(this, "ban-screen", "discord", "\"" + link + "\"")) {
                    getConfig().set("punishment.ban-screen.discord", link);
                    saveConfig();
                }
                messageUtil.send(sender, link.isEmpty() ? "&aDiscord-Link entfernt." : "&aDiscord-Link gesetzt: &f" + link + " &7(erscheint ab sofort im Ban-Screen)");
                return true;
            }
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!label.equalsIgnoreCase("bccore") || (!sender.isOp() && !sender.hasPermission("spookycraft.core.admin"))) {
            return Collections.emptyList();
        }
        if (args.length == 1) return TabCompleteUtil.filter(args[0], "reload", "modules", "enable", "disable", "discord");
        if (args.length == 2 && (args[0].equalsIgnoreCase("enable") || args[0].equalsIgnoreCase("disable"))) {
            return TabCompleteUtil.filter(args[1], moduleManager.getModuleIds());
        }
        return Collections.emptyList();
    }

    public static SpookyCraftCore getInstance() {
        return instance;
    }

    public Database getDatabase() {
        return database;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public MessageUtil getMessageUtil() {
        return messageUtil;
    }
}
