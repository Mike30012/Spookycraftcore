package de.craftsucht.core.farmreset;

import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.EntityType;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;
import org.bukkit.loot.LootTables;

import java.util.Random;

/**
 * Versteckte Dungeons unter der Erde der Farmwelt: Raum ohne Eingang (man findet ihn beim Graben/Hoehlen),
 * Material passend zum Biom, fester Boss + Waechter (kein Spawner), Loot-Kisten, Spinnweben. Liegt komplett innerhalb des Chunks.
 */
public class DungeonPopulator extends BlockPopulator {

    /** Wahrscheinlichkeit pro Chunk (1 von N). */
    private static final int CHANCE = 22;
    private final FarmGenerator gen;

    public DungeonPopulator(FarmGenerator gen) {
        this.gen = gen;
    }

    @Override
    public void populate(WorldInfo info, Random rnd, int chunkX, int chunkZ, LimitedRegion region) {
        if (rnd.nextInt(CHANCE) != 0) return;
        // Raumgroesse (Innenraum) 5..9 x 4 x 5..9, inkl. Wand max 11 -> passt in den Chunk (16)
        int sx = 5 + rnd.nextInt(3) * 2;
        int sz = 5 + rnd.nextInt(3) * 2;
        int ih = 4;
        int x0 = chunkX * 16 + rnd.nextInt(16 - (sx + 2) + 1);
        int z0 = chunkZ * 16 + rnd.nextInt(16 - (sz + 2) + 1);
        int cx = x0 + (sx + 2) / 2;
        int cz = z0 + (sz + 2) / 2;
        int surface = gen.height(cx, cz);
        int minY = info.getMinHeight();
        int top = Math.min(surface - 8, 50);
        int bottom = minY + 10;
        if (top - bottom < 6) return;
        int y0 = bottom + rnd.nextInt(top - bottom - ih - 1);   // Bodenhoehe (unterste Wandebene)
        if (y0 + ih + 2 >= surface - 4) return;
        if (!region.isInRegion(x0, y0, z0) || !region.isInRegion(x0 + sx + 1, y0 + ih + 1, z0 + sz + 1)) return;

        org.bukkit.World world = org.bukkit.Bukkit.getWorld(info.getUID());
        Biome biome = gen.biomeAt(info.getSeed(), cx, y0, cz);
        Material[] wall = wallMaterials(biome, y0, info);
        boolean jungle = biome == Biome.JUNGLE || biome == Biome.SWAMP || biome == Biome.DARK_FOREST;

        // Huelle + Innenraum
        for (int x = 0; x < sx + 2; x++) {
            for (int z = 0; z < sz + 2; z++) {
                for (int y = 0; y < ih + 2; y++) {
                    boolean edge = x == 0 || z == 0 || x == sx + 1 || z == sz + 1 || y == 0 || y == ih + 1;
                    int wx = x0 + x, wy = y0 + y, wz = z0 + z;
                    if (edge) {
                        Material m = wall[rnd.nextInt(wall.length)];
                        if (jungle && rnd.nextInt(3) == 0) m = Material.MOSSY_STONE_BRICKS;
                        region.setType(wx, wy, wz, m);
                    } else {
                        region.setType(wx, wy, wz, Material.AIR);
                    }
                }
            }
        }
        // Spinnweben + Knochen/Deko
        for (int i = 0; i < 10; i++) {
            int wx = x0 + 1 + rnd.nextInt(sx), wz = z0 + 1 + rnd.nextInt(sz);
            region.setType(wx, y0 + ih, wz, Material.COBWEB);
        }
        // Sockel in der Mitte + fester Boss (KEIN Spawner -> keine Mobfarm)
        int mx = x0 + 1 + sx / 2, mz = z0 + 1 + sz / 2;
        region.setType(mx, y0 + 1, mz, wall[0]);
        try {
            spawnMob(world, region, mx + 0.5, y0 + 2, mz + 0.5, rnd, true);
            // 3-5 normale Waechter im Raum
            int n = 3 + rnd.nextInt(3);
            for (int i = 0; i < n; i++) {
                spawnMob(world, region, x0 + 1.5 + rnd.nextInt(sx), y0 + 1, z0 + 1.5 + rnd.nextInt(sz), rnd, false);
            }
        } catch (Exception ignored) {
            // Mobs sind nur Deko - der Raum bleibt auch ohne sie bestehen
        }
        // 2 Kisten an den Waenden (mit Dungeon-Loot)
        int chests = 2;
        for (int i = 0; i < chests; i++) {
            boolean alongX = rnd.nextBoolean();
            int wx, wz;
            BlockFace face;
            if (alongX) {
                wx = x0 + 1 + rnd.nextInt(sx);
                boolean north = rnd.nextBoolean();
                wz = north ? z0 + 1 : z0 + sz;
                face = north ? BlockFace.SOUTH : BlockFace.NORTH;
            } else {
                wz = z0 + 1 + rnd.nextInt(sz);
                boolean west = rnd.nextBoolean();
                wx = west ? x0 + 1 : x0 + sx;
                face = west ? BlockFace.EAST : BlockFace.WEST;
            }
            if (wx == mx && wz == mz) continue;
            region.setType(wx, y0 + 1, wz, Material.CHEST);
            org.bukkit.block.data.BlockData data = region.getBlockData(wx, y0 + 1, wz);
            if (data instanceof Directional d) {
                d.setFacing(face);
                region.setBlockData(wx, y0 + 1, wz, d);
            }
            BlockState cs = region.getBlockState(wx, y0 + 1, wz);
            if (cs instanceof Chest c) {
                c.setLootTable(rnd.nextInt(4) == 0 ? LootTables.ABANDONED_MINESHAFT.getLootTable() : LootTables.SIMPLE_DUNGEON.getLootTable(), rnd.nextLong());
                c.update(true, false);
            }
        }
        // Fackeln an den Ecken (leicht beleuchtet, wirkt "echt")
        int[][] corners = {{1, 1}, {sx, 1}, {1, sz}, {sx, sz}};
        for (int[] c : corners) {
            if (rnd.nextInt(2) == 0) region.setType(x0 + c[0], y0 + 1, z0 + c[1], Material.COBWEB);
        }
    }

    private static void spawnMob(org.bukkit.World world, LimitedRegion region, double x, double y, double z, Random rnd, boolean boss) {
        EntityType[] normal = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.HUSK};
        EntityType type = boss ? EntityType.WITHER_SKELETON : normal[rnd.nextInt(normal.length)];
        org.bukkit.entity.Entity e = region.spawnEntity(new org.bukkit.Location(world, x, y, z), type);
        if (e == null) return;
        if (e instanceof org.bukkit.entity.LivingEntity le) {
            le.setPersistent(true);
            le.setRemoveWhenFarAway(false);
            if (boss) {
                le.setCustomName("§c§lDungeon-Wächter");
                le.setCustomNameVisible(true);
                var hp = le.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH);
                if (hp != null) { hp.setBaseValue(80.0); le.setHealth(80.0); }
            }
        }
    }

    private static Material[] wallMaterials(Biome b, int y, WorldInfo info) {
        if (y < 0) return new Material[]{Material.DEEPSLATE_BRICKS, Material.CRACKED_DEEPSLATE_BRICKS, Material.DEEPSLATE_TILES};
        if (b == Biome.DESERT || b == Biome.SAVANNA || b == Biome.BEACH)
            return new Material[]{Material.SANDSTONE, Material.CUT_SANDSTONE, Material.SMOOTH_SANDSTONE};
        if (b == Biome.SNOWY_PLAINS || b == Biome.SNOWY_TAIGA || b == Biome.FROZEN_PEAKS || b == Biome.SNOWY_SLOPES || b == Biome.SNOWY_BEACH)
            return new Material[]{Material.STONE_BRICKS, Material.PACKED_ICE, Material.CRACKED_STONE_BRICKS};
        if (b == Biome.JUNGLE || b == Biome.SWAMP || b == Biome.DARK_FOREST)
            return new Material[]{Material.MOSSY_COBBLESTONE, Material.COBBLESTONE, Material.MOSSY_STONE_BRICKS};
        return new Material[]{Material.COBBLESTONE, Material.MOSSY_COBBLESTONE, Material.STONE_BRICKS, Material.CRACKED_STONE_BRICKS};
    }
}
