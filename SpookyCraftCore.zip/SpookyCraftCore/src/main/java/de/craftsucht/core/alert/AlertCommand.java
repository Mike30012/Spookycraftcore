package de.craftsucht.core.alert;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

/**
 * /alert <nachricht mit &-farbcodes> - broadcastet eine frei einfärbbare
 * Nachricht an alle Spieler, egal in welcher (Multiverse-)Welt sie gerade
 * sind. Läuft alles auf demselben Server-Prozess, daher reicht ein
 * Bukkit-weiter Broadcast, um "jeden Server" abzudecken.
 */
public class AlertCommand implements CommandExecutor, TabCompleter {

    private static final String[] COLOR_CODES = {
            "&0", "&1", "&2", "&3", "&4", "&5", "&6", "&7", "&8", "&9",
            "&a", "&b", "&c", "&d", "&e", "&f",
            "&k", "&l", "&m", "&n", "&o", "&r"
    };

    private final SpookyCraftCore plugin;

    public AlertCommand(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.core.alert") && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cKeine Berechtigung.");
            return true;
        }
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /alert <nachricht, z.B. &6Hallo &laller>");
            return true;
        }

        String raw = String.join(" ", args);
        String colored = plugin.getMessageUtil().color("&8[&6Alert&8] &r" + raw);

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(colored);
        }
        Bukkit.getConsoleSender().sendMessage(colored);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            return Collections.emptyList();
        }
        String current = args[args.length - 1];
        // Sobald ein "&" getippt wird, Farbcodes vorschlagen (z.B. "&" -> alle, "&6" -> nur &6).
        if (current.startsWith("&") || current.isEmpty()) {
            return TabCompleteUtil.filter(current, COLOR_CODES);
        }
        return Collections.emptyList();
    }
}
