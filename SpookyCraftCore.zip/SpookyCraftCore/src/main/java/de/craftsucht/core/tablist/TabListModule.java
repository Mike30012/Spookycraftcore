package de.craftsucht.core.tablist;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/** Simple header/footer tab-list branding; per-rank formatting can hook into LuckPerms later. */
public class TabListModule implements Module {

    private final SpookyCraftCore plugin;
    private BukkitTask task;

    public TabListModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "tablist";
    }

    @Override
    public void enable() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::update, 20L, 100L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
    }

    private void update() {
        String header = plugin.getMessageUtil().color("&6&lSpookyCraft\n&7Willkommen auf dem Server!");
        for (Player p : Bukkit.getOnlinePlayers()) {
            int count = plugin.getModuleManager().get("vanish") instanceof de.craftsucht.core.vanish.VanishModule vm
                    ? vm.visibleCount(p) : Bukkit.getOnlinePlayers().size();
            String footer = plugin.getMessageUtil().color("&7Online: &b" + count);
            if (plugin.getConfig().getBoolean("scoreboard.logo-tab", false)) {
                // Logo (Resource-Pack-Zeichen) statt "SpookyCraft"-Text, darunter die Willkommenszeile
                net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer ser =
                        net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection();
                net.kyori.adventure.text.Component logo = net.kyori.adventure.text.Component.text(
                        plugin.getConfig().getString("scoreboard.logo-char", "\uE000"))
                        .font(net.kyori.adventure.key.Key.key("spookycraft", "logo"));
                net.kyori.adventure.text.Component head = logo.append(net.kyori.adventure.text.Component.newline())
                        .append(plugin.getMessageUtil().styled(plugin.getMessageUtil().color("&7Willkommen auf dem Server!")));
                p.sendPlayerListHeaderAndFooter(head, plugin.getMessageUtil().styled(footer));
                continue;
            }
            p.sendPlayerListHeaderAndFooter(plugin.getMessageUtil().styled(header), plugin.getMessageUtil().styled(footer));
        }
    }
}
