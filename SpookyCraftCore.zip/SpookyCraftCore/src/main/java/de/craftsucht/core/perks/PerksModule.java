package de.craftsucht.core.perks;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.GameMode;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * /perks - dauerhafte Geister-Kräfte, die man mit Kristallen kauft und per Klick an/aus schaltet.
 * Liste in config.yml (perks.list), Besitz in perks.yml.
 */
public class PerksModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private BukkitTask task;

    public PerksModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "perks";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "perks.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("perks").setExecutor(this);
        plugin.getCommand("perkitem").setExecutor(this);
        plugin.getCommand("perkview").setExecutor(this);
        plugin.getCommand("fly").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 100L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        org.bukkit.event.HandlerList.unregisterAll(this);
        for (Player p : Bukkit.getOnlinePlayers()) clearAll(p);
        save();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("perks.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private List<Map<?, ?>> perks() {
        return plugin.getConfig().getMapList("perks.list");
    }

    private static String str(Map<?, ?> m, String k, String def) {
        Object o = m.get(k);
        return o == null ? def : String.valueOf(o);
    }

    private static int num(Map<?, ?> m, String k, int def) {
        try {
            return Integer.parseInt(str(m, k, String.valueOf(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private boolean owns(Player p, String id) {
        return data.getStringList(p.getUniqueId() + ".owned").contains(id);
    }

    private boolean enabled(Player p, String id) {
        return !data.getStringList(p.getUniqueId() + ".off").contains(id);
    }

    private void toggle(Player p, String id) {
        List<String> off = new ArrayList<>(data.getStringList(p.getUniqueId() + ".off"));
        if (!off.remove(id)) off.add(id);
        data.set(p.getUniqueId() + ".off", off);
        save();
    }

    private void grant(Player p, String id) {
        List<String> owned = new ArrayList<>(data.getStringList(p.getUniqueId() + ".owned"));
        if (!owned.contains(id)) owned.add(id);
        data.set(p.getUniqueId() + ".owned", owned);
        save();
    }

    // ------------------------------------------------------------------ Effekte

    private PotionEffectType type(Map<?, ?> m) {
        return PotionEffectType.getByKey(NamespacedKey.minecraft(str(m, "effect", "speed").toLowerCase(Locale.ROOT)));
    }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
    }

    /** Aktive Spezial-Perk-IDs (glow, nohunger, nofall, keepxp, keepinv, fly) des Spielers. */
    private boolean hasSpecial(Player p, String special) {
        for (Map<?, ?> m : perks()) {
            if (!str(m, "special", "").equalsIgnoreCase(special)) continue;
            String id = str(m, "id", "");
            if (owns(p, id) && enabled(p, id)) return true;
        }
        return false;
    }

    private boolean ownsSpecial(Player p, String special) {
        for (Map<?, ?> m : perks()) {
            if (str(m, "special", "").equalsIgnoreCase(special) && owns(p, str(m, "id", ""))) return true;
        }
        return false;
    }

    private void apply(Player p) {
        for (Map<?, ?> m : perks()) {
            String id = str(m, "id", "");
            PotionEffectType t = type(m);
            if (t == null || !m.containsKey("effect") || !owns(p, id) || !enabled(p, id)) continue;
            p.addPotionEffect(new PotionEffect(t, 260, Math.max(0, num(m, "amplifier", 0)), true, false, false));
        }
        boolean glow = hasSpecial(p, "glow");
        if (p.isGlowing() != glow && (glow || ownsSpecial(p, "glow"))) p.setGlowing(glow);
        if (ownsSpecial(p, "fly") && !hasSpecial(p, "fly") && p.getGameMode() == GameMode.SURVIVAL && p.getAllowFlight()
                && !flyAdmin.contains(p.getUniqueId())) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
    }

    private final java.util.Set<java.util.UUID> flyAdmin = java.util.concurrent.ConcurrentHashMap.newKeySet();

    private void clearAll(Player p) {
        for (Map<?, ?> m : perks()) {
            PotionEffectType t = type(m);
            if (t != null && m.containsKey("effect") && owns(p, str(m, "id", ""))) p.removePotionEffect(t);
        }
        if (ownsSpecial(p, "glow")) p.setGlowing(false);
    }

    // ------------------------------------------------------------------ Befehl + GUI

    private static class PerkHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cn = command.getName().toLowerCase(Locale.ROOT);
        if (cn.equals("fly")) {
            if (!(sender instanceof Player p)) return true;
            boolean admin = p.isOp() || p.hasPermission("perks.fly");
            if (!admin && !hasSpecial(p, "fly")) {
                plugin.getMessageUtil().send(p, "&cDie Geister haben dir noch nicht das Schweben gelehrt (Perk &fFlug&c).");
                return true;
            }
            boolean on = !p.getAllowFlight();
            p.setAllowFlight(on);
            if (!on) p.setFlying(false);
            if (on && admin) flyAdmin.add(p.getUniqueId()); else flyAdmin.remove(p.getUniqueId());
            plugin.getMessageUtil().send(p, on ? "&aDu schwebst wie ein Geist." : "&cDu bist wieder sterblich und fällst zur Erde.");
            return true;
        }
        if (cn.equals("perkitem")) {
            if (!(sender.isOp() || sender.hasPermission("perks.giveitem") || !(sender instanceof Player))) {
                plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
                return true;
            }
            if (args.length < 1) {
                plugin.getMessageUtil().send(sender, "&cNutzung: /perkitem <perk-id> [spieler]");
                return true;
            }
            Map<?, ?> found = null;
            for (Map<?, ?> m : perks()) if (str(m, "id", "").equalsIgnoreCase(args[0])) found = m;
            if (found == null) {
                plugin.getMessageUtil().send(sender, "&cDiese Kraft kennen die Geister nicht. IDs stehen in der config.yml (perks.list).");
                return true;
            }
            Player t = args.length >= 2 ? Bukkit.getPlayerExact(args[1]) : (sender instanceof Player sp ? sp : null);
            if (t == null) {
                plugin.getMessageUtil().send(sender, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
                return true;
            }
            ItemStack it = new ItemStack(Material.NETHER_STAR);
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(c("&5☠ &dPerk-Schriftrolle: " + str(found, "name", args[0])));
            meta.setLore(List.of(c("&7Rechtsklick, um die Kraft freizuschalten.")));
            meta.getPersistentDataContainer().set(itemKey(), PersistentDataType.STRING, str(found, "id", args[0]));
            it.setItemMeta(meta);
            t.getInventory().addItem(it).values().forEach(l -> t.getWorld().dropItemNaturally(t.getLocation(), l));
            plugin.getMessageUtil().send(sender, "&aPerk-Schriftrolle an " + t.getName() + " übergeben.");
            return true;
        }
        if (cn.equals("perkview")) {
            if (!(sender.isOp() || sender.hasPermission("perks.perkview") || !(sender instanceof Player))) {
                plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
                return true;
            }
            if (args.length < 1) {
                plugin.getMessageUtil().send(sender, "&cNutzung: /perkview <spieler>");
                return true;
            }
            Player t = Bukkit.getPlayerExact(args[0]);
            if (t == null) {
                plugin.getMessageUtil().send(sender, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
                return true;
            }
            plugin.getMessageUtil().send(sender, "&7--- &6☠ Kräfte von " + t.getName() + " &7---");
            for (Map<?, ?> m : perks()) {
                String id = str(m, "id", "");
                plugin.getMessageUtil().sendRaw(sender, "&8 - " + c(str(m, "name", id)) + " &8| "
                        + (owns(t, id) ? (enabled(t, id) ? "&aaktiv" : "&eaus") : "&cnicht freigeschaltet"));
            }
            return true;
        }
        if (args.length >= 3 && args[0].equalsIgnoreCase("give")) {
            if (!(sender.isOp() || sender.hasPermission("spookycraft.core.admin") || !(sender instanceof Player))) {
                plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
                return true;
            }
            Player t = Bukkit.getPlayerExact(args[1]);
            if (t == null) {
                plugin.getMessageUtil().send(sender, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
                return true;
            }
            grant(t, args[2]);
            plugin.getMessageUtil().send(sender, "&aDie Geister haben " + t.getName() + " die Kraft &e" + args[2] + " &averliehen.");
            return true;
        }
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        open(p);
        return true;
    }

    private void open(Player p) {
        List<Map<?, ?>> list = perks();
        int size = Math.max(27, ((list.size() + 8) / 9) * 9 + 9);
        size = Math.min(size, 54);
        Inventory inv = Bukkit.createInventory(new PerkHolder(), size, c("&5☠ &dGeister-Kräfte"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < size; i++) inv.setItem(i, filler);
        for (int i = 0; i < Math.min(list.size(), size - 9); i++) {
            Map<?, ?> m = list.get(i);
            String id = str(m, "id", "");
            Material mat = Material.matchMaterial(str(m, "icon", "PAPER"));
            ItemStack it = new ItemStack(mat == null ? Material.PAPER : mat);
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(c(str(m, "name", id)));
            List<String> lore = new ArrayList<>();
            lore.add(c("&7" + str(m, "desc", "Eine Kraft der Geister")));
            lore.add("");
            if (owns(p, id)) {
                lore.add(c(enabled(p, id) ? "&a✔ Aktiv &8- &7Klicken zum Ausschalten" : "&c✖ Aus &8- &7Klicken zum Einschalten"));
            } else {
                lore.add(c("&7Preis: &b" + num(m, "cost", 100) + " Kristalle"));
                lore.add(c("&eKlicken zum Kaufen"));
            }
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }
        long cr = crystalsOf(p);
        ItemStack info = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&bDeine Kristalle: &f" + cr));
        info.setItemMeta(im);
        inv.setItem(size - 5, info);
        p.openInventory(inv);
    }

    private long crystalsOf(Player p) {
        if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
            return cm.getCrystals().get(p.getUniqueId());
        }
        return 0;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof PerkHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        List<Map<?, ?>> list = perks();
        int slot = e.getSlot();
        if (slot < 0 || slot >= list.size()) return;
        Map<?, ?> m = list.get(slot);
        String id = str(m, "id", "");
        if (owns(p, id)) {
            toggle(p, id);
            PotionEffectType t = type(m);
            if (t != null && m.containsKey("effect") && !enabled(p, id)) p.removePotionEffect(t);
            apply(p);
            p.playSound(p.getLocation(), "block.note_block.bell", 0.7f, 1.2f);
        } else {
            int cost = num(m, "cost", 100);
            if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null
                    && cm.getCrystals().take(p.getUniqueId(), cost)) {
                grant(p, id);
                apply(p);
                p.playSound(p.getLocation(), "entity.witch.celebrate", 0.8f, 1.0f);
                plugin.getMessageUtil().send(p, "&5☠ &dDie Geister haben dir die Kraft " + c(str(m, "name", id)) + " &dverliehen!");
            } else {
                plugin.getMessageUtil().send(p, "&cDir fehlen Kristalle für diese Kraft.");
                return;
            }
        }
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof PerkHolder) e.setCancelled(true);
    }

    private NamespacedKey itemKey() {
        return new NamespacedKey(plugin, "perkitem");
    }

    @EventHandler
    public void onUseItem(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR && e.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        String id = it.getItemMeta().getPersistentDataContainer().get(itemKey(), PersistentDataType.STRING);
        if (id == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (owns(p, id)) {
            plugin.getMessageUtil().send(p, "&cDiese Kraft besitzt du bereits.");
            return;
        }
        grant(p, id);
        apply(p);
        it.setAmount(it.getAmount() - 1);
        p.playSound(p.getLocation(), "entity.witch.celebrate", 0.8f, 1.0f);
        plugin.getMessageUtil().send(p, "&5☠ &dDie Schriftrolle zerfällt – die Kraft gehört nun dir! Aktiviere sie mit &e/perks&d.");
    }

    @EventHandler
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL && e.getEntity() instanceof Player p && hasSpecial(p, "nofall")) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && hasSpecial(p, "nohunger") && e.getFoodLevel() < p.getFoodLevel()) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (hasSpecial(p, "keepinv")) {
            e.setKeepInventory(true);
            e.getDrops().clear();
        }
        if (hasSpecial(p, "keepxp")) {
            e.setKeepLevel(true);
            e.setDroppedExp(0);
        }
    }

    @EventHandler
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> apply(e.getPlayer()), 20L);
    }
}
