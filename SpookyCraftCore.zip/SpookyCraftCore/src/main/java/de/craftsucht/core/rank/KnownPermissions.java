package de.craftsucht.core.rank;

import org.bukkit.Bukkit;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * Zentrale Quelle für "alle bekannten Permission-Nodes auf dem Server" -
 * genutzt sowohl für die Tab-Completion bei /rank setpermission als auch
 * für die Auflösung des "*"-Wildcards (siehe RankManager#apply).
 */
public final class KnownPermissions {

    /**
     * Eigene Permission-Nodes, die im Code per hasPermission() geprüft werden,
     * aber NICHT in der plugin.yml als "permissions:" deklariert sind (Bukkit
     * kennt sie deswegen nicht über getPluginManager().getPermissions()).
     */
    private static final String[] UNDECLARED_OWN_PERMISSIONS = {
            "craftsucht.punish.ban", "craftsucht.punish.unban", "craftsucht.punish.tempban",
            "craftsucht.punish.warn", "craftsucht.punish.kick", "craftsucht.punish.mute",
            "craftsucht.punish.unmute", "craftsucht.punish.history",
            "skript.adminpanel", "item.sign", "item.changename", "item.lore", "freeze.use", "playersize.use", "vd.use",
            "chatclear.use", "fake.use", "code.create", "rang.set"
    };

    private KnownPermissions() {
    }

    /** Alle bekannten Permission-Nodes von JEDEM Plugin auf dem Server + unsere eigenen undeklarierten. */
    public static TreeSet<String> all() {
        TreeSet<String> all = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (org.bukkit.permissions.Permission perm : Bukkit.getPluginManager().getPermissions()) {
            all.add(perm.getName());
        }
        for (String p : UNDECLARED_OWN_PERMISSIONS) {
            all.add(p);
        }
        return all;
    }

    /** Für Tab-Completion: alle bekannten Nodes, gefiltert nach Präfix. */
    public static List<String> search(String prefix) {
        String lower = prefix.toLowerCase();
        List<String> result = new ArrayList<>();
        for (String perm : all()) {
            if (perm.toLowerCase().startsWith(lower)) {
                result.add(perm);
            }
        }
        return result;
    }
}
