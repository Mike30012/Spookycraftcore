package de.craftsucht.core.pwarp;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Spieler-Warps: /pwarp (Menue), /pwarp <name>, /pwarp set <name> (kostet pwarp.cost, Icon = Item in der Hand),
 * /pwarp delete <name>, /pwarp list. Daten: pwarps.yml
 */
public class PwarpModule implements Module, CommandExecutor, TabCompleter, Listener {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public PwarpModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "pwarp";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "pwarps.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("pwarp").setExecutor(this);
        plugin.getCommand("pwarp").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        save();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("pwarps.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private List<String> names() {
        ConfigurationSection s = data.getConfigurationSection("warps");
        List<String> out = new ArrayList<>();
        if (s != null) out.addAll(s.getKeys(false));
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    private String findName(String input) {
        for (String n : names()) if (n.equalsIgnoreCase(input)) return n;
        return null;
    }

    private int countOf(UUID owner) {
        int n = 0;
        for (String name : names()) if (owner.toString().equals(data.getString("warps." + name + ".owner"))) n++;
        return n;
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            open(p, 0);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "set" -> set(p, args);
            case "delete", "del", "remove" -> delete(p, args);
            case "list" -> {
                List<String> n = names();
                plugin.getMessageUtil().sendRaw(p, "&8--- &5☠ &dSpieler-Portale &8(" + n.size() + ") ---");
                plugin.getMessageUtil().sendRaw(p, n.isEmpty() ? "&7Noch keine Portale." : "&f" + String.join("&7, &f", n));
            }
            default -> teleport(p, args[0]);
        }
        return true;
    }

    private void set(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /pwarp set <name>");
            return;
        }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_]{2,16}")) {
            plugin.getMessageUtil().send(p, "&cDer Name braucht 2-16 Zeichen (Buchstaben, Zahlen, _).");
            return;
        }
        String existing = findName(name);
        boolean mine = existing != null && p.getUniqueId().toString().equals(data.getString("warps." + existing + ".owner"));
        if (existing != null && !mine) {
            plugin.getMessageUtil().send(p, "&cDieses Portal gibt es schon.");
            return;
        }
        int max = Math.max(1, plugin.getConfig().getInt("pwarp.max-per-player", 2));
        for (int extra = 20; extra >= 1; extra--) {
            if (p.hasPermission("spookycraft.pwarp.max." + extra)) {
                max = Math.max(max, extra);
                break;
            }
        }
        if (!mine && countOf(p.getUniqueId()) >= max) {
            plugin.getMessageUtil().send(p, "&cDu darfst höchstens &f" + max + " &cPortale besitzen.");
            return;
        }
        double cost = mine ? 0 : plugin.getConfig().getDouble("pwarp.cost", 10000);
        if (cost > 0) {
            EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
            if (eco == null || !eco.withdraw(p.getUniqueId(), cost)) {
                plugin.getMessageUtil().send(p, "&cDeine Taschen sind zu leer – ein Portal kostet &e" + String.format(Locale.GERMANY, "%,.0f", cost) + "$&c.");
                return;
            }
        }
        String key = existing != null ? existing : name;
        Location l = p.getLocation();
        String base = "warps." + key + ".";
        data.set(base + "owner", p.getUniqueId().toString());
        data.set(base + "ownerName", p.getName());
        data.set(base + "world", l.getWorld().getName());
        data.set(base + "x", l.getX());
        data.set(base + "y", l.getY());
        data.set(base + "z", l.getZ());
        data.set(base + "yaw", (double) l.getYaw());
        data.set(base + "pitch", (double) l.getPitch());
        Material hand = p.getInventory().getItemInMainHand().getType();
        data.set(base + "icon", hand.isAir() ? "OAK_SIGN" : hand.name());
        if (!data.contains(base + "visits")) data.set(base + "visits", 0);
        save();
        plugin.getMessageUtil().send(p, "&5☠ &dDein Portal &f" + key + " &dwurde " + (mine ? "neu gesetzt" : "erschaffen") + "! &7Das Icon ist dein Item in der Hand.");
    }

    private void delete(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /pwarp delete <name>");
            return;
        }
        String n = findName(args[1]);
        if (n == null) {
            plugin.getMessageUtil().send(p, "&cDieses Portal existiert nicht.");
            return;
        }
        boolean mine = p.getUniqueId().toString().equals(data.getString("warps." + n + ".owner"));
        if (!mine && !p.isOp() && !p.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(p, "&cDas ist nicht dein Portal.");
            return;
        }
        data.set("warps." + n, null);
        save();
        plugin.getMessageUtil().send(p, "&aDas Portal &f" + n + " &awurde in die Dunkelheit verbannt.");
    }

    private void teleport(Player p, String input) {
        String n = findName(input);
        if (n == null) {
            plugin.getMessageUtil().send(p, "&cDieses Portal existiert nicht.");
            return;
        }
        String base = "warps." + n + ".";
        World w = Bukkit.getWorld(data.getString(base + "world", ""));
        if (w == null) {
            plugin.getMessageUtil().send(p, "&cDiese Welt schläft noch tief im Nebel.");
            return;
        }
        Location l = new Location(w, data.getDouble(base + "x"), data.getDouble(base + "y"), data.getDouble(base + "z"),
                (float) data.getDouble(base + "yaw"), (float) data.getDouble(base + "pitch"));
        p.teleportAsync(l).thenAccept(ok -> {
            if (ok) {
                if (!p.getUniqueId().toString().equals(data.getString(base + "owner"))) {
                    data.set(base + "visits", data.getInt(base + "visits") + 1);
                }
                plugin.getMessageUtil().send(p, "&aEin Nebel trägt dich zum Portal &f" + n + "&a.");
            }
        });
    }

    // ------------------------------------------------------------------ Menue

    private static class PwarpHolder implements InventoryHolder {
        final int page;
        final List<String> shown;

        PwarpHolder(int page, List<String> shown) {
            this.page = page;
            this.shown = shown;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private void open(Player p, int page) {
        List<String> all = names();
        int perPage = 45;
        int pages = Math.max(1, (all.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pages - 1));
        List<String> shown = new ArrayList<>(all.subList(page * perPage, Math.min(all.size(), page * perPage + perPage)));
        Inventory inv = Bukkit.createInventory(new PwarpHolder(page, shown), 54, c("&5☠ &dSpieler-Portale &8(" + (page + 1) + "/" + pages + ")"));
        for (int i = 0; i < shown.size(); i++) {
            String n = shown.get(i);
            String base = "warps." + n + ".";
            Material mat = Material.matchMaterial(data.getString(base + "icon", "OAK_SIGN"));
            ItemStack it = new ItemStack(mat == null ? Material.OAK_SIGN : mat);
            ItemMeta m = it.getItemMeta();
            m.setDisplayName(c("&d" + n));
            List<String> lore = new ArrayList<>();
            lore.add(c("&7Besitzer: &f" + data.getString(base + "ownerName", "?")));
            lore.add(c("&7Besuche: &f" + data.getInt(base + "visits")));
            lore.add("");
            lore.add(c("&eKlicken zum Reisen"));
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(i, it);
        }
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 45; i < 54; i++) inv.setItem(i, filler);
        if (page > 0) inv.setItem(45, named(Material.ARROW, "&a« Zurück"));
        if (page < pages - 1) inv.setItem(53, named(Material.ARROW, "&aWeiter »"));
        ItemStack info = named(Material.BOOK, "&dEigenes Portal erschaffen");
        ItemMeta im = info.getItemMeta();
        im.setLore(List.of(c("&7Stelle dich an den Ort und tippe"), c("&e/pwarp set <name>"),
                c("&7Kosten: &e" + String.format(Locale.GERMANY, "%,.0f", plugin.getConfig().getDouble("pwarp.cost", 10000)) + "$"),
                c("&7Das Icon ist dein Item in der Hand.")));
        info.setItemMeta(im);
        inv.setItem(49, info);
        p.openInventory(inv);
    }

    private ItemStack named(Material mat, String name) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(c(name));
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof PwarpHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot == 45 && h.page > 0) {
            open(p, h.page - 1);
        } else if (slot == 53) {
            open(p, h.page + 1);
        } else if (slot >= 0 && slot < h.shown.size()) {
            p.closeInventory();
            teleport(p, h.shown.get(slot));
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof PwarpHolder) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = new ArrayList<>(TabCompleteUtil.filter(args[0], "set", "delete", "list"));
            for (String n : names()) if (n.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(n);
            return out;
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("set"))) {
            List<String> out = new ArrayList<>();
            for (String n : names()) if (n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(n);
            return out;
        }
        return Collections.emptyList();
    }
}
