package de.craftsucht.core.booster;

import org.bukkit.Material;

import java.util.List;
import java.util.Map;

public class ItemTemplate {
    private final String id;
    private final Material material;
    private final String displayName;
    private final boolean unbreakable;
    private final boolean glow;
    private final Map<String, Integer> enchants;
    private final List<String> lore;
    private final String boosterJob;
    private final double boosterMoneyPercent;
    private final double boosterXpPercent;
    private final int areaSize;

    public ItemTemplate(String id, Material material, String displayName, boolean unbreakable, boolean glow,
                         Map<String, Integer> enchants, List<String> lore, String boosterJob,
                         double boosterMoneyPercent, double boosterXpPercent, int areaSize) {
        this.id = id;
        this.material = material;
        this.displayName = displayName;
        this.unbreakable = unbreakable;
        this.glow = glow;
        this.enchants = enchants;
        this.lore = lore;
        this.boosterJob = boosterJob;
        this.boosterMoneyPercent = boosterMoneyPercent;
        this.boosterXpPercent = boosterXpPercent;
        this.areaSize = areaSize;
    }

    public String getId() {
        return id;
    }

    public Material getMaterial() {
        return material;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isUnbreakable() {
        return unbreakable;
    }

    public boolean isGlow() {
        return glow;
    }

    public Map<String, Integer> getEnchants() {
        return enchants;
    }

    public List<String> getLore() {
        return lore;
    }

    public String getBoosterJob() {
        return boosterJob;
    }

    public double getBoosterMoneyPercent() {
        return boosterMoneyPercent;
    }

    public double getBoosterXpPercent() {
        return boosterXpPercent;
    }

    /** Größe der Abbau-Fläche (NxN), 0/1 = normale Spitzhacke. */
    public int getAreaSize() {
        return areaSize;
    }
}
