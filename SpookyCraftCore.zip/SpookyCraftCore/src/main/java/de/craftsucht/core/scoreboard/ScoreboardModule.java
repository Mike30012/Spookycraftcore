package de.craftsucht.core.scoreboard;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.rank.RankModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.jobs.PlayerData;
import de.craftsucht.core.module.Module;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Live sidebar scoreboard im Opsucht-artigen "»"-Bullet-Stil: Rang, Geld,
 * Server (aktuelle Multiverse-Welt). Synchronisiert außerdem pro Tick den
 * Rang-Prefix in Tabliste und Nametag über dem Kopf (per Scoreboard-Team),
 * damit ein neuer/angepasster Rang überall sofort sichtbar ist.
 */
public class ScoreboardModule implements Module {

    private final SpookyCraftCore plugin;
    private BukkitTask task;

    public ScoreboardModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "scoreboard";
    }

    @Override
    public void enable() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 20L, 40L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        boards.clear();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            p.setPlayerListName(null);
        }
    }

    /** Erzwingt ein sofortiges Update (z.B. direkt nach LuckPerms-Änderungen). */
    public void refreshNow() {
        updateAll();
    }

    /** Pro Spieler ein dauerhaftes Scoreboard - es werden nur geänderte Zeilen/Teams angefasst (spart TPS). */
    private static final class Board {
        final Scoreboard sb;
        final Objective obj;
        java.util.List<String> lines = new java.util.ArrayList<>();
        final Map<String, String> teamSig = new HashMap<>();
        String tabName;

        Board(Scoreboard sb, Objective obj) {
            this.sb = sb;
            this.obj = obj;
        }
    }

    private final Map<java.util.UUID, Board> boards = new HashMap<>();

    private void updateAll() {
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        RankModule rankModule = (RankModule) plugin.getModuleManager().get("rank");
        JobsModule jobsModule = (JobsModule) plugin.getModuleManager().get("jobs");

        java.util.Collection<? extends Player> players = Bukkit.getOnlinePlayers();
        boards.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);

        Map<Player, String> prefixes = new HashMap<>();
        Map<Player, String> nameColorCodes = new HashMap<>();
        Map<Player, ChatColor> teamColors = new HashMap<>();
        for (Player online : players) {
            prefixes.put(online, getRangPrefix(online, rankModule));
            nameColorCodes.put(online, getJobNameColorCode(online, jobsModule));
            teamColors.put(online, getLegacyTeamColor(online, jobsModule));
        }

        for (Player p : players) {
            Board b = boards.get(p.getUniqueId());
            if (b == null) {
                Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
                Objective obj = sb.registerNewObjective("bc", "dummy", "§6§lSpookyCraft");
                obj.setDisplaySlot(DisplaySlot.SIDEBAR);
                // Blendet die Score-Zahl rechts neben jeder Zeile aus (Paper-API).
                obj.numberFormat(NumberFormat.blank());
                b = new Board(sb, obj);
                boards.put(p.getUniqueId(), b);
            }
            if (p.getScoreboard() != b.sb) p.setScoreboard(b.sb);

            String rang = prefixes.get(p);

            // --- Sidebar-Zeilen: nur neu schreiben, wenn sich etwas geändert hat
            java.util.List<String> newLines = new java.util.ArrayList<>();
            newLines.add("§8§m----------------");
            newLines.add("§8» §7Rang: " + (rang.isEmpty() ? "§7Spieler" : rang));
            if (economyModule != null) {
                double bal = economyModule.getManager().getBalance(p.getUniqueId());
                newLines.add("§8» §7Geld: §a$" + String.format(Locale.GERMANY, "%,.0f", bal));
            }
            newLines.add("§8» §7Server: §b" + prettyWorldName(p.getWorld().getName()));
            newLines.add(" ");
            newLines.add("§8§m-----------------");
            if (!newLines.equals(b.lines)) {
                for (String old : b.lines) b.sb.resetScores(old);
                int line = 10;
                for (String l : newLines) b.obj.getScore(l).setScore(line--);
                b.lines = newLines;
            }

            // --- Teams (Nametag-Farbe/Prefix): ein Team pro Spieler, nur bei Änderung aktualisieren
            for (Player other : players) {
                String otherPrefix = prefixes.get(other);
                ChatColor otherTeamColor = teamColors.get(other);
                String sig = otherPrefix + "|" + otherTeamColor;
                String name = other.getName();
                if (sig.equals(b.teamSig.get(name))) continue;
                Team team = b.sb.getTeam(name);
                if (team == null) team = b.sb.registerNewTeam(name);
                team.setPrefix(otherPrefix.isEmpty() ? "" : otherPrefix + "§r: ");
                // Team#setColor() kennt nur die 16 klassischen Farben (siehe getLegacyTeamColor).
                if (otherTeamColor != null) team.setColor(otherTeamColor);
                team.setAllowFriendlyFire(true);
                if (!team.hasEntry(name)) team.addEntry(name);
                b.teamSig.put(name, sig);
            }
            // Teams von Spielern entfernen, die nicht mehr online sind
            b.teamSig.keySet().removeIf(n -> {
                if (Bukkit.getPlayerExact(n) != null) return false;
                Team t = b.sb.getTeam(n);
                if (t != null) t.unregister();
                return true;
            });

            // --- Tab-Name nur setzen, wenn er sich geändert hat
            String myColorCode = nameColorCodes.get(p);
            String tab = (rang.isEmpty() ? "" : rang + "§r: ") + (myColorCode != null ? myColorCode : "") + p.getName();
            if (!tab.equals(b.tabName)) {
                p.setPlayerListName(tab);
                b.tabName = tab;
            }
        }
    }

    /** Eigenes Rang-System wenn aktiv, sonst Prefix aus LuckPerms. */
    private String getRangPrefix(Player p, RankModule rankModule) {
        if (rankModule != null && rankModule.getManager() != null && plugin.getModuleManager().isEnabled("rank")) {
            String prefix = rankModule.getManager().getColoredPrefix(p.getUniqueId());
            if (!prefix.isEmpty()) {
                return prefix;
            }
        } else if (de.craftsucht.core.luckperms.LuckPermsHook.isAvailable()) {
            String prefix = de.craftsucht.core.luckperms.LuckPermsHook.getPrefix(p);
            if (!prefix.isEmpty()) {
                return prefix;
            }
        }
        return p.isOp() ? "§4§lOwner" : "";
    }

    /** Erster Buchstabe groß, Unterstriche zu Leerzeichen - aus "world_nether" wird "World Nether". */
    private String prettyWorldName(String raw) {
        String[] parts = raw.replace('_', ' ').split(" ");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    /**
     * Fertige Farbcode-Sequenz für Chat/Tabliste - Farbe des höchsten
     * erreichten Job-Titels. Leerer String = keine (kein Jobs-Modul, kein
     * Job, noch kein Titel-Level erreicht).
     */
    private String getJobNameColorCode(Player p, JobsModule jobsModule) {
        if (jobsModule == null) return "";
        PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return "";
        ChatColor color = jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
        return color != null ? color.toString() : "";
    }

    /** Nametag-Farbe (Scoreboard-Team) - dieselbe Job-Tier-Farbe, immer eine legacy ChatColor. */
    private ChatColor getLegacyTeamColor(Player p, JobsModule jobsModule) {
        if (jobsModule == null) return null;
        PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return null;
        return jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
    }
}
