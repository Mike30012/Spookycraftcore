package de.craftsucht.core.itemdb;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class GuiBuilder {

    private GuiBuilder() {
    }

    public static Inventory build(List<DBEntry> entries, int page, String title) {
        ItemDbGuiHolder holder = new ItemDbGuiHolder(entries, page, title);
        String fullTitle = title + " (Seite " + (page + 1) + "/" + (holder.getMaxPage() + 1) + ")";
        Inventory inv = org.bukkit.Bukkit.createInventory(holder, 54, ChatColor.translateAlternateColorCodes('&', fullTitle));
        holder.setInventory(inv);

        int start = page * ItemDbGuiHolder.PAGE_SIZE;
        int end = Math.min(entries.size(), start + ItemDbGuiHolder.PAGE_SIZE);

        for (int i = start; i < end; i++) {
            DBEntry entry = entries.get(i);
            ItemStack display = entry.getItem().clone();
            display.setAmount(1);
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = meta.hasLore() ? new java.util.ArrayList<>(meta.getLore()) : new java.util.ArrayList<>();
                lore.add(ChatColor.GRAY + "Hinzugefügt von: " + ChatColor.YELLOW + entry.getAddedBy());
                lore.add(ChatColor.DARK_GRAY + "Klick = Kopie erhalten (falls berechtigt)");
                meta.setLore(lore);
                display.setItemMeta(meta);
            }
            inv.setItem(i - start, display);
        }

        if (page > 0) {
            inv.setItem(ItemDbGuiHolder.PREV_SLOT, navItem(Material.ARROW, ChatColor.GREEN + "« Vorherige Seite"));
        }
        if (page < holder.getMaxPage()) {
            inv.setItem(ItemDbGuiHolder.NEXT_SLOT, navItem(Material.ARROW, ChatColor.GREEN + "Nächste Seite »"));
        }
        inv.setItem(ItemDbGuiHolder.INFO_SLOT, navItem(Material.BOOK,
                ChatColor.AQUA + "" + entries.size() + " Item(s) in der Datenbank"));

        return inv;
    }

    private static ItemStack navItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }
}
