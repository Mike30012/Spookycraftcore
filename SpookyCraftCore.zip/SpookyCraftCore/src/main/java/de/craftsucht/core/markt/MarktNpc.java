package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

/**
 * Markt-NPC wie am OPSUCHT-Spawn: ein unbeweglicher, unverwundbarer Dorfbewohner, bei dessen Rechtsklick sich der Markt öffnet.
 * Gespeichert wird der NPC direkt in der Welt (bleibt nach Neustarts erhalten). Erstellen/Entfernen: /markt npc spawn|remove
 */
public class MarktNpc implements Listener {

    private final SpookyCraftCore plugin;
    private final GuiManager gui;
    private final NamespacedKey key;
    private volatile boolean spawning; // true nur während /markt npc spawn

    public MarktNpc(SpookyCraftCore plugin, GuiManager gui) {
        this.plugin = plugin;
        this.gui = gui;
        this.key = new NamespacedKey(plugin, "markt_npc");
    }

    public boolean isMarktNpc(Entity entity) {
        return entity != null && entity.getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    /** Spawnt den NPC an der Position des Spielers und dreht ihn zum Spieler. @return false, wenn er nicht erstellt werden konnte */
    public boolean spawn(Player player) {
        Location loc = player.getLocation();
        loc.setYaw(player.getLocation().getYaw() + 180.0f);
        loc.setPitch(0.0f);
        String name = ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("markt.npc-name", "&6&lMarkt"));
        spawning = true;
        try {
            Villager spawned = player.getWorld().spawn(loc, Villager.class, villager -> {
                villager.setAI(false);
                villager.setInvulnerable(true);
                villager.setSilent(true);
                villager.setPersistent(true);
                villager.setRemoveWhenFarAway(false);
                villager.setCollidable(false);
                villager.setProfession(Villager.Profession.LIBRARIAN);
                villager.setCustomName(name);
                villager.setCustomNameVisible(true);
                villager.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
            });
            return spawned != null && spawned.isValid();
        } catch (Exception e) {
            plugin.getLogger().warning("Markt-NPC konnte nicht gespawnt werden: " + e);
            return false;
        } finally {
            spawning = false;
        }
    }

    /**
     * Schutz-Plugins (z.B. WorldGuard "mob-spawning deny") blockieren oft jedes Spawnen von Mobs.
     * Unser eigener NPC-Spawn wird deshalb zuletzt wieder freigegeben.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (spawning && event.getEntityType() == org.bukkit.entity.EntityType.VILLAGER) {
            event.setCancelled(false);
        }
    }

    /** Entfernt den nächsten Markt-NPC im Umkreis. @return true, wenn einer entfernt wurde */
    public boolean removeNearest(Player player, double radius) {
        Entity nearest = null;
        double best = Double.MAX_VALUE;
        for (Entity entity : player.getNearbyEntities(radius, radius, radius)) {
            if (!isMarktNpc(entity)) continue;
            double d = entity.getLocation().distanceSquared(player.getLocation());
            if (d < best) {
                best = d;
                nearest = entity;
            }
        }
        if (nearest == null) return false;
        nearest.remove();
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent event) {
        if (!isMarktNpc(event.getRightClicked())) return;
        event.setCancelled(true); // kein Handels-Fenster des Dorfbewohners
        if (event.getHand() != EquipmentSlot.HAND) return;
        gui.openMain(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (isMarktNpc(event.getEntity())) event.setCancelled(true);
    }
}
