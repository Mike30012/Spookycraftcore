package de.craftsucht.core.util;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;

/** Versions-tolerante Zugriffe: Namen aendern sich zwischen Minecraft-Versionen (z.B. generic.max_health -> max_health). */
public final class Compat {
    private Compat() {
    }

    /** Attribut ueber den Kurznamen, z.B. "max_health", "armor", "armor_toughness", "knockback_resistance". */
    public static Attribute attr(String shortName) {
        Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(shortName));
        if (a == null) a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("generic." + shortName));
        return a;
    }
}
