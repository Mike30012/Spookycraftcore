package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Area-Spitzhacken (1x1 bis 10x10) wie auf OPSUCHT: Beim Abbauen eines Blocks werden zusätzlich die Blöcke
 * in einer Fläche NxN um ihn herum abgebaut - senkrecht zur abgebauten Seite (wie ein Hammer).
 * Jeder zusätzliche Block löst ein eigenes BlockBreakEvent aus, damit Grundstücks-/Schutz-Plugins mitreden.
 * Einstellungen: "area-mining:" in der config.yml. Items: /citem give <spieler> spitzhacke_5x5
 */
public class AreaMiningListener implements Listener {

    /** true, solange zusätzliche Blöcke abgebaut werden (andere Module, z.B. AntiCheat/Jobs, fragen das ab). */
    private static boolean extraBreak;

    public static boolean isExtraBreak() {
        return extraBreak;
    }

    /** Für Spezial-Items: Folge-Events nicht als normales Abbauen zählen (Jobs/AntiCheat ignorieren sie dann). */
    public static void setExtraBreak(boolean value) {
        extraBreak = value;
    }

    public static NamespacedKey keyArea(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "area_size");
    }

    private static final Set<String> PROTECTED = Set.of(
            "SPAWNER", "TRIAL_SPAWNER", "VAULT", "ENDER_CHEST", "BEACON", "FURNACE", "BLAST_FURNACE", "SMOKER", "HOPPER",
            "DISPENSER", "DROPPER", "CHEST", "TRAPPED_CHEST", "BARREL", "BREWING_STAND", "ENCHANTING_TABLE", "LECTERN",
            "JUKEBOX", "CRAFTER", "END_PORTAL_FRAME", "END_PORTAL", "NETHER_PORTAL", "REINFORCED_DEEPSLATE");

    private final SpookyCraftCore plugin;
    private final NamespacedKey areaKey;

    public AreaMiningListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.areaKey = keyArea(plugin);
    }

    private int areaSize(ItemStack tool) {
        if (tool == null || !tool.hasItemMeta()) return 0;
        Integer size = tool.getItemMeta().getPersistentDataContainer().get(areaKey, PersistentDataType.INTEGER);
        return size == null ? 0 : size;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (extraBreak) return; // eigene Folge-Events
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        int size = areaSize(tool);
        if (size <= 1) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;

        FileConfiguration cfg = plugin.getConfig();
        if (player.isSneaking() && cfg.getBoolean("area-mining.sneak-disables", true)) return;
        List<String> worlds = cfg.getStringList("area-mining.worlds");
        if (!worlds.isEmpty() && !worlds.contains(player.getWorld().getName())) return;
        size = Math.min(size, Math.max(1, cfg.getInt("area-mining.max-size", 10)));
        boolean onlyPickaxeBlocks = cfg.getBoolean("area-mining.only-pickaxe-blocks", true);

        Block center = event.getBlock();
        BlockFace face = faceOf(player, center);
        int start = -(size - 1) / 2;
        int end = start + size - 1;

        List<Block> targets = new ArrayList<>();
        for (int u = start; u <= end; u++) {
            for (int v = start; v <= end; v++) {
                if (u == 0 && v == 0) continue; // der Mittelblock wird ganz normal abgebaut
                Block block = switch (face) {
                    case UP, DOWN -> center.getRelative(u, 0, v);
                    case NORTH, SOUTH -> center.getRelative(u, v, 0);
                    default -> center.getRelative(0, v, u); // EAST, WEST
                };
                if (breakable(block, onlyPickaxeBlocks)) targets.add(block);
            }
        }
        if (targets.isEmpty()) return;

        final int perTick = Math.max(5, cfg.getInt("area-mining.blocks-per-tick", 25));
        final boolean toInventory = cfg.getBoolean("area-mining.drops-to-inventory", true);
        final ItemStack toolCopy = tool.clone();
        final Block centerBlock = center;
        new org.bukkit.scheduler.BukkitRunnable() {
            int index = 0;
            long nanos = 0;
            int broken = 0;

            @Override
            public void run() {
                if (!player.isOnline()) { finish(); cancel(); return; }
                long t0 = System.nanoTime();
                extraBreak = true;
                try {
                    int done = 0;
                    while (index < targets.size() && done < perTick) {
                        Block block = targets.get(index++);
                        done++;
                        if (!breakable(block, onlyPickaxeBlocks)) continue;
                        BlockBreakEvent extra = new BlockBreakEvent(block, player);
                        Bukkit.getPluginManager().callEvent(extra);
                        if (extra.isCancelled()) continue;
                        broken++;
                        if (extra.isDropItems()) {
                            java.util.Collection<ItemStack> drops = block.getDrops(toolCopy, player);
                            block.setType(Material.AIR, false); // ohne Physik-Updates = deutlich weniger Lag
                            for (ItemStack drop : drops) {
                                if (toInventory) {
                                    for (ItemStack left : player.getInventory().addItem(drop).values()) {
                                        centerBlock.getWorld().dropItemNaturally(centerBlock.getLocation().add(0.5, 0.5, 0.5), left);
                                    }
                                } else {
                                    block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), drop);
                                }
                            }
                            if (extra.getExpToDrop() > 0) player.giveExp(extra.getExpToDrop());
                        } else {
                            block.setType(Material.AIR, false);
                        }
                    }
                } finally {
                    extraBreak = false;
                    nanos += System.nanoTime() - t0;
                }
                if (index >= targets.size()) { finish(); cancel(); }
            }

            private void finish() {
                de.craftsucht.core.perf.PerfModule.recordAreaBreak(nanos, broken);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Auch der angeklickte Mittelblock der Area-Hacke landet direkt im Inventar (Rest bei vollem Inventar auf dem Boden). */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrop(org.bukkit.event.block.BlockDropItemEvent event) {
        Player player = event.getPlayer();
        boolean all = plugin.getConfig().getBoolean("autopickup.all-blocks", true);
        if (!all) {
            if (!plugin.getConfig().getBoolean("area-mining.drops-to-inventory", true)) return;
            if (areaSize(player.getInventory().getItemInMainHand()) <= 1) return;
        }
        java.util.List<String> aw = plugin.getConfig().getStringList("autopickup.worlds");
        if (all && !aw.isEmpty() && !aw.contains(player.getWorld().getName())) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        java.util.Iterator<org.bukkit.entity.Item> it = event.getItems().iterator();
        while (it.hasNext()) {
            org.bukkit.entity.Item item = it.next();
            if (player.getInventory().addItem(item.getItemStack()).isEmpty()) it.remove();
        }
    }

    /** Mob-Drops und Erfahrung gehen direkt an den Killer (Spieler). */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMobDeath(org.bukkit.event.entity.EntityDeathEvent event) {
        if (!plugin.getConfig().getBoolean("autopickup.mob-drops", true)) return;
        if (event.getEntity() instanceof Player) return;
        Player killer = event.getEntity().getKiller();
        if (killer == null || killer.getGameMode() == GameMode.CREATIVE) return;
        java.util.List<String> aw = plugin.getConfig().getStringList("autopickup.worlds");
        if (!aw.isEmpty() && !aw.contains(killer.getWorld().getName())) return;
        java.util.Iterator<ItemStack> it = event.getDrops().iterator();
        java.util.List<ItemStack> leftovers = new ArrayList<>();
        while (it.hasNext()) {
            ItemStack drop = it.next();
            it.remove();
            leftovers.addAll(killer.getInventory().addItem(drop).values());
        }
        event.getDrops().addAll(leftovers); // nur was nicht mehr passt, fällt auf den Boden
        if (event.getDroppedExp() > 0) {
            killer.giveExp(event.getDroppedExp());
            event.setDroppedExp(0);
        }
    }

    /** Items auf dem Boden werden nach X Sekunden gelöscht - aber nur, wenn kein Spieler in der Nähe ist. 0 = aus. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onItemSpawn(org.bukkit.event.entity.ItemSpawnEvent event) {
        int seconds = plugin.getConfig().getInt("autopickup.ground-item-seconds", 60);
        if (seconds <= 0) return;
        scheduleCleanup(event.getEntity(), seconds * 20L);
    }

    private void scheduleCleanup(org.bukkit.entity.Item item, long delayTicks) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!item.isValid()) return;
            double radius = plugin.getConfig().getDouble("autopickup.player-radius", 24);
            boolean nearby = !item.getLocation().getNearbyPlayers(radius).isEmpty();
            if (nearby) {
                scheduleCleanup(item, 200L); // später nochmal prüfen (10 s)
            } else {
                item.remove();
            }
        }, delayTicks);
    }

    /** Seite, auf die der Spieler schaut; Fallback: Blickrichtung. */
    private BlockFace faceOf(Player player, Block center) {
        RayTraceResult ray = player.rayTraceBlocks(8.0);
        if (ray != null && center.equals(ray.getHitBlock()) && ray.getHitBlockFace() != null) {
            return ray.getHitBlockFace();
        }
        float pitch = player.getLocation().getPitch();
        if (pitch > 45) return BlockFace.UP;
        if (pitch < -45) return BlockFace.DOWN;
        return player.getFacing().getOppositeFace();
    }

    private boolean breakable(Block block, boolean onlyPickaxeBlocks) {
        Material type = block.getType();
        if (type.isAir() || block.isLiquid()) return false;
        if (type.getHardness() < 0) return false; // Bedrock & Co.
        String name = type.name();
        if (PROTECTED.contains(name) || name.endsWith("_SHULKER_BOX")) return false;
        return !onlyPickaxeBlocks || Tag.MINEABLE_PICKAXE.isTagged(type);
    }
}
