package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Area-Spitzhacken (1x1 bis 10x10) wie auf OPSUCHT: Beim Abbauen eines Blocks werden zusätzlich die Blöcke
 * in einer Fläche NxN um ihn herum abgebaut - senkrecht zur abgebauten Seite (wie ein Hammer).
 * Jeder zusätzliche Block löst ein eigenes BlockBreakEvent aus, damit Grundstücks-/Schutz-Plugins mitreden.
 * Einstellungen: "area-mining:" in der config.yml. Items: /citem give <spieler> spitzhacke_5x5
 */
public class AreaMiningListener implements Listener {

    /** true, solange zusätzliche Blöcke abgebaut werden (andere Module, z.B. AntiCheat/Jobs, fragen das ab). */
    private static boolean extraBreak;

    public static boolean isExtraBreak() {
        return extraBreak;
    }

    public static NamespacedKey keyArea(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "area_size");
    }

    private static final Set<String> PROTECTED = Set.of(
            "SPAWNER", "TRIAL_SPAWNER", "VAULT", "ENDER_CHEST", "BEACON", "FURNACE", "BLAST_FURNACE", "SMOKER", "HOPPER",
            "DISPENSER", "DROPPER", "CHEST", "TRAPPED_CHEST", "BARREL", "BREWING_STAND", "ENCHANTING_TABLE", "LECTERN",
            "JUKEBOX", "CRAFTER", "END_PORTAL_FRAME", "END_PORTAL", "NETHER_PORTAL", "REINFORCED_DEEPSLATE");

    private final SpookyCraftCore plugin;
    private final NamespacedKey areaKey;

    public AreaMiningListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.areaKey = keyArea(plugin);
    }

    private int areaSize(ItemStack tool) {
        if (tool == null || !tool.hasItemMeta()) return 0;
        Integer size = tool.getItemMeta().getPersistentDataContainer().get(areaKey, PersistentDataType.INTEGER);
        return size == null ? 0 : size;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (extraBreak) return; // eigene Folge-Events
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        int size = areaSize(tool);
        if (size <= 1) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;

        FileConfiguration cfg = plugin.getConfig();
        if (player.isSneaking() && cfg.getBoolean("area-mining.sneak-disables", true)) return;
        List<String> worlds = cfg.getStringList("area-mining.worlds");
        if (!worlds.isEmpty() && !worlds.contains(player.getWorld().getName())) return;
        size = Math.min(size, Math.max(1, cfg.getInt("area-mining.max-size", 10)));
        boolean onlyPickaxeBlocks = cfg.getBoolean("area-mining.only-pickaxe-blocks", true);

        Block center = event.getBlock();
        BlockFace face = faceOf(player, center);
        int start = -(size - 1) / 2;
        int end = start + size - 1;

        List<Block> targets = new ArrayList<>();
        for (int u = start; u <= end; u++) {
            for (int v = start; v <= end; v++) {
                if (u == 0 && v == 0) continue; // der Mittelblock wird ganz normal abgebaut
                Block block = switch (face) {
                    case UP, DOWN -> center.getRelative(u, 0, v);
                    case NORTH, SOUTH -> center.getRelative(u, v, 0);
                    default -> center.getRelative(0, v, u); // EAST, WEST
                };
                if (breakable(block, onlyPickaxeBlocks)) targets.add(block);
            }
        }
        if (targets.isEmpty()) return;

        long startNanos = System.nanoTime();
        int brokenCount = 0;
        extraBreak = true;
        try {
            for (Block block : targets) {
                BlockBreakEvent extra = new BlockBreakEvent(block, player);
                Bukkit.getPluginManager().callEvent(extra);
                if (extra.isCancelled()) continue;
                brokenCount++;
                if (extra.isDropItems()) {
                    block.breakNaturally(tool);
                } else {
                    block.setType(Material.AIR);
                }
            }
        } finally {
            extraBreak = false;
            de.craftsucht.core.perf.PerfModule.recordAreaBreak(System.nanoTime() - startNanos, brokenCount);
        }
    }

    /** Seite, auf die der Spieler schaut; Fallback: Blickrichtung. */
    private BlockFace faceOf(Player player, Block center) {
        RayTraceResult ray = player.rayTraceBlocks(8.0);
        if (ray != null && center.equals(ray.getHitBlock()) && ray.getHitBlockFace() != null) {
            return ray.getHitBlockFace();
        }
        float pitch = player.getLocation().getPitch();
        if (pitch > 45) return BlockFace.UP;
        if (pitch < -45) return BlockFace.DOWN;
        return player.getFacing().getOppositeFace();
    }

    private boolean breakable(Block block, boolean onlyPickaxeBlocks) {
        Material type = block.getType();
        if (type.isAir() || block.isLiquid()) return false;
        if (type.getHardness() < 0) return false; // Bedrock & Co.
        String name = type.name();
        if (PROTECTED.contains(name) || name.endsWith("_SHULKER_BOX")) return false;
        return !onlyPickaxeBlocks || Tag.MINEABLE_PICKAXE.isTagged(type);
    }
}
