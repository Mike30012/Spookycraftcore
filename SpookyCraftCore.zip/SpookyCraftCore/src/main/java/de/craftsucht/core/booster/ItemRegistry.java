package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ItemRegistry {

    /** Erlaubter Bereich für den Booster-Prozentsatz, siehe build() mit Override. */
    public static final double MIN_PERCENT = 10.0;
    public static final double MAX_PERCENT = 1000.0;

    private final SpookyCraftCore plugin;
    private final Map<String, ItemTemplate> templates = new LinkedHashMap<>();

    public ItemRegistry(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        templates.clear();
        File file = new File(plugin.getDataFolder(), "items.yml");
        if (!file.exists()) {
            plugin.saveResource("items.yml", false);
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection itemsSection = yaml.getConfigurationSection("items");
        if (itemsSection == null) {
            plugin.getLogger().warning("items.yml enthält keinen 'items:' Abschnitt.");
            addAreaPickaxes();
            addSpecialItems();
            return;
        }
        for (String id : itemsSection.getKeys(false)) {
            ConfigurationSection section = itemsSection.getConfigurationSection(id);
            if (section == null) continue;
            try {
                ItemTemplate template = parseTemplate(id, section);
                templates.put(id.toLowerCase(), template);
            } catch (Exception e) {
                plugin.getLogger().warning("Konnte Item '" + id + "' nicht laden: " + e.getMessage());
            }
        }
        addAreaPickaxes();
        addSpecialItems();
    }

    /**
     * Spezial-Items (früher als Skript): Flug-Schuhe, Speed-Schuhe, Mining-Pistole, Erz-Wandler, Bedrock-Brecher,
     * Ban-Hammer und die Bedrock-Rüstung. Das Verhalten steckt in {@link SpecialItemsListener}.
     * Eigene Einträge mit derselben ID in items.yml haben Vorrang.
     */
    private void addSpecialItems() {
        special("flugschuhe", Material.DIAMOND_BOOTS, "&b&l✈ FLUG-SCHUHE ✈",
                List.of("&7Ziehe diese Schuhe an, um", "&7wie im Creative zu fliegen!"), "flugschuhe");
        special("speedschuhe", Material.DIAMOND_BOOTS, "&bSpeed Schuhe",
                List.of("&7Verleiht Speed 11"), "speedschuhe");
        special("mining_pistole", Material.NETHERITE_PICKAXE, "&b&lMining-Pistole",
                List.of("&7Rechtsklick, um Blöcke", "&7aus der Ferne massenhaft abzubauen!"), "mining_pistole");
        special("erz_wandler", Material.NETHERITE_PICKAXE, "&6&lErz-Wandler Spitzhacke",
                List.of("&7Rechtsklick auf JEDEN Block,", "&7um Erze im Radius zu erschaffen!"), "erz_wandler");
        special("bedrock_brecher", Material.NETHERITE_PICKAXE, "&0&lBedrock-Brecher",
                List.of("&7Kann unzerstörbaren Bedrock", "&7abbauen und als Item droppen!"), "bedrock_brecher");
        special("banhammer", Material.MACE, "&4&l⚡ DER BAN-HAMMER ⚡",
                List.of("&7Schlage einen echten Spieler zum Bannen!"), "banhammer");

        ItemTemplate sword = special("bedrock_schwert", Material.NETHERITE_SWORD, "&7Bedrock-Schwert",
                List.of("&8Aus Bedrock geschmiedet"), "bedrock_sword");
        if (sword != null) sword.modelData(1001);
        for (String[] gear : new String[][]{
                {"bedrock_helm", "LEATHER_HELMET", "Bedrock-Helm", "bedrock_helm"},
                {"bedrock_brustplatte", "LEATHER_CHESTPLATE", "Bedrock-Brustplatte", "bedrock_chest"},
                {"bedrock_beinschutz", "LEATHER_LEGGINGS", "Bedrock-Beinschutz", "bedrock_legs"},
                {"bedrock_stiefel", "LEATHER_BOOTS", "Bedrock-Stiefel", "bedrock_boots"}}) {
            ItemTemplate t = special(gear[0], Material.valueOf(gear[1]), "&7" + gear[2],
                    List.of("&8Aus Bedrock geschmiedet", "&7Resistenz alle 10 Minuten"), gear[3]);
            if (t != null) {
                t.dye(0x2D2D2D);
                t.getEnchants().put("UNBREAKING", 10);
            }
        }
    }

    private ItemTemplate special(String id, Material material, String name, List<String> lore, String special) {
        if (templates.containsKey(id)) return null;
        ItemTemplate t = new ItemTemplate(id, material, name, false, false, new LinkedHashMap<>(),
                new ArrayList<>(lore), null, 0.0, 0.0, 0).special(special);
        templates.put(id, t);
        return t;
    }

    /**
     * Area-Spitzhacken 1x1 bis 10x10 (spitzhacke_NxN). Sie werden immer eingebaut, damit sie auch mit einer bereits
     * vorhandenen items.yml funktionieren. Eigene Einträge mit derselben ID in items.yml haben Vorrang.
     */
    private void addAreaPickaxes() {
        String[] colors = {"&f", "&a", "&2", "&b", "&3", "&9", "&d", "&5", "&6", "&c"};
        for (int n = 1; n <= 10; n++) {
            String id = "spitzhacke_" + n + "x" + n;
            if (templates.containsKey(id)) continue;
            Map<String, Integer> enchants = new LinkedHashMap<>();
            enchants.put("EFFICIENCY", n >= 7 ? 14 : n >= 4 ? 13 : 12);
            enchants.put("FORTUNE", 3);
            enchants.put("UNBREAKING", 10);
            enchants.put("MENDING", 1);
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("&a✪ &lArea-Spitzhacke &7⚒");
            lore.add(n > 1 ? "&8↳ &7Baut &f{area}x{area} &7Blöcke auf einmal ab" : "&8↳ &7Normale Spitzhacke &8(&f1x1&8)");
            lore.add(n > 1 ? "&8↳ &7Nur Steine & Erze &8· &7Sneaken = 1 Block" : "&8↳ &7Unzerstörbar");
            templates.put(id, new ItemTemplate(id, Material.NETHERITE_PICKAXE, colors[n - 1] + "&lSpitzhacke &f" + n + "x" + n,
                    true, true, enchants, lore, null, 0.0, 0.0, n));
        }
    }

    private ItemTemplate parseTemplate(String id, ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "STONE"));
        if (material == null) material = Material.STONE;
        String displayName = section.getString("display-name", "&fCustom Item");
        boolean unbreakable = section.getBoolean("unbreakable", false);
        boolean glow = section.getBoolean("glow", false);
        Map<String, Integer> enchants = new LinkedHashMap<>();
        ConfigurationSection enchSection = section.getConfigurationSection("enchants");
        if (enchSection != null) {
            for (String key : enchSection.getKeys(false)) {
                enchants.put(key.toUpperCase(), enchSection.getInt(key));
            }
        }
        List<String> lore = section.getStringList("lore");
        String boosterJob = null;
        double moneyPercent = 0.0;
        double xpPercent = 0.0;
        ConfigurationSection boosterSection = section.getConfigurationSection("booster");
        if (boosterSection != null) {
            boosterJob = boosterSection.getString("job");
            moneyPercent = boosterSection.getDouble("money-percent", 0.0);
            xpPercent = boosterSection.getDouble("xp-percent", 0.0);
        }
        return new ItemTemplate(id, material, displayName, unbreakable, glow, enchants, lore, boosterJob, moneyPercent, xpPercent,
                section.getInt("area", 0));
    }

    public ItemStack build(ItemTemplate template) {
        return build(template, null);
    }

    /**
     * Baut das Item wie im Original, aber mit optionalem Prozent-Override
     * für Geld/XP (z.B. per /citem give <spieler> <id> <prozent>) - geklemmt
     * auf MIN_PERCENT-MAX_PERCENT (10-1000%). null = Standardwert aus items.yml.
     */
    public ItemStack build(ItemTemplate template, Double percentOverride) {
        double money = template.getBoosterMoneyPercent();
        double xp = template.getBoosterXpPercent();
        if (percentOverride != null) {
            double clamped = Math.max(MIN_PERCENT, Math.min(MAX_PERCENT, percentOverride));
            money = clamped;
            xp = clamped;
        }

        ItemStack item = new ItemStack(template.getMaterial());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(template.getDisplayName()));
        meta.setUnbreakable(template.isUnbreakable());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);

        for (Map.Entry<String, Integer> entry : template.getEnchants().entrySet()) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(entry.getKey().toLowerCase()));
            if (enchantment == null) {
                plugin.getLogger().warning("Unbekanntes Enchantment: " + entry.getKey());
                continue;
            }
            meta.addEnchant(enchantment, entry.getValue(), true);
        }
        if (template.isGlow() && template.getEnchants().isEmpty()) {
            Enchantment glowEnchant = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("unbreaking"));
            if (glowEnchant != null) {
                meta.addEnchant(glowEnchant, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
        }

        List<String> coloredLore = new ArrayList<>();
        for (String line : template.getLore()) {
            String replaced = line.replace("{money}", trimPercent(money)).replace("{xp}", trimPercent(xp))
                    .replace("{area}", String.valueOf(template.getAreaSize()));
            coloredLore.add(color(replaced));
        }
        meta.setLore(coloredLore);

        if (template.getBoosterJob() != null) {
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            pdc.set(BoosterAPI.keyJob(plugin), PersistentDataType.STRING, template.getBoosterJob());
            pdc.set(BoosterAPI.keyMoney(plugin), PersistentDataType.DOUBLE, money);
            pdc.set(BoosterAPI.keyXp(plugin), PersistentDataType.DOUBLE, xp);
        }
        if (template.getSpecial() != null) {
            meta.getPersistentDataContainer().set(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING, template.getSpecial());
        }
        if (template.getDyeRgb() != null && meta instanceof org.bukkit.inventory.meta.LeatherArmorMeta leather) {
            leather.setColor(org.bukkit.Color.fromRGB(template.getDyeRgb()));
            meta.addItemFlags(ItemFlag.HIDE_DYE);
        }
        if (template.getModelData() != null) {
            meta.setCustomModelData(template.getModelData());
        }
        if (template.getAreaSize() > 1) {
            meta.getPersistentDataContainer().set(AreaMiningListener.keyArea(plugin), PersistentDataType.INTEGER, template.getAreaSize());
        }
        item.setItemMeta(meta);
        return item;
    }

    private String trimPercent(double value) {
        if (value == Math.floor(value)) {
            return String.valueOf((int) value);
        }
        return String.valueOf(value);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public Map<String, ItemTemplate> getTemplates() {
        return templates;
    }

    public ItemTemplate getTemplate(String id) {
        return templates.get(id.toLowerCase());
    }
}
