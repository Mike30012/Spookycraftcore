package de.craftsucht.core.emoji;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Chat-Emojis: :geist: wird zu ☠ usw. (config emojis.list, /emojis zeigt alle).
 * Recht spookycraft.chat.emoji (Standard: jeder).
 */
public class EmojiModule implements Module, Listener, CommandExecutor {

    private final SpookyCraftCore plugin;
    private final Map<String, String> emojis = new LinkedHashMap<>();

    public EmojiModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "emoji";
    }

    @Override
    public void enable() {
        load();
        plugin.getCommand("emojis").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
    }

    private void load() {
        emojis.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("emojis.list");
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            String v = sec.getString(k);
            if (v != null && !v.isEmpty()) emojis.put(":" + k.toLowerCase() + ":", v);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        if (emojis.isEmpty() || !e.getPlayer().hasPermission("spookycraft.chat.emoji")) return;
        String m = e.getMessage();
        if (m.indexOf(':') < 0) return;
        for (Map.Entry<String, String> en : emojis.entrySet()) {
            m = m.replace(en.getKey(), en.getValue());
        }
        e.setMessage(m);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        plugin.getMessageUtil().sendRaw(s, "&8&l☠ &7Emojis &8(&7einfach im Chat tippen&8)");
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> en : emojis.entrySet()) {
            sb.append("&f").append(en.getValue()).append(" &8").append(en.getKey()).append("   ");
        }
        plugin.getMessageUtil().sendRaw(s, sb.toString());
        return true;
    }
}
