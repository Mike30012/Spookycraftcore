package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class ShopManager {

    private final SpookyCraftCore plugin;
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();
    private final Set<Material> tradable = EnumSet.noneOf(Material.class);
    private final Map<Material, Double> serverBuy = new EnumMap<>(Material.class);

    public ShopManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        categories.clear();
        tradable.clear();
        loadServerPrices();
        if (plugin.getConfig().getBoolean("markt.auto-categories", true)) {
            loadAutomatic();
            return;
        }
        File file = new File(plugin.getDataFolder(), "shop.yml");
        if (!file.exists()) {
            plugin.saveResource("shop.yml", false);
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection categoriesSection = config.getConfigurationSection("categories");
        if (categoriesSection == null) {
            plugin.getLogger().warning("shop.yml enthält keine 'categories'-Sektion.");
            return;
        }
        for (String key : categoriesSection.getKeys(false)) {
            ConfigurationSection catSection = categoriesSection.getConfigurationSection(key);
            if (catSection == null) continue;
            String displayName = catSection.getString("display-name", key);
            Material icon = Material.matchMaterial(catSection.getString("icon", "CHEST"));
            if (icon == null) icon = Material.CHEST;
            int slot = catSection.getInt("slot", 0);
            ShopCategory category = new ShopCategory(key, displayName, icon, slot);
            for (Map<?, ?> raw : catSection.getMapList("items")) {
                Object matObj = raw.get("material");
                if (matObj == null) continue;
                Material material = Material.matchMaterial(matObj.toString());
                if (material == null) {
                    plugin.getLogger().warning("Unbekanntes Material in shop.yml: " + matObj);
                    continue;
                }
                double buyPrice = toDouble(raw.get("buy-price"));
                double sellPrice = toDouble(raw.get("sell-price"));
                category.addItem(new ShopItem(material, buyPrice, sellPrice));
                tradable.add(material);
            }
            categories.put(key, category);
        }
        applyLayout();
        plugin.getLogger().info("Markt geladen: " + categories.size() + " Kategorien.");
    }

    /** Liest die "buy-price"-Werte der shop.yml als Server-Preise für den Sofortkauf (auch bei automatischen Kategorien). */
    private void loadServerPrices() {
        serverBuy.clear();
        File file = new File(plugin.getDataFolder(), "shop.yml");
        if (!file.exists()) plugin.saveResource("shop.yml", false);
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection cats = config.getConfigurationSection("categories");
        if (cats == null) return;
        for (String key : cats.getKeys(false)) {
            ConfigurationSection section = cats.getConfigurationSection(key);
            if (section == null) continue;
            for (Map<?, ?> raw : section.getMapList("items")) {
                Object matObj = raw.get("material");
                if (matObj == null) continue;
                Material material = Material.matchMaterial(matObj.toString());
                if (material == null) continue;
                double buy = toDouble(raw.get("buy-price"));
                if (buy > 0) serverBuy.put(material, buy);
            }
        }
    }

    public double getServerBuyPrice(Material material) {
        return serverBuy.getOrDefault(material, 0.0);
    }

    /** Kategorien wie beim OPSUCHT-Marktplatz: alle Vanilla-Ressourcen, automatisch einsortiert. */
    private void loadAutomatic() {
        Object[][] meta = {
                {"bergbau", "&6&lBergbau", Material.DIAMOND_PICKAXE},
                {"holz", "&2&lHolz", Material.OAK_LOG},
                {"nahrung", "&a&lNahrung", Material.COOKED_BEEF},
                {"kampf", "&c&lKampf", Material.IRON_SWORD},
                {"besonderes", "&d&lBesonderes", Material.NETHER_STAR},
                {"sonstiges", "&7&lSonstiges", Material.COBBLESTONE}
        };
        Map<String, java.util.List<Material>> built = MarketCatalog.build();
        for (Object[] m : meta) {
            String key = (String) m[0];
            ShopCategory category = new ShopCategory(key, (String) m[1], (Material) m[2], 0);
            for (Material material : built.get(key)) {
                category.addItem(new ShopItem(material, 0, 0));
                tradable.add(material);
            }
            categories.put(key, category);
        }
        applyLayout();
        plugin.getLogger().info("Markt geladen: " + tradable.size() + " handelbare Items in " + categories.size() + " Kategorien.");
    }

    /** Ordnet die Kategorien im 27er-Hauptmenü symmetrisch an (die "slot"-Werte in shop.yml werden ignoriert). */
    private void applyLayout() {
        int[] slots = switch (categories.size()) {
            case 1 -> new int[]{13};
            case 2 -> new int[]{12, 14};
            case 3 -> new int[]{11, 13, 15};
            case 4 -> new int[]{10, 12, 14, 16};
            case 5 -> new int[]{11, 13, 15, 21, 23};
            case 6 -> new int[]{11, 13, 15, 20, 22, 24};
            default -> new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
        };
        int i = 0;
        for (ShopCategory category : categories.values()) {
            category.setSlot(i < slots.length ? slots[i] : -1); // -1 = erster freier Platz
            i++;
        }
    }

    private double toDouble(Object o) {
        if (o instanceof Number number) {
            return number.doubleValue();
        }
        return 0.0;
    }

    /** Alle Items, die im Spielermarkt gehandelt werden dürfen (= alle Items aus den Kategorien der shop.yml). */
    public boolean isTradable(Material material) {
        return tradable.contains(material);
    }

    public Set<Material> getTradableMaterials() {
        return tradable;
    }

    public Map<String, ShopCategory> getCategories() {
        return categories;
    }
}
