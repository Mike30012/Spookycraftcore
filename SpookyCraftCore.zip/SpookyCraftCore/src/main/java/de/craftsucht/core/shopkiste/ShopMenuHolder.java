package de.craftsucht.core.shopkiste;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Menü "Anzahl wählen" (Sneak + Rechtsklick auf das Schild). */
public class ShopMenuHolder implements InventoryHolder {

    private final ShopRecord shop;
    private final int count;

    public ShopMenuHolder(ShopRecord shop, int count) {
        this.shop = shop;
        this.count = count;
    }

    public ShopRecord getShop() {
        return shop;
    }

    public int getCount() {
        return count;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
