package de.craftsucht.core.anticheat;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Leichtgewichtiger, rein Bukkit-basierter AntiCheat (keine Packet-Library nötig).
 *
 * Checks: Fly, Speed, NoFall/GroundSpoof, Teleport, Reach, KillAura (Winkel + Multi-Target),
 * AutoClicker, Nuker, X-Ray-Verdacht. Jeder Check sammelt Violation Levels (VL), die mit der Zeit
 * abklingen. Staff wird ab einem einstellbaren VL gewarnt (/anticheat alerts).
 *
 * Wichtig: Das ist KEIN Ersatz für Grim/Vulcan & Co., sondern eine solide erste Verteidigungslinie.
 * Standardmäßig wird nur gewarnt (und optional zurückgesetzt/gekickt) - nie automatisch gebannt.
 * Alle Schwellen stehen unter "anticheat:" in der config.yml.
 */
public class AntiCheatModule implements Module, Listener {

    public static final String[] CHECKS = {
            "fly", "speed", "ground-spoof", "teleport", "reach", "killaura", "autoclicker", "nuker", "xray"
    };

    private static final String BYPASS_PERMISSION = "craftsucht.anticheat.bypass";

    private static final Set<Material> SPECIAL_BLOCKS = EnumSet.of(
            Material.COBWEB, Material.SWEET_BERRY_BUSH, Material.HONEY_BLOCK, Material.SLIME_BLOCK,
            Material.POWDER_SNOW, Material.BUBBLE_COLUMN, Material.WATER, Material.LAVA);

    private static final Set<Material> RARE_ORES = EnumSet.of(
            Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE, Material.ANCIENT_DEBRIS,
            Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE);

    private static final class State {
        long exemptUntil;
        int airMoves;
        double lastDy;
        double speedBuf;
        int spoofBuf;
        long lastHitTime;
        UUID lastHitTarget;
        final Map<String, Double> vl = new HashMap<>();
        final Map<String, Long> lastAlert = new HashMap<>();
        final ArrayDeque<Long> swings = new ArrayDeque<>();
        final ArrayDeque<Long> breaks = new ArrayDeque<>();
        final ArrayDeque<Long> ores = new ArrayDeque<>();
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, State> states = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();
    private BukkitTask decayTask;

    public AntiCheatModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "anticheat";
    }

    @Override
    public void enable() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
        AntiCheatCommand command = new AntiCheatCommand(plugin, this);
        PluginCommand pc = plugin.getCommand("anticheat");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }
        decayTask = Bukkit.getScheduler().runTaskTimer(plugin, this::decay, 600L, 600L);
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            state(p).exemptUntil = now + 3000L;
        }
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        if (decayTask != null) {
            decayTask.cancel();
            decayTask = null;
        }
        states.clear();
        PluginCommand pc = plugin.getCommand("anticheat");
        if (pc != null) {
            pc.setExecutor((sender, cmd, label, args) -> {
                plugin.getMessageUtil().send(sender, "&cAntiCheat ist deaktiviert. Aktivieren: /bccore enable anticheat");
                return true;
            });
            pc.setTabCompleter(null);
        }
    }

    // ------------------------------------------------------------------ API für den Command

    public Map<String, Double> getViolations(UUID uuid) {
        State st = states.get(uuid);
        return st == null ? new HashMap<>() : new HashMap<>(st.vl);
    }

    public void resetViolations(UUID uuid) {
        State st = states.get(uuid);
        if (st != null) {
            st.vl.clear();
            st.lastAlert.clear();
            st.speedBuf = 0;
            st.spoofBuf = 0;
        }
    }

    /** @return true, wenn Alerts für diesen Spieler danach AN sind. */
    public boolean toggleAlerts(UUID uuid) {
        if (alertsOff.remove(uuid)) return true;
        alertsOff.add(uuid);
        return false;
    }

    public boolean isCheckEnabled(String name) {
        return plugin.getConfig().getBoolean("anticheat.checks." + name, true);
    }

    // ------------------------------------------------------------------ Hilfen

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    private void exempt(Player p, long millis) {
        State st = state(p);
        st.exemptUntil = Math.max(st.exemptUntil, System.currentTimeMillis() + millis);
        st.airMoves = 0;
        st.speedBuf = 0;
        st.spoofBuf = 0;
    }

    private void decay() {
        double dec = cfg().getDouble("anticheat.vl-decay-per-30s", 1.0);
        for (State st : states.values()) {
            st.vl.replaceAll((k, v) -> Math.max(0.0, v - dec));
            st.vl.values().removeIf(v -> v <= 0.0001);
        }
    }

    private boolean isExempt(Player p, State st, long now) {
        if (p.hasPermission(BYPASS_PERMISSION)) return true;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return true;
        if (p.getAllowFlight() || p.isFlying() || p.isInsideVehicle() || p.isGliding()
                || p.isRiptiding() || p.isSleeping() || p.isDead()) return true;
        if (st.exemptUntil > now) return true;
        return Bukkit.getTPS()[0] < cfg().getDouble("anticheat.min-tps", 17.0);
    }

    private int effectLevel(Player p, PotionEffectType type) {
        PotionEffect pe = p.getPotionEffect(type);
        return pe == null ? 0 : pe.getAmplifier() + 1;
    }

    private boolean canSeeAlerts(Player p) {
        return p.isOp() || p.hasPermission("craftsucht.core.admin") || p.hasPermission("craftsucht.anticheat.alerts");
    }

    private void alertStaff(String message) {
        String text = "&8[&cAC&8] " + message;
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (canSeeAlerts(staff) && !alertsOff.contains(staff.getUniqueId())) {
                plugin.getMessageUtil().sendRaw(staff, text);
            }
        }
        plugin.getLogger().info("[AC] " + org.bukkit.ChatColor.stripColor(plugin.getMessageUtil().color(message)));
    }

    private void flag(Player p, State st, String check, double add, String detail) {
        flag(p, st, check, add, detail, false);
    }

    private void flag(Player p, State st, String check, double add, String detail, boolean forceAlert) {
        double vl = st.vl.merge(check, add, Double::sum);
        long now = System.currentTimeMillis();
        double alertVl = cfg().getDouble("anticheat.alert-vl", 2.0);
        if (forceAlert || vl >= alertVl) {
            long cooldown = cfg().getLong("anticheat.alert-cooldown-seconds", 3L) * 1000L;
            if (now - st.lastAlert.getOrDefault(check, 0L) >= cooldown) {
                st.lastAlert.put(check, now);
                alertStaff("&b" + p.getName() + " &7flaggt &e" + check + " &8(VL &f" + String.format("%.1f", vl)
                        + "&8) &7" + detail);
            }
        }
        double kickAt = cfg().getDouble("anticheat.kick-at-vl", 0.0);
        if (kickAt > 0 && vl >= kickAt) {
            st.vl.put(check, 0.0);
            p.kickPlayer(plugin.getMessageUtil().color("&cDu wurdest vom AntiCheat gekickt.\n&7Verdacht: &f" + check));
        }
    }

    // ------------------------------------------------------------------ Ausnahmen (Teleport, Knockback, ...)

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        exempt(e.getPlayer(), 2000L);
    }

    @EventHandler
    public void onVelocity(PlayerVelocityEvent e) {
        exempt(e.getPlayer(), 2500L); // Knockback, Explosionen, Windcharge, Pistons, ...
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        exempt(e.getPlayer(), 3000L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        exempt(e.getPlayer(), 3000L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        exempt(e.getPlayer(), 3000L);
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent e) {
        exempt(e.getPlayer(), 3000L);
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        exempt(e.getPlayer(), 3000L);
    }

    @EventHandler
    public void onRiptide(PlayerRiptideEvent e) {
        exempt(e.getPlayer(), 3000L);
    }

    @EventHandler
    public void onGlide(EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player p) exempt(p, 3000L);
    }

    @EventHandler
    public void onDamaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) exempt(p, 1000L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Bewegung: Teleport, Speed, Fly, NoFall

    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null || from.getWorld() == null || !from.getWorld().equals(to.getWorld())) return;

        double dx = to.getX() - from.getX();
        double dy = to.getY() - from.getY();
        double dz = to.getZ() - from.getZ();
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz == 0 && dy == 0) return; // nur Kopfdrehung

        Player p = e.getPlayer();
        State st = state(p);
        long now = System.currentTimeMillis();
        if (isExempt(p, st, now)) {
            st.airMoves = 0;
            st.speedBuf = 0;
            st.spoofBuf = 0;
            st.lastDy = dy;
            return;
        }

        boolean setback = false;

        // --- Teleport: riesiger Sprung in einem einzigen Bewegungsschritt
        double total = Math.sqrt(horiz * horiz + dy * dy);
        if (isCheckEnabled("teleport") && total > cfg().getDouble("anticheat.teleport.max-distance", 10.0)) {
            flag(p, st, "Teleport", 2.0, String.format("%.1f Blöcke in einem Schritt", total));
            setback = true;
        }

        // --- Speed
        if (isCheckEnabled("speed")) {
            double max = cfg().getDouble("anticheat.speed.max-per-move", 0.75);
            int speedLevel = effectLevel(p, PotionEffectType.SPEED);
            if (speedLevel > 0) max *= 1.0 + 0.25 * speedLevel;
            if (onIce(to)) max *= 1.8;
            if (horiz > max) {
                st.speedBuf += 1.0;
            } else {
                st.speedBuf = Math.max(0.0, st.speedBuf - 0.5);
            }
            if (st.speedBuf >= cfg().getInt("anticheat.speed.buffer", 5)) {
                st.speedBuf = 2.0;
                flag(p, st, "Speed", 1.0, String.format("%.2f Blöcke/Tick (erlaubt %.2f)", horiz, max));
                setback = true;
            }
        }

        // --- Fly + NoFall/GroundSpoof
        boolean env = specialEnvironment(p, to);
        boolean grounded = isGrounded(to);

        if (env || grounded) {
            st.airMoves = 0;
        } else {
            st.airMoves++;
            if (isCheckEnabled("fly")) {
                int jump = effectLevel(p, PotionEffectType.JUMP_BOOST);
                boolean hover = st.airMoves > 14 + 4 * jump && dy > -0.04;
                boolean rising = st.airMoves > 8 + 3 * jump && dy > 0.03;
                if ((hover || rising) && !standingOnEntity(to)) {
                    flag(p, st, "Fly", 1.0, (hover ? "schwebt" : "steigt in der Luft") + " ("
                            + st.airMoves + " Ticks in der Luft)");
                    setback = true;
                }
            }
        }

        if (isCheckEnabled("ground-spoof")) {
            if (p.isOnGround() && !grounded && !env) {
                st.spoofBuf++;
                if (st.spoofBuf >= cfg().getInt("anticheat.ground-spoof.buffer", 6)) {
                    st.spoofBuf = 0;
                    if (!standingOnEntity(to)) {
                        flag(p, st, "NoFall/GroundSpoof", 1.0, "Client meldet Boden, aber kein Block darunter");
                    }
                }
            } else {
                st.spoofBuf = Math.max(0, st.spoofBuf - 1);
            }
        }

        st.lastDy = dy;

        if (setback && cfg().getBoolean("anticheat.setback", true)) {
            e.setCancelled(true);
            st.airMoves = 0;
            st.speedBuf = 0;
        }
    }

    private boolean onIce(Location loc) {
        for (double off : new double[]{0.5, 1.2}) {
            String name = loc.clone().subtract(0, off, 0).getBlock().getType().name();
            if (name.contains("ICE")) return true;
        }
        return false;
    }

    /** Wasser, Lava, Leitern, Ranken, Spinnennetz, Slime, Honig, Betten, Levitation ... = kein Fly-Verdacht. */
    private boolean specialEnvironment(Player p, Location loc) {
        if (p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
            return true;
        }
        Block feet = loc.getBlock();
        Block[] blocks = {feet, feet.getRelative(0, 1, 0), feet.getRelative(0, -1, 0)};
        for (Block b : blocks) {
            Material m = b.getType();
            if (b.isLiquid() || SPECIAL_BLOCKS.contains(m) || Tag.CLIMBABLE.isTagged(m) || m.name().endsWith("_BED")) {
                return true;
            }
        }
        return false;
    }

    /** Steht der Spieler auf einem festen Block? Berücksichtigt auch hohe Kollisionsboxen (Zäune, Mauern). */
    private boolean isGrounded(Location loc) {
        World w = loc.getWorld();
        double x = loc.getX();
        double y = loc.getY();
        double z = loc.getZ();
        double[] offs = {-0.3, 0.0, 0.3};

        for (double ox : offs) {
            for (double oz : offs) {
                int bx = (int) Math.floor(x + ox);
                int bz = (int) Math.floor(z + oz);
                if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return true;
                Block b = w.getBlockAt(bx, (int) Math.floor(y - 0.1), bz);
                if (!b.isPassable()) return true;
            }
        }

        BoundingBox feet = new BoundingBox(x - 0.3, y - 0.1, z - 0.3, x + 0.3, y, z + 0.3);
        for (double ox : offs) {
            for (double oz : offs) {
                int bx = (int) Math.floor(x + ox);
                int bz = (int) Math.floor(z + oz);
                Block b = w.getBlockAt(bx, (int) Math.floor(y - 0.6), bz);
                if (b.isPassable()) continue;
                for (BoundingBox bb : b.getCollisionShape().getBoundingBoxes()) {
                    if (bb.clone().shift(b.getX(), b.getY(), b.getZ()).overlaps(feet)) return true;
                }
            }
        }
        return false;
    }

    /** Boote, Loren, Shulker zählen als Boden. */
    private boolean standingOnEntity(Location loc) {
        return !loc.getWorld().getNearbyEntities(loc.clone().subtract(0, 0.5, 0), 0.8, 0.8, 0.8,
                en -> en instanceof Boat || en instanceof Minecart || en instanceof Shulker).isEmpty();
    }

    // ------------------------------------------------------------------ Kampf: Reach, KillAura

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (p.hasPermission(BYPASS_PERMISSION)) return;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;

        Entity target = e.getEntity();
        State st = state(p);
        long now = System.currentTimeMillis();
        Location eye = p.getEyeLocation();

        if (isCheckEnabled("reach")) {
            BoundingBox bb = target.getBoundingBox();
            double cx = Math.max(bb.getMinX(), Math.min(eye.getX(), bb.getMaxX()));
            double cy = Math.max(bb.getMinY(), Math.min(eye.getY(), bb.getMaxY()));
            double cz = Math.max(bb.getMinZ(), Math.min(eye.getZ(), bb.getMaxZ()));
            double dist = Math.sqrt(Math.pow(eye.getX() - cx, 2) + Math.pow(eye.getY() - cy, 2) + Math.pow(eye.getZ() - cz, 2));
            double max = cfg().getDouble("anticheat.reach.max-distance", 3.6) + Math.min(0.6, p.getPing() * 0.002);
            if (dist > max) {
                flag(p, st, "Reach", 1.0, String.format("%.2f Blöcke (erlaubt %.2f)", dist, max));
            }
        }

        if (isCheckEnabled("killaura")) {
            Vector toTarget = target.getBoundingBox().getCenter().subtract(eye.toVector());
            double d = toTarget.length();
            if (d > 2.0) {
                double angle = Math.toDegrees(eye.getDirection().angle(toTarget.normalize()));
                double maxAngle = cfg().getDouble("anticheat.killaura.max-angle", 90.0);
                if (angle > maxAngle) {
                    flag(p, st, "KillAura", 1.0, String.format("trifft %.0f° neben das Ziel", angle));
                }
            }
            if (st.lastHitTarget != null && !st.lastHitTarget.equals(target.getUniqueId()) && now - st.lastHitTime < 40L) {
                flag(p, st, "KillAura", 1.5, "trifft mehrere Ziele gleichzeitig");
            }
            st.lastHitTarget = target.getUniqueId();
            st.lastHitTime = now;
        }
    }

    // ------------------------------------------------------------------ AutoClicker

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        if (!isCheckEnabled("autoclicker")) return;
        Player p = e.getPlayer();
        if (p.hasPermission(BYPASS_PERMISSION)) return;
        State st = state(p);
        long now = System.currentTimeMillis();
        st.swings.addLast(now);
        while (!st.swings.isEmpty() && now - st.swings.peekFirst() > 1000L) st.swings.removeFirst();
        int maxCps = cfg().getInt("anticheat.autoclicker.max-cps", 25);
        if (st.swings.size() > maxCps) {
            flag(p, st, "AutoClicker", 1.0, st.swings.size() + " Klicks/Sekunde");
            st.swings.clear();
        }
    }

    // ------------------------------------------------------------------ Nuker + X-Ray

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (de.craftsucht.core.booster.AreaMiningListener.isExtraBreak()) return; // Area-Spitzhacke: kein Nuker
        Player p = e.getPlayer();
        if (p.hasPermission(BYPASS_PERMISSION)) return;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        State st = state(p);
        long now = System.currentTimeMillis();

        if (isCheckEnabled("nuker")) {
            st.breaks.addLast(now);
            while (!st.breaks.isEmpty() && now - st.breaks.peekFirst() > 1000L) st.breaks.removeFirst();
            int max = cfg().getInt("anticheat.nuker.max-breaks-per-second", 40);
            if (st.breaks.size() > max) {
                flag(p, st, "Nuker", 1.0, st.breaks.size() + " Blöcke/Sekunde");
                st.breaks.clear();
            }
        }

        if (isCheckEnabled("xray") && RARE_ORES.contains(e.getBlock().getType())) {
            long window = cfg().getLong("anticheat.xray.window-minutes", 10L) * 60_000L;
            st.ores.addLast(now);
            while (!st.ores.isEmpty() && now - st.ores.peekFirst() > window) st.ores.removeFirst();
            int threshold = cfg().getInt("anticheat.xray.threshold", 12);
            if (st.ores.size() >= threshold) {
                flag(p, st, "X-Ray", 1.0, st.ores.size() + " seltene Erze in "
                        + cfg().getLong("anticheat.xray.window-minutes", 10L) + " Min. (nur Verdacht!)", true);
                st.ores.clear();
            }
        }
    }
}
