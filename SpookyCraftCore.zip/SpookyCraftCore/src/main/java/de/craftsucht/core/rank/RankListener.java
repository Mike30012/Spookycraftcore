package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class RankListener implements Listener {

    private final SpookyCraftCore plugin;
    private final RankManager manager;

    public RankListener(SpookyCraftCore plugin, RankManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent event) {
        manager.apply(event.getPlayer());
        refreshVisuals();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        manager.remove(event.getPlayer());
    }

    /**
     * Setzt den Rang-Prefix vor den Spielernamen im Chat. Läuft NACH dem
     * Mute-Check (LOWEST) und VOR dem Clan-Chat-Handler (NORMAL), und wird
     * bei einem bereits abgebrochenen Event (z.B. gemutet) übersprungen.
     * Spieler mit "spookycraft.chat.color" dürfen &-Farbcodes in ihrer
     * Nachricht benutzen, die werden dann hier übersetzt; alle anderen
     * schreiben ganz normal (& bleibt als reiner Text sichtbar).
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        String prefix = manager.getColoredPrefix(event.getPlayer().getUniqueId());
        String nameColor = plugin.getConfig().getBoolean("rank.chat-job-color", true) ? getJobNameColor(event.getPlayer()) : "";
        String msgColor = msgColorOf(event.getPlayer());
        String format = (prefix.isEmpty() ? "" : prefix + "§r: ") + nameColor + "%1$s " + msgColor + "%2$s";
        event.setFormat(format);

        if (event.getPlayer().hasPermission("spookycraft.chat.color")) {
            event.setMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', event.getMessage()));
        }
        applyPings(event);
        showHeldItem(event, prefix, nameColor);
    }

    /** Owner und Admin schreiben automatisch in rot-fett (&c&l), alle anderen weiss. */
    private String msgColorOf(org.bukkit.entity.Player p) {
        String r = manager.getUserRank(p.getUniqueId());
        if (r != null && (r.equalsIgnoreCase("owner") || r.equalsIgnoreCase("admin"))) return "§c§l";
        return "§f";
    }

    /**
     * Schreibt ein Spieler [item] in den Chat und haelt ein Item in der Hand, wird [item] durch den Item-Namen ersetzt.
     * Beim Drueberfahren zeigt der Chat das echte Item mit Verzauberungen und Beschreibung (Lore = "was es kann").
     */
    private void showHeldItem(AsyncPlayerChatEvent event, String prefix, String nameColor) {
        if (!plugin.getConfig().getBoolean("chat-item.enabled", true)) return;
        String message = event.getMessage();
        if (!message.toLowerCase().contains("[item]")) return;
        org.bukkit.entity.Player player = event.getPlayer();
        org.bukkit.inventory.ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            player.sendMessage("§cDu musst ein Item in der Hand halten, damit [item] funktioniert.");
            return;
        }
        final org.bukkit.inventory.ItemStack shown = hand.clone();
        var legacy = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection();
        net.kyori.adventure.text.Component itemComp = shown.displayName();
        if (shown.getAmount() > 1) itemComp = itemComp.append(net.kyori.adventure.text.Component.text(" x" + shown.getAmount(),
                net.kyori.adventure.text.format.NamedTextColor.GRAY));

        net.kyori.adventure.text.Component line = legacy.deserialize((prefix.isEmpty() ? "" : prefix + "§r: ")
                + nameColor + player.getDisplayName() + " " + msgColorOf(player));
        String[] parts = message.split("(?i)\\[item\\]", -1);
        for (int i = 0; i < parts.length; i++) {
            if (!parts[i].isEmpty()) line = line.append(legacy.deserialize(msgColorOf(player) + parts[i]));
            if (i < parts.length - 1) line = line.append(itemComp);
        }
        final net.kyori.adventure.text.Component out = line;
        event.setCancelled(true);
        java.util.Set<org.bukkit.entity.Player> recipients = new java.util.HashSet<>(event.getRecipients());
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (org.bukkit.entity.Player r : recipients) r.sendMessage(out);
            Bukkit.getConsoleSender().sendMessage(out);
        });
    }

    /**
     * Teamler (OP, Vanish-/Admin-Recht oder "spookycraft.chat.ping") können Spieler anpingen: Der Name in der Nachricht
     * wird automatisch zu &b@Name (blau) und der Gefragte hört einen Ton. Funktioniert mit und ohne @.
     */
    private void applyPings(AsyncPlayerChatEvent event) {
        org.bukkit.entity.Player sender = event.getPlayer();
        if (!plugin.getConfig().getBoolean("chat-ping.enabled", true)) return;
        if (!(de.craftsucht.core.vanish.VanishModule.isStaff(sender) || sender.hasPermission("spookycraft.chat.ping"))) return;
        String message = event.getMessage();
        java.util.List<org.bukkit.entity.Player> pinged = new java.util.ArrayList<>();
        de.craftsucht.core.vanish.VanishModule vanish = plugin.getModuleManager().get("vanish") instanceof de.craftsucht.core.vanish.VanishModule vm ? vm : null;
        for (org.bukkit.entity.Player target : new java.util.ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (target.getUniqueId().equals(sender.getUniqueId())) continue;
            if (vanish != null && vanish.isVanished(target.getUniqueId())) continue;   // Vanish nicht verraten
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "(?i)(?<![A-Za-z0-9_§])@?" + java.util.regex.Pattern.quote(target.getName()) + "(?![A-Za-z0-9_])").matcher(message);
            if (m.find()) {
                message = m.replaceAll(java.util.regex.Matcher.quoteReplacement("§b@" + target.getName() + "§f"));
                pinged.add(target);
            }
        }
        if (pinged.isEmpty()) return;
        event.setMessage(message);
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (org.bukkit.entity.Player t : pinged) {
                if (t.isOnline()) t.playSound(t.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);
            }
        });
    }

    /**
     * Nur die Farbe (kein Text) aus dem höchsten erreichten Job-Titel (siehe
     * jobs-Modul/RewardManager), leerer String falls kein Jobs-Modul aktiv
     * oder noch kein Titel-Level erreicht - dann bleibt die Standardfarbe.
     */
    private String getJobNameColor(org.bukkit.entity.Player p) {
        Module m = plugin.getModuleManager().get("jobs");
        if (!(m instanceof de.craftsucht.core.jobs.JobsModule jobsModule)) return "";
        de.craftsucht.core.jobs.PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return "";
        org.bukkit.ChatColor color = jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
        return color != null ? color.toString() : "";
    }

    private void refreshVisuals() {
        Module m = plugin.getModuleManager().get("scoreboard");
        if (m instanceof ScoreboardModule sm) {
            sm.refreshNow();
        }
    }
}
