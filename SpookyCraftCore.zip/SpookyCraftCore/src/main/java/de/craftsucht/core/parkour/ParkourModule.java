package de.craftsucht.core.parkour;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Spawn-Parkour: /parkour setstart | addcheckpoint | setend | sethologram | clear (Admin),
 * /parkour top | restart | leave (alle). Zeitmessung, Checkpoints, Bestenliste, Belohnungen.
 * Daten: plugins/SpookyCraftCore/parkour.yml
 */
public class ParkourModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static class Run {
        long start;
        int checkpoint = -1;   // -1 = Start
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private final Map<UUID, Run> runs = new HashMap<>();
    private BukkitTask task;
    private TextDisplay holo;

    public ParkourModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "parkour";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "parkour.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("parkour").setExecutor(this);
        plugin.getCommand("parkour").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
        Bukkit.getScheduler().runTaskLater(plugin, this::updateHologram, 40L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        org.bukkit.event.HandlerList.unregisterAll(this);
        if (holo != null && holo.isValid()) holo.remove();
        runs.clear();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("parkour.yml speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    private void msg(CommandSender s, String t) {
        plugin.getMessageUtil().send(s, t);
    }

    private boolean isStaff(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin");
    }

    // ------------------------------------------------------------------ Orte

    private static void putLoc(YamlConfiguration y, String path, Location l) {
        y.set(path + ".world", l.getWorld().getName());
        y.set(path + ".x", l.getBlockX());
        y.set(path + ".y", l.getBlockY());
        y.set(path + ".z", l.getBlockZ());
        y.set(path + ".yaw", l.getYaw());
    }

    private static Location getLoc(YamlConfiguration y, String path) {
        if (!y.contains(path + ".world")) return null;
        org.bukkit.World w = Bukkit.getWorld(y.getString(path + ".world", ""));
        if (w == null) return null;
        return new Location(w, y.getInt(path + ".x") + 0.5, y.getInt(path + ".y"), y.getInt(path + ".z") + 0.5,
                (float) y.getDouble(path + ".yaw"), 0f);
    }

    private List<Location> checkpoints() {
        List<Location> l = new ArrayList<>();
        int n = data.getInt("checkpoints", 0);
        for (int i = 0; i < n; i++) {
            Location c = getLoc(data, "cp." + i);
            if (c != null) l.add(c);
        }
        return l;
    }

    private static boolean at(Location a, Location b) {
        return a != null && b != null && a.getWorld().equals(b.getWorld())
                && a.getBlockX() == b.getBlockX() && a.getBlockZ() == b.getBlockZ()
                && Math.abs(a.getBlockY() - b.getBlockY()) <= 1;
    }

    // ------------------------------------------------------------------ Laufzeit

    private void tick() {
        Location start = getLoc(data, "start");
        Location end = getLoc(data, "end");
        List<Location> cps = checkpoints();
        // Markierungen
        if (start != null) mark(start, Particle.HAPPY_VILLAGER);
        if (end != null) mark(end, Particle.FLAME);
        for (Location c : cps) mark(c, Particle.END_ROD);
        // Zeit-Anzeige + Sturz-Erkennung
        for (Map.Entry<UUID, Run> e : new ArrayList<>(runs.entrySet())) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null) {
                runs.remove(e.getKey());
                continue;
            }
            Run r = e.getValue();
            double sec = (System.currentTimeMillis() - r.start) / 1000.0;
            p.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&5☠ &d" + fmt(sec) + " &8| &7Checkpoint &d" + (r.checkpoint + 1) + "&7/&d" + cps.size()));
            Location back = r.checkpoint >= 0 && r.checkpoint < cps.size() ? cps.get(r.checkpoint) : start;
            if (back != null && p.getWorld().equals(back.getWorld()) && p.getLocation().getY() < back.getY() - 12) {
                p.teleport(back);
                p.setFallDistance(0);
                msg(p, "&5☠ &dDie Geister haben dich zurückgeholt!");
            }
            if (back != null && !p.getWorld().equals(back.getWorld())) runs.remove(e.getKey());
        }
    }

    private void mark(Location l, Particle particle) {
        l.getWorld().spawnParticle(particle, l.clone().add(0, 0.2, 0), 6, 0.35, 0.2, 0.35, 0.0);
    }

    private static String fmt(double sec) {
        long m = (long) (sec / 60);
        double s = sec - m * 60;
        return String.format(Locale.ROOT, "%d:%05.2f", m, s);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (e.getFrom().getBlockX() == e.getTo().getBlockX() && e.getFrom().getBlockZ() == e.getTo().getBlockZ()
                && e.getFrom().getBlockY() == e.getTo().getBlockY()) return;
        Player p = e.getPlayer();
        Location to = e.getTo();
        Location start = getLoc(data, "start");
        if (start == null) return;
        Run r = runs.get(p.getUniqueId());
        if (at(to, start) && (r == null || r.checkpoint == -1)) {
            Run nr = new Run();
            nr.start = System.currentTimeMillis();
            runs.put(p.getUniqueId(), nr);
            msg(p, "&5☠ &dDer Parkour beginnt! &7Die Zeit läuft...");
            return;
        }
        if (r == null) return;
        List<Location> cps = checkpoints();
        for (int i = r.checkpoint + 1; i < cps.size(); i++) {
            if (at(to, cps.get(i))) {
                r.checkpoint = i;
                msg(p, "&aCheckpoint &f" + (i + 1) + "&a/&f" + cps.size() + " &7(" + fmt((System.currentTimeMillis() - r.start) / 1000.0) + ")");
                p.playSound(p.getLocation(), "block.note_block.pling", 0.8f, 1.4f);
                return;
            }
        }
        Location end = getLoc(data, "end");
        if (end != null && at(to, end) && r.checkpoint >= cps.size() - 1) {
            finish(p, r);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        runs.remove(e.getPlayer().getUniqueId());
    }

    private void finish(Player p, Run r) {
        runs.remove(p.getUniqueId());
        double sec = (System.currentTimeMillis() - r.start) / 1000.0;
        String base = "times." + p.getUniqueId();
        double best = data.getDouble(base + ".time", -1);
        boolean first = best < 0;
        boolean pb = first || sec < best;
        double oldTop = topTime();
        if (pb) {
            data.set(base + ".time", sec);
            data.set(base + ".name", p.getName());
            save();
        }
        msg(p, "&5☠ &dGeschafft in &5&l" + fmt(sec) + "&d!" + (pb && !first ? " &a(neue Bestzeit!)" : ""));
        boolean record = pb && (oldTop < 0 || sec < oldTop);
        long money = 0;
        long crystals = 0;
        if (first) money += plugin.getConfig().getLong("parkour.reward-first-money", 500);
        else if (pb) money += plugin.getConfig().getLong("parkour.reward-pb-money", 100);
        if (record) {
            money += plugin.getConfig().getLong("parkour.reward-record-money", 1000);
            crystals += plugin.getConfig().getLong("parkour.reward-record-crystals", 10);
            Bukkit.broadcastMessage("§8[§5☠§8] §d" + p.getName() + " §7hat einen neuen §5Parkour-Rekord§7: §f" + fmt(sec) + "§7!");
        }
        if (money > 0 && plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
            em.getManager().deposit(p.getUniqueId(), money);
            msg(p, "&6+ $" + money + " &7Belohnung");
        }
        if (crystals > 0 && plugin.getModuleManager().get("crates") instanceof de.craftsucht.core.crates.CratesModule cm && cm.getCrystals() != null) {
            cm.getCrystals().add(p.getUniqueId(), crystals);
            msg(p, "&b+" + crystals + " Kristalle");
        }
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.2);
        updateHologram();
    }

    private double topTime() {
        double best = -1;
        if (data.getConfigurationSection("times") == null) return best;
        for (String k : data.getConfigurationSection("times").getKeys(false)) {
            double t = data.getDouble("times." + k + ".time", -1);
            if (t >= 0 && (best < 0 || t < best)) best = t;
        }
        return best;
    }

    private List<Map.Entry<String, Double>> ranking() {
        List<Map.Entry<String, Double>> l = new ArrayList<>();
        if (data.getConfigurationSection("times") == null) return l;
        for (String k : data.getConfigurationSection("times").getKeys(false)) {
            double t = data.getDouble("times." + k + ".time", -1);
            if (t >= 0) l.add(Map.entry(data.getString("times." + k + ".name", "?"), t));
        }
        l.sort(Map.Entry.comparingByValue());
        return l;
    }

    private void updateHologram() {
        if (holo != null && holo.isValid()) holo.remove();
        holo = null;
        Location hl = getLoc(data, "hologram");
        if (hl == null) return;
        StringBuilder sb = new StringBuilder("&5&l☠ PARKOUR – BESTENLISTE ☠\n");
        List<Map.Entry<String, Double>> r = ranking();
        if (r.isEmpty()) sb.append("&7Noch niemand im Ziel!");
        for (int i = 0; i < Math.min(10, r.size()); i++) {
            String col = i == 0 ? "&6" : i == 1 ? "&f" : i == 2 ? "&c" : "&7";
            sb.append(col).append("#").append(i + 1).append(" &d").append(r.get(i).getKey()).append(" &8» &f").append(fmt(r.get(i).getValue())).append("\n");
        }
        final String text = sb.toString().trim();
        hl.setY(hl.getY() + 1.5);
        holo = hl.getWorld().spawn(hl, TextDisplay.class, t -> {
            t.setPersistent(false);
            t.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
            t.setBackgroundColor(org.bukkit.Color.fromARGB(90, 20, 0, 40));
            t.text(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize(text));
        });
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "top" : args[0].toLowerCase();
        switch (sub) {
            case "top" -> {
                List<Map.Entry<String, Double>> r = ranking();
                msg(sender, "&5☠ &dParkour-Bestenliste:");
                if (r.isEmpty()) msg(sender, "&7Noch niemand im Ziel!");
                for (int i = 0; i < Math.min(10, r.size()); i++)
                    plugin.getMessageUtil().sendRaw(sender, " &8#" + (i + 1) + " &d" + r.get(i).getKey() + " &8» &f" + fmt(r.get(i).getValue()));
            }
            case "restart", "leave" -> {
                if (!(sender instanceof Player p)) return true;
                if (sub.equals("leave")) {
                    runs.remove(p.getUniqueId());
                    msg(p, "&7Parkour abgebrochen.");
                    return true;
                }
                Run r = runs.get(p.getUniqueId());
                List<Location> cps = checkpoints();
                Location back = r != null && r.checkpoint >= 0 && r.checkpoint < cps.size() ? cps.get(r.checkpoint) : getLoc(data, "start");
                if (back == null) {
                    msg(p, "&cEs ist noch kein Parkour eingerichtet.");
                    return true;
                }
                p.teleport(back);
                p.setFallDistance(0);
            }
            case "setstart", "addcheckpoint", "setend", "sethologram", "clear" -> {
                if (!isStaff(sender)) {
                    msg(sender, "&cKeine Berechtigung.");
                    return true;
                }
                if (sub.equals("clear")) {
                    data.set("start", null);
                    data.set("end", null);
                    data.set("cp", null);
                    data.set("checkpoints", 0);
                    save();
                    msg(sender, "&aParkour-Orte gelöscht (Bestzeiten bleiben).");
                    return true;
                }
                if (!(sender instanceof Player p)) return true;
                Location l = p.getLocation();
                switch (sub) {
                    case "setstart" -> {
                        putLoc(data, "start", l);
                        msg(p, "&aStart gesetzt.");
                    }
                    case "setend" -> {
                        putLoc(data, "end", l);
                        msg(p, "&aZiel gesetzt.");
                    }
                    case "addcheckpoint" -> {
                        int n = data.getInt("checkpoints", 0);
                        putLoc(data, "cp." + n, l);
                        data.set("checkpoints", n + 1);
                        msg(p, "&aCheckpoint " + (n + 1) + " gesetzt.");
                    }
                    default -> {
                        putLoc(data, "hologram", l);
                        msg(p, "&aBestenlisten-Hologramm gesetzt.");
                    }
                }
                save();
                updateHologram();
            }
            default -> msg(sender, "&cNutzung: /parkour top|restart|leave" + (isStaff(sender) ? "|setstart|addcheckpoint|setend|sethologram|clear" : ""));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> l = new ArrayList<>(List.of("top", "restart", "leave"));
            if (isStaff(sender)) l.addAll(List.of("setstart", "addcheckpoint", "setend", "sethologram", "clear"));
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], l.toArray(new String[0]));
        }
        return List.of();
    }
}
