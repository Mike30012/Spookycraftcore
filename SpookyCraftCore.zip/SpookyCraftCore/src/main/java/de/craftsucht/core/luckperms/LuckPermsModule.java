package de.craftsucht.core.luckperms;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

/**
 * LuckPerms-Brücke: setzt den LuckPerms-Prefix (+ Job-Namensfarbe) in den Chat.
 * Rechte/Gruppen/Prefixe
 * verwaltest du komplett in LuckPerms (/lp).
 */
public class LuckPermsModule implements Module, Listener {

    private final SpookyCraftCore plugin;

    public LuckPermsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "luckperms";
    }

    @Override
    public void enable() {
        if (!LuckPermsHook.isAvailable()) {
            plugin.getLogger().warning("[luckperms] LuckPerms nicht gefunden - Modul ohne Funktion (Plugin installieren!).");
        }
        if (plugin.getModuleManager().isEnabled("rank")) {
            plugin.getLogger().warning("[luckperms] Das interne Rang-Modul ist ebenfalls aktiv - Chat nutzt dann dessen Prefix. Mit /bccore disable rank abschalten.");
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        // Internes Rang-Modul formatiert selbst, wenn es aktiv ist.
        if (plugin.getModuleManager().isEnabled("rank")) return;
        if (!LuckPermsHook.isAvailable()) return;

        Player p = event.getPlayer();
        String prefix = LuckPermsHook.getPrefix(p);
        String nameColor = jobNameColor(p);
        event.setFormat((prefix.isEmpty() ? "" : prefix + "§r ") + nameColor + "%1$s §f%2$s");

        if (p.hasPermission("craftsucht.chat.color")) {
            event.setMessage(ChatColor.translateAlternateColorCodes('&', event.getMessage()));
        }
    }

    private String jobNameColor(Player p) {
        Module m = plugin.getModuleManager().get("jobs");
        if (!(m instanceof de.craftsucht.core.jobs.JobsModule jobsModule)) return "";
        de.craftsucht.core.jobs.PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return "";
        ChatColor color = jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
        return color != null ? color.toString() : "";
    }
}
