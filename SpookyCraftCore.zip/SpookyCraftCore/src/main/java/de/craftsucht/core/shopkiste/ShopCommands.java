package de.craftsucht.core.shopkiste;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.Sign;
import org.bukkit.block.data.type.WallSign;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** /shopinfo, /shoptransactions, /cstoggle, /iteminfo, /shopcreate */
public class ShopCommands implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final ShopRepository repo;
    private final ShopService service;

    public ShopCommands(SpookyCraftCore plugin, ShopRepository repo, ShopService service) {
        this.plugin = plugin;
        this.repo = repo;
        this.service = service;
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    private ShopRecord lookedAtShop(Player player) {
        Block target = player.getTargetBlockExact(6);
        if (target == null) return null;
        ShopRecord shop = repo.atSign(target);
        return shop != null ? shop : repo.atContainer(target);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            msg(sender, "&cNur Spieler können Shopkisten nutzen.");
            return true;
        }
        switch (command.getName().toLowerCase()) {
            case "cstoggle" -> msg(player, "&7Shop-Benachrichtigungen: " + (service.toggleNotify(player) ? "&aAN" : "&cAUS"));
            case "shopinfo" -> shopInfo(player);
            case "shoptransactions" -> transactions(player);
            case "iteminfo" -> itemInfo(player, args);
            case "shopcreate" -> shopCreate(player, args);
            default -> {
            }
        }
        return true;
    }

    private void shopInfo(Player player) {
        ShopRecord shop = lookedAtShop(player);
        if (shop == null) {
            msg(player, "&cSchau auf ein Shop-Schild oder eine Shopkiste (max. 6 Blöcke Entfernung).");
            return;
        }
        msg(player, "&7--- &6Shopkiste &7---");
        plugin.getMessageUtil().sendRaw(player, "&8» &7Besitzer: &f" + shop.ownerName());
        plugin.getMessageUtil().sendRaw(player, "&8» &7Item: &f" + ShopService.itemName(shop.item()) + " &8(" + shop.item().getType().name() + ")");
        plugin.getMessageUtil().sendRaw(player, "&8» &7Menge pro Transaktion: &f" + shop.amount());
        plugin.getMessageUtil().sendRaw(player, "&8» &7Kaufen (Rechtsklick): " + (shop.canBuy() ? "&a$" + ShopService.fmt(shop.buy()) : "&cnicht möglich"));
        plugin.getMessageUtil().sendRaw(player, "&8» &7Verkaufen (Linksklick): " + (shop.canSell() ? "&6$" + ShopService.fmt(shop.sell()) : "&cnicht möglich"));
        plugin.getMessageUtil().sendRaw(player, "&8» &7Lagerbestand: &f" + service.stockOf(shop));
    }

    private void transactions(Player player) {
        ShopRecord shop = lookedAtShop(player);
        if (shop == null) {
            msg(player, "&cSchau auf ein Shop-Schild oder eine Shopkiste (max. 6 Blöcke Entfernung).");
            return;
        }
        if (!shop.owner().equals(player.getUniqueId()) && !service.isAdmin(player)) {
            msg(player, "&cNur der Besitzer sieht die Transaktionen.");
            return;
        }
        List<String> lines = repo.lastTransactions(shop.id(), 10);
        if (lines.isEmpty()) {
            msg(player, "&7Noch keine Transaktionen.");
            return;
        }
        msg(player, "&7--- &6Letzte Transaktionen &7---");
        for (String line : lines) plugin.getMessageUtil().sendRaw(player, line);
    }

    @SuppressWarnings("deprecation")
    private void itemInfo(Player player, String[] args) {
        ItemStack item;
        if (args.length > 0) {
            Material material = Material.matchMaterial(args[0]);
            if (material == null || material.isAir()) {
                msg(player, "&cUnbekanntes Item: &f" + args[0]);
                return;
            }
            item = new ItemStack(material);
        } else {
            item = player.getInventory().getItemInMainHand();
            if (item.getType().isAir()) {
                msg(player, "&cDu hältst kein Item. Nutze &e/iteminfo <name>&c.");
                return;
            }
        }
        msg(player, "&7--- &6Iteminfo &7---");
        plugin.getMessageUtil().sendRaw(player, "&8» &7Name: &f" + ShopService.itemName(item));
        plugin.getMessageUtil().sendRaw(player, "&8» &7Item-ID für Schilder: &f" + item.getType().name());
        plugin.getMessageUtil().sendRaw(player, "&8» &7Max. Stack: &f" + item.getType().getMaxStackSize());
        if (!item.getEnchantments().isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<Enchantment, Integer> e : item.getEnchantments().entrySet()) {
                sb.append(e.getKey().getKey().getKey()).append(' ').append(e.getValue()).append("  ");
            }
            plugin.getMessageUtil().sendRaw(player, "&8» &7Verzauberungen: &f" + sb.toString().trim());
        }
        if (item.hasItemMeta()) {
            plugin.getMessageUtil().sendRaw(player, "&8» &7Hinweis: &fItem hat Zusatzdaten - im Shop mit &e?&f in Zeile 4 verwenden.");
        }
    }

    /** /shopcreate <menge> <preise> - setzt automatisch ein Schild an die Kiste, auf die du schaust. */
    private void shopCreate(Player player, String[] args) {
        if (args.length < 2) {
            msg(player, "&cNutzung: /shopcreate <menge> <preise>  &7z.B. &f/shopcreate 64 B1000:500S &7(Item aus der Kiste, Blick auf die Kiste)");
            return;
        }
        int amount;
        try {
            amount = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            msg(player, "&cDie Menge muss eine Zahl sein.");
            return;
        }
        double[] prices = ShopService.parsePrices(String.join("", java.util.Arrays.copyOfRange(args, 1, args.length)));
        if (prices == null) {
            msg(player, "&cUngültiger Preis. Beispiele: &fB1000:500S &c(Kauf 1000, Ankauf 500), &fB50 &coder &f20S");
            return;
        }
        if (amount < 1 || amount > ShopService.MAX_AMOUNT) {
            msg(player, "&cDie Menge muss zwischen 1 und " + ShopService.MAX_AMOUNT + " liegen.");
            return;
        }
        RayTraceResult ray = player.rayTraceBlocks(6.0);
        Block container = ray != null ? ray.getHitBlock() : null;
        if (container == null || !ShopListener.isContainer(container)) {
            msg(player, "&cSchau auf eine Kiste oder ein Fass (max. 6 Blöcke Entfernung).");
            return;
        }
        if (repo.atContainer(container) != null) {
            msg(player, "&cDiese Kiste ist bereits ein Shop.");
            return;
        }
        ItemStack template = null;
        if (container.getState() instanceof Container c) {
            for (ItemStack stack : c.getInventory().getStorageContents()) {
                if (stack != null && !stack.getType().isAir()) {
                    template = stack.clone();
                    break;
                }
            }
        }
        if (template == null) {
            msg(player, "&cLege zuerst das Item in die Kiste.");
            return;
        }
        template.setAmount(1);

        // Schild-Seite: die angeschaute Seite, sonst eine freie Seite der Kiste
        List<BlockFace> faces = new ArrayList<>();
        BlockFace hit = ray.getHitBlockFace();
        if (hit != null && hit != BlockFace.UP && hit != BlockFace.DOWN) faces.add(hit);
        for (BlockFace f : new BlockFace[]{BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST}) {
            if (!faces.contains(f)) faces.add(f);
        }
        Block signBlock = null;
        BlockFace signFace = null;
        for (BlockFace f : faces) {
            Block candidate = container.getRelative(f);
            if (candidate.getType().isAir()) {
                signBlock = candidate;
                signFace = f;
                break;
            }
        }
        if (signBlock == null) {
            msg(player, "&cAn der Kiste ist kein Platz für ein Schild.");
            return;
        }

        // Baurechte prüfen (WorldGuard, PlotSquared, ...): Schild setzen und BlockPlaceEvent auslösen
        BlockState replaced = signBlock.getState();
        signBlock.setType(Material.OAK_WALL_SIGN, false);
        WallSign data = (WallSign) signBlock.getBlockData();
        data.setFacing(signFace);
        signBlock.setBlockData(data, false);
        BlockPlaceEvent placeEvent = new BlockPlaceEvent(signBlock, replaced, container, new ItemStack(Material.OAK_SIGN),
                player, true, EquipmentSlot.HAND);
        Bukkit.getPluginManager().callEvent(placeEvent);
        if (placeEvent.isCancelled() || !placeEvent.canBuild()) {
            replaced.update(true, false);
            msg(player, "&cHier darfst du nicht bauen.");
            return;
        }

        ShopRecord shop = repo.insert(signBlock.getWorld().getName(), signBlock, container, player.getUniqueId(), player.getName(),
                template, amount, prices[0], prices[1]);
        if (shop == null) {
            replaced.update(true, false);
            msg(player, "&cDer Shop konnte nicht gespeichert werden.");
            return;
        }
        Sign sign = (Sign) signBlock.getState();
        SignSide side = sign.getSide(Side.FRONT);
        side.setLine(0, player.getName());
        side.setLine(1, String.valueOf(amount));
        side.setLine(2, ShopService.priceLine(prices[0], prices[1]));
        side.setLine(3, ShopService.signItemLine(template));
        sign.update();
        msg(player, "&aShopkiste erstellt: &f" + amount + "x " + ShopService.itemName(template)
                + (prices[0] >= 0 ? " &7| Kauf $" + ShopService.fmt(prices[0]) : "")
                + (prices[1] >= 0 ? " &7| Ankauf $" + ShopService.fmt(prices[1]) : ""));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("iteminfo") && args.length == 1) {
            List<String> names = new ArrayList<>();
            String prefix = args[0].toLowerCase();
            for (Material m : Material.values()) {
                if (m.isItem() && !m.isLegacy() && m.name().toLowerCase().startsWith(prefix)) names.add(m.name().toLowerCase());
                if (names.size() >= 50) break;
            }
            return names;
        }
        return Collections.emptyList();
    }
}
