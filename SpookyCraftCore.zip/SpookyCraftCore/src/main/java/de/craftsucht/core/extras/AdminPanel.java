package de.craftsucht.core.extras;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.List;

/** Admin-Panel (/adminpanel) und Plot-Bewertung (/rateplot, /clearplotrate). */
class AdminPanel implements Listener {

    private static final String RATING_HEADER = "&8[&6Bewertung&8]";

    /** Erkennt unsere Menüs (statt am Titel). */
    private static final class Holder implements InventoryHolder {
        final boolean rating;
        final Block sign;
        Inventory inventory;

        Holder(boolean rating, Block sign) {
            this.rating = rating;
            this.sign = sign;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final SpookyCraftCore plugin;
    private final ExtrasModule extras;

    AdminPanel(SpookyCraftCore plugin, ExtrasModule extras) {
        this.plugin = plugin;
        this.extras = extras;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        List<String> lines = new ArrayList<>();
        for (String l : lore) lines.add(color(l));
        meta.setLore(lines);
        stack.setItemMeta(meta);
        return stack;
    }

    private void fill(Inventory inv) {
        ItemStack glass = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, glass);
        }
    }

    // ------------------------------------------------------------------ Admin-Panel

    void open(Player p) {
        Holder holder = new Holder(false, null);
        Inventory inv = Bukkit.createInventory(holder, 54, color("&c&lAdmin Panel | CityBuild"));
        holder.inventory = inv;
        inv.setItem(10, item(Material.GRASS_BLOCK, "&a&lTag setzen", "&7Zeit auf Tag stellen."));
        inv.setItem(11, item(Material.OBSIDIAN, "&8&lNacht setzen", "&7Zeit auf Nacht stellen."));
        inv.setItem(12, item(Material.SUNFLOWER, "&e&lWetter leeren", "&7Regen und Sturm ausschalten."));
        inv.setItem(14, item(Material.TNT, "&4&lLag-Clear (Boden-Items)", "&7Löscht alle Drops auf dem Boden."));
        inv.setItem(15, item(Material.PAPER, "&c&lPlugin neu laden", "&7Lädt SpookyCraftCore neu (/bccore reload)."));
        inv.setItem(16, item(Material.REDSTONE_LAMP, "&6&lWartungsmodus", Bukkit.hasWhitelist()
                ? "&7Status: &aAN &7(Nur Whitelist-Spieler)" : "&7Status: &cAUS &7(Alle können joinen)"));
        inv.setItem(19, item(Material.IRON_SWORD, "&a&lÜberlebensmodus", "&7Wechsle in den Gamemode Survival."));
        inv.setItem(20, item(Material.DIAMOND_SWORD, "&b&lKreativmodus", "&7Wechsle in den Gamemode Creative."));
        inv.setItem(21, item(Material.STONE_SWORD, "&e&lAbenteuermodus", "&7Wechsle in den Gamemode Adventure."));
        inv.setItem(22, item(Material.ENDER_EYE, "&d&lZuschauermodus", "&7Wechsle in den Gamemode Spectator."));
        inv.setItem(28, item(Material.GOLD_INGOT, "&e&lGeld-Geber (10k)", "&7Gibt dir selbst 10.000$."));
        inv.setItem(29, item(Material.FEATHER, "&b&lFlugmodus (Fly)", "&7Schaltet deinen Flugmodus um."));
        inv.setItem(30, item(Material.POTION, "&d&lHeilung & Sättigung", "&7Heilt dich komplett auf und löscht Effekte."));
        inv.setItem(32, item(Material.ANVIL, "&6&lItem reparieren", "&7Repariert das Item in deiner Hand."));
        inv.setItem(34, item(Material.DIAMOND_CHESTPLATE, "&3&lGottmodus (Godmode)", "&7Schaltet deine Unverwundbarkeit um."));
        inv.setItem(37, item(Material.BARRIER, "&c&lChat leeren", "&7Löscht den globalen Chat für alle Spieler."));
        inv.setItem(39, item(Material.BOOK, "&4&lChat Mute", extras.isChatMuted()
                ? "&7Status: &cSTUMM &7(Klicke zum Entmuten)" : "&7Status: &aOFFEN &7(Klicke zum Stummschalten)"));
        inv.setItem(49, item(Material.COMPASS, "&9&lTeleport zum Spawn", "&7Teleportiert dich direkt zum Server-Spawn."));
        inv.setItem(50, item(Material.IRON_BARS, "&6&lAlle kicken", "&7Kickt alle Spieler außer dem Team vom Server."));
        inv.setItem(53, item(Material.REDSTONE_BLOCK, "&4&lMenü schließen", "&7Klicke hier zum Verlassen."));
        fill(inv);
        p.openInventory(inv);
    }

    private void handlePanelClick(Player p, int slot) {
        World world = p.getWorld();
        switch (slot) {
            case 10 -> {
                world.setTime(1000);
                p.closeInventory();
            }
            case 11 -> {
                world.setTime(13000);
                p.closeInventory();
            }
            case 12 -> {
                world.setStorm(false);
                world.setThundering(false);
                p.closeInventory();
            }
            case 14 -> {
                int removed = 0;
                for (World w : Bukkit.getWorlds()) {
                    for (Entity e : new ArrayList<>(w.getEntities())) {
                        if (e instanceof Item) {
                            e.remove();
                            removed++;
                        }
                    }
                }
                Bukkit.broadcastMessage(color("&c&lSystem &8| &7Alle Boden-Items wurden vom Admin entfernt! &8(" + removed + ")"));
                p.closeInventory();
            }
            case 15 -> {
                plugin.getMessageUtil().send(p, "&c&lAdmin &8| &7SpookyCraftCore wird neu geladen...");
                p.closeInventory();
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "bccore reload");
            }
            case 16 -> {
                boolean on = !Bukkit.hasWhitelist();
                Bukkit.setWhitelist(on);
                plugin.getMessageUtil().send(p, "&c&lAdmin &8| &7Der Wartungsmodus wurde " + (on ? "&aaktiviert&7." : "&cdeaktiviert&7."));
                p.closeInventory();
            }
            case 19 -> mode(p, GameMode.SURVIVAL);
            case 20 -> mode(p, GameMode.CREATIVE);
            case 21 -> mode(p, GameMode.ADVENTURE);
            case 22 -> mode(p, GameMode.SPECTATOR);
            case 28 -> {
                if (plugin.getModuleManager().get("economy") instanceof EconomyModule eco && eco.getManager() != null) {
                    eco.getManager().deposit(p.getUniqueId(), 10000);
                    plugin.getMessageUtil().send(p, "&aDu hast &e10.000$ &aerhalten.");
                }
                p.closeInventory();
            }
            case 29 -> {
                p.closeInventory();
                p.performCommand("fly");
            }
            case 30 -> {
                p.setHealth(p.getMaxHealth());
                p.setFoodLevel(20);
                p.setSaturation(20f);
                for (PotionEffect effect : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(effect.getType());
                p.closeInventory();
            }
            case 32 -> {
                p.closeInventory();
                p.performCommand("repair");
            }
            case 34 -> {
                p.setInvulnerable(!p.isInvulnerable());
                plugin.getMessageUtil().send(p, "&7Gottmodus: " + (p.isInvulnerable() ? "&aAN" : "&cAUS"));
                p.closeInventory();
            }
            case 37 -> {
                extras.broadcastClear(p);
                p.closeInventory();
            }
            case 39 -> {
                boolean mute = !extras.isChatMuted();
                extras.setChatMuted(mute);
                Bukkit.broadcastMessage(color(mute
                        ? "&c&lSystem &8| &7Der globale Chat wurde von &c" + p.getName() + " &4stummgeschaltet&7!"
                        : "&c&lSystem &8| &7Der globale Chat wurde von &c" + p.getName() + " &awieder freigegeben&7!"));
                p.closeInventory();
            }
            case 49 -> {
                String worldName = plugin.getConfig().getString("extras.spawn-world", "");
                World spawnWorld = worldName.isEmpty() ? null : Bukkit.getWorld(worldName);
                if (spawnWorld == null) spawnWorld = Bukkit.getWorlds().get(0);
                p.teleport(spawnWorld.getSpawnLocation());
                p.closeInventory();
            }
            case 50 -> {
                p.closeInventory();
                for (Player online : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                    if (!extras.isStaff(online)) online.kickPlayer("Wartungsarbeiten");
                }
            }
            case 53 -> p.closeInventory();
            default -> { }
        }
    }

    private void mode(Player p, GameMode mode) {
        p.setGameMode(mode);
        p.closeInventory();
    }

    // ------------------------------------------------------------------ Plot-Bewertung

    void openRating(Player p) {
        Block target = p.getTargetBlockExact(8);
        if (target == null || !Tag.ALL_SIGNS.isTagged(target.getType())) {
            plugin.getMessageUtil().send(p, "&c&lSystem &8| &cBitte schaue zuerst ein platziertes Schild an, um es zu beschreiben!");
            return;
        }
        Holder holder = new Holder(true, target);
        Inventory inv = Bukkit.createInventory(holder, 9, color("&6&lPlot bewerten..."));
        holder.inventory = inv;
        String lore = "&7Schreibt die Bewertung auf das Schild, das du anschaust.";
        inv.setItem(1, item(Material.DIRT, "&c&lSchlecht (1/5)", lore));
        inv.setItem(3, item(Material.IRON_INGOT, "&e&lGeht so (2/5)", lore));
        inv.setItem(5, item(Material.GOLD_INGOT, "&a&lGut (4/5)", lore));
        inv.setItem(7, item(Material.DIAMOND, "&b&lSehr gut (5/5)", lore));
        fill(inv);
        p.openInventory(inv);
    }

    private void writeRating(Player p, Block block, int slot) {
        if (!(block.getState() instanceof Sign sign)) {
            plugin.getMessageUtil().send(p, "&c&lSystem &8| &cFehler: Das Schild gibt es nicht mehr!");
            return;
        }
        String stars;
        String label;
        switch (slot) {
            case 1 -> {
                stars = "&c★☆☆☆☆ &7(Schlecht)";
                label = "&cSchlecht";
            }
            case 3 -> {
                stars = "&e★★☆☆☆ &7(Geht so)";
                label = "&eGeht so";
            }
            case 5 -> {
                stars = "&a★★★★☆ &7(Gut)";
                label = "&aGut";
            }
            default -> {
                stars = "&b★★★★★ &b&lPERFEKT!";
                label = "&bSehr gut";
            }
        }
        SignSide side = sign.getSide(Side.FRONT);
        side.setLine(0, color(RATING_HEADER));
        side.setLine(1, color(stars));
        side.setLine(2, color("&7Bewertet von:"));
        side.setLine(3, color("&e" + p.getName()));
        sign.update();
        plugin.getMessageUtil().send(p, "&c&lSystem &8| &7Schild erfolgreich mit " + label + " &7beschrieben!");
    }

    void clearRatings(Player p) {
        String header = color(RATING_HEADER);
        int count = 0;
        Block center = p.getLocation().getBlock();
        for (int x = -3; x <= 3; x++) {
            for (int y = -3; y <= 3; y++) {
                for (int z = -3; z <= 3; z++) {
                    if (x * x + y * y + z * z > 9) continue;
                    Block b = center.getRelative(x, y, z);
                    if (!Tag.ALL_SIGNS.isTagged(b.getType())) continue;
                    if (b.getState() instanceof Sign sign && header.equals(sign.getSide(Side.FRONT).getLine(0))) {
                        b.setType(Material.AIR);
                        count++;
                    }
                }
            }
        }
        if (count > 0) {
            plugin.getMessageUtil().send(p, "&c&lSystem &8| &a" + count + " &7Bewertungsschild(er) wurden rückstandslos entfernt!");
        } else {
            plugin.getMessageUtil().send(p, "&c&lSystem &8| &cKein Bewertungsschild in deiner Nähe gefunden!");
        }
    }

    // ------------------------------------------------------------------ Klicks

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player p)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getInventory()) return;
        if (!extras.isStaff(p)) {
            p.closeInventory();
            return;
        }
        int slot = event.getSlot();
        if (holder.rating) {
            if (slot == 1 || slot == 3 || slot == 5 || slot == 7) {
                p.closeInventory();
                writeRating(p, holder.sign, slot);
            }
        } else {
            handlePanelClick(p, slot);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof Holder) event.setCancelled(true);
    }
}
