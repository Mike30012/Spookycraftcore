package de.craftsucht.core.punish;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Strafkatalog für /punish. Jeder Grund hat eine Basisdauer und entweder einen Verdopplungsfaktor
 * ("doubling") oder eine lineare Steigerung ("increase", z.B. +14 Tage pro Wiederholung).
 */
public class PunishCatalog {

    /**
     * baseMillis == 0 bedeutet permanent.
     * stepMillis > 0 = linear: Basisdauer + (Vorstrafen * Schritt), z.B. 14d, 28d, 42d ... (maxRepeats 0 = unbegrenzt).
     * stepMillis == 0 = Verdopplung: Basisdauer * 2^Vorstrafen, nach maxRepeats Verstößen permanent (0 = sofort perm.).
     */
    public record Reason(String id, String name, boolean ban, long baseMillis, int maxRepeats, long stepMillis) {
        public boolean isPermanent(int prior) {
            if (baseMillis <= 0) return true;
            if (stepMillis > 0) return maxRepeats > 0 && prior >= maxRepeats;
            return maxRepeats <= 0 || prior >= maxRepeats;
        }

        public long durationFor(int prior) {
            if (stepMillis > 0) return baseMillis + (long) prior * stepMillis;
            return baseMillis * (1L << Math.min(prior, 20));
        }
    }

    private final Map<String, Reason> reasons = new LinkedHashMap<>();

    public PunishCatalog(FileConfiguration config) {
        ConfigurationSection section = config.getConfigurationSection("punishment.catalog");
        // Bestehende config.yml ohne Katalog: Bukkit liefert dann eine LEERE Section, deshalb die Defaults aus dem Jar nehmen.
        if (section == null || section.getKeys(false).isEmpty()) {
            org.bukkit.configuration.Configuration defaults = config.getDefaults();
            if (defaults != null) section = defaults.getConfigurationSection("punishment.catalog");
        }
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(id);
            if (s == null) continue;
            String name = s.getString("name", id);
            boolean ban = "BAN".equalsIgnoreCase(s.getString("type", "MUTE"));
            long base = parseDuration(s.getString("duration", "perm"));
            int doubling = s.getInt("doubling", 0);
            long step = parseDuration(s.getString("increase", "0"));
            reasons.put(id.toLowerCase(), new Reason(id.toLowerCase(), name, ban, base, doubling, step));
        }
    }

    public Reason get(String id) {
        return id == null ? null : reasons.get(id.toLowerCase());
    }

    public List<Reason> all() {
        return new ArrayList<>(reasons.values());
    }

    public String[] ids() {
        return reasons.keySet().toArray(new String[0]);
    }

    /** "6h", "10d", "30m" ... ; "perm" oder alles Unlesbare = 0 (permanent). */
    public static long parseDuration(String input) {
        if (input == null) return 0;
        String s = input.trim().toLowerCase();
        if (!s.matches("\\d+[smhd]")) return 0;
        long value = Long.parseLong(s.substring(0, s.length() - 1));
        return switch (s.charAt(s.length() - 1)) {
            case 's' -> value * 1_000L;
            case 'm' -> value * 60_000L;
            case 'h' -> value * 3_600_000L;
            default -> value * 86_400_000L;
        };
    }
}
