package de.craftsucht.core.util;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Kleine Helfer fuer Menues (Farbcodes, Items mit Name und Beschreibung). */
public final class GuiUtil {

    private GuiUtil() {
    }

    public static String c(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }

    public static ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat == null ? Material.STONE : mat);
        ItemMeta m = it.getItemMeta();
        if (m != null) {
            m.setDisplayName(c(name));
            List<String> out = new ArrayList<>();
            if (lore != null) for (String l : lore) out.add(c(l));
            m.setLore(out);
            it.setItemMeta(m);
        }
        return it;
    }

    public static ItemStack item(Material mat, String name, String... lore) {
        return item(mat, name, List.of(lore));
    }

    public static ItemStack glow(ItemStack it) {
        ItemMeta m = it.getItemMeta();
        if (m != null) {
            m.setEnchantmentGlintOverride(true);
            it.setItemMeta(m);
        }
        return it;
    }

    public static Material mat(String name, Material fallback) {
        if (name == null) return fallback;
        Material m = Material.matchMaterial(name.trim());
        return m == null ? fallback : m;
    }

    public static String money(double v) {
        return String.format(java.util.Locale.GERMANY, "%,.0f", v) + "$";
    }
}
