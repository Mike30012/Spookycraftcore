package de.craftsucht.core.rtp;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * /rtp: Menue mit Zielwelten (config rtp.destinations). Sucht einen sicheren Platz (kein Wasser/Lava/Void),
 * Countdown mit Abbruch bei Bewegung, Cooldown (rtp.cooldown-seconds, Recht spookycraft.rtp.bypass).
 */
public class RtpModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;
    private final Map<UUID, Long> lastUse = new HashMap<>();
    private final Map<UUID, BukkitTask> pending = new HashMap<>();

    public RtpModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "rtp";
    }

    @Override
    public void enable() {
        plugin.getCommand("rtp").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        pending.values().forEach(BukkitTask::cancel);
        pending.clear();
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private static String str(Map<?, ?> m, String k, String def) {
        Object o = m.get(k);
        return o == null ? def : String.valueOf(o);
    }

    private static int num(Map<?, ?> m, String k, int def) {
        try {
            return Integer.parseInt(str(m, k, String.valueOf(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private List<Map<?, ?>> destinations() {
        return plugin.getConfig().getMapList("rtp.destinations");
    }

    // ------------------------------------------------------------------ Menue

    private static class RtpHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private void open(Player p) {
        List<Map<?, ?>> list = destinations();
        int size = Math.min(54, Math.max(27, ((list.size() + 8) / 9) * 9 + 9));
        Inventory inv = Bukkit.createInventory(new RtpHolder(), size, c("&5☠ &dReise durch den Nebel"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < size; i++) inv.setItem(i, filler);
        int n = Math.min(list.size(), size - 9);
        int start = n <= 7 ? 13 - (n / 2) : 0;
        for (int i = 0; i < n; i++) {
            Map<?, ?> d = list.get(i);
            World w = Bukkit.getWorld(str(d, "world", ""));
            Material mat = Material.matchMaterial(str(d, "icon", "GRASS_BLOCK"));
            ItemStack it = new ItemStack(w == null ? Material.BARRIER : (mat == null ? Material.GRASS_BLOCK : mat));
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(c(str(d, "name", str(d, "world", "?"))));
            List<String> lore = new ArrayList<>();
            lore.add(c("&7" + str(d, "desc", "Zufälliger Ort in dieser Welt")));
            lore.add(c("&8Radius: " + num(d, "radius", 2000) + " Blöcke"));
            lore.add("");
            lore.add(c(w == null ? "&cDiese Welt schläft noch im Nebel" : "&eKlicken zum Reisen"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(start + i, it);
        }
        p.openInventory(inv);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        open(p);
        return true;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof RtpHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        List<Map<?, ?>> list = destinations();
        int n = Math.min(list.size(), e.getView().getTopInventory().getSize() - 9);
        int start = n <= 7 ? 13 - (n / 2) : 0;
        int idx = e.getSlot() - start;
        if (idx < 0 || idx >= n) return;
        p.closeInventory();
        start(p, list.get(idx));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof RtpHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        BukkitTask t = pending.remove(e.getPlayer().getUniqueId());
        if (t != null) t.cancel();
    }

    // ------------------------------------------------------------------ Ablauf

    private void start(Player p, Map<?, ?> dest) {
        World world = Bukkit.getWorld(str(dest, "world", ""));
        if (world == null) {
            plugin.getMessageUtil().send(p, "&cDiese Welt schläft noch tief im Nebel.");
            return;
        }
        if (pending.containsKey(p.getUniqueId())) {
            plugin.getMessageUtil().send(p, "&cDie Reise hat schon begonnen.");
            return;
        }
        int cooldown = Math.max(0, plugin.getConfig().getInt("rtp.cooldown-seconds", 60));
        long now = System.currentTimeMillis();
        if (cooldown > 0 && !p.hasPermission("spookycraft.rtp.bypass")) {
            Long last = lastUse.get(p.getUniqueId());
            if (last != null) {
                long remaining = (last + cooldown * 1000L - now + 999) / 1000;
                if (remaining > 0) {
                    plugin.getMessageUtil().send(p, "&cDie Geister brauchen Ruhe – /rtp erst in &f" + remaining + " &cSekunden.");
                    return;
                }
            }
        }
        int delay = Math.max(0, plugin.getConfig().getInt("rtp.delay-seconds", 3));
        Location from = p.getLocation().clone();
        int[] left = {delay};
        if (delay == 0) {
            search(p, world, num(dest, "radius", 2000), 0);
            return;
        }
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline()) {
                cancel(p);
                return;
            }
            Location now2 = p.getLocation();
            if (now2.getWorld() != from.getWorld() || now2.distanceSquared(from) > 1.0) {
                cancel(p);
                plugin.getMessageUtil().send(p, "&cDu hast dich bewegt – die Reise wurde abgebrochen.");
                return;
            }
            if (left[0] <= 0) {
                cancel(p);
                search(p, world, num(dest, "radius", 2000), 0);
                return;
            }
            p.sendActionBar(net.kyori.adventure.text.Component.text("☠ Der Nebel zieht auf... " + left[0] + " (nicht bewegen!)",
                    net.kyori.adventure.text.format.NamedTextColor.LIGHT_PURPLE));
            p.playSound(p.getLocation(), "block.note_block.chime", 0.5f, 1.2f);
            left[0]--;
        }, 0L, 20L);
        pending.put(p.getUniqueId(), task);
    }

    private void cancel(Player p) {
        BukkitTask t = pending.remove(p.getUniqueId());
        if (t != null) t.cancel();
    }

    /** Sucht (bis zu 25 Versuche) einen sicheren Platz und teleportiert dann. */
    private void search(Player p, World world, int radius, int attempt) {
        if (!p.isOnline()) return;
        if (attempt >= 25) {
            plugin.getMessageUtil().send(p, "&cDie Geister fanden keinen sicheren Ort. Versuche es gleich nochmal.");
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int x = r.nextInt(-radius, radius + 1);
        int z = r.nextInt(-radius, radius + 1);
        world.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> {
            Location loc = safeSpot(world, x, z);
            if (loc == null || !world.getWorldBorder().isInside(loc)) {
                search(p, world, radius, attempt + 1);
                return;
            }
            lastUse.put(p.getUniqueId(), System.currentTimeMillis());
            p.teleportAsync(loc).thenAccept(ok -> {
                if (ok) {
                    p.playSound(p.getLocation(), "entity.enderman.teleport", 0.8f, 1.0f);
                    plugin.getMessageUtil().send(p, "&5☠ &dDer Nebel trägt dich fort: &f" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
                }
            });
        });
    }

    private static boolean bad(Material m) {
        return m == Material.LAVA || m == Material.WATER || m == Material.FIRE || m == Material.SOUL_FIRE || m == Material.CACTUS
                || m == Material.MAGMA_BLOCK || m == Material.CAMPFIRE || m == Material.SOUL_CAMPFIRE || m == Material.POWDER_SNOW
                || m == Material.SWEET_BERRY_BUSH || m == Material.POINTED_DRIPSTONE || m == Material.BEDROCK;
    }

    private Location safeSpot(World w, int x, int z) {
        if (w.getEnvironment() == World.Environment.NETHER) {
            for (int y = 120; y > 32; y--) {
                Block ground = w.getBlockAt(x, y, z);
                if (ground.getType().isSolid() && !bad(ground.getType())
                        && w.getBlockAt(x, y + 1, z).isPassable() && !w.getBlockAt(x, y + 1, z).isLiquid()
                        && w.getBlockAt(x, y + 2, z).isPassable() && !w.getBlockAt(x, y + 2, z).isLiquid()) {
                    return new Location(w, x + 0.5, y + 1, z + 0.5);
                }
            }
            return null;
        }
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y <= w.getMinHeight() + 1) return null;
        Block ground = w.getBlockAt(x, y, z);
        Material gt = ground.getType();
        if (gt.isAir() || bad(gt) || ground.isLiquid()) return null;
        if (!w.getBlockAt(x, y + 1, z).isPassable() || w.getBlockAt(x, y + 1, z).isLiquid()) return null;
        return new Location(w, x + 0.5, y + 1, z + 0.5);
    }
}
