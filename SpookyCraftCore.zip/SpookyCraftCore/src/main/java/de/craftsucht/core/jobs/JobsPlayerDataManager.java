package de.craftsucht.core.jobs;

import de.craftsucht.core.SpookyCraftCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistiert den unabhängigen Fortschritt jedes einzelnen Jobs. */
public class JobsPlayerDataManager {

    private final SpookyCraftCore plugin;
    private final JobManager jobManager;
    private final Map<UUID, PlayerData> cache = new HashMap<>();

    public JobsPlayerDataManager(SpookyCraftCore plugin, JobManager jobManager) {
        this.plugin = plugin;
        this.jobManager = jobManager;
    }

    public PlayerData get(UUID uuid) {
        PlayerData cached = cache.get(uuid);
        if (cached != null) return cached;
        PlayerData data = load(uuid);
        cache.put(uuid, data);
        return data;
    }

    private PlayerData load(UUID uuid) {
        PlayerData data = new PlayerData(uuid);

        // Alte Einzel-Job-Tabelle migrieren, falls sie noch Daten enthält.
        migrateLegacyRow(uuid);

        String sql = "SELECT job, level, xp, total_earned FROM jobs_player_jobs WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String job = rs.getString("job");
                    if (!jobManager.isValidJob(job)) continue;
                    JobData jd = data.getOrCreateJob(job);
                    jd.setLevel(Math.max(1, rs.getInt("level")));
                    jd.setXp(Math.max(0, rs.getInt("xp")));
                    jd.addTotalEarned(Math.max(0L, rs.getLong("total_earned")));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Jobs load fehlgeschlagen: " + e.getMessage());
        }

        // Jeder Spieler ist automatisch in jedem Job. Neue Jobs beginnen auf Level 1.
        for (String job : jobManager.getAvailableJobs()) data.ensureJob(job);
        if (data.getCurrentJob() == null && !jobManager.getAvailableJobs().isEmpty()) {
            data.setCurrentJob(jobManager.getAvailableJobs().get(0));
        }
        return data;
    }

    private void migrateLegacyRow(UUID uuid) {
        String sql = "INSERT OR IGNORE INTO jobs_player_jobs (uuid, job, level, xp, total_earned) " +
                "SELECT uuid, job, level, xp, total_earned FROM jobs_players WHERE uuid = ? AND job IS NOT NULL";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            // Alte Installation ohne jobs_players ist kein Fehler; die neue Tabelle wird trotzdem genutzt.
        }
    }

    public void save(UUID uuid) {
        PlayerData data = cache.get(uuid);
        if (data == null) return;
        String delete = "DELETE FROM jobs_player_jobs WHERE uuid = ?";
        String insert = "INSERT INTO jobs_player_jobs (uuid, job, level, xp, total_earned) VALUES (?,?,?,?,?)";
        try (Connection c = plugin.getDatabase().getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement del = c.prepareStatement(delete); PreparedStatement ins = c.prepareStatement(insert)) {
                del.setString(1, uuid.toString());
                del.executeUpdate();
                for (JobData jd : data.getJobs()) {
                    ins.setString(1, uuid.toString());
                    ins.setString(2, jd.getJobId());
                    ins.setInt(3, jd.getLevel());
                    ins.setInt(4, jd.getXp());
                    ins.setLong(5, jd.getTotalEarned());
                    ins.addBatch();
                }
                ins.executeBatch();
            }
            c.commit();
            c.setAutoCommit(true);
        } catch (SQLException e) {
            plugin.getLogger().warning("Jobs save fehlgeschlagen: " + e.getMessage());
        }
    }

    public void saveAll() {
        for (UUID uuid : cache.keySet()) save(uuid);
    }

    public void unload(UUID uuid) {
        save(uuid);
        cache.remove(uuid);
    }
}
