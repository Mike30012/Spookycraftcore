package de.craftsucht.core.jobs;

import de.craftsucht.core.SpookyCraftCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistiert den unabhängigen Fortschritt jedes einzelnen Jobs. */
public class JobsPlayerDataManager {

    private final SpookyCraftCore plugin;
    private final JobManager jobManager;
    private final Map<UUID, PlayerData> cache = new HashMap<>();

    // Speichern passiert gebündelt und im Hintergrund: Jeder bezahlte Block würde sonst eine SQLite-Transaktion
    // (löschen + einfügen + commit) auf dem Main-Thread auslösen - bei Area-Spitzhacken bis zu 100x pro Schlag.
    private record Row(String job, int level, int xp, long total) {}

    private final java.util.Set<UUID> dirty = new java.util.HashSet<>();
    private final java.util.concurrent.ExecutorService writer =
            java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "SpookyCraft-Jobs-Writer");
                t.setDaemon(true);
                return t;
            });
    private final org.bukkit.scheduler.BukkitTask flushTask;

    public JobsPlayerDataManager(SpookyCraftCore plugin, JobManager jobManager) {
        this.plugin = plugin;
        this.jobManager = jobManager;
        this.flushTask = org.bukkit.Bukkit.getScheduler().runTaskTimer(plugin, this::flushDirty, 100L, 100L);
    }

    public PlayerData get(UUID uuid) {
        PlayerData cached = cache.get(uuid);
        if (cached != null) return cached;
        PlayerData data = load(uuid);
        cache.put(uuid, data);
        return data;
    }

    private PlayerData load(UUID uuid) {
        PlayerData data = new PlayerData(uuid);

        // Alte Einzel-Job-Tabelle migrieren, falls sie noch Daten enthält.
        migrateLegacyRow(uuid);

        String sql = "SELECT job, level, xp, total_earned FROM jobs_player_jobs WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String job = rs.getString("job");
                    if (!jobManager.isValidJob(job)) continue;
                    JobData jd = data.getOrCreateJob(job);
                    jd.setLevel(Math.max(1, rs.getInt("level")));
                    jd.setXp(Math.max(0, rs.getInt("xp")));
                    jd.addTotalEarned(Math.max(0L, rs.getLong("total_earned")));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Jobs load fehlgeschlagen: " + e.getMessage());
        }

        // Jeder Spieler ist automatisch in jedem Job. Neue Jobs beginnen auf Level 1.
        for (String job : jobManager.getAvailableJobs()) data.ensureJob(job);
        if (data.getCurrentJob() == null && !jobManager.getAvailableJobs().isEmpty()) {
            data.setCurrentJob(jobManager.getAvailableJobs().get(0));
        }
        return data;
    }

    private void migrateLegacyRow(UUID uuid) {
        String sql = "INSERT OR IGNORE INTO jobs_player_jobs (uuid, job, level, xp, total_earned) " +
                "SELECT uuid, job, level, xp, total_earned FROM jobs_players WHERE uuid = ? AND job IS NOT NULL";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            // Alte Installation ohne jobs_players ist kein Fehler; die neue Tabelle wird trotzdem genutzt.
        }
    }

    /** Merkt den Spieler zum Speichern vor (wird alle 5 Sekunden gebündelt im Hintergrund geschrieben). */
    public void save(UUID uuid) {
        if (cache.containsKey(uuid)) dirty.add(uuid);
    }

    private java.util.List<Row> snapshot(UUID uuid) {
        PlayerData data = cache.get(uuid);
        if (data == null) return null;
        java.util.List<Row> rows = new java.util.ArrayList<>();
        for (JobData jd : data.getJobs()) {
            rows.add(new Row(jd.getJobId(), jd.getLevel(), jd.getXp(), jd.getTotalEarned()));
        }
        return rows;
    }

    private void submit(UUID uuid, java.util.List<Row> rows) {
        if (rows == null) return;
        Runnable task = () -> write(uuid, rows);
        if (writer.isShutdown()) task.run();
        else writer.execute(task);
    }

    private void flushDirty() {
        if (dirty.isEmpty()) return;
        java.util.List<UUID> copy = new java.util.ArrayList<>(dirty);
        dirty.clear();
        for (UUID uuid : copy) submit(uuid, snapshot(uuid));
    }

    private void write(UUID uuid, java.util.List<Row> rows) {
        String delete = "DELETE FROM jobs_player_jobs WHERE uuid = ?";
        String insert = "INSERT INTO jobs_player_jobs (uuid, job, level, xp, total_earned) VALUES (?,?,?,?,?)";
        try (Connection c = plugin.getDatabase().getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement del = c.prepareStatement(delete); PreparedStatement ins = c.prepareStatement(insert)) {
                del.setString(1, uuid.toString());
                del.executeUpdate();
                for (Row r : rows) {
                    ins.setString(1, uuid.toString());
                    ins.setString(2, r.job());
                    ins.setInt(3, r.level());
                    ins.setInt(4, r.xp());
                    ins.setLong(5, r.total());
                    ins.addBatch();
                }
                ins.executeBatch();
            }
            c.commit();
            c.setAutoCommit(true);
        } catch (SQLException e) {
            plugin.getLogger().warning("Jobs save fehlgeschlagen: " + e.getMessage());
        }
    }

    public void saveAll() {
        for (UUID uuid : new java.util.ArrayList<>(cache.keySet())) submit(uuid, snapshot(uuid));
        dirty.clear();
    }

    /** Beim Abschalten: alles speichern und warten, bis der Hintergrund-Thread fertig ist. */
    public void shutdown() {
        flushTask.cancel();
        saveAll();
        writer.shutdown();
        try {
            writer.awaitTermination(10, java.util.concurrent.TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    public void unload(UUID uuid) {
        dirty.remove(uuid);
        submit(uuid, snapshot(uuid));
        cache.remove(uuid);
    }
}
