package de.craftsucht.core.staffchat;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * /sc <nachricht> - schickt eine Nachricht nur an Staff (sichtbar für alle
 * mit craftsucht.core.staffchat oder craftsucht.core.admin, sowie OP).
 * /sc ohne Text togglet einen Dauer-Modus: alles, was der Spieler danach
 * schreibt, geht nur noch in den Staffchat, bis er /sc erneut eingibt.
 */
public class StaffChatModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;
    private final Set<UUID> toggled = new HashSet<>();

    public StaffChatModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "staffchat";
    }

    @Override
    public void enable() {
        plugin.getCommand("sc").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        toggled.clear();
        HandlerList.unregisterAll(this);
    }

    private boolean isStaff(Player p) {
        return p.isOp() || p.hasPermission("craftsucht.core.staffchat") || p.hasPermission("craftsucht.core.admin");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Spieler können diesen Befehl nutzen.");
            return true;
        }
        if (!isStaff(player)) {
            plugin.getMessageUtil().send(player, "&cKeine Berechtigung.");
            return true;
        }
        if (args.length == 0) {
            UUID uuid = player.getUniqueId();
            if (toggled.contains(uuid)) {
                toggled.remove(uuid);
                plugin.getMessageUtil().send(player, "&7Staffchat-Modus &cdeaktiviert&7. Du schreibst wieder normal.");
            } else {
                toggled.add(uuid);
                plugin.getMessageUtil().send(player, "&7Staffchat-Modus &aaktiviert&7. Alles, was du jetzt schreibst, geht nur an Staff.");
            }
            return true;
        }
        broadcastStaff(player, String.join(" ", args));
        return true;
    }

    private void broadcastStaff(Player sender, String message) {
        String formatted = ChatColor.translateAlternateColorCodes('&',
                "&8[&cStaff&8] &7" + sender.getName() + "&8: &f" + message);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isStaff(p)) {
                p.sendMessage(formatted);
            }
        }
        Bukkit.getConsoleSender().sendMessage(formatted);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!toggled.contains(event.getPlayer().getUniqueId())) return;
        event.setCancelled(true);
        broadcastStaff(event.getPlayer(), event.getMessage());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        toggled.remove(event.getPlayer().getUniqueId());
    }
}
