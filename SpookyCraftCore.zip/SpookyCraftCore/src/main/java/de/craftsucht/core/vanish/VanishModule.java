package de.craftsucht.core.vanish;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Simple visibility-based vanish (Paper's player-hide API), packet-level tab handling stays in the standalone VanishPlugin. */
public class VanishModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;
    private final Set<UUID> vanished = new HashSet<>();

    public VanishModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "vanish";
    }

    @Override
    public void enable() {
        plugin.getCommand("vanish").setExecutor(this);
    }

    @Override
    public void disable() {
        vanished.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!p.isOp() && !p.hasPermission("craftsucht.core.vanish") && !p.hasPermission("craftsucht.core.admin")) {
            plugin.getMessageUtil().send(p, "&cKeine Berechtigung.");
            return true;
        }
        boolean nowVanished = vanished.contains(p.getUniqueId());
        if (nowVanished) {
            vanished.remove(p.getUniqueId());
            for (Player other : Bukkit.getOnlinePlayers()) other.showPlayer(plugin, p);
            plugin.getMessageUtil().send(p, "&aDu bist wieder sichtbar.");
        } else {
            vanished.add(p.getUniqueId());
            for (Player other : Bukkit.getOnlinePlayers()) {
                if (!other.isOp() && !other.hasPermission("craftsucht.core.vanish") && !other.hasPermission("craftsucht.core.admin")) {
                    other.hidePlayer(plugin, p);
                }
            }
            plugin.getMessageUtil().send(p, "&aDu bist jetzt unsichtbar.");
        }
        return true;
    }

    public boolean isVanished(UUID uuid) {
        return vanished.contains(uuid);
    }
}
