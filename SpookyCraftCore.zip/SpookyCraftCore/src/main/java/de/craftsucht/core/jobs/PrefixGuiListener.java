package de.craftsucht.core.jobs;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /prefix - GUI zum Auswählen der Namensfarbe.
 *
 * Normale Spieler: zeigt direkt die Meilensteine (Level 10-230) ihres
 * aktuell aktiven Jobs, erreichte Level anklickbar, Rest gesperrt.
 *
 * Spieler mit "craftsucht.jobs.allprefixes" (z.B. Owner, oder über
 * "*"-Wildcard): sehen zuerst eine Job-Auswahl, und in jedem Job sind
 * ALLE Titel freigeschaltet, unabhängig vom tatsächlichen Level.
 */
public class PrefixGuiListener implements Listener {

    private static final Map<String, Material> JOB_ICONS = Map.of(
            "miner", Material.DIAMOND_PICKAXE,
            "woodcutter", Material.IRON_AXE,
            "hunter", Material.BOW,
            "fisher", Material.FISHING_ROD,
            "digger", Material.IRON_SHOVEL
    );

    private final JobsModule jobs;

    public PrefixGuiListener(JobsModule jobs) {
        this.jobs = jobs;
    }

    private boolean hasBypass(Player player) {
        return player.isOp() || player.hasPermission("craftsucht.jobs.allprefixes");
    }

    public void open(Player player) {
        // Da jeder Spieler automatisch alle Jobs hat, wählt man hier nur den
        // Job aus, dessen Titel man ansehen/verwenden möchte.
        openJobSelect(player);
    }

    private void openJobSelect(Player player) {
        PrefixGuiHolder holder = new PrefixGuiHolder(PrefixGuiHolder.Type.JOB_SELECT, null);
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.translateAlternateColorCodes('&', "&8&lPrefix: Job wählen"));
        holder.setInventory(inv);

        int slot = 10;
        for (String jobId : jobs.getJobManager().getAvailableJobs()) {
            Material icon = JOB_ICONS.getOrDefault(jobId, Material.NAME_TAG);
            String name = ChatColor.translateAlternateColorCodes('&', jobs.getJobManager().getJobDisplayName(jobId));
            inv.setItem(slot, namedItem(icon, name, List.of(ChatColor.GRAY + "Klicken für alle Titel dieses Jobs")));
            slot++;
        }

        ItemStack hexInfo = namedItem(Material.NETHER_STAR, ChatColor.LIGHT_PURPLE + "Eigene Hex-Farbe",
                List.of(ChatColor.GRAY + "Nutze /prefix hex <RRGGBB>", ChatColor.GRAY + "für JEDE beliebige Farbe"));
        inv.setItem(22, hexInfo);

        player.openInventory(inv);
    }

    /** jobIdOverride != null nur im Bypass-Modus (Owner klickt sich einen Job aus). */
    private void openMilestones(Player player, String jobIdOverride) {
        boolean bypass = hasBypass(player);
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        String jobId = jobIdOverride != null ? jobIdOverride : data.getCurrentJob();

        if (jobId == null || !jobs.getJobManager().isValidJob(jobId)) {
            openJobSelect(player);
            return;
        }

        PrefixGuiHolder holder = new PrefixGuiHolder(PrefixGuiHolder.Type.MILESTONES, jobId);
        Inventory inv = Bukkit.createInventory(holder, 45, ChatColor.translateAlternateColorCodes('&', "&8&lPrefix-Farbe wählen"));
        holder.setInventory(inv);

        int effectiveLevel = bypass ? 230 : data.getOrCreateJob(jobId).getLevel();
        List<RewardManager.MilestoneEntry> milestones = jobs.getRewardManager().getMilestones(jobId, effectiveLevel);
        int slot = 0;
        for (RewardManager.MilestoneEntry m : milestones) {
            if (slot >= 36) break;
            inv.setItem(slot++, buildMilestoneItem(m));
        }

        if (bypass) {
            ItemStack back = namedItem(Material.ARROW, ChatColor.YELLOW + "Zurück zur Job-Auswahl", List.of());
            inv.setItem(36, back);
        }
        ItemStack reset = namedItem(Material.BARRIER, ChatColor.RED + "Zurücksetzen",
                List.of(ChatColor.GRAY + "Setzt deine Namensfarbe auf", ChatColor.GRAY + "die automatische (höchster Titel) zurück."));
        inv.setItem(40, reset);

        ItemStack hexInfo = namedItem(Material.NETHER_STAR, ChatColor.LIGHT_PURPLE + "Eigene Hex-Farbe",
                List.of(ChatColor.GRAY + "Nutze /prefix hex <RRGGBB>", ChatColor.GRAY + "für JEDE beliebige Farbe,",
                        ChatColor.GRAY + "z.B. /prefix hex FF00AA"));
        inv.setItem(44, hexInfo);

        player.openInventory(inv);
    }

    private ItemStack buildMilestoneItem(RewardManager.MilestoneEntry m) {
        String title = ChatColor.translateAlternateColorCodes('&', m.rawTitle());
        if (!m.unlocked()) {
            return namedItem(Material.GRAY_STAINED_GLASS_PANE, ChatColor.DARK_GRAY + "??? " + ChatColor.GRAY + "(Level " + m.level() + ")",
                    List.of(ChatColor.GRAY + "Noch nicht freigeschaltet.", ChatColor.GRAY + "Erreiche Level " + m.level() + " in deinem Job."));
        }
        Material pane = paneFor(m.color());
        return namedItem(pane, title,
                List.of(ChatColor.GREEN + "✔ Freigeschaltet (Level " + m.level() + ")", ChatColor.YELLOW + "Klicken zum Auswählen"));
    }

    private Material paneFor(ChatColor color) {
        if (color == null) return Material.WHITE_STAINED_GLASS_PANE;
        DyeColor dye = switch (color) {
            case BLACK -> DyeColor.BLACK;
            case DARK_BLUE -> DyeColor.BLUE;
            case DARK_GREEN -> DyeColor.GREEN;
            case DARK_AQUA -> DyeColor.CYAN;
            case DARK_RED -> DyeColor.RED;
            case DARK_PURPLE -> DyeColor.PURPLE;
            case GOLD -> DyeColor.ORANGE;
            case GRAY -> DyeColor.LIGHT_GRAY;
            case DARK_GRAY -> DyeColor.GRAY;
            case BLUE -> DyeColor.LIGHT_BLUE;
            case GREEN -> DyeColor.LIME;
            case AQUA -> DyeColor.LIGHT_BLUE;
            case RED -> DyeColor.RED;
            case LIGHT_PURPLE -> DyeColor.MAGENTA;
            case YELLOW -> DyeColor.YELLOW;
            case WHITE -> DyeColor.WHITE;
            default -> DyeColor.WHITE;
        };
        Material mat = Material.matchMaterial(dye.name() + "_STAINED_GLASS_PANE");
        return mat != null ? mat : Material.WHITE_STAINED_GLASS_PANE;
    }

    private ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(new ArrayList<>(lore));
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof PrefixGuiHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof PrefixGuiHolder)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        if (holder.getType() == PrefixGuiHolder.Type.JOB_SELECT) {
            for (Map.Entry<String, Material> entry : JOB_ICONS.entrySet()) {
                if (entry.getValue() == clicked.getType() && jobs.getJobManager().isValidJob(entry.getKey())) {
                    jobs.getJobManager().selectJob(player, entry.getKey());
                    openMilestones(player, entry.getKey());
                    return;
                }
            }
            return;
        }

        // Type.MILESTONES
        if (clicked.getType() == Material.ARROW && event.getSlot() == 36) {
            openJobSelect(player);
            return;
        }
        if (clicked.getType() == Material.BARRIER && event.getSlot() == 40) {
            applyRankColor(player, "&f", "auf Weiß zurückgesetzt");
            player.closeInventory();
            return;
        }
        if (clicked.getType().name().endsWith("_STAINED_GLASS_PANE") && clicked.getType() != Material.GRAY_STAINED_GLASS_PANE) {
            boolean bypass = hasBypass(player);
            PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
            String jobId = holder.getJobId();
            int effectiveLevel = bypass ? 230 : data.getOrCreateJob(jobId).getLevel();
            List<RewardManager.MilestoneEntry> milestones = jobs.getRewardManager().getMilestones(jobId, effectiveLevel);
            int index = event.getSlot();
            if (index < 0 || index >= milestones.size()) return;
            RewardManager.MilestoneEntry m = milestones.get(index);
            if (!m.unlocked() || m.color() == null) return;
            applyRankColor(player, "&" + legacyChar(m.color()), "gesetzt");
            player.closeInventory();
        }
    }

    /** Setzt die Farbe des aktuellen Rangs des Spielers und refresht Chat/Tab/Nametag/Scoreboard sofort. */
    private void applyRankColor(Player player, String colorCode, String feedbackSuffix) {
        RankModule rankModule = (RankModule) jobs.plugin.getModuleManager().get("rank");
        if (rankModule == null || rankModule.getManager() == null) {
            player.sendMessage(ChatColor.RED + "Rang-Farben gibt es nur mit dem internen Rang-System. Mit LuckPerms setzt du den Prefix per /lp.");
            return;
        }
        String rankName = rankModule.getManager().getUserRank(player.getUniqueId());
        boolean ok = rankModule.getManager().setRankColorCode(rankName, colorCode);
        if (!ok) {
            player.sendMessage(ChatColor.RED + "Konnte Rang-Farbe nicht ändern.");
            return;
        }
        player.sendMessage(ChatColor.translateAlternateColorCodes('&', colorCode) + "Rang-Farbe " + feedbackSuffix + " §7(betrifft alle mit dem Rang \"" + rankName + "\")");

        de.craftsucht.core.module.Module m = jobs.plugin.getModuleManager().get("scoreboard");
        if (m instanceof de.craftsucht.core.scoreboard.ScoreboardModule sm) {
            sm.refreshNow();
        }
    }

    /** Findet das & -Zeichen für eine legacy ChatColor (z.B. GOLD -> '6'), für die Rang-Farbe. */
    private char legacyChar(ChatColor color) {
        for (char c = '0'; c <= '9'; c++) {
            if (ChatColor.getByChar(c) == color) return c;
        }
        for (char c = 'a'; c <= 'f'; c++) {
            if (ChatColor.getByChar(c) == color) return c;
        }
        return 'f';
    }
}
