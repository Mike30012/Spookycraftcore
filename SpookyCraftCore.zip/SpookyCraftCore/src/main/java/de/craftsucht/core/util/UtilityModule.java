package de.craftsucht.core.util;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

import java.util.concurrent.ThreadLocalRandom;

/** Grab-bag of small quality-of-life commands: /rtp, /ec, /craft, /repair, /hat. */
public class UtilityModule implements Module, CommandExecutor {

    private static final int DEFAULT_RTP_RADIUS = 2000;
    private static final int DEFAULT_RTP_COOLDOWN_SECONDS = 60;

    /** Letzte /rtp-Nutzung pro Spieler (Millisekunden). */
    private final java.util.Map<java.util.UUID, Long> rtpLastUse = new java.util.HashMap<>();

    private final SpookyCraftCore plugin;

    public UtilityModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "utility";
    }

    @Override
    public void enable() {
        for (String cmd : new String[]{"rtp", "ec", "craft", "repair", "hat"}) {
            plugin.getCommand(cmd).setExecutor(this);
        }
    }

    @Override
    public void disable() {
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur als Spieler nutzbar.");
            return true;
        }
        switch (label.toLowerCase()) {
            case "rtp" -> randomTeleport(p);
            case "ec" -> p.openInventory(p.getEnderChest());
            case "craft" -> p.openWorkbench(null, true);
            case "repair" -> repair(p);
            case "hat" -> hat(p);
        }
        return true;
    }

    private void randomTeleport(Player p) {
        int cooldown = Math.max(0, plugin.getConfig().getInt("rtp.cooldown-seconds", DEFAULT_RTP_COOLDOWN_SECONDS));
        int radius = Math.max(10, plugin.getConfig().getInt("rtp.radius", DEFAULT_RTP_RADIUS));
        long now = System.currentTimeMillis();
        if (cooldown > 0 && !p.hasPermission("craftsucht.rtp.bypass")) {
            Long last = rtpLastUse.get(p.getUniqueId());
            if (last != null) {
                long remaining = (last + cooldown * 1000L - now + 999) / 1000;
                if (remaining > 0) {
                    plugin.getMessageUtil().send(p, "&cDu kannst /rtp erst in &f" + remaining + " &cSekunden wieder nutzen.");
                    return;
                }
            }
        }
        World world = p.getWorld();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        int x = random.nextInt(-radius, radius);
        int z = random.nextInt(-radius, radius);
        int y = world.getHighestBlockYAt(x, z) + 1;
        Location target = new Location(world, x + 0.5, y, z + 0.5);
        p.teleport(target);
        rtpLastUse.put(p.getUniqueId(), now);
        plugin.getMessageUtil().send(p, "&aZufällig teleportiert.");
    }

    private void repair(Player p) {
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR || !(item.getItemMeta() instanceof Damageable damageable)) {
            plugin.getMessageUtil().send(p, "&cHalte ein reparierbares Item in der Hand.");
            return;
        }
        damageable.setDamage(0);
        item.setItemMeta((org.bukkit.inventory.meta.ItemMeta) damageable);
        plugin.getMessageUtil().send(p, "&aItem repariert.");
    }

    private void hat(Player p) {
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR) {
            plugin.getMessageUtil().send(p, "&cHalte ein Item in der Hand.");
            return;
        }
        ItemStack currentHelmet = p.getInventory().getHelmet();
        p.getInventory().setHelmet(item.clone());
        p.getInventory().setItemInMainHand(currentHelmet);
        plugin.getMessageUtil().send(p, "&aAufgesetzt.");
    }
}
