package de.craftsucht.core.farmreset;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Farmwelt-Reset nach Zeitplan (wie bei OPSUCHT): Die konfigurierten Welten werden in festen Abständen neu generiert.
 * Spieler werden vorher zum Spawn teleportiert und rechtzeitig gewarnt.
 * Befehle: /farmreset status | /farmreset now confirm
 */
public class FarmResetModule implements Module, Listener, CommandExecutor, TabCompleter {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    private final SpookyCraftCore plugin;
    private final Set<Integer> warned = new HashSet<>();
    private BukkitTask task;
    private File dataFile;
    private YamlConfiguration data;
    private NamespacedKey seenKey;
    private boolean resetting;

    public FarmResetModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "farmreset";
    }

    @Override
    public void enable() {
        seenKey = new NamespacedKey(plugin, "farmreset_seen");
        dataFile = new File(plugin.getDataFolder(), "farmreset.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        if (!data.contains("last-reset")) {
            data.set("last-reset", System.currentTimeMillis()); // Zeitplan startet ab jetzt
            save();
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
        PluginCommand command = plugin.getCommand("farmreset");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 600L, 600L); // alle 30 Sekunden
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (task != null) task.cancel();
        task = null;
    }

    // ------------------------------------------------------------------ Config

    private List<String> worldNames() {
        return plugin.getConfig().getStringList("farmreset.worlds");
    }

    private int intervalDays() {
        return plugin.getConfig().getInt("farmreset.interval-days");
    }

    private LocalTime resetTime() {
        try {
            return LocalTime.parse(plugin.getConfig().getString("farmreset.reset-time", "04:00"));
        } catch (Exception e) {
            return LocalTime.of(4, 0);
        }
    }

    private World fallbackWorld() {
        World fallback = Bukkit.getWorld(plugin.getConfig().getString("farmreset.fallback-world", "world"));
        List<String> farm = worldNames();
        if (fallback != null && !farm.contains(fallback.getName())) return fallback;
        for (World w : Bukkit.getWorlds()) {
            if (!farm.contains(w.getName())) return w;
        }
        return null;
    }

    private void save() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("farmreset.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    /** Zeitpunkt des nächsten Resets oder null, wenn nur manuell. */
    private LocalDateTime nextReset() {
        int days = intervalDays();
        if (days <= 0) return null;
        long last = data.getLong("last-reset", System.currentTimeMillis());
        LocalDate lastDate = Instant.ofEpochMilli(last).atZone(ZoneId.systemDefault()).toLocalDate();
        return lastDate.plusDays(days).atTime(resetTime());
    }

    // ------------------------------------------------------------------ Zeitplan

    private void tick() {
        if (resetting) return;
        LocalDateTime next = nextReset();
        if (next == null) return;
        LocalDateTime now = LocalDateTime.now();
        if (!now.isBefore(next)) {
            performReset();
            return;
        }
        long minutesLeft = Duration.between(now, next).toMinutes();
        for (int minutes : plugin.getConfig().getIntegerList("farmreset.warn-minutes")) {
            if (minutesLeft == minutes && warned.add(minutes)) {
                broadcast("&c&lFarmwelt-Reset in " + minutes + " Minute" + (minutes == 1 ? "" : "n") + "! &7Bring deine Items in Sicherheit, du wirst zum Spawn teleportiert.");
            }
        }
    }

    private void broadcast(String text) {
        for (Player p : Bukkit.getOnlinePlayers()) plugin.getMessageUtil().send(p, text);
        plugin.getLogger().info(org.bukkit.ChatColor.stripColor(plugin.getMessageUtil().color(text)));
    }

    // ------------------------------------------------------------------ Reset

    private record Pending(String name, World.Environment environment, File folder) {
    }

    private void performReset() {
        if (resetting) return;
        resetting = true;
        World fallback = fallbackWorld();
        if (fallback == null) {
            plugin.getLogger().severe("Farm-Reset abgebrochen: keine Fallback-Welt gefunden.");
            resetting = false;
            return;
        }
        World mainWorld = Bukkit.getWorlds().get(0);
        broadcast("&c&lFarmwelt-Reset läuft jetzt! &7Die Welten werden neu generiert.");

        List<String> commands = plugin.getConfig().getStringList("farmreset.commands");
        List<Pending> pending = new ArrayList<>();
        for (String name : worldNames()) {
            World world = Bukkit.getWorld(name);
            if (world == null) continue; // nicht geladen
            if (world.equals(mainWorld)) {
                plugin.getLogger().warning("Farm-Reset: '" + name + "' ist die Haupt-Welt und wird nicht zurückgesetzt.");
                continue;
            }
            for (Player p : new ArrayList<>(world.getPlayers())) {
                p.teleport(fallback.getSpawnLocation());
                plugin.getMessageUtil().send(p, "&eDie Farmwelt wird zurückgesetzt - du wurdest zum Spawn teleportiert.");
            }
            if (!commands.isEmpty()) {
                for (String cmd : commands) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{world}", name));
                continue;
            }
            World.Environment environment = world.getEnvironment();
            File folder = world.getWorldFolder();
            if (!Bukkit.unloadWorld(world, false)) {
                plugin.getLogger().warning("Farm-Reset: Welt '" + name + "' konnte nicht entladen werden.");
                continue;
            }
            pending.add(new Pending(name, environment, folder));
        }

        if (pending.isEmpty()) {
            finishReset(0);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            for (Pending p : pending) deleteRecursively(p.folder().toPath());
            Bukkit.getScheduler().runTask(plugin, () -> {
                int created = 0;
                for (Pending p : pending) {
                    try {
                        World world = new WorldCreator(p.name()).environment(p.environment()).createWorld();
                        if (world != null) created++;
                    } catch (Exception e) {
                        plugin.getLogger().severe("Farm-Reset: Welt '" + p.name() + "' konnte nicht neu erstellt werden: " + e);
                    }
                }
                finishReset(created);
            });
        });
    }

    private void finishReset(int created) {
        int id = data.getInt("reset-id", 0) + 1;
        data.set("reset-id", id);
        data.set("last-reset", System.currentTimeMillis());
        save();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.getPersistentDataContainer().set(seenKey, PersistentDataType.INTEGER, id);
        }
        warned.clear();
        resetting = false;
        broadcast("&a&lDie Farmwelt wurde zurückgesetzt! &7Viel Spaß in der neuen Welt.");
        plugin.getLogger().info("Farm-Reset abgeschlossen (" + created + " Welt(en) neu erstellt).");
    }

    private void deleteRecursively(Path root) {
        if (!Files.exists(root)) return;
        try (Stream<Path> walk = Files.walk(root)) {
            walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException e) {
                    plugin.getLogger().warning("Konnte nicht löschen: " + path + " (" + e.getMessage() + ")");
                }
            });
        } catch (IOException e) {
            plugin.getLogger().warning("Welt-Ordner konnte nicht gelöscht werden: " + root + " (" + e.getMessage() + ")");
        }
    }

    /** Spieler, die während des Resets offline waren, stehen sonst in der neuen Welt mitten im Gelände. */
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        int id = data.getInt("reset-id", 0);
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        Integer seen = pdc.get(seenKey, PersistentDataType.INTEGER);
        if (id > 0 && (seen == null || seen != id) && worldNames().contains(player.getWorld().getName())) {
            World fallback = fallbackWorld();
            if (fallback != null) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.teleport(fallback.getSpawnLocation());
                    plugin.getMessageUtil().send(player, "&eDie Farmwelt wurde zurückgesetzt, während du offline warst - du wurdest zum Spawn teleportiert.");
                });
            }
        }
        pdc.set(seenKey, PersistentDataType.INTEGER, id);
    }

    // ------------------------------------------------------------------ Befehl

    private boolean isAdmin(CommandSender s) {
        return s.isOp() || s.hasPermission("craftsucht.core.admin") || s.hasPermission("craftsucht.farmreset.admin");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!isAdmin(sender)) {
            plugin.getMessageUtil().send(sender, "&cDazu hast du keine Berechtigung.");
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase() : "status";
        switch (sub) {
            case "now" -> {
                if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
                    plugin.getMessageUtil().send(sender, "&cAchtung: Das löscht die Farmwelt(en) sofort! Bestätigen mit &e/farmreset now confirm");
                    return true;
                }
                if (resetting) {
                    plugin.getMessageUtil().send(sender, "&cEin Reset läuft bereits.");
                    return true;
                }
                broadcast("&c&lFarmwelt-Reset in 10 Sekunden! &7Du wirst zum Spawn teleportiert.");
                Bukkit.getScheduler().runTaskLater(plugin, this::performReset, 200L);
            }
            default -> {
                plugin.getMessageUtil().send(sender, "&7--- &6Farm-Reset &7---");
                LocalDateTime next = nextReset();
                long last = data.getLong("last-reset", 0);
                plugin.getMessageUtil().sendRaw(sender, "&8» &7Welten: &f" + String.join(", ", worldNames()));
                for (String name : worldNames()) {
                    plugin.getMessageUtil().sendRaw(sender, "&8   - &f" + name + (Bukkit.getWorld(name) != null ? " &a(geladen)" : " &c(nicht gefunden)"));
                }
                plugin.getMessageUtil().sendRaw(sender, "&8» &7Letzter Reset: &f" + (last > 0
                        ? FORMAT.format(Instant.ofEpochMilli(last).atZone(ZoneId.systemDefault())) : "-"));
                plugin.getMessageUtil().sendRaw(sender, "&8» &7Nächster Reset: &f" + (next != null ? FORMAT.format(next)
                        + " &8(alle " + intervalDays() + " Tage um " + resetTime() + ")" : "nur manuell (interval-days: 0)"));
                plugin.getMessageUtil().sendRaw(sender, "&8» &7Sofort zurücksetzen: &e/farmreset now confirm");
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!isAdmin(sender)) return Collections.emptyList();
        if (args.length == 1) return TabCompleteUtil.filter(args[0], "status", "now");
        if (args.length == 2 && args[0].equalsIgnoreCase("now")) return TabCompleteUtil.filter(args[1], "confirm");
        return Collections.emptyList();
    }
}
