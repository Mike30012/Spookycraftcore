package de.craftsucht.core.anticheat;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/** /anticheat (Alias /ac): alerts | vl <spieler> | reset <spieler> | status */
public class AntiCheatCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final AntiCheatModule module;

    public AntiCheatCommand(SpookyCraftCore plugin, AntiCheatModule module) {
        this.plugin = plugin;
        this.module = module;
    }

    private boolean allowed(CommandSender sender) {
        return sender.isOp() || sender.hasPermission("spookycraft.core.admin") || sender.hasPermission("spookycraft.anticheat.use");
    }

    private void help(CommandSender sender) {
        plugin.getMessageUtil().send(sender, "&cNutzung: /anticheat <alerts|vl <spieler>|reset <spieler>|status>");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!allowed(sender)) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length == 0) {
            help(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "alerts" -> {
                if (!(sender instanceof Player player)) {
                    plugin.getMessageUtil().send(sender, "&cNur im Spiel nutzbar.");
                    return true;
                }
                boolean on = module.toggleAlerts(player.getUniqueId());
                plugin.getMessageUtil().send(sender, "&7Warnungen der Wächter: " + (on ? "&aAN" : "&cAUS"));
            }
            case "vl" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (target == null) {
                    plugin.getMessageUtil().send(sender, "&cNutzung: /anticheat vl <spieler> (Spieler muss online sein)");
                    return true;
                }
                Map<String, Double> vl = module.getViolations(target.getUniqueId());
                if (vl.isEmpty()) {
                    plugin.getMessageUtil().send(sender, "&a" + target.getName() + " hat die Wächter noch nicht erzürnt.");
                    return true;
                }
                plugin.getMessageUtil().send(sender, "&7Violations von &e" + target.getName() + "&7:");
                vl.forEach((check, value) -> plugin.getMessageUtil().sendRaw(sender,
                        "&8 - &e" + check + " &8| &fVL " + String.format("%.1f", value)));
            }
            case "reset" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (target == null) {
                    plugin.getMessageUtil().send(sender, "&cNutzung: /anticheat reset <spieler>");
                    return true;
                }
                module.resetViolations(target.getUniqueId());
                plugin.getMessageUtil().send(sender, "&aViolations von " + target.getName() + " zurückgesetzt.");
            }
            case "status" -> {
                plugin.getMessageUtil().send(sender, "&7--- &6☠ Wächter-Status &7---");
                for (String check : AntiCheatModule.CHECKS) {
                    plugin.getMessageUtil().sendRaw(sender, "&8 - &e" + check + " &8| "
                            + (module.isCheckEnabled(check) ? "&aAN" : "&cAUS"));
                }
                plugin.getMessageUtil().sendRaw(sender, "&7Warnung ab VL &f" + plugin.getConfig().getDouble("anticheat.alert-vl", 2.0)
                        + " &8| &7Setback: &f" + plugin.getConfig().getBoolean("anticheat.setback", true)
                        + " &8| &7Kick ab VL: &f" + plugin.getConfig().getDouble("anticheat.kick-at-vl", 0.0) + " &8(0 = aus)");
            }
            default -> help(sender);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!allowed(sender)) return Collections.emptyList();
        if (args.length == 1) return TabCompleteUtil.filter(args[0], "alerts", "vl", "reset", "status");
        if (args.length == 2 && (args[0].equalsIgnoreCase("vl") || args[0].equalsIgnoreCase("reset"))) {
            return TabCompleteUtil.onlinePlayers(args[1]);
        }
        return Collections.emptyList();
    }
}
