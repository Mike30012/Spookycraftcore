package de.craftsucht.core.luckperms;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.cache.CachedMetaData;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.UUID;

/** Dünner, null-sicherer Zugriff auf die LuckPerms-API. Nur benutzen, wenn {@link #isAvailable()} true ist. */
public final class LuckPermsHook {

    private LuckPermsHook() {}

    public static boolean isAvailable() {
        return Bukkit.getPluginManager().isPluginEnabled("LuckPerms") && api() != null;
    }

    private static LuckPerms api() {
        try {
            var reg = Bukkit.getServicesManager().getRegistration(LuckPerms.class);
            return reg == null ? null : reg.getProvider();
        } catch (Throwable t) {
            return null;
        }
    }

    /** Prefix mit übersetzten Farbcodes (&amp; -> §), leer wenn keiner gesetzt / LuckPerms fehlt. */
    public static String getPrefix(UUID uuid) {
        try {
            LuckPerms lp = api();
            if (lp == null) return "";
            User user = lp.getUserManager().getUser(uuid);
            if (user == null) return "";
            CachedMetaData meta = user.getCachedData().getMetaData();
            String prefix = meta.getPrefix();
            return prefix == null ? "" : ChatColor.translateAlternateColorCodes('&', prefix);
        } catch (Throwable t) {
            return "";
        }
    }

    public static String getPrefix(Player p) {
        return getPrefix(p.getUniqueId());
    }
}
