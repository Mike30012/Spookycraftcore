package de.craftsucht.core.clan;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.sql.*;

/**
 * Clan module for the SpookyCraft server.
 */
public class ClanModule implements Module, CommandExecutor, Listener, org.bukkit.command.TabCompleter {

    private final SpookyCraftCore plugin;

    public ClanModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "clan";
    }

    @Override
    public void enable() {
        plugin.getCommand("clan").setExecutor(this);
        plugin.getCommand("clan").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /clan <create|invite|leave|info|chat> [args]");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> create(p, args);
            case "leave" -> leave(p);
            case "info" -> info(p);
            default -> plugin.getMessageUtil().send(p, "&cUnbekannter Befehl.");
        }
        return true;
    }

    private void create(Player p, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(p, "&cNutzung: /clan create <name> <tag>");
            return;
        }
        String sql = "INSERT INTO clans (name, tag, color, owner, created_at) VALUES (?,?,?,?,?)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, args[1]);
            ps.setString(2, args[2]);
            ps.setString(3, "LIGHT_PURPLE");
            ps.setString(4, p.getUniqueId().toString());
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int clanId = keys.getInt(1);
                    try (PreparedStatement ps2 = c.prepareStatement("INSERT INTO clan_members (clan_id, uuid, rank) VALUES (?,?, 'OWNER')")) {
                        ps2.setInt(1, clanId);
                        ps2.setString(2, p.getUniqueId().toString());
                        ps2.executeUpdate();
                    }
                }
            }
            plugin.getMessageUtil().send(p, "&aClan '" + args[1] + "' [" + args[2] + "] erstellt.");
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler (existiert der Clan-Name schon?).");
        }
    }

    private void leave(Player p) {
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM clan_members WHERE uuid=?")) {
            ps.setString(1, p.getUniqueId().toString());
            ps.executeUpdate();
            plugin.getMessageUtil().send(p, "&aDu hast deinen Clan verlassen.");
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler.");
        }
    }

    private void info(Player p) {
        String sql = "SELECT c.name, c.tag, c.color, c.owner FROM clans c JOIN clan_members m ON m.clan_id=c.id WHERE m.uuid=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    plugin.getMessageUtil().send(p, "&7Du bist in keinem Clan.");
                    return;
                }
                plugin.getMessageUtil().sendRaw(p, "&8--- &bClan &8---");
                plugin.getMessageUtil().sendRaw(p, "&7Name: &b" + rs.getString("name") + " &7Tag: &b[" + rs.getString("tag") + "]");
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler.");
        }
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "create", "leave", "info");
        }
        return java.util.Collections.emptyList();
    }

    /** Returns the clan name+tag for a player, or null if they're not in a clan. */
    public String getPlayerClanName(java.util.UUID uuid) {
        String sql = "SELECT c.name, c.tag FROM clans c JOIN clan_members m ON m.clan_id=c.id WHERE m.uuid=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("name") + " [" + rs.getString("tag") + "]";
                }
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    /** Handles "@clan message" clan-chat prefix in normal chat. */
    @EventHandler(ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!event.getMessage().startsWith("@clan ")) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        String message = event.getMessage().substring(6);
        String sql = "SELECT clan_id FROM clan_members WHERE uuid=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    plugin.getMessageUtil().send(p, "&7Du bist in keinem Clan.");
                    return;
                }
                int clanId = rs.getInt("clan_id");
                try (PreparedStatement ps2 = c.prepareStatement("SELECT uuid FROM clan_members WHERE clan_id=?")) {
                    ps2.setInt(1, clanId);
                    try (ResultSet members = ps2.executeQuery()) {
                        while (members.next()) {
                            Player member = Bukkit.getPlayer(java.util.UUID.fromString(members.getString("uuid")));
                            if (member != null) {
                                member.sendMessage(ChatColor.LIGHT_PURPLE + "[Clan] " + ChatColor.WHITE + p.getName() + ": " + message);
                            }
                        }
                    }
                }
            }
        } catch (SQLException ignored) {
        }
    }
}
