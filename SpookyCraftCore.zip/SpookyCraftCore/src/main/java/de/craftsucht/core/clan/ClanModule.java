package de.craftsucht.core.clan;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Geisterzirkel (Clans): erstellen, einladen, Raenge (Besitzer/Offizier/Mitglied), Clan-Chat,
 * Clan-Kasse, Clan-Home, Rangliste, Clan-Tag im Chat und Friendly-Fire-Schutz.
 * Config: clan.create-cost, clan.max-members, clan.friendly-fire
 */
public class ClanModule implements Module, CommandExecutor, Listener, TabCompleter {

    private record ClanInfo(int id, String name, String tag, String owner) {
    }

    private record Invite(int clanId, String clanName, long expires) {
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, Invite> invites = new ConcurrentHashMap<>();
    private final Map<UUID, String> tagCache = new ConcurrentHashMap<>();
    private static final String NONE = "\u0000";

    public ClanModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "clan";
    }

    @Override
    public void enable() {
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS clan_extra (clan_id INTEGER PRIMARY KEY, bank REAL DEFAULT 0, home TEXT)");
        } catch (SQLException e) {
            plugin.getLogger().warning("clan_extra konnte nicht angelegt werden: " + e.getMessage());
        }
        plugin.getCommand("clan").setExecutor(this);
        plugin.getCommand("clan").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        invites.clear();
        tagCache.clear();
    }

    // ------------------------------------------------------------------ Hilfen

    private void msg(CommandSender s, String m) {
        plugin.getMessageUtil().send(s, m);
    }

    private void raw(CommandSender s, String m) {
        plugin.getMessageUtil().sendRaw(s, m);
    }

    private EconomyManager eco() {
        return plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
    }

    private ClanInfo clanOf(UUID uuid) {
        String sql = "SELECT c.id, c.name, c.tag, c.owner FROM clans c JOIN clan_members m ON m.clan_id=c.id WHERE m.uuid=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new ClanInfo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    private ClanInfo clanByName(String name) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT id, name, tag, owner FROM clans WHERE LOWER(name)=LOWER(?) OR LOWER(tag)=LOWER(?)")) {
            ps.setString(1, name);
            ps.setString(2, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new ClanInfo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    private String rankOf(UUID uuid) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT rank FROM clan_members WHERE uuid=?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString(1);
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    private List<UUID> members(int clanId) {
        List<UUID> out = new ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT uuid FROM clan_members WHERE clan_id=?")) {
            ps.setInt(1, clanId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(UUID.fromString(rs.getString(1)));
            }
        } catch (SQLException ignored) {
        }
        return out;
    }

    private boolean update(String sql, Object... params) {
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    private double bank(int clanId) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT bank FROM clan_extra WHERE clan_id=?")) {
            ps.setInt(1, clanId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble(1);
            }
        } catch (SQLException ignored) {
        }
        return 0;
    }

    private boolean addBank(int clanId, double delta) {
        update("INSERT OR IGNORE INTO clan_extra (clan_id, bank) VALUES (?, 0)", clanId);
        return update("UPDATE clan_extra SET bank = bank + ? WHERE clan_id=?", delta, clanId);
    }

    private String name(UUID uuid) {
        String n = Bukkit.getOfflinePlayer(uuid).getName();
        return n == null ? uuid.toString().substring(0, 8) : n;
    }

    private static boolean leader(String rank) {
        return "OWNER".equalsIgnoreCase(rank) || "ADMIN".equalsIgnoreCase(rank);
    }

    private static String rankLabel(String rank) {
        return switch (rank == null ? "" : rank.toUpperCase(Locale.ROOT)) {
            case "OWNER" -> "&c&lAnführer";
            case "ADMIN" -> "&6Offizier";
            default -> "&7Mitglied";
        };
    }

    private void broadcastClan(int clanId, String message) {
        for (UUID u : members(clanId)) {
            Player m = Bukkit.getPlayer(u);
            if (m != null) plugin.getMessageUtil().send(m, message);
        }
    }

    private OfflinePlayer findMember(ClanInfo clan, String nameArg) {
        for (UUID u : members(clan.id())) {
            if (name(u).equalsIgnoreCase(nameArg)) return Bukkit.getOfflinePlayer(u);
        }
        return null;
    }

    /** Clan-Tag fuer den Chat, z.B. "§8[§dABC§8] ", leer wenn kein Clan. */
    public String getChatTag(UUID uuid) {
        String t = tagCache.get(uuid);
        if (t == null) {
            ClanInfo ci = clanOf(uuid);
            t = ci == null ? NONE : ci.tag();
            tagCache.put(uuid, t);
        }
        return NONE.equals(t) ? "" : "§8[§d" + t + "§8] ";
    }

    /** Returns the clan name+tag for a player, or null if they're not in a clan. */
    public String getPlayerClanName(UUID uuid) {
        ClanInfo ci = clanOf(uuid);
        return ci == null ? null : ci.name() + " [" + ci.tag() + "]";
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            msg(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            help(p);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create", "gruenden" -> create(p, args);
            case "invite", "einladen" -> invite(p, args);
            case "accept", "annehmen" -> accept(p);
            case "deny", "ablehnen" -> {
                invites.remove(p.getUniqueId());
                msg(p, "&7Du hast die Einladung ausgeschlagen.");
            }
            case "leave", "verlassen" -> leave(p);
            case "kick" -> kick(p, args);
            case "promote", "befoerdern" -> setRank(p, args, true);
            case "demote", "degradieren" -> setRank(p, args, false);
            case "transfer" -> transfer(p, args);
            case "disband", "aufloesen" -> disband(p);
            case "info" -> info(p, args);
            case "list", "members", "mitglieder" -> list(p, args);
            case "top" -> top(p);
            case "chat", "c" -> chat(p, args, 1);
            case "deposit", "einzahlen" -> deposit(p, args);
            case "withdraw", "abheben" -> withdraw(p, args);
            case "sethome" -> setHome(p);
            case "home" -> home(p);
            default -> msg(p, "&cDieser Zauberspruch ist unbekannt. &7/clan für die Hilfe.");
        }
        return true;
    }

    private void help(Player p) {
        raw(p, "&8--- &5☠ &dGeisterzirkel (Clan) &8---");
        raw(p, "&d/clan create <name> <tag> &8» &7Zirkel gründen");
        raw(p, "&d/clan invite <spieler> &8» &7Einladen &8| &d/clan accept|deny");
        raw(p, "&d/clan info [clan] &8» &7Infos &8| &d/clan list &8» &7Mitglieder &8| &d/clan top");
        raw(p, "&d/clan chat <text> &8» &7Clan-Chat &8(&7oder &d@clan text&8)");
        raw(p, "&d/clan deposit|withdraw <betrag> &8» &7Clan-Kasse");
        raw(p, "&d/clan sethome &8| &d/clan home &8» &7Zirkel-Treffpunkt");
        raw(p, "&d/clan kick|promote|demote|transfer <spieler> &8| &d/clan leave|disband");
    }

    private void create(Player p, String[] args) {
        if (args.length < 3) {
            msg(p, "&cNutzung: /clan create <name> <tag>");
            return;
        }
        if (clanOf(p.getUniqueId()) != null) {
            msg(p, "&cDu gehörst bereits einem Geisterzirkel an.");
            return;
        }
        String name = args[1], tag = args[2];
        if (!name.matches("[A-Za-z0-9_]{3,16}")) {
            msg(p, "&cDer Name braucht 3-16 Zeichen (Buchstaben, Zahlen, _).");
            return;
        }
        if (!tag.matches("[A-Za-z0-9]{2,4}")) {
            msg(p, "&cDer Tag braucht 2-4 Zeichen (Buchstaben, Zahlen).");
            return;
        }
        if (clanByName(name) != null || clanByName(tag) != null) {
            msg(p, "&cDiesen Namen oder Tag gibt es bereits.");
            return;
        }
        double cost = plugin.getConfig().getDouble("clan.create-cost", 5000);
        EconomyManager eco = eco();
        if (cost > 0) {
            if (eco == null || !eco.withdraw(p.getUniqueId(), cost)) {
                msg(p, "&cDeine Taschen sind zu leer – ein Zirkel kostet &e" + (long) cost + "$&c.");
                return;
            }
        }
        String sql = "INSERT INTO clans (name, tag, color, owner, created_at) VALUES (?,?,?,?,?)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, tag.toUpperCase(Locale.ROOT));
            ps.setString(3, "LIGHT_PURPLE");
            ps.setString(4, p.getUniqueId().toString());
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    try (PreparedStatement ps2 = c.prepareStatement("INSERT INTO clan_members (clan_id, uuid, rank) VALUES (?,?, 'OWNER')")) {
                        ps2.setInt(1, keys.getInt(1));
                        ps2.setString(2, p.getUniqueId().toString());
                        ps2.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            if (cost > 0 && eco != null) eco.deposit(p.getUniqueId(), cost);
            msg(p, "&cEin Fluch verhinderte die Gründung.");
            return;
        }
        tagCache.clear();
        p.playSound(p.getLocation(), "entity.witch.celebrate", 0.8f, 1.0f);
        msg(p, "&5☠ &dDein Geisterzirkel &f" + name + " &8[&d" + tag.toUpperCase(Locale.ROOT) + "&8] &dwurde gegründet!");
    }

    private void invite(Player p, String[] args) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&cDu gehörst keinem Geisterzirkel an.");
            return;
        }
        if (!leader(rankOf(p.getUniqueId()))) {
            msg(p, "&cNur Anführer und Offiziere dürfen einladen.");
            return;
        }
        if (args.length < 2) {
            msg(p, "&cNutzung: /clan invite <spieler>");
            return;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            msg(p, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
            return;
        }
        if (clanOf(t.getUniqueId()) != null) {
            msg(p, "&cDieser Spieler gehört bereits einem Zirkel an.");
            return;
        }
        if (members(clan.id()).size() >= plugin.getConfig().getInt("clan.max-members", 20)) {
            msg(p, "&cDein Zirkel ist voll.");
            return;
        }
        invites.put(t.getUniqueId(), new Invite(clan.id(), clan.name(), System.currentTimeMillis() + 60_000L));
        msg(p, "&aDie Einladung flattert als Fledermaus zu " + t.getName() + ".");
        msg(t, "&5☠ &dDer Geisterzirkel &f" + clan.name() + " &dlädt dich ein! &a/clan accept &7oder &c/clan deny &7(60 Sek.)");
    }

    private void accept(Player p) {
        Invite inv = invites.remove(p.getUniqueId());
        if (inv == null || inv.expires() < System.currentTimeMillis()) {
            msg(p, "&cKeine Fledermaus mit Einladung in Sicht.");
            return;
        }
        if (clanOf(p.getUniqueId()) != null) {
            msg(p, "&cDu gehörst bereits einem Geisterzirkel an.");
            return;
        }
        if (members(inv.clanId()).size() >= plugin.getConfig().getInt("clan.max-members", 20)) {
            msg(p, "&cDieser Zirkel ist inzwischen voll.");
            return;
        }
        if (update("INSERT INTO clan_members (clan_id, uuid, rank) VALUES (?,?, 'MEMBER')", inv.clanId(), p.getUniqueId().toString())) {
            tagCache.clear();
            broadcastClan(inv.clanId(), "&5☠ &f" + p.getName() + " &dist dem Zirkel beigetreten!");
        } else {
            msg(p, "&cEin Fluch verhinderte den Beitritt.");
        }
    }

    private void leave(Player p) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&cDu gehörst keinem Geisterzirkel an.");
            return;
        }
        if ("OWNER".equalsIgnoreCase(rankOf(p.getUniqueId()))) {
            if (members(clan.id()).size() > 1) {
                msg(p, "&cAls Anführer musst du erst &e/clan transfer <spieler> &cnutzen oder den Zirkel mit &e/clan disband &cauflösen.");
                return;
            }
            disband(p);
            return;
        }
        update("DELETE FROM clan_members WHERE uuid=?", p.getUniqueId().toString());
        tagCache.clear();
        msg(p, "&aDu hast deinen Geisterzirkel verlassen.");
        broadcastClan(clan.id(), "&5☠ &f" + p.getName() + " &dhat den Zirkel verlassen.");
    }

    private void kick(Player p, String[] args) {
        ClanInfo clan = clanOf(p.getUniqueId());
        String my = rankOf(p.getUniqueId());
        if (clan == null || !leader(my)) {
            msg(p, "&cNur Anführer und Offiziere dürfen Mitglieder verbannen.");
            return;
        }
        if (args.length < 2) {
            msg(p, "&cNutzung: /clan kick <spieler>");
            return;
        }
        OfflinePlayer t = findMember(clan, args[1]);
        if (t == null) {
            msg(p, "&cDieser Spieler ist nicht in deinem Zirkel.");
            return;
        }
        String tr = rankOf(t.getUniqueId());
        if ("OWNER".equalsIgnoreCase(tr) || ("ADMIN".equalsIgnoreCase(tr) && !"OWNER".equalsIgnoreCase(my))) {
            msg(p, "&cDen kannst du nicht verbannen.");
            return;
        }
        update("DELETE FROM clan_members WHERE uuid=?", t.getUniqueId().toString());
        tagCache.clear();
        broadcastClan(clan.id(), "&5☠ &f" + name(t.getUniqueId()) + " &dwurde aus dem Zirkel verbannt.");
        if (t.isOnline() && t.getPlayer() != null) msg(t.getPlayer(), "&cDu wurdest aus dem Geisterzirkel &f" + clan.name() + " &cverbannt.");
    }

    private void setRank(Player p, String[] args, boolean up) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null || !"OWNER".equalsIgnoreCase(rankOf(p.getUniqueId()))) {
            msg(p, "&cNur der Anführer darf Ränge ändern.");
            return;
        }
        if (args.length < 2) {
            msg(p, "&cNutzung: /clan " + (up ? "promote" : "demote") + " <spieler>");
            return;
        }
        OfflinePlayer t = findMember(clan, args[1]);
        if (t == null || t.getUniqueId().equals(p.getUniqueId())) {
            msg(p, "&cDieser Spieler ist nicht in deinem Zirkel (oder du selbst).");
            return;
        }
        String nr = up ? "ADMIN" : "MEMBER";
        update("UPDATE clan_members SET rank=? WHERE uuid=?", nr, t.getUniqueId().toString());
        broadcastClan(clan.id(), "&5☠ &f" + name(t.getUniqueId()) + " &dist nun " + rankLabel(nr) + "&d.");
    }

    private void transfer(Player p, String[] args) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null || !"OWNER".equalsIgnoreCase(rankOf(p.getUniqueId()))) {
            msg(p, "&cNur der Anführer darf das.");
            return;
        }
        if (args.length < 2) {
            msg(p, "&cNutzung: /clan transfer <spieler>");
            return;
        }
        OfflinePlayer t = findMember(clan, args[1]);
        if (t == null || t.getUniqueId().equals(p.getUniqueId())) {
            msg(p, "&cDieser Spieler ist nicht in deinem Zirkel.");
            return;
        }
        update("UPDATE clan_members SET rank='ADMIN' WHERE uuid=?", p.getUniqueId().toString());
        update("UPDATE clan_members SET rank='OWNER' WHERE uuid=?", t.getUniqueId().toString());
        update("UPDATE clans SET owner=? WHERE id=?", t.getUniqueId().toString(), clan.id());
        broadcastClan(clan.id(), "&5☠ &f" + name(t.getUniqueId()) + " &dist nun der neue &c&lAnführer&d!");
    }

    private void disband(Player p) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null || !"OWNER".equalsIgnoreCase(rankOf(p.getUniqueId()))) {
            msg(p, "&cNur der Anführer darf den Zirkel auflösen.");
            return;
        }
        double bank = bank(clan.id());
        EconomyManager eco = eco();
        if (bank > 0 && eco != null) eco.deposit(p.getUniqueId(), bank);
        broadcastClan(clan.id(), "&5☠ &cDer Geisterzirkel &f" + clan.name() + " &cwurde aufgelöst.");
        update("DELETE FROM clan_members WHERE clan_id=?", clan.id());
        update("DELETE FROM clan_extra WHERE clan_id=?", clan.id());
        update("DELETE FROM clans WHERE id=?", clan.id());
        tagCache.clear();
        if (bank > 0) msg(p, "&aDie Clan-Kasse (&e" + (long) bank + "$&a) wurde dir ausgezahlt.");
    }

    private void info(Player p, String[] args) {
        ClanInfo clan = args.length >= 2 ? clanByName(args[1]) : clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, args.length >= 2 ? "&cDiesen Zirkel kennen die Geister nicht." : "&7Du gehörst keinem Geisterzirkel an.");
            return;
        }
        List<UUID> ms = members(clan.id());
        long on = ms.stream().filter(u -> Bukkit.getPlayer(u) != null).count();
        raw(p, "&8--- &5☠ &d" + clan.name() + " &8[&d" + clan.tag() + "&8] ---");
        raw(p, "&8» &7Anführer: &f" + name(UUID.fromString(clan.owner())));
        raw(p, "&8» &7Mitglieder: &f" + ms.size() + "&7/" + plugin.getConfig().getInt("clan.max-members", 20) + " &8(&a" + on + " online&8)");
        raw(p, "&8» &7Kasse: &e" + (long) bank(clan.id()) + "$");
    }

    private void list(Player p, String[] args) {
        ClanInfo clan = args.length >= 2 ? clanByName(args[1]) : clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&7Du gehörst keinem Geisterzirkel an.");
            return;
        }
        raw(p, "&8--- &5☠ &dMitglieder von " + clan.name() + " &8---");
        for (UUID u : members(clan.id())) {
            raw(p, "&8 - " + (Bukkit.getPlayer(u) != null ? "&a" : "&7") + name(u) + " &8| " + rankLabel(rankOf(u)));
        }
    }

    private void top(Player p) {
        raw(p, "&8--- &5☠ &dMächtigste Geisterzirkel &8---");
        String sql = "SELECT c.name, c.tag, COUNT(m.uuid) AS n, COALESCE(e.bank,0) AS bank FROM clans c "
                + "LEFT JOIN clan_members m ON m.clan_id=c.id LEFT JOIN clan_extra e ON e.clan_id=c.id "
                + "GROUP BY c.id ORDER BY n DESC, bank DESC LIMIT 10";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            int i = 1;
            while (rs.next()) {
                raw(p, "&8" + i++ + ". &d" + rs.getString(1) + " &8[&d" + rs.getString(2) + "&8] &7- &f" + rs.getInt(3)
                        + " Mitglieder &8| &e" + (long) rs.getDouble(4) + "$");
            }
            if (i == 1) raw(p, "&7Noch kein Zirkel wurde gegründet.");
        } catch (SQLException e) {
            msg(p, "&cEin Fluch verhinderte das Laden.");
        }
    }

    private void chat(Player p, String[] args, int from) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&7Du gehörst keinem Geisterzirkel an.");
            return;
        }
        if (args.length <= from) {
            msg(p, "&cNutzung: /clan chat <nachricht>");
            return;
        }
        sendClanChat(p, clan, String.join(" ", java.util.Arrays.copyOfRange(args, from, args.length)));
    }

    private void sendClanChat(Player p, ClanInfo clan, String text) {
        String line = "§5[Zirkel] §d" + p.getName() + "§8: §f" + text;
        for (UUID u : members(clan.id())) {
            Player m = Bukkit.getPlayer(u);
            if (m != null) m.sendMessage(line);
        }
        Bukkit.getConsoleSender().sendMessage("[Clan " + clan.name() + "] " + p.getName() + ": " + text);
    }

    private double parseAmount(Player p, String[] args) {
        if (args.length < 2) {
            msg(p, "&cNutzung: /clan " + args[0] + " <betrag>");
            return -1;
        }
        try {
            double v = Double.parseDouble(args[1].replace(",", "."));
            if (v <= 0 || Double.isNaN(v) || Double.isInfinite(v)) throw new NumberFormatException();
            return Math.floor(v * 100) / 100;
        } catch (NumberFormatException e) {
            msg(p, "&cDas ist keine gültige Zahl, Sterblicher.");
            return -1;
        }
    }

    private void deposit(Player p, String[] args) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&cDu gehörst keinem Geisterzirkel an.");
            return;
        }
        double v = parseAmount(p, args);
        EconomyManager eco = eco();
        if (v < 0 || eco == null) return;
        if (!eco.withdraw(p.getUniqueId(), v)) {
            msg(p, "&cDeine Taschen sind zu leer – nicht genug Geld!");
            return;
        }
        addBank(clan.id(), v);
        broadcastClan(clan.id(), "&5☠ &f" + p.getName() + " &dlegt &e" + (long) v + "$ &din die Zirkel-Kasse.");
    }

    private void withdraw(Player p, String[] args) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null || !leader(rankOf(p.getUniqueId()))) {
            msg(p, "&cNur Anführer und Offiziere dürfen die Kasse öffnen.");
            return;
        }
        double v = parseAmount(p, args);
        EconomyManager eco = eco();
        if (v < 0 || eco == null) return;
        if (bank(clan.id()) + 1e-9 < v) {
            msg(p, "&cIn der Kasse liegt nicht genug Gold!");
            return;
        }
        addBank(clan.id(), -v);
        eco.deposit(p.getUniqueId(), v);
        broadcastClan(clan.id(), "&5☠ &f" + p.getName() + " &dnimmt &e" + (long) v + "$ &daus der Zirkel-Kasse.");
    }

    private void setHome(Player p) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null || !leader(rankOf(p.getUniqueId()))) {
            msg(p, "&cNur Anführer und Offiziere dürfen den Treffpunkt setzen.");
            return;
        }
        Location l = p.getLocation();
        String s = l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch();
        update("INSERT OR IGNORE INTO clan_extra (clan_id, bank) VALUES (?, 0)", clan.id());
        update("UPDATE clan_extra SET home=? WHERE clan_id=?", s, clan.id());
        broadcastClan(clan.id(), "&5☠ &dDer Treffpunkt des Zirkels wurde gesetzt.");
    }

    private void home(Player p) {
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&cDu gehörst keinem Geisterzirkel an.");
            return;
        }
        String s = null;
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT home FROM clan_extra WHERE clan_id=?")) {
            ps.setInt(1, clan.id());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) s = rs.getString(1);
            }
        } catch (SQLException ignored) {
        }
        if (s == null) {
            msg(p, "&cDein Zirkel hat noch keinen Treffpunkt.");
            return;
        }
        String[] a = s.split(";");
        World w = Bukkit.getWorld(a[0]);
        if (w == null || a.length < 6) {
            msg(p, "&cDiese Welt schläft noch tief im Nebel.");
            return;
        }
        p.teleport(new Location(w, Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]),
                Float.parseFloat(a[4]), Float.parseFloat(a[5])));
        msg(p, "&aEin Nebel trägt dich zum Treffpunkt deines Zirkels.");
    }

    // ------------------------------------------------------------------ Events

    /** "@clan text" im normalen Chat = Clan-Chat. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!event.getMessage().toLowerCase(Locale.ROOT).startsWith("@clan ")) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        ClanInfo clan = clanOf(p.getUniqueId());
        if (clan == null) {
            msg(p, "&7Du gehörst keinem Geisterzirkel an.");
            return;
        }
        sendClanChat(p, clan, event.getMessage().substring(6));
    }

    /** Kein Schaden zwischen Clan-Mitgliedern (config clan.friendly-fire: true erlaubt ihn). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (plugin.getConfig().getBoolean("clan.friendly-fire", false)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        Player damager = null;
        if (e.getDamager() instanceof Player dp) damager = dp;
        else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sp) damager = sp;
        if (damager == null || damager.equals(victim)) return;
        ClanInfo a = clanOf(damager.getUniqueId());
        if (a != null) {
            ClanInfo b = clanOf(victim.getUniqueId());
            if (b != null && a.id() == b.id()) {
                e.setCancelled(true);
                damager.sendActionBar(net.kyori.adventure.text.Component.text("☠ Du kannst keinen Zirkel-Bruder verletzen", net.kyori.adventure.text.format.NamedTextColor.LIGHT_PURPLE));
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return TabCompleteUtil.filter(args[0], "create", "invite", "accept", "deny", "leave", "kick", "promote", "demote",
                    "transfer", "disband", "info", "list", "top", "chat", "deposit", "withdraw", "sethome", "home");
        }
        if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "invite", "kick", "promote", "demote", "transfer" -> {
                    return TabCompleteUtil.onlinePlayers(args[1]);
                }
                default -> {
                }
            }
        }
        return java.util.Collections.emptyList();
    }
}
