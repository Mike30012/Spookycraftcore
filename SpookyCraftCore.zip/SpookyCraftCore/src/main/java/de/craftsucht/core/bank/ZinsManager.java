package de.craftsucht.core.bank;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;

public class ZinsManager {

    private final SpookyCraftCore plugin;
    private final BankManager bankManager;
    private BukkitTask task;

    public ZinsManager(SpookyCraftCore plugin, BankManager bankManager) {
        this.plugin = plugin;
        this.bankManager = bankManager;
        start();
    }

    public void start() {
        // Einmalig: alte 10%-Zinsen auf 2% alle 15 Minuten senken.
        if (!plugin.getConfig().getBoolean("bank-migration.zins-v4", false)) {
            plugin.getConfig().set("bank.zinsen-prozent", 2.0);
            plugin.getConfig().set("bank.zinsen-intervall-minuten", 15);
            plugin.getConfig().set("bank-migration.zins-v4", true);
            plugin.saveConfig();
            plugin.getLogger().info("Bank: Zinsen auf 2% alle 15 Minuten gesetzt.");
        }
        if (!plugin.getConfig().getBoolean("bank.zinsen-enabled", true)) {
            return;
        }
        int minuten = plugin.getConfig().getInt("bank.zinsen-intervall-minuten", 10);
        long ticks = (long) minuten * 60L * 20L;
        double prozent = plugin.getConfig().getDouble("bank.zinsen-prozent", 10.0);
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Map<UUID, Double> gains = bankManager.applyInterestToAll(prozent);
            for (Map.Entry<UUID, Double> entry : gains.entrySet()) {
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player == null || !player.isOnline()) continue;
                player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                        "&8[&6☠ Bank&8] " + de.craftsucht.core.util.MessageUtil.spookify("&aZinsen gutgeschrieben: &e+" + String.format("%.2f", entry.getValue()) + "$")));
            }
        }, ticks, ticks);
    }

    public void shutdown() {
        if (task != null) task.cancel();
    }

    public void restart() {
        shutdown();
        start();
    }
}
