package de.craftsucht.core.rucksack;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.UUID;

/** /rucksack (/rs): persoenlicher Zusatz-Speicher, per /rucksack upgrade um Reihen erweiterbar. Stand in rucksack.yml. */
public class RucksackModule implements Module, CommandExecutor, Listener {

    private static final class BagHolder implements InventoryHolder {
        final UUID owner;

        BagHolder(UUID owner) {
            this.owner = owner;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public RucksackModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "rucksack";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "rucksack.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("rucksack").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof BagHolder h) {
                store(h.owner, p.getOpenInventory().getTopInventory());
            }
        }
        save();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("rucksack.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private int rows(UUID id) {
        int max = Math.max(1, Math.min(6, plugin.getConfig().getInt("rucksack.max-rows", 6)));
        int start = Math.max(1, Math.min(max, plugin.getConfig().getInt("rucksack.start-rows", 2)));
        return Math.min(max, data.getInt("players." + id + ".rows", start));
    }

    private void store(UUID id, Inventory inv) {
        try {
            data.set("players." + id + ".items", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(inv.getContents())));
            save();
        } catch (RuntimeException e) {
            plugin.getLogger().warning("Rucksack von " + id + " konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private void open(Player p) {
        int rows = rows(p.getUniqueId());
        Inventory inv = Bukkit.createInventory(new BagHolder(p.getUniqueId()), rows * 9, GuiUtil.c("&8&l☠ &7Rucksack"));
        String b64 = data.getString("players." + p.getUniqueId() + ".items");
        if (b64 != null) {
            try {
                ItemStack[] all = ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(b64));
                for (int i = 0; i < all.length && i < inv.getSize(); i++) inv.setItem(i, all[i]);
            } catch (RuntimeException e) {
                plugin.getLogger().warning("Rucksack von " + p.getName() + " ist unlesbar: " + e.getMessage());
            }
        }
        p.openInventory(inv);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("upgrade")) {
            int max = Math.max(1, Math.min(6, plugin.getConfig().getInt("rucksack.max-rows", 6)));
            int rows = rows(p.getUniqueId());
            if (rows >= max) {
                plugin.getMessageUtil().send(p, "&cDein Rucksack ist schon voll ausgebaut.");
                return true;
            }
            long price = plugin.getConfig().getLong("rucksack.row-price", 25000) * (rows);
            if (!(plugin.getModuleManager().get("economy") instanceof EconomyModule em) || em.getManager() == null
                    || !em.getManager().withdraw(p.getUniqueId(), price)) {
                plugin.getMessageUtil().send(p, "&cEine weitere Reihe kostet &f" + GuiUtil.money(price) + "&c.");
                return true;
            }
            data.set("players." + p.getUniqueId() + ".rows", rows + 1);
            save();
            plugin.getMessageUtil().send(p, "&aDein Rucksack hat jetzt &f" + (rows + 1) + " &aReihen.");
            return true;
        }
        open(p);
        if (rows(p.getUniqueId()) < 6) {
            long price = plugin.getConfig().getLong("rucksack.row-price", 25000) * rows(p.getUniqueId());
            plugin.getMessageUtil().send(p, "&7Mehr Platz: &f/rucksack upgrade &7(&e" + GuiUtil.money(price) + "&7)");
        }
        return true;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof BagHolder h) store(h.owner, e.getInventory());
    }
}
