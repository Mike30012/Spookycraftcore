package de.craftsucht.core.daily;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;

/** /daily: taegliche Belohnung mit Serie. Tag 7 jeder Serie gibt Kristalle. Stand in daily.yml. */
public class DailyModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public DailyModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "daily";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "daily.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("daily").setExecutor(this);
    }

    @Override
    public void disable() {
        // nichts offen
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        LocalDate today = LocalDate.now(ZoneId.of("Europe/Berlin"));
        String key = "players." + p.getUniqueId();
        String last = data.getString(key + ".last", "");
        int streak = data.getInt(key + ".streak", 0);
        if (last.equals(today.toString())) {
            plugin.getMessageUtil().send(p, "&cDu hast deine Belohnung heute schon geholt. Komm morgen wieder, Geist.");
            return true;
        }
        streak = last.equals(today.minusDays(1).toString()) ? streak + 1 : 1;
        data.set(key + ".last", today.toString());
        data.set(key + ".streak", streak);
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("daily.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
        int day = ((streak - 1) % 7) + 1;
        long money = plugin.getConfig().getLong("daily.money", 1000) + plugin.getConfig().getLong("daily.money-per-day", 500) * (day - 1);
        long crystals = day == 7 ? plugin.getConfig().getLong("daily.week-crystals", 5) : 0;
        if (plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
            em.getManager().deposit(p.getUniqueId(), money);
        }
        if (crystals > 0 && plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
            cm.getCrystals().add(p.getUniqueId(), crystals);
        }
        plugin.getMessageUtil().send(p, "&6☠ Tägliche Belohnung &7(Tag &f" + day + "&7/7, Serie &f" + streak + "&7): &e" + GuiUtil.money(money)
                + (crystals > 0 ? " &7+ &d" + crystals + " Kristalle" : ""));
        p.playSound(p.getLocation(), "entity.player.levelup", 0.8f, 1.0f);
        return true;
    }
}
