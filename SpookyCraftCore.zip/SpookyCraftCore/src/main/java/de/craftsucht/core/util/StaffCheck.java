package de.craftsucht.core.util;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.rank.RankModule;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Staff = OP, spookycraft.core.admin oder Rang owner/admin. */
public final class StaffCheck {
    private StaffCheck() {
    }

    public static boolean isStaff(SpookyCraftCore plugin, CommandSender s) {
        if (s.isOp() || s.hasPermission("spookycraft.core.admin")) return true;
        if (s instanceof Player p && plugin.getModuleManager().get("rank") instanceof RankModule rm && rm.getManager() != null) {
            String r = rm.getManager().getUserRank(p.getUniqueId());
            return r != null && (r.equalsIgnoreCase("owner") || r.equalsIgnoreCase("admin"));
        }
        return false;
    }
}
