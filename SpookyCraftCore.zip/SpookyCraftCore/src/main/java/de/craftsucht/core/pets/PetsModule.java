package de.craftsucht.core.pets;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.Compat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Geister-Begleiter (/pet): kleine Pets mit eigenem Modell (Resourcepack, Custom-Model-Data 2001-2008),
 * die dir folgen, Level sammeln und kleine Boni geben. Besitz/Level in pets.yml.
 */
public class PetsModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static PetsModule INSTANCE;

    /** Multiplikator fuer Job-Geld (Fledermaus). 1.0 wenn kein passendes Pet aktiv ist. */
    public static double jobMoneyMultiplier(Player p) {
        PetsModule m = INSTANCE;
        if (m == null) return 1.0;
        try {
            PetDef d = m.activeDef(p);
            if (d != null && d.id.equals("fledermaus")) return 1.0 + m.bonus(p, d) / 100.0;
        } catch (RuntimeException ignored) {
            // nie den Job-Lohn gefaehrden
        }
        return 1.0;
    }

    private record PetDef(String id, String name, String color, int model, boolean crystals, long price,
                          Particle particle, double min, double max) {
    }

    private static final List<PetDef> DEFS = List.of(
            new PetDef("fledermaus", "Fledermaus", "&8", 2001, false, 15000, Particle.SMOKE, 2, 10),
            new PetDef("irrlicht", "Irrlicht", "&b", 2002, false, 25000, Particle.END_ROD, 0, 0),
            new PetDef("geist", "Mini-Geist", "&f", 2003, false, 40000, Particle.SOUL, 0, 0),
            new PetDef("kuerbis", "Kürbis-Golem", "&6", 2004, false, 60000, Particle.HAPPY_VILLAGER, 5, 25),
            new PetDef("katze", "Skelett-Katze", "&7", 2005, false, 80000, Particle.CRIT, 3, 15),
            new PetDef("schatz", "Schatzgeist", "&e", 2006, false, 150000, Particle.TOTEM_OF_UNDYING, 2, 10),
            new PetDef("todesritter", "Todesritter", "&5", 2007, true, 250, Particle.SCULK_SOUL, 3, 15),
            new PetDef("phoenix", "Phönix", "&c", 2008, true, 400, Particle.FLAME, 0, 0)
    );

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private BukkitTask followTask;
    private BukkitTask effectTask;
    private final Map<UUID, ItemDisplay> spawned = new ConcurrentHashMap<>();
    private final Map<UUID, Long> phoenixUsed = new ConcurrentHashMap<>();
    private final Map<UUID, Long> trickUntil = new ConcurrentHashMap<>();
    private long tick;

    public PetsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "pets";
    }

    @Override
    public void enable() {
        INSTANCE = this;
        file = new File(plugin.getDataFolder(), "pets.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("pet").setExecutor(this);
        plugin.getCommand("pet").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        followTask = Bukkit.getScheduler().runTaskTimer(plugin, this::followTick, 40L, 2L);
        effectTask = Bukkit.getScheduler().runTaskTimer(plugin, this::effectTick, 60L, 40L);
        for (Player p : Bukkit.getOnlinePlayers()) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> respawn(p), 20L);
        }
    }

    @Override
    public void disable() {
        INSTANCE = null;
        if (followTask != null) followTask.cancel();
        if (effectTask != null) effectTask.cancel();
        for (ItemDisplay d : spawned.values()) {
            if (d != null && d.isValid()) d.remove();
        }
        spawned.clear();
    }

    // ------------------------------------------------------------------ Daten

    private static PetDef def(String id) {
        for (PetDef d : DEFS) if (d.id.equals(id)) return d;
        return null;
    }

    private String path(Player p) {
        return "players." + p.getUniqueId();
    }

    private boolean owns(Player p, String id) {
        return data.contains(path(p) + ".owned." + id);
    }

    private int xp(Player p, String id) {
        return data.getInt(path(p) + ".owned." + id, 0);
    }

    private double factor() {
        return Math.max(1, plugin.getConfig().getDouble("pets.xp-factor", 60));
    }

    private int level(int xp) {
        return Math.min(10, 1 + (int) Math.floor(Math.sqrt(xp / factor())));
    }

    private int levelOf(Player p, String id) {
        return level(xp(p, id));
    }

    private PetDef activeDef(Player p) {
        String a = data.getString(path(p) + ".active");
        if (a == null || !owns(p, a)) return null;
        return def(a);
    }

    private double bonus(Player p, PetDef d) {
        int lv = levelOf(p, d.id);
        return d.min + (d.max - d.min) * (lv - 1) / 9.0;
    }

    private long price(PetDef d) {
        return plugin.getConfig().getLong("pets.prices." + d.id, d.price);
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("pets.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private void addXp(Player p, int amount) {
        PetDef d = activeDef(p);
        if (d == null) return;
        int before = xp(p, d.id);
        int after = before + amount;
        data.set(path(p) + ".owned." + d.id, after);
        if (level(after) > level(before)) {
            plugin.getMessageUtil().send(p, "&5Dein Begleiter &f" + petName(p, d) + " &5ist auf &dLevel " + level(after) + " &5aufgestiegen!");
            p.playSound(p.getLocation(), "entity.player.levelup", 0.6f, 1.4f);
            refreshName(p);
        }
        if (ThreadLocalRandom.current().nextInt(20) == 0) save();
    }

    private String petName(Player p, PetDef d) {
        String custom = data.getString(path(p) + ".names." + d.id);
        return custom != null && !custom.isBlank() ? custom : d.name;
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String effectText(PetDef d, int lv) {
        double b = d.min + (d.max - d.min) * (lv - 1) / 9.0;
        String pct = String.format(Locale.GERMANY, "%.1f", b);
        return switch (d.id) {
            case "fledermaus" -> "+" + pct + "% Job-Geld";
            case "irrlicht" -> "Nachtsicht in dunklen Orten";
            case "geist" -> lv >= 10 ? "Geschwindigkeit II" : "Geschwindigkeit I";
            case "kuerbis" -> "+" + pct + "% Erfahrung";
            case "katze" -> pct + "% Chance auf Extra-Drop";
            case "schatz" -> pct + "% Chance auf Münzen beim Abbauen";
            case "todesritter" -> "-" + pct + "% Schaden von Monstern";
            case "phoenix" -> "Feuerresistenz + 1x/Std. Rettung vor dem Tod";
            default -> "";
        };
    }

    // ------------------------------------------------------------------ Entity

    private ItemStack modelItem(PetDef d) {
        ItemStack it = new ItemStack(Material.PHANTOM_MEMBRANE);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setCustomModelData(d.model);
            it.setItemMeta(meta);
        }
        return it;
    }

    private void despawn(Player p) {
        ItemDisplay old = spawned.remove(p.getUniqueId());
        if (old != null && old.isValid()) old.remove();
    }

    private void respawn(Player p) {
        despawn(p);
        if (!p.isOnline() || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) return;
        PetDef d = activeDef(p);
        if (d == null) return;
        float s = (float) plugin.getConfig().getDouble("pets.scale", 0.6);
        Location loc = target(p, 0);
        ItemDisplay e = p.getWorld().spawn(loc, ItemDisplay.class, disp -> {
            disp.setItemStack(modelItem(d));
            disp.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            disp.setTransformation(new Transformation(new Vector3f(-0.5f * s, 0f, -0.5f * s), new AxisAngle4f(),
                    new Vector3f(s, s, s), new AxisAngle4f()));
            disp.setTeleportDuration(3);
            disp.setInvulnerable(true);
            disp.setPersistent(false);
            disp.setGravity(false);
        });
        spawned.put(p.getUniqueId(), e);
        refreshName(p);
    }

    private void refreshName(Player p) {
        ItemDisplay e = spawned.get(p.getUniqueId());
        PetDef d = activeDef(p);
        if (e == null || !e.isValid() || d == null) return;
        e.setCustomName(c(d.color + petName(p, d) + " &8[&7Lv." + levelOf(p, d.id) + "&8]"));
        e.setCustomNameVisible(true);
    }

    private Location target(Player p, double bob) {
        Location l = p.getLocation();
        Vector dir = l.getDirection().setY(0);
        if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
        dir.normalize();
        Vector right = new Vector(-dir.getZ(), 0, dir.getX());
        Location t = l.clone().add(right.multiply(0.9)).subtract(dir.multiply(0.6));
        t.setY(l.getY() + 1.1 + bob);
        t.setYaw(l.getYaw() + (float) plugin.getConfig().getDouble("pets.yaw-offset", 0));
        t.setPitch(0f);
        return t;
    }

    private void followTick() {
        tick += 2;
        for (Player p : Bukkit.getOnlinePlayers()) {
            ItemDisplay e = spawned.get(p.getUniqueId());
            if (e == null) continue;
            if (!e.isValid() || !p.isOnline() || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) {
                despawn(p);
                continue;
            }
            PetDef d = activeDef(p);
            if (d == null) {
                despawn(p);
                continue;
            }
            double bob = Math.sin(tick / 10.0) * 0.12;
            Long trick = trickUntil.get(p.getUniqueId());
            if (trick != null) {
                if (System.currentTimeMillis() > trick) {
                    trickUntil.remove(p.getUniqueId());
                } else {
                    bob += Math.abs(Math.sin(tick / 3.0)) * 0.6;
                }
            }
            Location t = target(p, bob);
            if (!e.getWorld().equals(t.getWorld()) || e.getLocation().distanceSquared(t) > 400) {
                respawn(p);
                continue;
            }
            e.teleport(t);
            if (tick % 6 == 0 && data.getBoolean(path(p) + ".particles", true)) {
                p.getWorld().spawnParticle(d.particle, t.clone().add(0, 0.4, 0), 1, 0.15, 0.15, 0.15, 0.0);
            }
        }
    }

    // ------------------------------------------------------------------ Effekte

    private void effectTick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            PetDef d = activeDef(p);
            if (d == null || spawned.get(p.getUniqueId()) == null) continue;
            int lv = levelOf(p, d.id);
            switch (d.id) {
                case "irrlicht" -> {
                    if (p.getLocation().getBlock().getLightLevel() < 8) give(p, "night_vision", 0);
                }
                case "geist" -> give(p, "speed", lv >= 10 ? 1 : 0);
                case "phoenix" -> give(p, "fire_resistance", 0);
                default -> {
                }
            }
        }
    }

    private void give(Player p, String key, int amp) {
        PotionEffectType t = PotionEffectType.getByKey(NamespacedKey.minecraft(key));
        if (t == null) return;
        p.addPotionEffect(new PotionEffect(t, 140, amp, true, false, false));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        PetDef d = activeDef(p);
        if (d == null) return;
        addXp(p, 1);
        if (d.id.equals("schatz") && ThreadLocalRandom.current().nextDouble() * 100 < bonus(p, d)
                && plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
            long coins = 20L * levelOf(p, d.id) + ThreadLocalRandom.current().nextInt(30);
            em.getManager().deposit(p.getUniqueId(), coins);
            p.sendActionBar(c("&e✦ Dein Schatzgeist fand &f" + coins + "$"));
            p.playSound(p.getLocation(), "entity.experience_orb.pickup", 0.5f, 1.6f);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent e) {
        Player p = e.getEntity().getKiller();
        if (p == null || e.getEntity() instanceof Player) return;
        PetDef d = activeDef(p);
        if (d == null) return;
        addXp(p, 3);
        if (d.id.equals("katze") && !e.getDrops().isEmpty() && ThreadLocalRandom.current().nextDouble() * 100 < bonus(p, d)) {
            ItemStack drop = e.getDrops().get(ThreadLocalRandom.current().nextInt(e.getDrops().size())).clone();
            drop.setAmount(1);
            e.getDrops().add(drop);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onExp(PlayerExpChangeEvent e) {
        PetDef d = activeDef(e.getPlayer());
        if (d == null || !d.id.equals("kuerbis") || e.getAmount() <= 0) return;
        e.setAmount((int) Math.round(e.getAmount() * (1 + bonus(e.getPlayer(), d) / 100.0)));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        PetDef d = activeDef(p);
        if (d == null) return;
        if (d.id.equals("todesritter") && e instanceof EntityDamageByEntityEvent be
                && be.getDamager() instanceof Monster) {
            e.setDamage(e.getDamage() * (1 - bonus(p, d) / 100.0));
        } else if (d.id.equals("phoenix") && p.getHealth() - e.getFinalDamage() <= 0) {
            long cd = plugin.getConfig().getLong("pets.phoenix-cooldown-minutes", 60) * 60_000L;
            Long last = phoenixUsed.get(p.getUniqueId());
            if (last != null && System.currentTimeMillis() - last < cd) return;
            phoenixUsed.put(p.getUniqueId(), System.currentTimeMillis());
            e.setCancelled(true);
            double max = p.getAttribute(Compat.attr("max_health")).getValue();
            p.setHealth(Math.min(max, 10.0));
            p.setFireTicks(0);
            p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 60, 0.5, 0.8, 0.5, 0.05);
            p.playSound(p.getLocation(), "item.totem.use", 1f, 1f);
            plugin.getMessageUtil().send(p, "&cDein Phönix hat dich aus der Asche gerettet!");
        }
    }

    // ------------------------------------------------------------------ Lebenszyklus

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> respawn(p), 30L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        despawn(e.getPlayer());
        trickUntil.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> respawn(p), 10L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        despawn(e.getEntity());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> respawn(p), 20L);
    }

    // ------------------------------------------------------------------ Befehl

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("give")) {
            return give(sender, args);
        }
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            open(p);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "trick" -> trick(p);
            case "off", "weg" -> {
                data.set(path(p) + ".active", null);
                save();
                despawn(p);
                plugin.getMessageUtil().send(p, "&7Dein Begleiter verschwindet im Nebel.");
            }
            case "rename", "name" -> {
                PetDef d = activeDef(p);
                if (d == null) {
                    plugin.getMessageUtil().send(p, "&cDu hast gerade keinen Begleiter dabei.");
                    return true;
                }
                if (args.length < 2) {
                    plugin.getMessageUtil().send(p, "&cNutzung: /pet rename <Name>");
                    return true;
                }
                String name = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
                name = ChatColor.stripColor(c(name));
                if (name.length() > 16) name = name.substring(0, 16);
                data.set(path(p) + ".names." + d.id, name);
                save();
                refreshName(p);
                plugin.getMessageUtil().send(p, "&aDein Begleiter hört jetzt auf &f" + name + "&a.");
            }
            default -> open(p);
        }
        return true;
    }

    private boolean give(CommandSender sender, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.pets.admin") && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /pet give <Spieler> <id>");
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        PetDef d = def(args[2].toLowerCase(Locale.ROOT));
        if (t == null || d == null) {
            plugin.getMessageUtil().send(sender, "&cSpieler nicht online oder Pet unbekannt. IDs: fledermaus, irrlicht, geist, kuerbis, katze, schatz, todesritter, phoenix");
            return true;
        }
        if (!owns(t, d.id)) data.set(path(t) + ".owned." + d.id, 0);
        save();
        plugin.getMessageUtil().send(sender, "&a" + t.getName() + " besitzt jetzt " + d.name + ".");
        plugin.getMessageUtil().send(t, "&5Ein neuer Begleiter wartet auf dich: &f" + d.name + " &7(/pet)");
        return true;
    }

    private void trick(Player p) {
        if (activeDef(p) == null || spawned.get(p.getUniqueId()) == null) {
            plugin.getMessageUtil().send(p, "&cDu hast gerade keinen Begleiter dabei.");
            return;
        }
        trickUntil.put(p.getUniqueId(), System.currentTimeMillis() + 2500);
        ItemDisplay e = spawned.get(p.getUniqueId());
        e.getWorld().spawnParticle(Particle.HEART, e.getLocation().add(0, 0.8, 0), 6, 0.3, 0.3, 0.3, 0.0);
        p.playSound(p.getLocation(), "entity.cat.purr", 0.7f, 1.2f);
    }

    @Override
    public List<String> tabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) {
            List<String> out = new ArrayList<>(List.of("trick", "rename", "off"));
            if (s.isOp()) out.add("give");
            out.removeIf(x -> !x.startsWith(a[0].toLowerCase(Locale.ROOT)));
            return out;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("give") && s.isOp()) return null;
        if (a.length == 3 && a[0].equalsIgnoreCase("give") && s.isOp()) {
            List<String> ids = new ArrayList<>();
            for (PetDef d : DEFS) ids.add(d.id);
            return ids;
        }
        return List.of();
    }

    // ------------------------------------------------------------------ GUI

    private static class PetHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(new PetHolder(), 27, c("&5&l☠ &dGeister-Begleiter"));
        ItemStack pane = named(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);
        PetDef active = activeDef(p);
        for (int i = 0; i < DEFS.size(); i++) {
            PetDef d = DEFS.get(i);
            ItemStack it = modelItem(d);
            ItemMeta m = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            boolean has = owns(p, d.id);
            m.setDisplayName(c(d.color + "&l" + (has ? petName(p, d) : d.name)));
            if (has) {
                int lv = levelOf(p, d.id);
                lore.add(c("&7Level: &f" + lv + (lv >= 10 ? " &6(MAX)" : "")));
                lore.add(c("&7Effekt: &f" + effectText(d, lv)));
                lore.add("");
                lore.add(c(active != null && active.id.equals(d.id) ? "&a✔ Aktiv &7(Klick: wegschicken)" : "&eKlick: Begleiter rufen"));
            } else {
                lore.add(c("&7Effekt (Lv.1): &f" + effectText(d, 1)));
                lore.add(c("&7Effekt (Lv.10): &f" + effectText(d, 10)));
                lore.add("");
                lore.add(c("&7Preis: &f" + price(d) + (d.crystals ? " Kristalle" : "$")));
                lore.add(c("&eKlick: Kaufen"));
            }
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(9 + i, it);
        }
        boolean part = data.getBoolean(path(p) + ".particles", true);
        inv.setItem(18, named(Material.BLAZE_POWDER, c("&dPartikel: " + (part ? "&aAn" : "&cAus")), List.of(c("&7Klick zum Umschalten"))));
        inv.setItem(22, named(Material.BONE, c("&dTrick"), List.of(c("&7Dein Begleiter hüpft vor Freude"))));
        inv.setItem(26, named(Material.BARRIER, c("&cBegleiter wegschicken"), List.of()));
        p.openInventory(inv);
    }

    private ItemStack named(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof PetHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof PetHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot == 18) {
            data.set(path(p) + ".particles", !data.getBoolean(path(p) + ".particles", true));
            save();
            open(p);
            return;
        }
        if (slot == 22) {
            p.closeInventory();
            trick(p);
            return;
        }
        if (slot == 26) {
            data.set(path(p) + ".active", null);
            save();
            despawn(p);
            p.closeInventory();
            plugin.getMessageUtil().send(p, "&7Dein Begleiter verschwindet im Nebel.");
            return;
        }
        int idx = slot - 9;
        if (idx < 0 || idx >= DEFS.size()) return;
        PetDef d = DEFS.get(idx);
        p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.0f);
        if (owns(p, d.id)) {
            PetDef cur = activeDef(p);
            if (cur != null && cur.id.equals(d.id)) {
                data.set(path(p) + ".active", null);
                despawn(p);
                plugin.getMessageUtil().send(p, "&7Dein Begleiter verschwindet im Nebel.");
            } else {
                data.set(path(p) + ".active", d.id);
                respawn(p);
                plugin.getMessageUtil().send(p, "&aDein Begleiter &f" + petName(p, d) + " &afolgt dir jetzt.");
            }
            save();
            open(p);
            return;
        }
        if (!pay(p, d)) {
            plugin.getMessageUtil().send(p, "&cDafür fehlt dir " + (d.crystals ? "es an Kristallen." : "das Geld."));
            return;
        }
        data.set(path(p) + ".owned." + d.id, 0);
        data.set(path(p) + ".active", d.id);
        save();
        respawn(p);
        plugin.getMessageUtil().send(p, "&5Ein neuer Begleiter erwacht: &f" + d.name + "&5!");
        p.playSound(p.getLocation(), "entity.player.levelup", 0.8f, 1.2f);
        open(p);
    }

    private boolean pay(Player p, PetDef d) {
        long cost = price(d);
        if (d.crystals) {
            return plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null
                    && cm.getCrystals().take(p.getUniqueId(), cost);
        }
        return plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null
                && em.getManager().withdraw(p.getUniqueId(), cost);
    }
}
