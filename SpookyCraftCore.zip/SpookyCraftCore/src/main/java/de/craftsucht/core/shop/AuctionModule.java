package de.craftsucht.core.shop;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.*;

/** Minimal command-based auction house (list / buy / listings). Item storage as a Base64 string via Bukkit's ItemStack serialization is recommended for a full item-preview GUI later. */
public class AuctionModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter {

    private final SpookyCraftCore plugin;

    public AuctionModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "auction";
    }

    @Override
    public void enable() {
        plugin.getCommand("ah").setExecutor(this);
        plugin.getCommand("ah").setTabCompleter(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "sell", "buy", "list");
        }
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length < 1) {
            plugin.getMessageUtil().send(p, "&cNutzung: /ah <sell|buy|list> [preis|id]");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "sell" -> sell(p, args);
            case "buy" -> buy(p, args);
            case "list" -> list(p);
            default -> plugin.getMessageUtil().send(p, "&cUnbekannter Befehl.");
        }
        return true;
    }

    private void sell(Player p, String[] args) {
        if (args.length < 2 || p.getInventory().getItemInMainHand().getType().isAir()) {
            plugin.getMessageUtil().send(p, "&cHalte ein Item in der Hand: /ah sell <preis>");
            return;
        }
        double price;
        try {
            price = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            plugin.getMessageUtil().send(p, "&cUngültiger Preis.");
            return;
        }
        String itemData = p.getInventory().getItemInMainHand().getType().name() + ":" + p.getInventory().getItemInMainHand().getAmount();
        String sql = "INSERT INTO auctions (seller, item_data, price, listed_at, sold) VALUES (?,?,?,?,0)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            ps.setString(2, itemData);
            ps.setDouble(3, price);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
            p.getInventory().setItemInMainHand(null);
            plugin.getMessageUtil().send(p, "&aItem für $" + price + " gelistet.");
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Listen.");
        }
    }

    private void buy(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /ah buy <id>");
            return;
        }
        int id;
        try {
            id = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            plugin.getMessageUtil().send(p, "&cUngültige ID.");
            return;
        }
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        if (economyModule == null) return;
        String sql = "SELECT seller, item_data, price FROM auctions WHERE id=? AND sold=0";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    plugin.getMessageUtil().send(p, "&cAngebot nicht gefunden.");
                    return;
                }
                double price = rs.getDouble("price");
                String seller = rs.getString("seller");
                String itemData = rs.getString("item_data");
                if (!economyModule.getManager().withdraw(p.getUniqueId(), price)) {
                    plugin.getMessageUtil().send(p, "&cNicht genug Geld.");
                    return;
                }
                economyModule.getManager().deposit(java.util.UUID.fromString(seller), price);
                String[] parts = itemData.split(":");
                p.getInventory().addItem(new org.bukkit.inventory.ItemStack(org.bukkit.Material.valueOf(parts[0]), Integer.parseInt(parts[1])));
                try (PreparedStatement ps2 = c.prepareStatement("UPDATE auctions SET sold=1 WHERE id=?")) {
                    ps2.setInt(1, id);
                    ps2.executeUpdate();
                }
                plugin.getMessageUtil().send(p, "&aGekauft!");
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Kauf.");
        }
    }

    private void list(Player p) {
        String sql = "SELECT id, seller, item_data, price FROM auctions WHERE sold=0 ORDER BY listed_at DESC LIMIT 15";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) {
                plugin.getMessageUtil().sendRaw(p, "&8--- &bAuktionshaus &8---");
                while (rs.next()) {
                    String sellerName = Bukkit.getOfflinePlayer(java.util.UUID.fromString(rs.getString("seller"))).getName();
                    plugin.getMessageUtil().sendRaw(p, "&7#" + rs.getInt("id") + " &b" + rs.getString("item_data") + " &7von " + sellerName + " &7- &a$" + rs.getDouble("price"));
                }
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Laden.");
        }
    }
}
