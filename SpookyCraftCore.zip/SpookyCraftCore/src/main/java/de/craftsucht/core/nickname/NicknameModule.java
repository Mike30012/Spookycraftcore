package de.craftsucht.core.nickname;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.*;

public class NicknameModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter, org.bukkit.event.Listener {

    private final SpookyCraftCore plugin;
    private final java.util.Map<java.util.UUID, String> nicks = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<java.util.UUID, org.bukkit.entity.TextDisplay> tags = new java.util.HashMap<>();

    /** Nickname des Spielers oder null. */
    public String getNick(Player p) {
        return nicks.get(p.getUniqueId());
    }

    /** Zeigt (oder aktualisiert) den Nick-Namen ueber dem Kopf. Text null = Tag entfernen. */
    public void updateTag(Player p, String text) {
        org.bukkit.entity.TextDisplay d = tags.get(p.getUniqueId());
        if (text == null || !p.isOnline() || p.isDead()) {
            if (d != null) { if (d.isValid()) d.remove(); tags.remove(p.getUniqueId()); }
            return;
        }
        if (d != null && (!d.isValid() || !p.getPassengers().contains(d))) {
            if (d.isValid()) d.remove();
            tags.remove(p.getUniqueId());
            d = null;
        }
        if (d == null) {
            d = p.getWorld().spawn(p.getLocation(), org.bukkit.entity.TextDisplay.class, t -> {
                t.setPersistent(false);
                t.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
                t.setBackgroundColor(org.bukkit.Color.fromARGB(64, 0, 0, 0));
                t.setShadowed(false);
                t.setSeeThrough(false);
                t.setViewRange(1.0f);
                t.setInterpolationDuration(0);
                t.setTransformation(new org.bukkit.util.Transformation(
                        new org.joml.Vector3f(0f, 0.28f, 0f), new org.joml.AxisAngle4f(),
                        new org.joml.Vector3f(1f, 1f, 1f), new org.joml.AxisAngle4f()));
            });
            p.addPassenger(d);
            p.hideEntity(plugin, d);
            tags.put(p.getUniqueId(), d);
        }
        String legacy = text;
        net.kyori.adventure.text.Component c = net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(legacy);
        if (!c.equals(d.text())) d.text(c);
    }

    @org.bukkit.event.EventHandler
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String nick = loadNickname(p.getUniqueId().toString());
        if (nick != null) {
            nicks.put(p.getUniqueId(), nick);
            p.setDisplayName(nick);
        }
    }

    @org.bukkit.event.EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent e) {
        updateTag(e.getPlayer(), null);
        nicks.remove(e.getPlayer().getUniqueId());
    }

    private String loadNickname(String uuid) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT nickname FROM nicknames WHERE uuid = ?")) {
            ps.setString(1, uuid);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString(1);
            }
        } catch (SQLException ex) {
            plugin.getLogger().warning("Nickname laden fehlgeschlagen: " + ex.getMessage());
        }
        return null;
    }

    public NicknameModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "nickname";
    }

    @Override
    public void enable() {
        plugin.getCommand("nick").setExecutor(this);
        plugin.getCommand("nick").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (Player p : Bukkit.getOnlinePlayers()) {
            String nick = loadNickname(p.getUniqueId().toString());
            if (nick != null) { nicks.put(p.getUniqueId(), nick); p.setDisplayName(nick); }
        }
        // Eigener Takt (1 Sek.): Vanilla-Nametag bei Nick-Spielern auf JEDEM Scoreboard ausblenden
        // und den Nick-Tag + Scoreboard neu setzen - unabhaengig vom Scoreboard-Modul-Takt.
        enforceTask = Bukkit.getScheduler().runTaskTimer(plugin, this::enforce, 20L, 20L);
    }

    private org.bukkit.scheduler.BukkitTask enforceTask;

    private void enforce() {
        if (nicks.isEmpty()) return;
        de.craftsucht.core.module.Module m = plugin.getModuleManager().get("scoreboard");
        if (m instanceof de.craftsucht.core.scoreboard.ScoreboardModule sm) sm.refreshNow();
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            org.bukkit.scoreboard.Scoreboard sb = viewer.getScoreboard();
            for (Player nicked : Bukkit.getOnlinePlayers()) {
                if (!nicks.containsKey(nicked.getUniqueId())) continue;
                org.bukkit.scoreboard.Team t = sb.getEntryTeam(nicked.getName());
                if (t == null) {
                    t = sb.getTeam("zz_nick_" + nicked.getName());
                    if (t == null) t = sb.registerNewTeam("zz_nick_" + nicked.getName());
                    t.addEntry(nicked.getName());
                }
                if (t.getOption(org.bukkit.scoreboard.Team.Option.NAME_TAG_VISIBILITY) != org.bukkit.scoreboard.Team.OptionStatus.NEVER)
                    t.setOption(org.bukkit.scoreboard.Team.Option.NAME_TAG_VISIBILITY, org.bukkit.scoreboard.Team.OptionStatus.NEVER);
            }
        }
    }

    @Override
    public void disable() {
        org.bukkit.event.HandlerList.unregisterAll(this);
        if (enforceTask != null) enforceTask.cancel();
        for (org.bukkit.entity.TextDisplay d : tags.values()) if (d.isValid()) d.remove();
        tags.clear();
        nicks.clear();
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "reset");
        }
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /nick <name|reset>");
            return true;
        }
        if (args[0].equalsIgnoreCase("reset")) {
            setNickname(p.getUniqueId().toString(), null);
            nicks.remove(p.getUniqueId());
            updateTag(p, null);
            p.setDisplayName(p.getName());
            plugin.getMessageUtil().send(p, "&aNickname zurückgesetzt.");
            refreshVisuals();
            return true;
        }
        String nick = args[0];
        setNickname(p.getUniqueId().toString(), nick);
        nicks.put(p.getUniqueId(), nick);
        p.setDisplayName(nick);
        plugin.getMessageUtil().send(p, "&aNickname gesetzt: &f" + nick + " &7(Chat, Tab und über dem Kopf)");
        refreshVisuals();
        return true;
    }

    /** Tab, Nametag und Name ueber dem Kopf sofort aktualisieren (statt auf den naechsten Scoreboard-Tick zu warten). */
    private void refreshVisuals() {
        org.bukkit.plugin.Plugin pl = plugin;
        Bukkit.getScheduler().runTask(pl, () -> {
            de.craftsucht.core.module.Module m = plugin.getModuleManager().get("scoreboard");
            if (m instanceof de.craftsucht.core.scoreboard.ScoreboardModule sm) sm.refreshNow();
        });
    }

    private void setNickname(String uuid, String nick) {
        String sql = "INSERT INTO nicknames (uuid, nickname) VALUES (?, ?) " +
                "ON CONFLICT(uuid) DO UPDATE SET nickname = excluded.nickname";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, nick);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Nickname speichern fehlgeschlagen: " + e.getMessage());
        }
    }
}
