package de.craftsucht.core.nickname;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.*;

public class NicknameModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter {

    private final SpookyCraftCore plugin;

    public NicknameModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "nickname";
    }

    @Override
    public void enable() {
        plugin.getCommand("nick").setExecutor(this);
        plugin.getCommand("nick").setTabCompleter(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "reset");
        }
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /nick <name|reset>");
            return true;
        }
        if (args[0].equalsIgnoreCase("reset")) {
            setNickname(p.getUniqueId().toString(), null);
            p.setDisplayName(p.getName());
            p.setPlayerListName(p.getName());
            plugin.getMessageUtil().send(p, "&aNickname zurückgesetzt.");
            return true;
        }
        String nick = args[0];
        setNickname(p.getUniqueId().toString(), nick);
        p.setDisplayName(nick);
        p.setPlayerListName(nick);
        plugin.getMessageUtil().send(p, "&aNickname gesetzt: " + nick);
        return true;
    }

    private void setNickname(String uuid, String nick) {
        String sql = "INSERT INTO nicknames (uuid, nickname) VALUES (?, ?) " +
                "ON CONFLICT(uuid) DO UPDATE SET nickname = excluded.nickname";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid);
            ps.setString(2, nick);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Nickname speichern fehlgeschlagen: " + e.getMessage());
        }
    }
}
