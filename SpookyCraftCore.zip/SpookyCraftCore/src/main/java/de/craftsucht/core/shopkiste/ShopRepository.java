package de.craftsucht.core.shopkiste;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.BlockFace;
import org.bukkit.block.DoubleChest;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Datenbank + schneller Speicher-Index aller Shopkisten (für Schutz-Checks bei Hoppern, Explosionen usw.). */
public class ShopRepository {

    private final SpookyCraftCore plugin;
    private final Map<String, ShopRecord> bySign = new HashMap<>();
    private final Map<String, ShopRecord> byContainer = new HashMap<>();

    public ShopRepository(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public static String key(String world, int x, int y, int z) {
        return world + ";" + x + ";" + y + ";" + z;
    }

    public static String key(Block b) {
        return key(b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
    }

    public boolean isEmpty() {
        return bySign.isEmpty();
    }

    public int size() {
        return bySign.size();
    }

    // ------------------------------------------------------------------ Datenbank

    public void init() {
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS chestshops (id INTEGER PRIMARY KEY AUTOINCREMENT, world TEXT NOT NULL, "
                    + "sx INTEGER, sy INTEGER, sz INTEGER, cx INTEGER, cy INTEGER, cz INTEGER, owner TEXT NOT NULL, owner_name TEXT, "
                    + "item TEXT NOT NULL, amount INTEGER NOT NULL, buy REAL NOT NULL, sell REAL NOT NULL, created_at INTEGER NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS chestshop_tx (id INTEGER PRIMARY KEY AUTOINCREMENT, shop_id INTEGER NOT NULL, "
                    + "time INTEGER NOT NULL, player_name TEXT, type TEXT NOT NULL, count INTEGER NOT NULL, total REAL NOT NULL, fee REAL NOT NULL)");
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_chestshop_tx_shop ON chestshop_tx (shop_id, time)");
        } catch (SQLException e) {
            plugin.getLogger().severe("Shopkisten: Tabellen konnten nicht erstellt werden: " + e.getMessage());
            return;
        }
        loadAll();
    }

    private void loadAll() {
        bySign.clear();
        byContainer.clear();
        String sql = "SELECT id, world, sx, sy, sz, cx, cy, cz, owner, owner_name, item, amount, buy, sell FROM chestshops";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                try {
                    ItemStack item = ItemStack.deserializeBytes(Base64.getDecoder().decode(rs.getString("item")));
                    ShopRecord shop = new ShopRecord(rs.getInt("id"), rs.getString("world"), rs.getInt("sx"), rs.getInt("sy"),
                            rs.getInt("sz"), rs.getInt("cx"), rs.getInt("cy"), rs.getInt("cz"), UUID.fromString(rs.getString("owner")),
                            rs.getString("owner_name"), item, rs.getInt("amount"), rs.getDouble("buy"), rs.getDouble("sell"));
                    index(shop);
                } catch (Exception e) {
                    plugin.getLogger().warning("Shopkiste #" + rs.getInt("id") + " konnte nicht geladen werden: " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Shopkisten laden fehlgeschlagen: " + e.getMessage());
        }
        plugin.getLogger().info("Shopkisten geladen: " + bySign.size());
    }

    private void index(ShopRecord shop) {
        bySign.put(key(shop.world(), shop.sx(), shop.sy(), shop.sz()), shop);
        byContainer.put(key(shop.world(), shop.cx(), shop.cy(), shop.cz()), shop);
    }

    public ShopRecord insert(String world, Block sign, Block container, UUID owner, String ownerName, ItemStack item,
                             int amount, double buy, double sell) {
        String sql = "INSERT INTO chestshops (world, sx, sy, sz, cx, cy, cz, owner, owner_name, item, amount, buy, sell, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ItemStack template = item.clone();
            template.setAmount(1);
            ps.setString(1, world);
            ps.setInt(2, sign.getX());
            ps.setInt(3, sign.getY());
            ps.setInt(4, sign.getZ());
            ps.setInt(5, container.getX());
            ps.setInt(6, container.getY());
            ps.setInt(7, container.getZ());
            ps.setString(8, owner.toString());
            ps.setString(9, ownerName);
            ps.setString(10, Base64.getEncoder().encodeToString(template.serializeAsBytes()));
            ps.setInt(11, amount);
            ps.setDouble(12, buy);
            ps.setDouble(13, sell);
            ps.setLong(14, System.currentTimeMillis());
            ps.executeUpdate();
            int id = 0;
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) id = keys.getInt(1);
            }
            ShopRecord shop = new ShopRecord(id, world, sign.getX(), sign.getY(), sign.getZ(), container.getX(), container.getY(),
                    container.getZ(), owner, ownerName, template, amount, buy, sell);
            index(shop);
            return shop;
        } catch (SQLException e) {
            plugin.getLogger().warning("Shopkiste speichern fehlgeschlagen: " + e.getMessage());
            return null;
        }
    }

    public void delete(ShopRecord shop) {
        bySign.remove(key(shop.world(), shop.sx(), shop.sy(), shop.sz()));
        byContainer.values().removeIf(s -> s.id() == shop.id());
        try (Connection c = plugin.getDatabase().getConnection()) {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM chestshops WHERE id = ?")) {
                ps.setInt(1, shop.id());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM chestshop_tx WHERE shop_id = ?")) {
                ps.setInt(1, shop.id());
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Shopkiste löschen fehlgeschlagen: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Suche

    public ShopRecord atSign(Block b) {
        if (bySign.isEmpty()) return null;
        return bySign.get(key(b));
    }

    /** Findet den Shop zu einem Kisten-Block - auch wenn der Block die andere Hälfte einer Doppelkiste ist. */
    public ShopRecord atContainer(Block b) {
        if (byContainer.isEmpty()) return null;
        ShopRecord direct = byContainer.get(key(b));
        if (direct != null) return direct;
        Material type = b.getType();
        if (type != Material.CHEST && type != Material.TRAPPED_CHEST) return null;

        boolean neighbourIsShop = false;
        for (BlockFace face : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            if (byContainer.containsKey(key(b.getRelative(face)))) {
                neighbourIsShop = true;
                break;
            }
        }
        if (!neighbourIsShop) return null;

        BlockState state = b.getState(false);
        if (state instanceof org.bukkit.block.Chest chest) {
            InventoryHolder holder = chest.getInventory().getHolder();
            if (holder instanceof DoubleChest dc) {
                for (InventoryHolder side : new InventoryHolder[]{dc.getLeftSide(), dc.getRightSide()}) {
                    if (side instanceof org.bukkit.block.Chest part) {
                        ShopRecord found = byContainer.get(key(part.getBlock()));
                        if (found != null) {
                            byContainer.put(key(b), found); // Doppelkiste: auch diese Hälfte merken
                            return found;
                        }
                    }
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ Transaktionen

    public void logTransaction(int shopId, String playerName, String type, int count, double total, double fee) {
        String sql = "INSERT INTO chestshop_tx (shop_id, time, player_name, type, count, total, fee) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, shopId);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, playerName);
            ps.setString(4, type);
            ps.setInt(5, count);
            ps.setDouble(6, total);
            ps.setDouble(7, fee);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Shop-Transaktion speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    /** Formatierte Zeilen der letzten Transaktionen (neueste zuerst). */
    public List<String> lastTransactions(int shopId, int limit) {
        List<String> lines = new ArrayList<>();
        String sql = "SELECT time, player_name, type, count, total FROM chestshop_tx WHERE shop_id = ? ORDER BY time DESC LIMIT ?";
        SimpleDateFormat format = new SimpleDateFormat("dd.MM. HH:mm");
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, shopId);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    boolean bought = "BUY".equals(rs.getString("type"));
                    lines.add("&8" + format.format(new Date(rs.getLong("time"))) + " &f" + rs.getString("player_name")
                            + (bought ? " &akaufte " : " &6verkaufte ") + "&f" + rs.getInt("count") + "x &7für &f$"
                            + String.format(java.util.Locale.GERMANY, "%,.2f", rs.getDouble("total")));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Shop-Transaktionen laden fehlgeschlagen: " + e.getMessage());
        }
        return lines;
    }

    public Map<String, ShopRecord> allBySign() {
        return bySign;
    }
}
