package de.craftsucht.core.punish;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public class PunishCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final PunishManager manager;

    public PunishCommand(SpookyCraftCore plugin, PunishManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.punish." + label.toLowerCase()) && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cKeine Berechtigung.");
            return true;
        }
        switch (label.toLowerCase()) {
            case "punish": return handlePunish(sender, args);
            case "ban": return handleBan(sender, args, false);
            case "tempban": return handleBan(sender, args, true);
            case "unban": return handleUnban(sender, args);
            case "warn": return handleWarn(sender, args);
            case "kick": return handleKick(sender, args);
            case "mute": return handleMute(sender, args);
            case "unmute": return handleUnmute(sender, args);
            case "history": return handleHistory(sender, args);
        }
        return false;
    }

    private PunishCatalog catalog() {
        return new PunishCatalog(plugin.getConfig()); // bei jedem Aufruf frisch, damit /reload der Config greift
    }

    private void sendCatalog(CommandSender sender) {
        plugin.getMessageUtil().send(sender, "&7--- &6Strafkatalog &7---");
        for (PunishCatalog.Reason r : catalog().all()) {
            String dur;
            if (r.baseMillis() <= 0) dur = "Permanent";
            else if (r.stepMillis() > 0) dur = manager.formatDuration(r.baseMillis()) + " &8(+" + manager.formatDuration(r.stepMillis()) + " pro Wiederholung)";
            else dur = manager.formatDuration(r.baseMillis()) + " &8(x2 bis " + r.maxRepeats() + "x, dann perm.)";
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&e" + r.id() + " &8| " + (r.ban() ? "&cBan" : "&6Mute") + " &8| &f" + r.name() + " &8| &7" + dur));
        }
    }

    private boolean handlePunish(CommandSender sender, String[] args) {
        PunishCatalog catalog = catalog();
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /punish <spieler> <grund> [notiz]  |  /punish list");
            sendCatalog(sender);
            return true;
        }
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /punish <spieler> <grund> [notiz]  |  /punish list");
            return true;
        }
        PunishCatalog.Reason reason = catalog.get(args[1]);
        if (reason == null) {
            plugin.getMessageUtil().send(sender, "&cUnbekannter Grund: &7" + args[1] + " &c- siehe /punish list");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.isOnline() && !target.hasPlayedBefore()) {
            plugin.getMessageUtil().send(sender, "&cSpieler &7" + args[0] + " &cwar noch nie auf dem Server.");
            return true;
        }

        // Steigerung je Wiederholung desselben Grundes (linear "+14d" oder Verdopplung, siehe config.yml)
        int prior = manager.countReasonHistory(target.getUniqueId(), reason.name(), reason.ban());
        boolean permanent = reason.isPermanent(prior);
        long duration = permanent ? 0 : reason.durationFor(prior);
        long expiresAt = permanent ? 0 : System.currentTimeMillis() + duration;

        String note = args.length > 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "";
        String storedReason = note.isEmpty() ? reason.name() : reason.name() + " - " + note;
        String type = reason.ban() ? (permanent ? "BAN" : "TEMPBAN") : "MUTE";
        manager.addPunishment(target.getUniqueId(), type, storedReason, sender.getName(), expiresAt);

        String durationText = permanent ? "Permanent" : manager.formatDuration(duration);
        if (reason.ban()) {
            if (target.isOnline() && target.getPlayer() != null) {
                PunishManager.BanRecord ban = manager.getActiveBan(target.getUniqueId());
                target.getPlayer().kickPlayer(ban != null ? manager.buildBanScreen(ban)
                        : ChatColor.translateAlternateColorCodes('&', "&cDu wurdest gebannt: &7" + storedReason));
            }
        } else if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(),
                    "&cDu wurdest stummgeschaltet: &7" + reason.name() + " &8(Dauer: " + durationText + ")");
        }
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde " + (reason.ban() ? "gebannt" : "gemutet")
                + ": &7" + reason.name() + " &8| &f" + durationText + " &8| &7" + (prior + 1) + ". Verstoß mit diesem Grund");
        return true;
    }

    private boolean handleBan(CommandSender sender, String[] args, boolean temp) {
        int minArgs = temp ? 2 : 1;
        if (args.length < minArgs) {
            plugin.getMessageUtil().send(sender, temp ? "&cNutzung: /tempban <spieler> <dauer z.B. 1d> [grund]" : "&cNutzung: /ban <spieler> [grund]");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        long expiresAt = 0;
        int reasonStart = 1;
        if (temp) {
            expiresAt = System.currentTimeMillis() + parseDuration(args[1]);
            reasonStart = 2;
        }
        String reason = args.length > reasonStart ? String.join(" ", java.util.Arrays.copyOfRange(args, reasonStart, args.length)) : "Kein Grund angegeben";
        manager.addPunishment(target.getUniqueId(), temp ? "TEMPBAN" : "BAN", reason, sender.getName(), expiresAt);
        if (target.isOnline() && target.getPlayer() != null) {
            PunishManager.BanRecord ban = manager.getActiveBan(target.getUniqueId());
            String screen = ban != null ? manager.buildBanScreen(ban)
                    : ChatColor.translateAlternateColorCodes('&', "&cDu wurdest gebannt: &7" + reason);
            target.getPlayer().kickPlayer(screen);
        }
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde gebannt: &7" + reason);
        return true;
    }

    private boolean handleUnban(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /unban <spieler>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        manager.clearBans(target.getUniqueId(), sender.getName());
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde entbannt.");
        return true;
    }

    private boolean handleWarn(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /warn <spieler> [grund]");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Kein Grund angegeben";
        manager.addPunishment(target.getUniqueId(), "WARN", reason, sender.getName(), 0);
        if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(), "&eDu wurdest verwarnt: &7" + reason);
        }
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde verwarnt.");
        return true;
    }

    private boolean handleKick(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /kick <spieler> [grund]");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.getMessageUtil().send(sender, "&cSpieler nicht online.");
            return true;
        }
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Kein Grund angegeben";
        target.kickPlayer(ChatColor.translateAlternateColorCodes('&', "&cDu wurdest gekickt: &7" + reason));
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde gekickt.");
        return true;
    }

    private boolean handleMute(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /mute <spieler> [dauer z.B. 1h] [grund]");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        long expiresAt = 0;
        int reasonStart = 1;
        if (args.length > 1 && isDuration(args[1])) {
            expiresAt = System.currentTimeMillis() + parseDuration(args[1]);
            reasonStart = 2;
        }
        String reason = args.length > reasonStart ? String.join(" ", java.util.Arrays.copyOfRange(args, reasonStart, args.length)) : "Kein Grund angegeben";
        manager.addPunishment(target.getUniqueId(), "MUTE", reason, sender.getName(), expiresAt);
        if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(), "&cDu wurdest stummgeschaltet: &7" + reason);
        }
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde stummgeschaltet: &7" + reason);
        return true;
    }

    private boolean handleUnmute(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /unmute <spieler>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        manager.clearMutes(target.getUniqueId(), sender.getName());
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde entmutet.");
        return true;
    }

    private boolean handleHistory(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /history <spieler>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        List<PunishManager.PunishmentRecord> history = manager.getHistory(target.getUniqueId(), 10);
        if (history.isEmpty()) {
            plugin.getMessageUtil().send(sender, "&7" + target.getName() + " hat keine Einträge.");
            return true;
        }
        plugin.getMessageUtil().send(sender, "&7--- Strafhistorie von &b" + target.getName() + " &7---");
        java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
        for (PunishManager.PunishmentRecord r : history) {
            String status = r.active() ? "&aaktiv" : "&7erledigt";
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&8[" + fmt.format(new java.util.Date(r.createdAt())) + "] &e" + r.type()
                            + " &7von &b" + r.staff() + " &7(" + status + "&7): &f" + r.reason()));
        }
        return true;
    }

    /** Erkennt Kurzformen wie 10m, 1h, 7d - alles andere zählt als Freitext-Grund. */
    private boolean isDuration(String input) {
        return input.matches("\\d+[smhd]");
    }

    /** Parses simple durations like 1d, 12h, 30m, 45s. */
    private long parseDuration(String input) {
        try {
            char unit = input.charAt(input.length() - 1);
            long value = Long.parseLong(input.substring(0, input.length() - 1));
            return switch (unit) {
                case 's' -> value * 1000L;
                case 'm' -> value * 60_000L;
                case 'h' -> value * 3_600_000L;
                case 'd' -> value * 86_400_000L;
                default -> value * 60_000L;
            };
        } catch (Exception e) {
            return 60_000L * 10; // default 10 minutes if unparseable
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("punish")) {
            if (args.length == 1) {
                List<String> result = TabCompleteUtil.onlinePlayers(args[0]);
                result.addAll(TabCompleteUtil.filter(args[0], "list"));
                return result;
            }
            if (args.length == 2) return TabCompleteUtil.filter(args[1], catalog().ids());
            return Collections.emptyList();
        }
        if (args.length == 1) {
            switch (label.toLowerCase()) {
                case "ban", "warn", "unban", "mute", "unmute", "history": return TabCompleteUtil.onlinePlayers(args[0]);
                case "tempban", "kick": return TabCompleteUtil.onlinePlayers(args[0]);
            }
        }
        if (args.length == 2 && label.equalsIgnoreCase("tempban")) {
            return TabCompleteUtil.filter(args[1], "10m", "30m", "1h", "12h", "1d", "7d", "30d");
        }
        if (args.length == 2 && label.equalsIgnoreCase("mute")) {
            return TabCompleteUtil.filter(args[1], "10m", "30m", "1h", "12h", "1d", "7d", "30d");
        }
        return Collections.emptyList();
    }
}
