package de.craftsucht.core.swarp;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * /swarp - Spieler-Shop-Warps: /swarp create &lt;name&gt; setzt einen Warp an deiner Position,
 * /swarp &lt;name&gt; teleportiert dorthin. Weitere: /swarp delete &lt;name&gt;, /swarp list, /swarp mine.
 */
public class SwarpModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter {

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final List<String> SUBS = List.of("create", "delete", "list", "mine");

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public SwarpModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "swarp";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "swarps.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("swarp").setExecutor(this);
        plugin.getCommand("swarp").setTabCompleter(this);
    }

    @Override
    public void disable() {
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("swarps.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private ConfigurationSection root() {
        ConfigurationSection s = data.getConfigurationSection("swarps");
        return s != null ? s : data.createSection("swarps");
    }

    private boolean isAdmin(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin");
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur für Spieler!");
            return true;
        }
        if (args.length == 0) {
            list(p);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create", "set" -> create(p, args);
            case "delete", "del", "remove" -> delete(p, args);
            case "list" -> list(p);
            case "mine", "meine" -> mine(p);
            default -> teleport(p, args[0]);
        }
        return true;
    }

    private void create(Player p, String[] args) {
        if (args.length < 2) {
            msg(p, "&cNutzung: &e/swarp create <name>");
            return;
        }
        String name = args[1];
        if (!NAME.matcher(name).matches()) {
            msg(p, "&cDer Name darf nur Buchstaben, Zahlen und _ enthalten (max. 16 Zeichen).");
            return;
        }
        String key = name.toLowerCase(Locale.ROOT);
        if (SUBS.contains(key)) {
            msg(p, "&cDieser Name ist reserviert.");
            return;
        }
        ConfigurationSection root = root();
        if (root.isConfigurationSection(key)) {
            msg(p, "&cEinen Shop-Warp namens &e" + name + " &cgibt es schon.");
            return;
        }
        int max = plugin.getConfig().getInt("swarp.max-per-player", 3);
        if (!isAdmin(p) && countOf(p.getUniqueId().toString()) >= max) {
            msg(p, "&cDu hast schon &e" + max + " &cShop-Warps. Lösche einen mit &e/swarp delete <name>&c.");
            return;
        }
        Location l = p.getLocation();
        ConfigurationSection s = root.createSection(key);
        s.set("name", name);
        s.set("owner", p.getUniqueId().toString());
        s.set("owner-name", p.getName());
        s.set("world", l.getWorld().getName());
        s.set("x", l.getX());
        s.set("y", l.getY());
        s.set("z", l.getZ());
        s.set("yaw", (double) l.getYaw());
        s.set("pitch", (double) l.getPitch());
        save();
        msg(p, "&aShop-Warp &e" + name + " &aerstellt. Andere kommen mit &e/swarp " + name + " &ahierher.");
    }

    private void delete(Player p, String[] args) {
        if (args.length < 2) {
            msg(p, "&cNutzung: &e/swarp delete <name>");
            return;
        }
        String key = args[1].toLowerCase(Locale.ROOT);
        ConfigurationSection s = root().getConfigurationSection(key);
        if (s == null) {
            msg(p, "&cDen Shop-Warp gibt es nicht.");
            return;
        }
        if (!s.getString("owner", "").equals(p.getUniqueId().toString()) && !isAdmin(p)) {
            msg(p, "&cDas ist nicht dein Shop-Warp.");
            return;
        }
        root().set(key, null);
        save();
        msg(p, "&aShop-Warp gelöscht.");
    }

    private void teleport(Player p, String name) {
        ConfigurationSection s = root().getConfigurationSection(name.toLowerCase(Locale.ROOT));
        if (s == null) {
            msg(p, "&cDen Shop-Warp &e" + name + " &cgibt es nicht. Alle: &e/swarp list");
            return;
        }
        World w = Bukkit.getWorld(s.getString("world", ""));
        if (w == null) {
            msg(p, "&cDie Welt dieses Warps ist nicht geladen.");
            return;
        }
        Location l = new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
        p.teleport(l);
        msg(p, "&aTeleportiert zu &e" + s.getString("name", name) + " &7(von " + s.getString("owner-name", "?") + ")");
    }

    private void mine(Player p) {
        String id = p.getUniqueId().toString();
        List<String> names = new ArrayList<>();
        for (String k : root().getKeys(false)) {
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s != null && id.equals(s.getString("owner"))) names.add(s.getString("name", k));
        }
        if (names.isEmpty()) {
            msg(p, "&7Du hast noch keinen Shop-Warp. Erstelle einen mit &e/swarp create <name>");
            return;
        }
        msg(p, "&7Deine Shop-Warps: &e" + String.join("&7, &e", names));
    }

    private int countOf(String ownerId) {
        int n = 0;
        for (String k : root().getKeys(false)) {
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s != null && ownerId.equals(s.getString("owner"))) n++;
        }
        return n;
    }

    private void list(Player p) {
        List<ConfigurationSection> all = new ArrayList<>();
        for (String k : root().getKeys(false)) {
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s != null) all.add(s);
        }
        if (all.isEmpty()) {
            msg(p, "&7Es gibt noch keine Shop-Warps. Erstelle einen mit &e/swarp create <name>");
            return;
        }
        all.sort(Comparator.comparing(s -> s.getString("name", "").toLowerCase(Locale.ROOT)));
        p.sendMessage(Component.text("--- Shop-Warps (klicken zum Teleportieren) ---", NamedTextColor.GOLD));
        int shown = 0;
        for (ConfigurationSection s : all) {
            if (shown++ >= 40) {
                p.sendMessage(Component.text("... und weitere. Nutze /swarp <name>", NamedTextColor.GRAY));
                break;
            }
            String name = s.getString("name", "?");
            p.sendMessage(Component.text("» ", NamedTextColor.DARK_GRAY)
                    .append(Component.text(name, NamedTextColor.YELLOW))
                    .append(Component.text(" von " + s.getString("owner-name", "?"), NamedTextColor.GRAY))
                    .clickEvent(ClickEvent.runCommand("/swarp " + name))
                    .hoverEvent(HoverEvent.showText(Component.text("Klick: /swarp " + name, NamedTextColor.GREEN))));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String pre = args[0].toLowerCase(Locale.ROOT);
            for (String sub : SUBS) if (sub.startsWith(pre)) out.add(sub);
            for (String k : root().getKeys(false)) {
                ConfigurationSection s = root().getConfigurationSection(k);
                String n = s != null ? s.getString("name", k) : k;
                if (n.toLowerCase(Locale.ROOT).startsWith(pre)) out.add(n);
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("del"))) {
            String pre = args[1].toLowerCase(Locale.ROOT);
            for (String k : root().getKeys(false)) {
                ConfigurationSection s = root().getConfigurationSection(k);
                if (s == null) continue;
                boolean own = sender instanceof Player pl && pl.getUniqueId().toString().equals(s.getString("owner"));
                if ((own || isAdmin(sender)) && k.startsWith(pre)) out.add(s.getString("name", k));
            }
        }
        return out;
    }
}
