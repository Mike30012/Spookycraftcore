package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * God's Picke: Rechtsklick auf die Hacke im Inventar (oder Sneaken + Rechtsklick in der Hand) wechselt den
 * Abbau-Modus 1x1 -> 2x2 -> 3x3 -> 4x4 -> 5x5 -> 1x1. Der Abbau selbst macht der AreaMiningListener (PDC "area_size").
 */
public class GodPickeListener implements Listener {

    private static final int MAX = 5;
    private final SpookyCraftCore plugin;

    public GodPickeListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    private boolean isGod(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        String s = item.getItemMeta().getPersistentDataContainer()
                .get(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING);
        return "gods_picke".equals(s);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getClick() != ClickType.RIGHT) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack cur = e.getCurrentItem();
        if (!isGod(cur)) return;
        ItemStack cursor = e.getCursor();
        if (cursor != null && !cursor.getType().isAir()) return;     // Item in der Hand -> normales Verhalten
        e.setCancelled(true);
        switchMode(p, cur);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!p.isSneaking()) return;
        ItemStack item = p.getInventory().getItemInMainHand();
        if (!isGod(item)) return;
        e.setCancelled(true);
        switchMode(p, item);
    }

    private void switchMode(Player p, ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        Integer now = meta.getPersistentDataContainer().get(de.craftsucht.core.booster.AreaMiningListener.keyArea(plugin), PersistentDataType.INTEGER);
        int size = (now == null || now < 1) ? 1 : now;
        size = size % MAX + 1;
        meta.getPersistentDataContainer().set(AreaMiningListener.keyArea(plugin), PersistentDataType.INTEGER, size);
        List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        String line = ChatColor.translateAlternateColorCodes('&', "&8↳ &7Modus: &e" + size + "x" + size);
        boolean replaced = false;
        for (int i = 0; i < lore.size(); i++) {
            if (ChatColor.stripColor(lore.get(i)).contains("Modus:")) {
                lore.set(i, line);
                replaced = true;
                break;
            }
        }
        if (!replaced) lore.add(line);
        meta.setLore(lore);
        item.setItemMeta(meta);
        p.playSound(p.getLocation(), "ui.button.click", 0.8f, 1.0f + size * 0.12f);
        plugin.getMessageUtil().send(p, "&6God's Picke &7Modus: &e" + size + "x" + size);
    }
}
