package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import io.papermc.paper.event.player.PlayerArmorChangeEvent;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Verhalten der Spezial-Items aus ItemRegistry (früher Skripte): Flug-Schuhe, Speed-Schuhe, Mining-Pistole,
 * Erz-Wandler, Bedrock-Brecher, Ban-Hammer und die Bedrock-Rüstung (Rezepte + Resistenz).
 * Items per /citem give <spieler> <id>. Einstellungen: "special-items:" in der config.yml.
 */
public class SpecialItemsListener implements Listener {

    public static NamespacedKey keySpecial(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "special_item");
    }

    private static final Set<String> PROTECTED = Set.of(
            "SPAWNER", "TRIAL_SPAWNER", "VAULT", "ENDER_CHEST", "BEACON", "FURNACE", "BLAST_FURNACE", "SMOKER", "HOPPER",
            "DISPENSER", "DROPPER", "CHEST", "TRAPPED_CHEST", "BARREL", "BREWING_STAND", "ENCHANTING_TABLE", "LECTERN",
            "JUKEBOX", "CRAFTER", "END_PORTAL_FRAME", "END_PORTAL", "NETHER_PORTAL", "REINFORCED_DEEPSLATE");

    private static final Set<String> BEDROCK_ARMOR = Set.of("bedrock_helm", "bedrock_chest", "bedrock_legs", "bedrock_boots");
    private static final Material[] ORES = {Material.DIAMOND_BLOCK, Material.COAL_BLOCK, Material.GOLD_BLOCK,
            Material.NETHERITE_BLOCK, Material.EMERALD_BLOCK, Material.COPPER_BLOCK, Material.IRON_BLOCK};
    private static final int[] PISTOL_RADII = {3, 5, 7};
    private static final long RESISTANCE_PERIOD_TICKS = 12000L; // 10 Minuten
    private static final int RESISTANCE_DURATION_TICKS = 600 * 20;

    private final SpookyCraftCore plugin;
    private final ItemRegistry registry;
    private final NamespacedKey key;
    private final Random random = new Random();
    private final Set<UUID> flyers = new HashSet<>();
    private final Set<UUID> speeders = new HashSet<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final List<NamespacedKey> recipeKeys = new ArrayList<>();
    private BukkitTask resistanceTask;

    public SpecialItemsListener(SpookyCraftCore plugin, ItemRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
        this.key = keySpecial(plugin);
    }

    // ------------------------------------------------------------------ Start / Stop

    public void start() {
        registerRecipes();
        resistanceTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (wearsBedrockArmor(p)) giveResistance(p);
            }
        }, RESISTANCE_PERIOD_TICKS, RESISTANCE_PERIOD_TICKS);
        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
    }

    public void stop() {
        if (resistanceTask != null) resistanceTask.cancel();
        for (NamespacedKey k : recipeKeys) Bukkit.removeRecipe(k);
        recipeKeys.clear();
        for (UUID id : new ArrayList<>(speeders)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.removePotionEffect(PotionEffectType.SPEED);
        }
        for (UUID id : new ArrayList<>(flyers)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE)) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
        }
        speeders.clear();
        flyers.clear();
    }

    private void registerRecipes() {
        addRecipe("bedrock_schwert", "B", "B", "S");
        addRecipe("bedrock_helm", "BBB", "B B");
        addRecipe("bedrock_brustplatte", "B B", "BBB", "BBB");
        addRecipe("bedrock_beinschutz", "BBB", "B B", "B B");
        addRecipe("bedrock_stiefel", "B B", "B B");
    }

    private void addRecipe(String id, String... shape) {
        ItemTemplate template = registry.getTemplate(id);
        if (template == null) return;
        NamespacedKey recipeKey = new NamespacedKey(plugin, "craft_" + id);
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, registry.build(template));
        recipe.shape(shape);
        recipe.setIngredient('B', Material.BEDROCK);
        if (id.equals("bedrock_schwert")) recipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(recipe);
        recipeKeys.add(recipeKey);
    }

    // ------------------------------------------------------------------ Hilfen

    private String special(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    private boolean onCooldown(Player p) {
        long seconds = Math.max(0, plugin.getConfig().getInt("special-items.cooldown-seconds", 1));
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(p.getUniqueId());
        if (last != null && now - last < seconds * 1000L) return true;
        cooldowns.put(p.getUniqueId(), now);
        return false;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    private boolean breakable(Block block) {
        Material type = block.getType();
        if (type.isAir() || block.isLiquid()) return false;
        if (type.getHardness() < 0) return false; // Bedrock & Co.
        String name = type.name();
        return !PROTECTED.contains(name) && !name.endsWith("_SHULKER_BOX");
    }

    private List<Block> sphere(Block center, int radius) {
        List<Block> blocks = new ArrayList<>();
        int r2 = radius * radius;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x * x + y * y + z * z <= r2) blocks.add(center.getRelative(x, y, z));
                }
            }
        }
        return blocks;
    }

    /** Fragt Schutz-Plugins (Grundstücke etc.) per BlockBreakEvent; true = erlaubt. */
    private boolean allowed(Player player, Block block) {
        BlockBreakEvent event = new BlockBreakEvent(block, player);
        AreaMiningListener.setExtraBreak(true);
        try {
            Bukkit.getPluginManager().callEvent(event);
        } finally {
            AreaMiningListener.setExtraBreak(false);
        }
        return !event.isCancelled();
    }

    // ------------------------------------------------------------------ Flug-Schuhe / Speed-Schuhe / Bedrock-Rüstung

    @EventHandler
    public void onArmorChange(PlayerArmorChangeEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            if (event.getSlotType() == PlayerArmorChangeEvent.SlotType.FEET) {
                updateFlight(p);
                updateSpeed(p);
            }
            if (wearsBedrockArmor(p) && !p.hasPotionEffect(PotionEffectType.RESISTANCE)) giveResistance(p);
        });
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) refresh(p);
        }, 5L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) refresh(p);
        }, 5L);
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) updateFlight(p);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        flyers.remove(id);
        speeders.remove(id);
        cooldowns.remove(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        flyers.remove(event.getEntity().getUniqueId());
        speeders.remove(event.getEntity().getUniqueId());
    }

    private void refresh(Player p) {
        updateFlight(p);
        updateSpeed(p);
        if (wearsBedrockArmor(p) && !p.hasPotionEffect(PotionEffectType.RESISTANCE)) giveResistance(p);
    }

    private void updateFlight(Player p) {
        boolean wears = "flugschuhe".equals(special(p.getInventory().getBoots()));
        GameMode gm = p.getGameMode();
        boolean survivalLike = gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE;
        if (wears && survivalLike) {
            if (flyers.add(p.getUniqueId())) {
                p.setAllowFlight(true);
                if (!p.isOnGround()) p.setFlying(true);
                msg(p, "&b[Flugschuhe] &eFlugmodus aktiviert!");
            }
        } else if (flyers.remove(p.getUniqueId())) {
            if (survivalLike) {
                p.setFlying(false);
                p.setAllowFlight(false);
                msg(p, "&b[Flugschuhe] &cFlugmodus deaktiviert!");
            }
        }
    }

    private void updateSpeed(Player p) {
        boolean wears = "speedschuhe".equals(special(p.getInventory().getBoots()));
        if (wears) {
            speeders.add(p.getUniqueId());
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 10, false, false, false));
        } else {
            boolean ours = speeders.remove(p.getUniqueId());
            PotionEffect effect = p.getPotionEffect(PotionEffectType.SPEED);
            // auch Reste vom alten Skript (Speed 11, sehr lang) entfernen
            boolean leftover = effect != null && effect.getAmplifier() == 10 && (effect.isInfinite() || effect.getDuration() > 20 * 3600);
            if (ours || leftover) p.removePotionEffect(PotionEffectType.SPEED);
        }
    }

    private boolean wearsBedrockArmor(Player p) {
        for (ItemStack piece : p.getInventory().getArmorContents()) {
            String s = special(piece);
            if (s != null && BEDROCK_ARMOR.contains(s)) return true;
        }
        return false;
    }

    private void giveResistance(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, RESISTANCE_DURATION_TICKS, 0, false, false, true));
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(event.getEntity() instanceof Player p)) return;
        if ("flugschuhe".equals(special(p.getInventory().getBoots()))) event.setCancelled(true);
    }

    // ------------------------------------------------------------------ Mining-Pistole / Erz-Wandler / Bedrock-Brecher

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        ItemStack item = event.getItem();
        String special = special(item);
        if (special == null) return;
        Player player = event.getPlayer();
        Action action = event.getAction();

        switch (special) {
            case "mining_pistole" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                if (onCooldown(player)) return;
                Block target = player.getTargetBlockExact(64);
                if (target == null || !breakable(target)) return;
                player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 2.0f);
                int radius = PISTOL_RADII[random.nextInt(PISTOL_RADII.length)];
                startPistole(player, item, target, radius);
            }
            case "erz_wandler" -> {
                if (action != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
                event.setCancelled(true);
                if (onCooldown(player)) return;
                convertOres(player, event.getClickedBlock());
            }
            case "bedrock_brecher" -> {
                if (action != Action.LEFT_CLICK_BLOCK && action != Action.RIGHT_CLICK_BLOCK) return;
                Block block = event.getClickedBlock();
                if (block == null || block.getType() != Material.BEDROCK) return;
                event.setCancelled(true);
                if (!allowed(player, block)) return;
                Location loc = block.getLocation().add(0.5, 0.5, 0.5);
                block.setType(Material.AIR);
                block.getWorld().dropItemNaturally(loc, new ItemStack(Material.BEDROCK));
                block.getWorld().playSound(loc, Sound.BLOCK_STONE_BREAK, 1.0f, 1.0f);
            }
            default -> { }
        }
    }

    /** Baut die Kugel in Stücken pro Tick ab (verhindert einen Lag-Spike bei Radius 7 = ~1400 Blöcke). */
    private void startPistole(Player player, ItemStack tool, Block center, int radius) {
        List<Block> blocks = new ArrayList<>();
        for (Block b : sphere(center, radius)) if (breakable(b)) blocks.add(b);
        if (blocks.isEmpty()) return;
        Location origin = center.getLocation();
        blocks.sort(Comparator.comparingDouble(b -> b.getLocation().distanceSquared(origin)));

        final int perTick = Math.max(20, plugin.getConfig().getInt("special-items.pistol-blocks-per-tick", 200));
        final boolean toInventory = plugin.getConfig().getBoolean("special-items.pistol-drops-to-inventory", true);
        final ItemStack toolCopy = tool.clone();

        new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                int done = 0;
                int end = Math.min(blocks.size(), index + perTick);
                for (; index < end; index++) {
                    Block block = blocks.get(index);
                    if (!breakable(block)) continue;
                    BlockBreakEvent event = new BlockBreakEvent(block, player);
                    AreaMiningListener.setExtraBreak(true);
                    try {
                        Bukkit.getPluginManager().callEvent(event);
                    } finally {
                        AreaMiningListener.setExtraBreak(false);
                    }
                    if (event.isCancelled()) continue;
                    done++;
                    if (event.isDropItems() && toInventory) {
                        Collection<ItemStack> drops = block.getDrops(toolCopy, player);
                        block.setType(Material.AIR);
                        for (ItemStack drop : drops) {
                            for (ItemStack left : player.getInventory().addItem(drop).values()) {
                                block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), left);
                            }
                        }
                    } else if (event.isDropItems()) {
                        block.breakNaturally(toolCopy);
                    } else {
                        block.setType(Material.AIR);
                    }
                }
                if (index >= blocks.size()) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void convertOres(Player player, Block center) {
        for (Block block : sphere(center, 3)) {
            if (!breakable(block)) continue;
            if (!allowed(player, block)) continue;
            block.setType(ORES[random.nextInt(ORES.length)]);
        }
        player.getWorld().playSound(center.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.0f);
    }

    // ------------------------------------------------------------------ Ban-Hammer

    @EventHandler
    public void onHammer(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker) || !(event.getEntity() instanceof Player victim)) return;
        if (!"banhammer".equals(special(attacker.getInventory().getItemInMainHand()))) return;
        event.setCancelled(true);
        if (!attacker.isOp() && !attacker.hasPermission("craftsucht.core.admin") && !attacker.hasPermission("craftsucht.punish.ban")) {
            msg(attacker, "&cDu darfst den Ban-Hammer nicht benutzen.");
            return;
        }
        if (victim.isOp()) {
            msg(attacker, "&cOperatoren kannst du nicht mit dem Ban-Hammer bannen.");
            return;
        }
        final String name = victim.getName();
        victim.getWorld().strikeLightningEffect(victim.getLocation());
        Bukkit.getScheduler().runTaskLater(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + name + " Du wurdest vom Ban-Hammer getroffen!"), 1L);
        msg(attacker, "&c&l[Ban-Hammer] &e" + name + " &cwurde permanent verbannt!");
    }
}
