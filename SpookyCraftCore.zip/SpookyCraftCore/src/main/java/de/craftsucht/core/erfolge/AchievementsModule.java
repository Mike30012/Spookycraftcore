package de.craftsucht.core.erfolge;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.jobs.PlayerData;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.prestige.PrestigeModule;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /erfolge - Aufgaben mit Belohnung (Geld und Kristalle). Wird alle erfolge.check-seconds geprueft und automatisch
 * vergeben. Typen: blocks (abgebaute Bloecke), kills, playtime_hours, balance, job_max (Jobs auf Maximal-Level), prestige.
 * Eigene Liste in der config.yml unter erfolge.list, sonst gilt die eingebaute.
 */
public class AchievementsModule implements Module, CommandExecutor, Listener {

    private record Def(String id, String name, String desc, String type, long value, long money, long crystals, boolean broadcast) {
    }

    private static final class AchHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static AchievementsModule INSTANCE;

    public static boolean isDone(UUID id, String ach) {
        AchievementsModule m = INSTANCE;
        return m != null && m.data.getStringList("done." + id).contains(ach);
    }

    public static String nameOf(String ach) {
        AchievementsModule m = INSTANCE;
        if (m == null) return ach;
        for (Def d : m.defs()) if (d.id.equals(ach)) return d.name;
        return ach;
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private BukkitTask task;

    public AchievementsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "erfolge";
    }

    @Override
    public void enable() {
        INSTANCE = this;
        file = new File(plugin.getDataFolder(), "achievements.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("erfolge").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        long period = Math.max(10, plugin.getConfig().getLong("erfolge.check-seconds", 60)) * 20L;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::check, 400L, period);
    }

    @Override
    public void disable() {
        INSTANCE = null;
        if (task != null) task.cancel();
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("achievements.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Definitionen

    private List<Def> defs() {
        List<Def> out = new ArrayList<>();
        List<Map<?, ?>> cfg = plugin.getConfig().getMapList("erfolge.list");
        if (!cfg.isEmpty()) {
            for (Map<?, ?> m : cfg) {
                try {
                    out.add(new Def(String.valueOf(m.get("id")), String.valueOf(m.get("name")),
                            m.get("desc") == null ? "" : String.valueOf(m.get("desc")), String.valueOf(m.get("type")),
                            Long.parseLong(String.valueOf(m.get("value"))), num(m.get("money")), num(m.get("crystals")),
                            Boolean.parseBoolean(String.valueOf(m.get("broadcast")))));
                } catch (NumberFormatException ignored) {
                    // kaputter Eintrag
                }
            }
            return out;
        }
        out.add(new Def("blocks_1000", "&aErste Schritte", "1.000 Blöcke abbauen", "blocks", 1000, 1000, 0, false));
        out.add(new Def("blocks_10000", "&6Minenarbeiter", "10.000 Blöcke abbauen", "blocks", 10000, 10000, 0, false));
        out.add(new Def("blocks_100000", "&8Grabegeist", "100.000 Blöcke abbauen", "blocks", 100000, 100000, 5, true));
        out.add(new Def("kills_100", "&5Geisterjäger", "100 Kills", "kills", 100, 5000, 0, false));
        out.add(new Def("kills_1000", "&dSeelenjäger", "1.000 Kills", "kills", 1000, 50000, 5, true));
        out.add(new Def("playtime_10", "&aStammgast", "10 Stunden spielen", "playtime_hours", 10, 5000, 0, false));
        out.add(new Def("playtime_50", "&bVeteran", "50 Stunden spielen", "playtime_hours", 50, 25000, 3, false));
        out.add(new Def("playtime_200", "&3Urgestein", "200 Stunden spielen", "playtime_hours", 200, 100000, 10, true));
        out.add(new Def("money_100k", "&eWohlhabend", "100.000$ besitzen", "balance", 100000, 5000, 0, false));
        out.add(new Def("money_1m", "&6Millionär", "1.000.000$ besitzen", "balance", 1000000, 0, 5, true));
        out.add(new Def("job_max", "&aFachmann", "Einen Job auf Maximal-Level bringen", "job_max", 1, 20000, 3, false));
        out.add(new Def("prestige_1", "&dWiedergeboren", "Ein Prestige abschließen", "prestige", 1, 50000, 10, true));
        return out;
    }

    private static long num(Object o) {
        try {
            return o == null ? 0 : Long.parseLong(String.valueOf(o));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ Werte

    private Map<String, Long> dbStats(UUID id) {
        Map<String, Long> out = new HashMap<>();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT blocks_broken, kills FROM stats WHERE uuid=?")) {
            ps.setString(1, id.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    out.put("blocks", rs.getLong(1));
                    out.put("kills", rs.getLong(2));
                }
            }
        } catch (SQLException ignored) {
            // keine Zahlen = 0
        }
        return out;
    }

    private long playHours(Player p) {
        for (String n : new String[]{"PLAY_ONE_MINUTE", "PLAY_TIME"}) {
            try {
                return p.getStatistic(Statistic.valueOf(n)) / 20L / 3600L;
            } catch (IllegalArgumentException ignored) {
                // Name gibt es in dieser Version nicht
            } catch (RuntimeException ignored) {
                // nicht lesbar
            }
        }
        return 0;
    }

    private long value(Player p, Def d, Map<String, Long> st) {
        switch (d.type) {
            case "blocks":
                return st.getOrDefault("blocks", 0L);
            case "kills":
                return st.getOrDefault("kills", 0L);
            case "playtime_hours":
                return playHours(p);
            case "balance": {
                EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
                return eco == null ? 0 : (long) eco.getBalance(p.getUniqueId());
            }
            case "job_max": {
                if (!(plugin.getModuleManager().get("jobs") instanceof JobsModule jm)) return 0;
                PlayerData pd = jm.getPlayerDataManager().get(p.getUniqueId());
                long n = 0;
                for (String job : jm.getJobManager().getAvailableJobs()) {
                    var jd = pd.getJob(job);
                    if (jd != null && jd.getLevel() >= jm.getJobManager().getMaxLevelForJob(job)) n++;
                }
                return n;
            }
            case "prestige":
                return PrestigeModule.total(p.getUniqueId());
            default:
                return 0;
        }
    }

    // ------------------------------------------------------------------ Pruefen und vergeben

    private void check() {
        final List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        if (players.isEmpty()) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<UUID, Map<String, Long>> all = new HashMap<>();
            for (Player p : players) all.put(p.getUniqueId(), dbStats(p.getUniqueId()));
            Bukkit.getScheduler().runTask(plugin, () -> {
                List<Def> defs = defs();
                for (Player p : players) {
                    if (!p.isOnline()) continue;
                    Map<String, Long> st = all.getOrDefault(p.getUniqueId(), Map.of());
                    for (Def d : defs) {
                        if (isDone(p.getUniqueId(), d.id)) continue;
                        if (value(p, d, st) >= d.value) award(p, d);
                    }
                }
            });
        });
    }

    private void award(Player p, Def d) {
        List<String> done = new ArrayList<>(data.getStringList("done." + p.getUniqueId()));
        if (done.contains(d.id)) return;
        done.add(d.id);
        data.set("done." + p.getUniqueId(), done);
        save();
        if (d.money > 0 && plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
            em.getManager().deposit(p.getUniqueId(), d.money);
        }
        if (d.crystals > 0 && plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
            cm.getCrystals().add(p.getUniqueId(), d.crystals);
        }
        String reward = (d.money > 0 ? GuiUtil.money(d.money) : "") + (d.money > 0 && d.crystals > 0 ? " + " : "")
                + (d.crystals > 0 ? d.crystals + " Kristalle" : "");
        plugin.getMessageUtil().send(p, "&6☠ Erfolg freigeschaltet: " + d.name + (reward.isEmpty() ? "" : " &7(&f" + reward + "&7)"));
        p.playSound(p.getLocation(), "ui.toast.challenge_complete", 1f, 1f);
        if (d.broadcast) {
            Bukkit.broadcastMessage(GuiUtil.c("&8[&6☠&8] &f" + p.getName() + " &7hat den Erfolg " + d.name + " &7geschafft!"));
        }
    }

    // ------------------------------------------------------------------ Menue

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        List<Def> defs = defs();
        Map<String, Long> st = dbStats(p.getUniqueId());
        int rows = Math.max(2, Math.min(6, (defs.size() + 8) / 9 + 1));
        Inventory inv = Bukkit.createInventory(new AchHolder(), rows * 9, GuiUtil.c("&6&l☠ &eErfolge"));
        ItemStack pane = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        int doneCount = 0;
        for (int i = 0; i < defs.size() && i < inv.getSize() - 9; i++) {
            Def d = defs.get(i);
            boolean done = isDone(p.getUniqueId(), d.id);
            if (done) doneCount++;
            List<String> lore = new ArrayList<>();
            lore.add("&7" + d.desc);
            long have = Math.min(value(p, d, st), d.value);
            lore.add(done ? "&a✔ geschafft" : "&7Fortschritt: &f" + have + "&8/&f" + d.value);
            String r = (d.money > 0 ? GuiUtil.money(d.money) : "") + (d.money > 0 && d.crystals > 0 ? " + " : "")
                    + (d.crystals > 0 ? d.crystals + " Kristalle" : "");
            if (!r.isEmpty()) lore.add("&7Belohnung: &e" + r);
            ItemStack it = GuiUtil.item(done ? Material.EMERALD : Material.GRAY_DYE, d.name, lore);
            inv.setItem(i, done ? GuiUtil.glow(it) : it);
        }
        inv.setItem(inv.getSize() - 5, GuiUtil.item(Material.BOOK, "&e" + doneCount + " &7von &e" + defs.size() + " &7geschafft"));
        p.openInventory(inv);
        return true;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof AchHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof AchHolder) e.setCancelled(true);
    }
}
