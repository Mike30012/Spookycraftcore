package de.craftsucht.core.backup;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.StaffCheck;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Backups direkt im Spiel: /cbackup [Name] erstellt ein Backup (Welten + Plugin-Daten) als Zip, /lbackup zeigt die Liste
 * und spielt ein Backup zurueck. Einzelne Nebenwelten werden live neu geladen, Hauptwelt und Plugin-Daten werden beim
 * naechsten Serverstart ersetzt (das Plugin macht das ganz am Anfang, bevor die Welten laden).
 * Backups liegen in plugins/SpookyCraftCore/backups/, automatisch gesichert wird alle backup.auto-hours Stunden.
 */
public class BackupModule implements Module, CommandExecutor, TabCompleter {

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    private static final DateTimeFormatter SHOW = DateTimeFormatter.ofPattern("dd.MM. HH:mm");

    private final SpookyCraftCore plugin;
    private File dir;
    private BukkitTask autoTask;
    private volatile boolean busy;
    private final Map<String, Object[]> confirm = new HashMap<>();   // Absender -> {Befehlstext, Ablaufzeit}

    public BackupModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "backup";
    }

    @Override
    public void enable() {
        dir = backupDir(plugin.getDataFolder());
        dir.mkdirs();
        plugin.getCommand("cbackup").setExecutor(this);
        plugin.getCommand("lbackup").setExecutor(this);
        plugin.getCommand("lbackup").setTabCompleter(this);
        double hours = plugin.getConfig().getDouble("backup.auto-hours", 24);
        if (hours > 0) {
            long ticks = (long) (hours * 3600 * 20);
            autoTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> create(Bukkit.getConsoleSender(), "auto", true), ticks, ticks);
        }
    }

    @Override
    public void disable() {
        if (autoTask != null) autoTask.cancel();
    }

    private static File backupDir(File pluginData) {
        return new File(pluginData, "backups");
    }

    private boolean allowed(CommandSender s) {
        return s.isOp() || !(s instanceof Player) || StaffCheck.isStaff(plugin, s) || s.hasPermission("spookycraft.backup.admin");
    }

    // ------------------------------------------------------------------ Wiederherstellen beim Start (aus onLoad aufgerufen)

    /** Spielt ein vorgemerktes Backup ein. Muss VOR dem Laden der Welten laufen (SpookyCraftCore.onLoad). */
    public static void applyPending(File pluginData, Logger log) {
        File bdir = backupDir(pluginData);
        File pending = new File(bdir, "pending.properties");
        if (!pending.exists()) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(pending.toPath())) {
            props.load(in);
        } catch (IOException e) {
            log.severe("Backup: pending.properties nicht lesbar: " + e.getMessage());
            return;
        }
        String file = props.getProperty("file", "");
        String mode = props.getProperty("mode", "worlds");
        File zip = new File(bdir, file);
        pending.delete();   // nie in eine Dauerschleife geraten
        if (!zip.isFile() || file.contains("/") || file.contains("\\")) {
            log.severe("Backup: Datei zum Wiederherstellen nicht gefunden: " + file);
            return;
        }
        File container = Bukkit.getWorldContainer();
        log.info("Backup: stelle " + file + " wieder her (" + mode + ") ...");
        try (ZipFile zf = new ZipFile(zip)) {
            Set<String> folders = new LinkedHashSet<>();
            zf.stream().forEach(e -> {
                String n = e.getName();
                if (n.startsWith("worlds/")) {
                    String rest = n.substring(7);
                    int slash = rest.indexOf('/');
                    if (slash > 0) folders.add(rest.substring(0, slash));
                }
            });
            if (mode.equals("worlds") || mode.equals("all")) {
                for (String f : folders) {
                    deleteTree(new File(container, f).toPath());
                    extract(zf, "worlds/" + f + "/", new File(container, f).toPath());
                }
            }
            if (mode.equals("data") || mode.equals("all")) {
                extract(zf, "data/", pluginData.toPath());
            }
            log.info("Backup: fertig wiederhergestellt.");
        } catch (IOException | RuntimeException e) {
            log.severe("Backup: Wiederherstellen fehlgeschlagen: " + e);
        }
    }

    private static void extract(ZipFile zf, String prefix, Path dest) throws IOException {
        Path root = dest.toAbsolutePath().normalize();
        var en = zf.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            if (e.isDirectory() || !e.getName().startsWith(prefix)) continue;
            Path out = root.resolve(e.getName().substring(prefix.length())).normalize();
            if (!out.startsWith(root)) continue;   // Zip-Slip-Schutz
            Files.createDirectories(out.getParent());
            try (InputStream in = zf.getInputStream(e)) {
                Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    private static void deleteTree(Path p) throws IOException {
        if (!Files.exists(p)) return;
        try (Stream<Path> w = Files.walk(p)) {
            for (Path x : (Iterable<Path>) w.sorted(Comparator.reverseOrder())::iterator) Files.deleteIfExists(x);
        }
    }

    // ------------------------------------------------------------------ Backup erstellen

    private List<World> worldsToSave() {
        List<String> names = plugin.getConfig().getStringList("backup.worlds");
        List<World> out = new ArrayList<>();
        for (World w : Bukkit.getWorlds()) {
            if (names.isEmpty() || names.contains(w.getName())) out.add(w);
        }
        return out;
    }

    private void create(CommandSender who, String label, boolean silent) {
        create(who, label, silent, null);
    }

    private void create(CommandSender who, String label, boolean silent, Runnable done) {
        if (busy) {
            plugin.getMessageUtil().send(who, "&cEin Backup läuft schon. Bitte kurz warten.");
            return;
        }
        busy = true;
        final String name = "backup-" + LocalDateTime.now().format(STAMP)
                + (label == null || label.isBlank() ? "" : "_" + label.replaceAll("[^A-Za-z0-9äöüÄÖÜß_-]", "").toLowerCase(Locale.ROOT)) + ".zip";
        final boolean withData = plugin.getConfig().getBoolean("backup.include-plugin-data", true);
        final List<World> worlds = worldsToSave();
        final Map<World, Boolean> autosave = new HashMap<>();
        final List<Object[]> folders = new ArrayList<>();   // {Ordner, Name}
        for (World w : worlds) {
            autosave.put(w, w.isAutoSave());
            w.save();
            w.setAutoSave(false);
            folders.add(new Object[]{w.getWorldFolder(), w.getWorldFolder().getName()});
        }
        if (!silent) plugin.getMessageUtil().send(who, "&7Die Geister sichern die Welt … (Backup &f" + name + "&7)");
        else plugin.getLogger().info("Auto-Backup startet: " + name);
        final File data = plugin.getDataFolder();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            File target = new File(dir, name);
            String error = null;
            int skipped = 0;
            try {
                if (withData) {
                    try (var c = plugin.getDatabase().getConnection(); var st = c.createStatement()) {
                        st.execute("PRAGMA wal_checkpoint(TRUNCATE)");
                    } catch (Exception ignored) {
                        // Backup trotzdem machen
                    }
                }
                try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(target.toPath()))) {
                    zos.setLevel(plugin.getConfig().getInt("backup.compression", 5));
                    for (Object[] f : folders) {
                        skipped += addDir(zos, ((File) f[0]).toPath(), "worlds/" + f[1] + "/", false);
                    }
                    if (withData) skipped += addDir(zos, data.toPath(), "data/", true);
                }
            } catch (IOException | RuntimeException e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
                target.delete();
            }
            final String err = error;
            final int skip = skipped;
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (World w : worlds) w.setAutoSave(autosave.getOrDefault(w, true));
                busy = false;
                if (err != null) {
                    plugin.getMessageUtil().send(who, "&cBackup fehlgeschlagen: &f" + err + " &7(Speicherplatz voll?)");
                    plugin.getLogger().severe("Backup fehlgeschlagen: " + err);
                } else {
                    String text = "Backup fertig: " + name + " (" + mb(target.length()) + ")" + (skip > 0 ? ", " + skip + " Dateien übersprungen" : "");
                    if (silent) plugin.getLogger().info(text);
                    else plugin.getMessageUtil().send(who, "&a" + text);
                    prune();
                }
                if (done != null) done.run();
            });
        });
    }

    /** Fuegt einen Ordner dem Zip hinzu. Gibt die Zahl der uebersprungenen (gesperrten) Dateien zurueck. */
    private int addDir(ZipOutputStream zos, Path root, String prefix, boolean isData) throws IOException {
        int skipped = 0;
        List<String> excl = plugin.getConfig().getStringList("backup.exclude");
        try (Stream<Path> walk = Files.walk(root)) {
            for (Path p : (Iterable<Path>) walk.filter(Files::isRegularFile)::iterator) {
                String rel = root.relativize(p).toString().replace('\\', '/');
                String fn = p.getFileName().toString();
                if (fn.equals("session.lock")) continue;
                if (isData && (rel.startsWith("backups/") || excl.contains(fn))) continue;
                try {
                    zos.putNextEntry(new ZipEntry(prefix + rel));
                    Files.copy(p, (OutputStream) zos);
                    zos.closeEntry();
                } catch (IOException e) {
                    skipped++;
                    try {
                        zos.closeEntry();
                    } catch (IOException ignored) {
                        // Eintrag war nie offen
                    }
                }
            }
        }
        return skipped;
    }

    private void prune() {
        File[] files = dir.listFiles((d, n) -> n.endsWith(".zip"));
        if (files == null) return;
        List<File> list = new ArrayList<>(List.of(files));
        list.sort(Comparator.comparingLong(File::lastModified).reversed());
        long keepMs = (long) (plugin.getConfig().getDouble("backup.keep-days", 7) * 86_400_000L);
        int max = Math.max(1, plugin.getConfig().getInt("backup.max-backups", 10));
        for (int i = 0; i < list.size(); i++) {
            File f = list.get(i);
            boolean tooMany = i >= max;
            boolean tooOld = keepMs > 0 && System.currentTimeMillis() - f.lastModified() > keepMs && i > 0;
            if (tooMany || tooOld) {
                if (f.delete()) plugin.getLogger().info("Altes Backup gelöscht: " + f.getName());
            }
        }
    }

    private static String mb(long bytes) {
        return String.format(Locale.GERMANY, "%.1f MB", bytes / 1048576.0);
    }

    private List<File> list() {
        File[] files = dir.listFiles((d, n) -> n.endsWith(".zip"));
        List<File> out = new ArrayList<>();
        if (files != null) out.addAll(List.of(files));
        out.sort(Comparator.comparingLong(File::lastModified).reversed());
        return out;
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!allowed(sender)) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (command.getName().equalsIgnoreCase("cbackup")) {
            create(sender, args.length > 0 ? String.join("-", args) : "", false);
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            showList(sender);
            return true;
        }
        int nr;
        try {
            nr = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            showList(sender);
            return true;
        }
        List<File> all = list();
        if (nr < 1 || nr > all.size()) {
            plugin.getMessageUtil().send(sender, "&cDieses Backup gibt es nicht. &7Siehe &f/lbackup");
            return true;
        }
        load(sender, all.get(nr - 1), nr, args);
        return true;
    }

    private void showList(CommandSender s) {
        List<File> all = list();
        plugin.getMessageUtil().sendRaw(s, "&8&l☠ &7Backups &8(neueste zuerst, &7" + all.size() + "&8)");
        if (all.isEmpty()) {
            plugin.getMessageUtil().sendRaw(s, "&7Noch keine. Erstellen mit &f/cbackup");
            return;
        }
        int i = 1;
        for (File f : all) {
            String when = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(f.lastModified()), java.time.ZoneId.systemDefault()).format(SHOW);
            String n = f.getName().replace("backup-", "").replace(".zip", "");
            int us = n.indexOf('_', 11);
            String lab = us > 0 ? " &8(" + n.substring(us + 1) + ")" : "";
            plugin.getMessageUtil().sendRaw(s, "&e" + i + " &8- &f" + when + " &7" + mb(f.length()) + lab);
            i++;
        }
        plugin.getMessageUtil().sendRaw(s, "&7Zurückspielen: &f/lbackup <Nr> &7(alles, Neustart), &f/lbackup <Nr> welt <Name> &7(live), &f/lbackup <Nr> daten");
    }

    private void load(CommandSender s, File zip, int nr, String[] args) {
        String mode = "worlds";
        String worldName = null;
        if (args.length >= 2) {
            String m = args[1].toLowerCase(Locale.ROOT);
            if (m.equals("daten") || m.equals("data")) mode = "data";
            else if (m.equals("alles") || m.equals("all")) mode = "all";
            else if ((m.equals("welt") || m.equals("world")) && args.length >= 3) {
                mode = "world";
                worldName = args[2];
            } else {
                plugin.getMessageUtil().send(s, "&cNutzung: /lbackup <Nr> [welt <Name>|daten|alles]");
                return;
            }
        }
        String sig = s.getName() + ":" + String.join(" ", args);
        Object[] c = confirm.get(s.getName());
        if (c == null || !c[0].equals(sig) || (long) c[1] < System.currentTimeMillis()) {
            confirm.put(s.getName(), new Object[]{sig, System.currentTimeMillis() + 30_000L});
            String what = switch (mode) {
                case "data" -> "die PLUGIN-DATEN (Geld, Ränge, Clans …) zurückgesetzt";
                case "all" -> "ALLE Welten UND Plugin-Daten zurückgesetzt";
                case "world" -> "die Welt " + worldName + " zurückgesetzt (live, ohne Neustart)";
                default -> "ALLE Welten zurückgesetzt (der Server stoppt dafür)";
            };
            plugin.getMessageUtil().send(s, "&c&lAchtung: &cDamit werden " + what + " auf den Stand von Backup &f" + nr + "&c.");
            plugin.getMessageUtil().send(s, "&7Vorher wird automatisch ein Sicherheits-Backup erstellt. Zum Bestätigen den Befehl innerhalb von 30 Sekunden &fnochmal&7 eingeben.");
            return;
        }
        confirm.remove(s.getName());
        final String md = mode;
        final String wn = worldName;
        create(s, "vor-restore", false, () -> {
            if (md.equals("world")) loadWorldLive(s, zip, wn);
            else scheduleRestore(s, zip, md);
        });
    }

    private void scheduleRestore(CommandSender s, File zip, String mode) {
        Properties p = new Properties();
        p.setProperty("file", zip.getName());
        p.setProperty("mode", mode);
        try (OutputStream out = Files.newOutputStream(new File(dir, "pending.properties").toPath())) {
            p.store(out, "SpookyCraftCore Backup beim naechsten Start einspielen");
        } catch (IOException e) {
            plugin.getMessageUtil().send(s, "&cKonnte das Zurückspielen nicht vormerken: " + e.getMessage());
            return;
        }
        plugin.getMessageUtil().send(s, "&aBackup vorgemerkt. Der Server stoppt jetzt und spielt es beim Start ein. &7Falls er nicht von selbst startet: im Hoster-Panel auf Start drücken.");
        for (World w : Bukkit.getWorlds()) w.save();
        String msg = "§8§l☠ §cDie Geister stellen die Welt aus einem Backup wieder her.\n§7Bitte warte ein paar Minuten und komm dann zurück.";
        for (Player pl : new ArrayList<>(Bukkit.getOnlinePlayers())) pl.kickPlayer(msg);
        Bukkit.getScheduler().runTaskLater(plugin, Bukkit::shutdown, 40L);
    }

    private void loadWorldLive(CommandSender s, File zip, String name) {
        World w = Bukkit.getWorld(name);
        if (w == null) {
            plugin.getMessageUtil().send(s, "&cDiese Welt ist nicht geladen: &f" + name);
            return;
        }
        if (w.equals(Bukkit.getWorlds().get(0))) {
            plugin.getMessageUtil().send(s, "&cDie Hauptwelt geht nur mit Neustart: &f/lbackup <Nr>");
            return;
        }
        final String folder = w.getWorldFolder().getName();
        final World.Environment env = w.getEnvironment();
        try (ZipFile zf = new ZipFile(zip)) {
            if (zf.getEntry("worlds/" + folder + "/level.dat") == null && zf.stream().noneMatch(e -> e.getName().startsWith("worlds/" + folder + "/"))) {
                plugin.getMessageUtil().send(s, "&cIn diesem Backup steckt die Welt &f" + folder + " &cnicht.");
                return;
            }
        } catch (IOException e) {
            plugin.getMessageUtil().send(s, "&cBackup nicht lesbar: " + e.getMessage());
            return;
        }
        Location out = Bukkit.getWorlds().get(0).getSpawnLocation();
        for (Player p : new ArrayList<>(w.getPlayers())) {
            p.teleport(out);
            plugin.getMessageUtil().send(p, "&7Die Welt wird aus einem Backup wiederhergestellt …");
        }
        w.save();
        if (!Bukkit.unloadWorld(w, false)) {
            plugin.getMessageUtil().send(s, "&cDie Welt ließ sich nicht entladen (andere Plugins halten sie fest?). Abgebrochen.");
            return;
        }
        final File root = new File(Bukkit.getWorldContainer(), folder);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String err = null;
            try (ZipFile zf = new ZipFile(zip)) {
                deleteTree(root.toPath());
                extract(zf, "worlds/" + folder + "/", root.toPath());
            } catch (IOException | RuntimeException e) {
                err = e.toString();
            }
            final String e2 = err;
            Bukkit.getScheduler().runTask(plugin, () -> {
                World nw = new WorldCreator(name).environment(env).createWorld();
                if (e2 != null || nw == null) {
                    plugin.getMessageUtil().send(s, "&cWelt konnte nicht wiederhergestellt werden: " + (e2 == null ? "Laden fehlgeschlagen" : e2));
                } else {
                    plugin.getMessageUtil().send(s, "&aDie Welt &f" + name + " &aist wieder auf dem Stand des Backups.");
                }
            });
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!allowed(s) || !c.getName().equalsIgnoreCase("lbackup")) return List.of();
        if (a.length == 2) return List.of("welt", "daten", "alles");
        if (a.length == 3 && a[1].equalsIgnoreCase("welt")) {
            List<String> out = new ArrayList<>();
            for (World w : Bukkit.getWorlds()) out.add(w.getName());
            return out;
        }
        return List.of();
    }
}
