package de.craftsucht.core.vote;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Vote-System: empfängt Votes von NuVotifier (Vote-Listen wie minecraft-server-list), zahlt Belohnungen aus
 * (auch an Offline-Spieler, sobald sie joinen) und zeigt mit /vote die Vote-Links. Keine eigene Website nötig.
 * Einstellungen: "vote:" in der config.yml, Daten in votes.yml.
 */
public class VoteModule implements Module, CommandExecutor, TabCompleter, Listener {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private boolean registered;
    private BukkitTask retryTask;
    private BukkitTask reminderTask;

    public VoteModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "vote";
    }

    private String c(String s) {
        return plugin.getMessageUtil().color(s);
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    // ------------------------------------------------------------------ Start / Stop

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "votes.yml");
        data = YamlConfiguration.loadConfiguration(file);
        if (plugin.getCommand("vote") != null) {
            plugin.getCommand("vote").setExecutor(this);
            plugin.getCommand("vote").setTabCompleter(this);
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
        registered = false;
        tryRegisterVotifier();
        if (!registered) {
            retryTask = Bukkit.getScheduler().runTaskLater(plugin, this::tryRegisterVotifier, 100L);
        }
        int minutes = plugin.getConfig().getInt("vote.reminder-minutes", 30);
        if (minutes > 0) {
            long ticks = minutes * 60L * 20L;
            reminderTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                if (Bukkit.getOnlinePlayers().isEmpty()) return;
                Bukkit.broadcastMessage(c(plugin.getConfig().getString("vote.reminder-text",
                        "&8[&bVote&8] &7Vote mit &b/vote &7und erhalte &bKristalle &7für die Vote-Kiste!")));
            }, ticks, ticks);
        }
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (retryTask != null) retryTask.cancel();
        if (reminderTask != null) reminderTask.cancel();
        save();
    }

    private void save() {
        try {
            plugin.getDataFolder().mkdirs();
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("votes.yml speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ NuVotifier anbinden (ohne Compile-Abhängigkeit)

    @SuppressWarnings("unchecked")
    private void tryRegisterVotifier() {
        if (registered) return;
        Plugin votifier = Bukkit.getPluginManager().getPlugin("Votifier");
        if (votifier == null) votifier = Bukkit.getPluginManager().getPlugin("NuVotifier");
        if (votifier == null) {
            plugin.getLogger().info("Vote: NuVotifier nicht gefunden - Votes kommen erst an, wenn das Plugin NuVotifier installiert ist.");
            return;
        }
        try {
            Class<?> raw = Class.forName("com.vexsoftware.votifier.model.VotifierEvent", true, votifier.getClass().getClassLoader());
            Class<? extends Event> eventClass = (Class<? extends Event>) raw;
            Bukkit.getPluginManager().registerEvent(eventClass, this, EventPriority.NORMAL, (listener, event) -> {
                try {
                    Object vote = event.getClass().getMethod("getVote").invoke(event);
                    String name = String.valueOf(vote.getClass().getMethod("getUsername").invoke(vote));
                    String service = String.valueOf(vote.getClass().getMethod("getServiceName").invoke(vote));
                    Bukkit.getScheduler().runTask(plugin, () -> handleVote(name, service));
                } catch (Throwable t) {
                    plugin.getLogger().warning("Vote konnte nicht gelesen werden: " + t);
                }
            }, plugin);
            registered = true;
            plugin.getLogger().info("Vote: NuVotifier verbunden - Votes werden ausgezahlt.");
        } catch (Throwable t) {
            plugin.getLogger().warning("Vote: Anbindung an NuVotifier fehlgeschlagen: " + t);
        }
    }

    // ------------------------------------------------------------------ Votes verarbeiten

    private void handleVote(String name, String service) {
        if (name == null || name.isBlank()) return;
        String key = name.toLowerCase(Locale.ROOT);
        data.set("total." + key, data.getInt("total." + key, 0) + 1);
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            reward(online);
        } else {
            data.set("pending." + key, data.getInt("pending." + key, 0) + 1);
        }
        save();
        if (plugin.getConfig().getBoolean("vote.broadcast", true)) {
            Bukkit.broadcastMessage(c(plugin.getConfig().getString("vote.broadcast-text",
                    "&8[&bVote&8] &b%player% &7hat gevotet und Belohnungen erhalten! Auch du: &b/vote")
                    .replace("%player%", name).replace("%service%", service == null ? "" : service)));
        }
    }

    private void reward(Player player) {
        ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("vote.rewards");
        String crateId = cfg == null ? "vote" : cfg.getString("crate", "vote");
        int crates = cfg == null ? 1 : cfg.getInt("crate-amount", 1);
        long crystalsAmount = cfg == null ? 0 : cfg.getLong("crystals", 0);
        double money = cfg == null ? 0 : cfg.getDouble("money", 0);
        int total = data.getInt("total." + player.getName().toLowerCase(Locale.ROOT), 0);
        int every = plugin.getConfig().getInt("vote.milestone.every", 10);
        if (every > 0 && total > 0 && total % every == 0) {
            crates += plugin.getConfig().getInt("vote.milestone.crates", 1);
            player.sendMessage(c("&8[&bVote&8] &6Meilenstein! &7Das war dein &b" + total + ". &7Vote - Bonus-Kiste!"));
        }
        if (plugin.getModuleManager().get("crates") instanceof CratesModule cm) {
            if (crates > 0 && crateId != null && !crateId.isBlank() && cm.getCratePrice(crateId) >= 0) {
                cm.addKeys(player.getUniqueId(), crateId, crates);
            }
            if (crystalsAmount > 0 && cm.getCrystals() != null) cm.getCrystals().add(player.getUniqueId(), crystalsAmount);
        }
        if (money > 0 && plugin.getModuleManager().get("economy") instanceof EconomyModule eco && eco.getManager() != null) {
            eco.getManager().deposit(player.getUniqueId(), money);
        }
        for (String cmd : plugin.getConfig().getStringList("vote.rewards.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", player.getName()));
        }
        player.sendMessage(c("&8[&bVote&8] &7Danke fürs Voten! Du hast &b" + crates + " Vote-Kiste" + (crates == 1 ? "" : "n")
                + " &7erhalten - klicke in der Lobby auf die &bVote-Kiste&7, um sie zu öffnen."
                + (money > 0 ? " &7Dazu &6$" + (long) money + "&7." : "")));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        String key = p.getName().toLowerCase(Locale.ROOT);
        int pending = data.getInt("pending." + key, 0);
        if (pending <= 0) return;
        data.set("pending." + key, null);
        save();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            for (int i = 0; i < pending; i++) reward(p);
        }, 40L);
    }

    // ------------------------------------------------------------------ /vote

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("test")) {
            if (!sender.hasPermission("spookycraft.crates.admin") && !sender.isOp()) {
                msg(sender, "&cDafür hast du keine Rechte.");
                return true;
            }
            if (args.length < 2) {
                msg(sender, "&cNutzung: /vote test <spieler>  (simuliert einen Vote)");
                return true;
            }
            handleVote(args[1], "Test");
            msg(sender, "&aTest-Vote für &f" + args[1] + " &aausgelöst.");
            return true;
        }
        if (args.length >= 1 && (args[0].equalsIgnoreCase("ingame") || args[0].equalsIgnoreCase("jetzt"))) {
            if (!(sender instanceof Player p)) {
                msg(sender, "&cNur ingame.");
                return true;
            }
            ingameVote(p);
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("claim")) {
            if (!(sender instanceof Player p)) {
                msg(sender, "&cNur ingame.");
                return true;
            }
            claim(p);
            return true;
        }
        if (args.length == 0 && sender instanceof Player vp && plugin.getConfig().getBoolean("vote.ingame.enabled", true)) {
            ingameVote(vp);
            return true;
        }
        sender.sendMessage(c("&8&m          &r &b&lVote &8&m          "));
        sender.sendMessage(c("&7Vote auf den Listen und erhalte pro Vote &bKristalle &7+ Geld."));
        sender.sendMessage(c("&7Pro Vote bekommst du &b1 Vote-Kiste &7- Rechtsklick auf den Vote-Kisten-Block öffnet sie."));
        sender.sendMessage(c("&7Nach dem Voten: &b/vote claim &7tippen, um die Belohnung abzuholen."));
        sender.sendMessage(c("&7Direkt ingame: &b/vote &7(bis zu &b" + plugin.getConfig().getInt("vote.ingame.per-day", 6) + "x &7am Tag)."));
        List<Map<?, ?>> links = new ArrayList<>(plugin.getConfig().getMapList("vote.links"));
        for (Map<?, ?> site : plugin.getConfig().getMapList("vote.claim-sites")) {
            Object url = site.get("vote-url");
            if (url != null && !String.valueOf(url).isBlank()) {
                links.add(Map.of("name", String.valueOf(site.get("name")), "url", String.valueOf(url)));
            }
        }
        if (links.isEmpty()) {
            sender.sendMessage(c("&8» &7Noch keine Vote-Links eingetragen (config.yml → vote.links)."));
        }
        for (Map<?, ?> m : links) {
            String name = String.valueOf(m.get("name"));
            String url = String.valueOf(m.get("url"));
            sender.sendMessage(Component.text(" » ", NamedTextColor.DARK_GRAY)
                    .append(Component.text(name + ": ", NamedTextColor.GRAY))
                    .append(Component.text(url, NamedTextColor.AQUA, TextDecoration.UNDERLINED)
                            .clickEvent(ClickEvent.openUrl(url))));
        }
        if (sender instanceof Player p) {
            int total = data.getInt("total." + p.getName().toLowerCase(Locale.ROOT), 0);
            sender.sendMessage(c("&7Deine Votes insgesamt: &b" + total));
        }
        return true;
    }

    /** Voten ohne externe Seite: X mal pro Tag (config vote.ingame.per-day), mit Abstand (cooldown-hours). */
    private void ingameVote(Player p) {
        if (!plugin.getConfig().getBoolean("vote.ingame.enabled", true)) {
            msg(p, "&cIngame-Voten ist deaktiviert.");
            return;
        }
        int perDay = plugin.getConfig().getInt("vote.ingame.per-day", 6);
        double cdHours = plugin.getConfig().getDouble("vote.ingame.cooldown-hours", 4.0);
        String key = p.getUniqueId().toString();
        long today = System.currentTimeMillis() / 86_400_000L;
        if (data.getLong("ingame." + key + ".day", -1) != today) {
            data.set("ingame." + key + ".day", today);
            data.set("ingame." + key + ".count", 0);
        }
        int count = data.getInt("ingame." + key + ".count", 0);
        if (count >= perDay) {
            msg(p, "&5☠ &dDu hast heute schon &b" + perDay + "x &dgevotet. Komm morgen wieder!");
            return;
        }
        long last = data.getLong("ingame." + key + ".last", 0);
        long waitMs = (long) (cdHours * 3_600_000L) - (System.currentTimeMillis() - last);
        if (waitMs > 0) {
            long min = waitMs / 60_000L + 1;
            msg(p, "&cDu kannst erst in &f" + (min / 60) + " Std. " + (min % 60) + " Min. &cwieder voten.");
            return;
        }
        data.set("ingame." + key + ".count", count + 1);
        data.set("ingame." + key + ".last", System.currentTimeMillis());
        data.set("total." + p.getName().toLowerCase(Locale.ROOT), data.getInt("total." + p.getName().toLowerCase(Locale.ROOT), 0) + 1);
        save();
        reward(p);
        msg(p, "&5☠ &dIngame-Vote &b" + (count + 1) + "&7/&b" + perDay + " &dheute.");
    }

    // ------------------------------------------------------------------ /vote claim (Abfrage bei der Vote-Liste, ohne Votifier-Port)

    private final java.util.Map<java.util.UUID, Long> claimCooldown = new java.util.HashMap<>();
    private final java.net.http.HttpClient http = java.net.http.HttpClient.newBuilder()
            .connectTimeout(java.time.Duration.ofSeconds(8)).build();

    private void claim(Player player) {
        List<Map<?, ?>> sites = plugin.getConfig().getMapList("vote.claim-sites");
        List<Map<?, ?>> usable = new ArrayList<>();
        for (Map<?, ?> s : sites) {
            String key = String.valueOf(s.get("key"));
            if (s.get("api") != null && s.get("key") != null && !key.isBlank() && !key.startsWith("DEIN_")) usable.add(s);
        }
        if (usable.isEmpty()) {
            msg(player, "&cVote-Abfrage ist noch nicht eingerichtet (config.yml → vote.claim-sites).");
            return;
        }
        long now = System.currentTimeMillis();
        Long last = claimCooldown.get(player.getUniqueId());
        if (last != null && now - last < 10_000) {
            msg(player, "&cBitte warte kurz, bevor du erneut abfragst.");
            return;
        }
        claimCooldown.put(player.getUniqueId(), now);
        msg(player, "&7Prüfe deine Votes ...");
        final String name = player.getName();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<String> claimed = new ArrayList<>();
            for (Map<?, ?> s : usable) {
                try {
                    String api = String.valueOf(s.get("api"));
                    String key = java.net.URLEncoder.encode(String.valueOf(s.get("key")), java.nio.charset.StandardCharsets.UTF_8);
                    String user = java.net.URLEncoder.encode(name, java.nio.charset.StandardCharsets.UTF_8);
                    String base = api + (api.contains("?") ? "&" : "?");
                    String check = send(java.net.http.HttpRequest.newBuilder(java.net.URI.create(
                            base + "object=votes&element=claim&key=" + key + "&username=" + user))
                            .timeout(java.time.Duration.ofSeconds(8)).GET().build());
                    if (!"1".equals(check)) continue;   // 0 = nicht gefunden, 2 = schon abgeholt
                    String done = send(java.net.http.HttpRequest.newBuilder(java.net.URI.create(
                            base + "action=post&object=votes&element=claim&key=" + key + "&username=" + user))
                            .timeout(java.time.Duration.ofSeconds(8))
                            .POST(java.net.http.HttpRequest.BodyPublishers.noBody()).build());
                    if ("1".equals(done)) claimed.add(String.valueOf(s.get("name")));
                } catch (Exception e) {
                    plugin.getLogger().warning("Vote-Abfrage fehlgeschlagen (" + s.get("name") + "): " + e.getMessage());
                }
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                if (claimed.isEmpty()) {
                    msg(player, "&cKein offener Vote gefunden. Vote zuerst über die Links oben (&b/vote&c) und tippe dann erneut &b/vote claim&c.");
                    return;
                }
                for (String site : claimed) handleVote(player.getName(), site);
            });
        });
    }

    private String send(java.net.http.HttpRequest request) throws Exception {
        return http.send(request, java.net.http.HttpResponse.BodyHandlers.ofString()).body().trim();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) { out.add("claim"); out.add("info"); }
        if (args.length == 1 && (sender.isOp() || sender.hasPermission("spookycraft.crates.admin"))) out.add("test");
        if (args.length == 2 && args[0].equalsIgnoreCase("test")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        return out;
    }
}
