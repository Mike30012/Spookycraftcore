package de.craftsucht.core.profile;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.jobs.PlayerData;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.rank.RankModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /profil [spieler] - Menue mit Spielzeit, Geld, Kills, Job-Level, Rang und Beitrittsdatum. */
public class ProfileModule implements Module, CommandExecutor, TabCompleter, Listener {

    private final SpookyCraftCore plugin;

    public ProfileModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "profile";
    }

    @Override
    public void enable() {
        plugin.getCommand("profil").setExecutor(this);
        plugin.getCommand("profil").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        org.bukkit.event.HandlerList.unregisterAll(this);
    }

    private static class ProfileHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(c(name));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(c(s));
        meta.setLore(l);
        it.setItemMeta(meta);
        return it;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player viewer)) return true;
        OfflinePlayer target;
        if (args.length > 0) {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) target = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (target == null) {
                plugin.getMessageUtil().send(viewer, "&cSpieler nicht gefunden.");
                return true;
            }
        } else {
            target = viewer;
        }
        open(viewer, target);
        return true;
    }

    private void open(Player viewer, OfflinePlayer t) {
        UUID id = t.getUniqueId();
        String name = t.getName() == null ? "?" : t.getName();
        Inventory inv = Bukkit.createInventory(new ProfileHolder(), 27, c("&5☠ &dProfil: &f" + name));
        ItemStack filler = item(Material.PURPLE_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(t);
        sm.setDisplayName(c("&d&l" + name));
        List<String> hl = new ArrayList<>();
        hl.add(c(t.isOnline() ? "&a● Online" : "&7● Offline"));
        sm.setLore(hl);
        head.setItemMeta(sm);
        inv.setItem(4, head);

        // Rang
        String rank = "Spieler";
        if (plugin.getModuleManager().get("rank") instanceof RankModule rm && rm.getManager() != null) {
            String pre = rm.getManager().getColoredPrefix(id);
            if (pre != null && !pre.isBlank()) rank = pre;
        }
        inv.setItem(10, item(Material.NAME_TAG, "&6Rang", "&7" + rank));

        // Spielzeit
        long minutes = 0;
        try {
            minutes = t.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20L / 60L;
        } catch (Exception ignored) {
        }
        inv.setItem(11, item(Material.CLOCK, "&bSpielzeit", "&7" + (minutes / 60) + " Std. " + (minutes % 60) + " Min."));

        // Geld
        double bal = 0;
        if (plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null)
            bal = em.getManager().getBalance(id);
        inv.setItem(12, item(Material.GOLD_INGOT, "&eGeld", "&a$" + String.format(Locale.GERMANY, "%,.0f", bal)));

        // Kills / Tode
        int pk = 0, mk = 0, deaths = 0;
        try {
            pk = t.getStatistic(Statistic.PLAYER_KILLS);
            mk = t.getStatistic(Statistic.MOB_KILLS);
            deaths = t.getStatistic(Statistic.DEATHS);
        } catch (Exception ignored) {
        }
        inv.setItem(14, item(Material.DIAMOND_SWORD, "&cKills", "&7Spieler: &f" + pk, "&7Monster: &f" + mk));
        inv.setItem(15, item(Material.SKELETON_SKULL, "&8Tode", "&7" + deaths));

        // Job
        String jobLine = "&7Kein Job";
        String jobLvl = "";
        if (plugin.getModuleManager().get("jobs") instanceof JobsModule jm && jm.getPlayerDataManager() != null) {
            PlayerData d = jm.getPlayerDataManager().get(id);
            if (d != null && d.hasJob()) {
                jobLine = "&f" + d.getCurrentJob();
                jobLvl = "&7Level: &a" + d.getJobLevel();
            }
        }
        inv.setItem(16, item(Material.IRON_PICKAXE, "&6Job", jobLine, jobLvl));

        // Beitritt
        long first = t.getFirstPlayed();
        String date = first <= 0 ? "unbekannt" : new SimpleDateFormat("dd.MM.yyyy").format(new Date(first));
        inv.setItem(22, item(Material.WRITABLE_BOOK, "&dErster Besuch", "&7" + date));
        inv.setItem(21, item(Material.ENCHANTED_BOOK, "&5Titel", "&7Bald verfügbar"));

        viewer.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ProfileHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ProfileHolder) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return de.craftsucht.core.util.TabCompleteUtil.onlinePlayers(args[0]);
        return List.of();
    }
}
