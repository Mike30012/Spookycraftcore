package de.craftsucht.core.party;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.*;

/** Lightweight in-memory party system, independent from clans. Not persisted across restarts by design. */
public class PartyModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter {

    private final SpookyCraftCore plugin;
    private final Map<UUID, UUID> playerToLeader = new HashMap<>();
    private final Map<UUID, Set<UUID>> parties = new HashMap<>();
    private final Map<UUID, UUID> pendingInvites = new HashMap<>(); // target -> leader

    public PartyModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "party";
    }

    @Override
    public void enable() {
        plugin.getCommand("party").setExecutor(this);
        plugin.getCommand("party").setTabCompleter(this);
    }

    @Override
    public void disable() {
        playerToLeader.clear();
        parties.clear();
        pendingInvites.clear();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "invite", "accept", "leave", "chat", "list");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("invite")) {
            return de.craftsucht.core.util.TabCompleteUtil.onlinePlayers(args[1]);
        }
        return Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /party <invite|accept|leave|chat|list> [args]");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "invite" -> invite(p, args);
            case "accept" -> accept(p);
            case "leave" -> leave(p);
            case "list" -> list(p);
            case "chat", "c" -> chat(p, args);
            default -> plugin.getMessageUtil().send(p, "&cUnbekannter Befehl.");
        }
        return true;
    }

    private void invite(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /party invite <spieler>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            plugin.getMessageUtil().send(p, "&cSpieler nicht online.");
            return;
        }
        UUID leader = playerToLeader.getOrDefault(p.getUniqueId(), p.getUniqueId());
        if (!leader.equals(p.getUniqueId())) {
            plugin.getMessageUtil().send(p, "&cNur der Party-Leiter kann einladen.");
            return;
        }
        parties.computeIfAbsent(leader, k -> new HashSet<>()).add(leader);
        pendingInvites.put(target.getUniqueId(), leader);
        plugin.getMessageUtil().send(target, "&b" + p.getName() + " &7lädt dich zur Party ein. /party accept");
        plugin.getMessageUtil().send(p, "&aEinladung gesendet.");
    }

    private void accept(Player p) {
        UUID leader = pendingInvites.remove(p.getUniqueId());
        if (leader == null) {
            plugin.getMessageUtil().send(p, "&cKeine offene Einladung.");
            return;
        }
        parties.computeIfAbsent(leader, k -> new HashSet<>()).add(p.getUniqueId());
        playerToLeader.put(p.getUniqueId(), leader);
        playerToLeader.putIfAbsent(leader, leader);
        plugin.getMessageUtil().send(p, "&aParty beigetreten.");
        broadcast(leader, "&b" + p.getName() + " &7ist der Party beigetreten.");
    }

    private void leave(Player p) {
        UUID leader = playerToLeader.remove(p.getUniqueId());
        if (leader == null) {
            plugin.getMessageUtil().send(p, "&cDu bist in keiner Party.");
            return;
        }
        Set<UUID> members = parties.get(leader);
        if (members != null) members.remove(p.getUniqueId());
        plugin.getMessageUtil().send(p, "&aParty verlassen.");
    }

    private void list(Player p) {
        UUID leader = playerToLeader.get(p.getUniqueId());
        if (leader == null) {
            plugin.getMessageUtil().send(p, "&7Du bist in keiner Party.");
            return;
        }
        Set<UUID> members = parties.getOrDefault(leader, Set.of());
        plugin.getMessageUtil().sendRaw(p, "&8--- &bParty &8---");
        for (UUID uuid : members) {
            String name = Bukkit.getOfflinePlayer(uuid).getName();
            plugin.getMessageUtil().sendRaw(p, "&b" + name + (uuid.equals(leader) ? " &7(Leiter)" : ""));
        }
    }

    private void chat(Player p, String[] args) {
        UUID leader = playerToLeader.get(p.getUniqueId());
        if (leader == null || args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /party chat <nachricht>");
            return;
        }
        String message = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        broadcast(leader, "&d[Party] &b" + p.getName() + "&7: &f" + message);
    }

    private void broadcast(UUID leader, String message) {
        for (UUID uuid : parties.getOrDefault(leader, Set.of())) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null) plugin.getMessageUtil().sendRaw(member, message);
        }
    }
}
