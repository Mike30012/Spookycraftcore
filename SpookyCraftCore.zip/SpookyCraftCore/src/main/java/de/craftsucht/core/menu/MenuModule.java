package de.craftsucht.core.menu;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * /menu - Hauptmenue mit Knoepfen fuer alle wichtigen Funktionen, und /warp (ohne Namen) als Menue mit allen Warps.
 * Knoepfe stehen eingebaut im Plugin, koennen aber in der config.yml unter menu.items ueberschrieben werden.
 */
public class MenuModule implements Module, CommandExecutor, Listener {

    private record Button(int slot, Material icon, String name, List<String> lore, String command) {
    }

    private static final class MenuHolder implements InventoryHolder {
        final Map<Integer, String> commands = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final class WarpHolder implements InventoryHolder {
        final Map<Integer, String> warps = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;

    public MenuModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "menu";
    }

    @Override
    public void enable() {
        plugin.getCommand("menu").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
    }

    // ------------------------------------------------------------------ Hauptmenue

    private List<Button> buttons() {
        List<Button> out = new ArrayList<>();
        List<Map<?, ?>> cfg = plugin.getConfig().getMapList("menu.items");
        if (!cfg.isEmpty()) {
            for (Map<?, ?> m : cfg) {
                try {
                    int slot = Integer.parseInt(String.valueOf(m.get("slot")));
                    List<String> lore = new ArrayList<>();
                    Object l = m.get("lore");
                    if (l instanceof List<?> ll) for (Object o : ll) lore.add(String.valueOf(o));
                    out.add(new Button(slot, GuiUtil.mat(String.valueOf(m.get("icon")), Material.STONE),
                            String.valueOf(m.get("name")), lore, String.valueOf(m.get("command"))));
                } catch (NumberFormatException ignored) {
                    // kaputter Eintrag
                }
            }
            return out;
        }
        out.add(new Button(10, Material.ENDER_PEARL, "&5&lWarps", List.of("&7Alle Reiseziele"), "warp"));
        out.add(new Button(11, Material.EMERALD, "&a&lMarkt", List.of("&7Kaufen und verkaufen"), "markt"));
        out.add(new Button(12, Material.GRASS_BLOCK, "&2&lImmobilien", List.of("&7Grundstücke kaufen"), "immo"));
        out.add(new Button(13, Material.ENDER_CHEST, "&d&lTresor", List.of("&7Dein großes Lager"), "tresor"));
        out.add(new Button(14, Material.BONE, "&d&lBegleiter", List.of("&7Deine Pets"), "pet"));
        out.add(new Button(15, Material.GOLD_INGOT, "&6&lRangshop", List.of("&7Ränge kaufen"), "rangshop"));
        out.add(new Button(16, Material.NETHER_STAR, "&b&lPerks", List.of("&7Geister-Kräfte"), "perks"));
        out.add(new Button(19, Material.DIAMOND_PICKAXE, "&e&lJobs", List.of("&7Dein Beruf"), "jobs"));
        out.add(new Button(20, Material.BOOK, "&f&lErfolge", List.of("&7Aufgaben mit Belohnung"), "erfolge"));
        out.add(new Button(21, Material.NAME_TAG, "&e&lTitel", List.of("&7Dein Titel im Chat"), "titel"));
        out.add(new Button(22, Material.GOLD_BLOCK, "&6&lBank", List.of("&7Geld sicher anlegen"), "bank"));
        out.add(new Button(23, Material.SHIELD, "&c&lClan", List.of("&7Deine Gemeinschaft"), "clan"));
        out.add(new Button(24, Material.COMPASS, "&b&lZufalls-Teleport", List.of("&7In die Farmwelt"), "rtp"));
        out.add(new Button(25, Material.RED_BED, "&f&lSpawn", List.of("&7Zurück zum Start"), "spawn"));
        return out;
    }

    /** Schwarzer Hintergrund, oben und unten eine durchgehende lila Leiste (ruhiger als Schachbrett). */
    private void frame(Inventory inv) {
        int size = inv.getSize();
        int rows = size / 9;
        var black = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        var purple = GuiUtil.item(Material.PURPLE_STAINED_GLASS_PANE, " ");
        var magenta = GuiUtil.item(Material.MAGENTA_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < size; i++) {
            int r = i / 9, col = i % 9;
            boolean bar = r == 0 || r == rows - 1;
            inv.setItem(i, bar ? (col == 4 ? magenta : purple) : black);
        }
    }

    private static final Map<String, Integer> MODEL = Map.ofEntries(
            Map.entry("warp", 930), Map.entry("markt", 931), Map.entry("immo", 932), Map.entry("tresor", 933),
            Map.entry("pet", 934), Map.entry("rangshop", 935), Map.entry("perks", 936), Map.entry("jobs", 937),
            Map.entry("erfolge", 938), Map.entry("titel", 939), Map.entry("bank", 940), Map.entry("clan", 941),
            Map.entry("rtp", 942), Map.entry("spawn", 943));

    private boolean customIcons() {
        return plugin.getConfig().getBoolean("menu.custom-icons", false);
    }

    /** Item mit eigener 256x256-Textur (Papier + CustomModelData) oder, wenn ausgeschaltet, das normale Item. */
    private org.bukkit.inventory.ItemStack iconItem(Material vanilla, int model, String name, List<String> lore) {
        if (model <= 0 || !customIcons()) return GuiUtil.glow(GuiUtil.item(vanilla, name, lore));
        var it = GuiUtil.item(Material.PAPER, name, lore);
        var m = it.getItemMeta();
        if (m != null) {
            m.setCustomModelData(model);
            it.setItemMeta(m);
        }
        return it;
    }

    private org.bukkit.inventory.ItemStack profileHead(Player p) {
        String rank = "Spieler";
        if (plugin.getModuleManager().get("rank") instanceof de.craftsucht.core.rank.RankModule rm && rm.getManager() != null) {
            String r = rm.getManager().getUserRank(p.getUniqueId());
            if (r != null && !r.isBlank() && !r.equalsIgnoreCase("default")) rank = r.substring(0, 1).toUpperCase(Locale.ROOT) + r.substring(1);
        }
        String money = "-";
        if (plugin.getModuleManager().get("economy") instanceof de.craftsucht.core.economy.EconomyModule eco && eco.getManager() != null) {
            money = GuiUtil.money(eco.getManager().getBalance(p.getUniqueId()));
        }
        var head = GuiUtil.item(Material.PLAYER_HEAD, "&d&l" + p.getName(),
                "", "&7Rang: &f" + rank, "&7Geld: &a" + money, "", "&8Willkommen in der Geisterwelt!");
        if (head.getItemMeta() instanceof org.bukkit.inventory.meta.SkullMeta sm) {
            sm.setOwningPlayer(p);
            head.setItemMeta(sm);
        }
        return head;
    }

    private void openMenu(Player p) {
        MenuHolder h = new MenuHolder();
        int rows = Math.max(4, Math.min(6, plugin.getConfig().getInt("menu.rows", 4)));
        Inventory inv = Bukkit.createInventory(h, rows * 9, GuiUtil.c(plugin.getConfig().getString("menu.title", "&5&l☠ &d&lSpookyCraft &5&l☠ &8» &dMenü")));
        frame(inv);
        List<Button> bs = buttons();
        boolean slot4Used = false;
        for (Button b : bs) if (b.slot == 4) slot4Used = true;
        if (!slot4Used) inv.setItem(4, profileHead(p));
        for (Button b : bs) {
            if (b.slot < 0 || b.slot >= inv.getSize()) continue;
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.addAll(b.lore);
            lore.add("");
            lore.add("&5▶ &dKlick zum Öffnen");
            inv.setItem(b.slot, iconItem(b.icon, MODEL.getOrDefault(b.command, 0), b.name, lore));
            h.commands.put(b.slot, b.command);
        }
        int closeSlot = (rows - 1) * 9 + 4;
        inv.setItem(closeSlot, iconItem(Material.BARRIER, 944, "&c&lSchließen", List.of("", "&7Menü schließen")));
        h.commands.put(closeSlot, "");
        p.openInventory(inv);
        p.playSound(p.getLocation(), "block.ender_chest.open", 0.5f, 1.3f);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        openMenu(p);
        return true;
    }

    // ------------------------------------------------------------------ Warp-Menue

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onWarpCommand(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("menu.warp-gui", true)) return;
        String msg = e.getMessage().trim().toLowerCase(Locale.ROOT);
        if (msg.equals("/warp") || msg.equals("/warps") || msg.equals("/essentials:warp")) {
            e.setCancelled(true);
            openWarps(e.getPlayer());
        }
    }

    private java.util.LinkedHashMap<String, String> warpNames() {
        java.util.LinkedHashMap<String, String> out = new java.util.LinkedHashMap<>();
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT name, world FROM warps ORDER BY name")) {
            while (rs.next()) out.put(rs.getString(1), rs.getString(2));
        } catch (SQLException e) {
            plugin.getLogger().warning("Warp-Menü: Warps nicht lesbar: " + e.getMessage());
        }
        return out;
    }

    private Material iconFor(String warp) {
        String cfg = plugin.getConfig().getString("menu.warp-icons." + warp);
        if (cfg == null) cfg = plugin.getConfig().getString("menu.warp-icons." + warp.toLowerCase(Locale.ROOT));
        if (cfg != null) return GuiUtil.mat(cfg, Material.ENDER_PEARL);
        String n = warp.toLowerCase(Locale.ROOT);
        if (n.contains("farm")) return Material.WHEAT;
        if (n.contains("nether")) return Material.NETHERRACK;
        if (n.contains("end")) return Material.END_STONE;
        if (n.contains("spawn") || n.contains("lobby")) return Material.BEACON;
        if (n.contains("markt") || n.contains("shop")) return Material.EMERALD;
        if (n.contains("plot") || n.contains("immo")) return Material.GRASS_BLOCK;
        if (n.contains("event")) return Material.FIREWORK_ROCKET;
        if (n.contains("pvp") || n.contains("arena")) return Material.IRON_SWORD;
        return Material.ENDER_PEARL;
    }

    private int warpModel(String warp) {
        if (plugin.getConfig().getString("menu.warp-icons." + warp) != null
                || plugin.getConfig().getString("menu.warp-icons." + warp.toLowerCase(Locale.ROOT)) != null) return 0;
        String n = warp.toLowerCase(Locale.ROOT);
        if (n.contains("farm")) return 947;
        if (n.contains("nether")) return 948;
        if (n.contains("end")) return 949;
        if (n.contains("spawn") || n.contains("lobby")) return 943;
        if (n.contains("markt") || n.contains("shop")) return 931;
        if (n.contains("plot") || n.contains("immo")) return 932;
        if (n.contains("event")) return 950;
        if (n.contains("pvp") || n.contains("arena")) return 951;
        return 952;
    }

    private void openWarps(Player p) {
        java.util.LinkedHashMap<String, String> warps = warpNames();
        WarpHolder h = new WarpHolder();
        int rows = Math.max(3, Math.min(6, (warps.size() + 6) / 7 + 2));
        Inventory inv = Bukkit.createInventory(h, rows * 9, GuiUtil.c("&5&l☠ &d&lWarps &5&l☠"));
        frame(inv);
        int slot = 10, placed = 0;
        for (var en : warps.entrySet()) {
            while (slot % 9 == 0 || slot % 9 == 8) slot++;
            if (slot >= inv.getSize() - 9) break;
            String n = en.getKey();
            String world = en.getValue() == null ? "?" : en.getValue();
            inv.setItem(slot, iconItem(iconFor(n), warpModel(n), "&d&l" + n,
                    List.of("", "&7Welt: &f" + world, "", "&5▶ &dKlick zum Teleportieren")));
            h.warps.put(slot, n);
            slot++;
            placed++;
        }
        if (warps.isEmpty()) {
            inv.setItem(13, GuiUtil.item(Material.BARRIER, "&c&lNoch keine Warps", "", "&7Ein Admin setzt sie mit &f/setwarp <Name>"));
        }
        inv.setItem(4, iconItem(Material.ENDER_EYE, 946, "&d&lReiseziele", List.of("", "&7" + warps.size() + " Warps verfügbar")));
        inv.setItem(inv.getSize() - 5, iconItem(Material.ARROW, 945, "&7« Zurück zum Hauptmenü", List.of()));
        p.openInventory(inv);
        p.playSound(p.getLocation(), "entity.enderman.teleport", 0.4f, 1.5f);
    }

    // ------------------------------------------------------------------ Klicks

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        var h = e.getView().getTopInventory().getHolder();
        if (h instanceof MenuHolder || h instanceof WarpHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        var holder = e.getView().getTopInventory().getHolder();
        if (!(holder instanceof MenuHolder) && !(holder instanceof WarpHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.0f);
        if (holder instanceof MenuHolder mh) {
            String cmd = mh.commands.get(slot);
            if (cmd == null) return;
            p.closeInventory();
            if (cmd.isEmpty()) return;
            Bukkit.getScheduler().runTask(plugin, () -> p.performCommand(cmd));
        } else if (holder instanceof WarpHolder wh) {
            if (slot == e.getView().getTopInventory().getSize() - 5) {
                openMenu(p);
                return;
            }
            String w = wh.warps.get(slot);
            if (w == null) return;
            p.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> p.performCommand("warp " + w));
        }
    }
}
