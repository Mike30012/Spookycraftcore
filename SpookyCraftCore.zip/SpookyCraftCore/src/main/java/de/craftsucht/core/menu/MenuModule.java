package de.craftsucht.core.menu;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * /menu - Hauptmenue mit Knoepfen fuer alle wichtigen Funktionen, und /warp (ohne Namen) als Menue mit allen Warps.
 * Knoepfe stehen eingebaut im Plugin, koennen aber in der config.yml unter menu.items ueberschrieben werden.
 */
public class MenuModule implements Module, CommandExecutor, Listener {

    private record Button(int slot, Material icon, String name, List<String> lore, String command) {
    }

    private static final class MenuHolder implements InventoryHolder {
        final Map<Integer, String> commands = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final class WarpHolder implements InventoryHolder {
        final Map<Integer, String> warps = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;

    public MenuModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "menu";
    }

    @Override
    public void enable() {
        plugin.getCommand("menu").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
    }

    // ------------------------------------------------------------------ Hauptmenue

    private List<Button> buttons() {
        List<Button> out = new ArrayList<>();
        List<Map<?, ?>> cfg = plugin.getConfig().getMapList("menu.items");
        if (!cfg.isEmpty()) {
            for (Map<?, ?> m : cfg) {
                try {
                    int slot = Integer.parseInt(String.valueOf(m.get("slot")));
                    List<String> lore = new ArrayList<>();
                    Object l = m.get("lore");
                    if (l instanceof List<?> ll) for (Object o : ll) lore.add(String.valueOf(o));
                    out.add(new Button(slot, GuiUtil.mat(String.valueOf(m.get("icon")), Material.STONE),
                            String.valueOf(m.get("name")), lore, String.valueOf(m.get("command"))));
                } catch (NumberFormatException ignored) {
                    // kaputter Eintrag
                }
            }
            return out;
        }
        out.add(new Button(10, Material.ENDER_PEARL, "&5&lWarps", List.of("&7Alle Reiseziele"), "warp"));
        out.add(new Button(11, Material.EMERALD, "&a&lMarkt", List.of("&7Kaufen und verkaufen"), "markt"));
        out.add(new Button(12, Material.GRASS_BLOCK, "&2&lImmobilien", List.of("&7Grundstücke kaufen"), "immo"));
        out.add(new Button(13, Material.ENDER_CHEST, "&d&lTresor", List.of("&7Dein großes Lager"), "tresor"));
        out.add(new Button(14, Material.BONE, "&d&lBegleiter", List.of("&7Deine Pets"), "pet"));
        out.add(new Button(15, Material.GOLD_INGOT, "&6&lRangshop", List.of("&7Ränge kaufen"), "rangshop"));
        out.add(new Button(16, Material.NETHER_STAR, "&b&lPerks", List.of("&7Geister-Kräfte"), "perks"));
        out.add(new Button(19, Material.DIAMOND_PICKAXE, "&e&lJobs", List.of("&7Dein Beruf"), "jobs"));
        out.add(new Button(20, Material.BOOK, "&f&lErfolge", List.of("&7Aufgaben mit Belohnung"), "erfolge"));
        out.add(new Button(21, Material.NAME_TAG, "&e&lTitel", List.of("&7Dein Titel im Chat"), "titel"));
        out.add(new Button(22, Material.GOLD_BLOCK, "&6&lBank", List.of("&7Geld sicher anlegen"), "bank"));
        out.add(new Button(23, Material.SHIELD, "&c&lClan", List.of("&7Deine Gemeinschaft"), "clan"));
        out.add(new Button(24, Material.COMPASS, "&b&lZufalls-Teleport", List.of("&7In die Farmwelt"), "rtp"));
        out.add(new Button(25, Material.RED_BED, "&f&lSpawn", List.of("&7Zurück zum Start"), "spawn"));
        return out;
    }

    private void openMenu(Player p) {
        MenuHolder h = new MenuHolder();
        int rows = Math.max(3, Math.min(6, plugin.getConfig().getInt("menu.rows", 3)));
        Inventory inv = Bukkit.createInventory(h, rows * 9, GuiUtil.c(plugin.getConfig().getString("menu.title", "&5&l☠ &dHauptmenü")));
        var pane = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        for (Button b : buttons()) {
            if (b.slot < 0 || b.slot >= inv.getSize()) continue;
            List<String> lore = new ArrayList<>(b.lore);
            lore.add("");
            lore.add("&eKlick: &7/" + b.command);
            inv.setItem(b.slot, GuiUtil.item(b.icon, b.name, lore));
            h.commands.put(b.slot, b.command);
        }
        p.openInventory(inv);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        openMenu(p);
        return true;
    }

    // ------------------------------------------------------------------ Warp-Menue

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onWarpCommand(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("menu.warp-gui", true)) return;
        String msg = e.getMessage().trim().toLowerCase(Locale.ROOT);
        if (msg.equals("/warp") || msg.equals("/warps") || msg.equals("/essentials:warp")) {
            e.setCancelled(true);
            openWarps(e.getPlayer());
        }
    }

    private List<String> warpNames() {
        List<String> out = new ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT name FROM warps ORDER BY name")) {
            while (rs.next()) out.add(rs.getString(1));
        } catch (SQLException e) {
            plugin.getLogger().warning("Warp-Menü: Warps nicht lesbar: " + e.getMessage());
        }
        return out;
    }

    private Material iconFor(String warp) {
        String cfg = plugin.getConfig().getString("menu.warp-icons." + warp);
        if (cfg == null) cfg = plugin.getConfig().getString("menu.warp-icons." + warp.toLowerCase(Locale.ROOT));
        if (cfg != null) return GuiUtil.mat(cfg, Material.ENDER_PEARL);
        String n = warp.toLowerCase(Locale.ROOT);
        if (n.contains("farm")) return Material.WHEAT;
        if (n.contains("nether")) return Material.NETHERRACK;
        if (n.contains("end")) return Material.END_STONE;
        if (n.contains("spawn") || n.contains("lobby")) return Material.BEACON;
        if (n.contains("markt") || n.contains("shop")) return Material.EMERALD;
        if (n.contains("plot") || n.contains("immo")) return Material.GRASS_BLOCK;
        if (n.contains("event")) return Material.FIREWORK_ROCKET;
        if (n.contains("pvp") || n.contains("arena")) return Material.IRON_SWORD;
        return Material.ENDER_PEARL;
    }

    private void openWarps(Player p) {
        List<String> names = warpNames();
        WarpHolder h = new WarpHolder();
        int rows = Math.max(2, Math.min(6, (names.size() + 8) / 9 + 1));
        Inventory inv = Bukkit.createInventory(h, rows * 9, GuiUtil.c("&5&l☠ &dWarps"));
        var pane = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        int max = inv.getSize() - 9;
        for (int i = 0; i < names.size() && i < max; i++) {
            String n = names.get(i);
            inv.setItem(i, GuiUtil.item(iconFor(n), "&d&l" + n, "", "&eKlick: &7hinreisen"));
            h.warps.put(i, n);
        }
        if (names.isEmpty()) {
            inv.setItem(4, GuiUtil.item(Material.BARRIER, "&cNoch keine Warps", "&7Ein Admin setzt sie mit &f/setwarp <Name>"));
        }
        inv.setItem(inv.getSize() - 5, GuiUtil.item(Material.ARROW, "&7« Hauptmenü"));
        p.openInventory(inv);
    }

    // ------------------------------------------------------------------ Klicks

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        var h = e.getView().getTopInventory().getHolder();
        if (h instanceof MenuHolder || h instanceof WarpHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        var holder = e.getView().getTopInventory().getHolder();
        if (!(holder instanceof MenuHolder) && !(holder instanceof WarpHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.0f);
        if (holder instanceof MenuHolder mh) {
            String cmd = mh.commands.get(slot);
            if (cmd == null) return;
            p.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> p.performCommand(cmd));
        } else if (holder instanceof WarpHolder wh) {
            if (slot == e.getView().getTopInventory().getSize() - 5) {
                openMenu(p);
                return;
            }
            String w = wh.warps.get(slot);
            if (w == null) return;
            p.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> p.performCommand("warp " + w));
        }
    }
}
