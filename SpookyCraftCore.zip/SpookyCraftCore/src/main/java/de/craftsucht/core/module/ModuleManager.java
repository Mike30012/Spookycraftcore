package de.craftsucht.core.module;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.rank.RankModule;
import de.craftsucht.core.punish.PunishModule;
import de.craftsucht.core.essentials.EssentialsModule;
import de.craftsucht.core.nickname.NicknameModule;
import de.craftsucht.core.atmosphere.AtmosphereModule;
import de.craftsucht.core.profile.ProfileModule;
import de.craftsucht.core.morph.MorphModule;
import de.craftsucht.core.hexe.HexeModule;
import de.craftsucht.core.afk.AfkModule;
import de.craftsucht.core.video.VideoModule;
import de.craftsucht.core.menu.MenuModule;
import de.craftsucht.core.prestige.PrestigeModule;
import de.craftsucht.core.erfolge.AchievementsModule;
import de.craftsucht.core.titel.TitlesModule;
import de.craftsucht.core.rucksack.RucksackModule;
import de.craftsucht.core.quests.QuestsModule;
import de.craftsucht.core.daily.DailyModule;

import de.craftsucht.core.backup.BackupModule;
import de.craftsucht.core.tresor.TresorModule;
import de.craftsucht.core.immobilien.ImmobilienModule;
import de.craftsucht.core.blocklog.BlockLogModule;
import de.craftsucht.core.pets.PetsModule;
import de.craftsucht.core.emoji.EmojiModule;
import de.craftsucht.core.multiacc.MultiAccountModule;
import de.craftsucht.core.perks.PerksModule;
import de.craftsucht.core.rtp.RtpModule;
import de.craftsucht.core.games.LottoModule;
import de.craftsucht.core.playtime.PlaytimeModule;
import de.craftsucht.core.trade.TradeModule;
import de.craftsucht.core.pwarp.PwarpModule;
import de.craftsucht.core.cenchant.CustomEnchantModule;
import de.craftsucht.core.games.ChatGamesModule;
import de.craftsucht.core.games.CoinflipModule;
import de.craftsucht.core.rankshop.RankShopModule;
import de.craftsucht.core.links.YoutubeModule;
import de.craftsucht.core.dungeon.DungeonModule;
import de.craftsucht.core.friends.FriendsModule;
import de.craftsucht.core.clan.ClanModule;
import de.craftsucht.core.vanish.VanishModule;
import de.craftsucht.core.stats.StatsModule;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import de.craftsucht.core.tablist.TabListModule;
import de.craftsucht.core.kits.KitsModule;
import de.craftsucht.core.shop.AuctionModule;
import de.craftsucht.core.report.ReportModule;
import de.craftsucht.core.discord.DiscordModule;
import de.craftsucht.core.party.PartyModule;
import de.craftsucht.core.anticheat.AntiCheatModule;
import de.craftsucht.core.maintenance.MaintenanceModule;
import de.craftsucht.core.util.UtilityModule;
import de.craftsucht.core.alert.AlertModule;
import de.craftsucht.core.itemdb.ItemDbModule;
import de.craftsucht.core.nav.NavModule;
import de.craftsucht.core.markt.MarktModule;
import de.craftsucht.core.farmreset.FarmResetModule;
import de.craftsucht.core.keepalive.KeepAliveModule;
import de.craftsucht.core.shopkiste.ShopkisteModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.booster.BoosterModule;
import de.craftsucht.core.bank.BankModule;
import de.craftsucht.core.staffchat.StaffChatModule;
import org.bukkit.command.CommandSender;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModuleManager {

    private final SpookyCraftCore plugin;
    private final Map<String, Module> modules = new LinkedHashMap<>();
    private final Map<String, Boolean> enabledState = new LinkedHashMap<>();

    public ModuleManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void registerAll() {
        register(new RankModule(plugin));
        register(new de.craftsucht.core.monitor.MonitorModule(plugin));
        register(new de.craftsucht.core.perf.PerfModule(plugin));
        register(new EconomyModule(plugin));
        register(new PunishModule(plugin));
        register(new EssentialsModule(plugin));
        register(new NicknameModule(plugin));
        register(new AtmosphereModule(plugin));
        register(new ProfileModule(plugin));
        register(new MorphModule(plugin));
        register(new HexeModule(plugin));
        register(new AfkModule(plugin));
        register(new VideoModule(plugin));
        register(new MenuModule(plugin));
        register(new PrestigeModule(plugin));
        register(new AchievementsModule(plugin));
        register(new TitlesModule(plugin));
        register(new RucksackModule(plugin));
        register(new QuestsModule(plugin));
        register(new DailyModule(plugin));
        register(new BackupModule(plugin));
        register(new TresorModule(plugin));
        register(new ImmobilienModule(plugin));
        register(new BlockLogModule(plugin));
        register(new PetsModule(plugin));
        register(new EmojiModule(plugin));
        register(new MultiAccountModule(plugin));
        register(new PerksModule(plugin));
        register(new RtpModule(plugin));
        register(new LottoModule(plugin));
        register(new PlaytimeModule(plugin));
        register(new TradeModule(plugin));
        register(new PwarpModule(plugin));
        register(new CustomEnchantModule(plugin));
        register(new ChatGamesModule(plugin));
        register(new CoinflipModule(plugin));
        register(new RankShopModule(plugin));
        register(new YoutubeModule(plugin));
        register(new DungeonModule(plugin));
        register(new FriendsModule(plugin));
        register(new ClanModule(plugin));
        register(new VanishModule(plugin));
        register(new StatsModule(plugin));
        register(new ScoreboardModule(plugin));
        register(new TabListModule(plugin));
        register(new KitsModule(plugin));
        register(new AuctionModule(plugin));
        register(new ReportModule(plugin));
        register(new DiscordModule(plugin));
        register(new PartyModule(plugin));
        register(new AntiCheatModule(plugin));
        register(new MaintenanceModule(plugin));
        register(new UtilityModule(plugin));
        register(new AlertModule(plugin));
        register(new ItemDbModule(plugin));
        register(new NavModule(plugin));
        register(new MarktModule(plugin));
        register(new ShopkisteModule(plugin));
        register(new FarmResetModule(plugin));
        register(new KeepAliveModule(plugin));
        register(new JobsModule(plugin));
        register(new BoosterModule(plugin));
        register(new BankModule(plugin));
        register(new StaffChatModule(plugin));
        register(new de.craftsucht.core.extras.ExtrasModule(plugin));
        register(new de.craftsucht.core.basics.BasicsModule(plugin));
        register(new de.craftsucht.core.crates.CratesModule(plugin));
        register(new de.craftsucht.core.vote.VoteModule(plugin));
        register(new de.craftsucht.core.swarp.SwarpModule(plugin));
    }

    private void register(Module module) {
        modules.put(module.getId(), module);
    }

    public void enableEnabled() {
        for (Module module : modules.values()) {
            boolean on = plugin.getConfig().getBoolean("modules." + module.getId(), true);
            enabledState.put(module.getId(), on);
            if (on) {
                try {
                    module.enable();
                } catch (Exception e) {
                    plugin.getLogger().warning("Modul '" + module.getId() + "' konnte nicht aktiviert werden: " + e.getMessage());
                }
            }
        }
    }

    public void disableAll() {
        for (Module module : modules.values()) {
            if (Boolean.TRUE.equals(enabledState.get(module.getId()))) {
                try {
                    module.disable();
                } catch (Exception ignored) {
                }
            }
        }
    }

    public void reloadAll() {
        disableAll();
        enableEnabled();
    }

    public boolean isEnabled(String id) {
        return Boolean.TRUE.equals(enabledState.get(id));
    }

    public Module get(String id) {
        return modules.get(id);
    }

    public String[] getModuleIds() {
        return modules.keySet().toArray(new String[0]);
    }

    /**
     * Schaltet ein Modul zur Laufzeit an/aus und speichert den Zustand in der config.yml (Kommentare bleiben erhalten).
     * @return null bei Erfolg, sonst eine Fehlermeldung
     */
    public String setEnabled(String id, boolean on) {
        Module module = modules.get(id);
        if (module == null) {
            return "Unbekanntes Modul: " + id + " (siehe /bccore modules)";
        }
        boolean current = Boolean.TRUE.equals(enabledState.get(id));
        if (current == on) {
            return "Modul '" + id + "' ist bereits " + (on ? "aktiviert" : "deaktiviert") + ".";
        }
        try {
            if (on) {
                module.enable();
            } else {
                module.disable();
            }
        } catch (Exception e) {
            return "Modul '" + id + "' konnte nicht " + (on ? "aktiviert" : "deaktiviert") + " werden: " + e.getMessage();
        }
        enabledState.put(id, on);
        if (!de.craftsucht.core.util.ConfigFile.setValue(plugin, "modules", id, String.valueOf(on))) {
            plugin.getConfig().set("modules." + id, on);
            plugin.saveConfig();
        }
        return null;
    }

    public int getEnabledCount() {
        return (int) enabledState.values().stream().filter(Boolean::booleanValue).count();
    }

    public void listModules(CommandSender sender) {
        sender.sendMessage("§7--- §6☠ SpookyCraft§7 – beschworene Module ---");
        modules.forEach((id, module) -> {
            boolean on = enabledState.getOrDefault(id, false);
            sender.sendMessage((on ? "§a● " : "§c● ") + id);
        });
    }
}
