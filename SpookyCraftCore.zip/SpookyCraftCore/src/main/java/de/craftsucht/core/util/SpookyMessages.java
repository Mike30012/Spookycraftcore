package de.craftsucht.core.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Spooky Join-/Quit-/Todes-Meldungen. Vanish-Spieler (Meldung null) bleiben unberuehrt. */
public class SpookyMessages implements Listener {

    private static Component legacy(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) {
        if (e.joinMessage() == null) return;
        String name = e.getPlayer().getName();
        e.joinMessage(legacy(e.getPlayer().hasPlayedBefore()
                ? "&8[&a+&8] &5☠ &d" + name + " &7ist aus dem Nebel aufgetaucht"
                : "&8[&6★&8] &5☠ &d" + name + " &7hat zum ersten Mal die &5Geisterwelt &7betreten! &6Willkommen!"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        if (e.quitMessage() == null) return;
        e.quitMessage(legacy("&8[&c-&8] &5☠ &d" + e.getPlayer().getName() + " &7ist im Nebel verschwunden"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Component orig = e.deathMessage();
        if (orig == null) return;
        e.deathMessage(legacy("&8[&4☠&8] ").append(orig.colorIfAbsent(NamedTextColor.GRAY)));
    }
}
