package de.craftsucht.core.bank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Bankguthaben getrennt vom normalen Kontostand (der normale Kontostand ist
 * das, was Scoreboard/`/eco`/`/pay` zeigen - unser EconomyManager). Vorher
 * lief das über Vault (ein eigener, potenziell abweichender Kontostand -
 * genau das war der gemeldete Bug "reagiert nicht auf unsere Economy").
 * Jetzt: Ein- und Auszahlen bucht direkt auf/von EconomyManager um, das
 * Bankguthaben selbst bleibt ein separater Topf (das ist ja der Sinn eines
 * Bankkontos - Zinsen gibt's nur darauf, nicht auf das Bargeld).
 */
public class BankManager {

    private final SpookyCraftCore plugin;
    private final Map<UUID, Double> cache = new HashMap<>();

    public BankManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    private EconomyManager economy() {
        EconomyModule module = (EconomyModule) plugin.getModuleManager().get("economy");
        return module != null ? module.getManager() : null;
    }

    public double getGuthaben(UUID uuid) {
        if (cache.containsKey(uuid)) {
            return cache.get(uuid);
        }
        double loaded = load(uuid);
        cache.put(uuid, loaded);
        return loaded;
    }

    private double load(UUID uuid) {
        String sql = "SELECT balance FROM bank_accounts WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("balance");
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Bank-Guthaben laden fehlgeschlagen: " + e.getMessage());
        }
        return 0.0;
    }

    public void setGuthaben(UUID uuid, double guthaben) {
        double max = plugin.getConfig().getDouble("bank.max-kontostand", -1.0);
        if (max > 0.0 && guthaben > max) {
            guthaben = max;
        }
        guthaben = Math.max(0.0, guthaben);
        cache.put(uuid, guthaben);
        save(uuid, guthaben);
    }

    private void save(UUID uuid, double guthaben) {
        String sql = "INSERT INTO bank_accounts (uuid, balance) VALUES (?,?) " +
                "ON CONFLICT(uuid) DO UPDATE SET balance = excluded.balance";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setDouble(2, guthaben);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Bank-Guthaben speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    public boolean einzahlen(Player player, double betrag) {
        EconomyManager eco = economy();
        if (eco == null) return false;
        if (eco.getBalance(player.getUniqueId()) < betrag) {
            return false;
        }
        if (!eco.withdraw(player.getUniqueId(), betrag)) {
            return false;
        }
        setGuthaben(player.getUniqueId(), getGuthaben(player.getUniqueId()) + betrag);
        return true;
    }

    public boolean auszahlen(Player player, double betrag) {
        double guthaben = getGuthaben(player.getUniqueId());
        if (guthaben < betrag) {
            return false;
        }
        EconomyManager eco = economy();
        if (eco == null) return false;
        setGuthaben(player.getUniqueId(), guthaben - betrag);
        eco.deposit(player.getUniqueId(), betrag);
        return true;
    }

    public void addZinsen(UUID uuid, double betrag) {
        setGuthaben(uuid, getGuthaben(uuid) + betrag);
    }

    /**
     * Wendet Zinsen auf ALLE Konten mit Guthaben > 0 an - direkt über die
     * Datenbank, nicht nur über den Cache, damit auch Offline-Spieler Zinsen
     * bekommen (der Cache enthält nur Konten, die in dieser Session schon
     * mal angefasst wurden). Gibt zurück, wie viel jeder Spieler bekommen
     * hat, für die Chat-Benachrichtigung von Online-Spielern.
     */
    public Map<UUID, Double> applyInterestToAll(double percent) {
        Map<UUID, Double> gains = new HashMap<>();
        double max = plugin.getConfig().getDouble("bank.max-kontostand", -1.0);
        String selectSql = "SELECT uuid, balance FROM bank_accounts WHERE balance > 0";
        try (Connection c = plugin.getDatabase().getConnection();
             java.sql.Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(selectSql)) {
            while (rs.next()) {
                UUID uuid = UUID.fromString(rs.getString("uuid"));
                double balance = rs.getDouble("balance");
                double zinsen = balance * (percent / 100.0);
                double newBalance = balance + zinsen;
                if (max > 0.0 && newBalance > max) newBalance = max;
                save(uuid, newBalance);
                cache.put(uuid, newBalance);
                gains.put(uuid, zinsen);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Zinsen anwenden fehlgeschlagen: " + e.getMessage());
        }
        return gains;
    }

    public void saveAll() {
        for (Map.Entry<UUID, Double> entry : cache.entrySet()) {
            save(entry.getKey(), entry.getValue());
        }
    }
}
