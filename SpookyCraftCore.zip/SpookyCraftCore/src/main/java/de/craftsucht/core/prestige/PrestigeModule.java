package de.craftsucht.core.prestige;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.jobs.JobData;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.jobs.PlayerData;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * /prestige - Wer einen Job auf Maximal-Level hat, kann ihn neu beginnen und bekommt dafuer dauerhaft mehr Job-Geld
 * (prestige.bonus-percent pro Stufe, hoechstens prestige.max) und Kristalle. Staende in prestige.yml.
 */
public class PrestigeModule implements Module, CommandExecutor, TabCompleter {

    private static PrestigeModule INSTANCE;

    /** Faktor fuer das Job-Geld dieses Jobs (1.0 ohne Prestige). */
    public static double jobMoneyMultiplier(Player p, String jobId) {
        PrestigeModule m = INSTANCE;
        if (m == null || jobId == null) return 1.0;
        try {
            return 1.0 + m.get(p.getUniqueId(), jobId) * m.bonus() / 100.0;
        } catch (RuntimeException e) {
            return 1.0;
        }
    }

    /** Summe aller Prestige-Stufen eines Spielers (fuer Erfolge und Titel). */
    public static int total(UUID id) {
        PrestigeModule m = INSTANCE;
        if (m == null) return 0;
        var sec = m.data.getConfigurationSection(id.toString());
        if (sec == null) return 0;
        int n = 0;
        for (String k : sec.getKeys(false)) n += sec.getInt(k);
        return n;
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public PrestigeModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "prestige";
    }

    @Override
    public void enable() {
        INSTANCE = this;
        file = new File(plugin.getDataFolder(), "prestige.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("prestige").setExecutor(this);
        plugin.getCommand("prestige").setTabCompleter(this);
    }

    @Override
    public void disable() {
        INSTANCE = null;
    }

    private double bonus() {
        return plugin.getConfig().getDouble("prestige.bonus-percent", 5);
    }

    private int max() {
        return Math.max(1, plugin.getConfig().getInt("prestige.max", 10));
    }

    private int get(UUID id, String job) {
        return data.getInt(id + "." + job.toLowerCase(Locale.ROOT), 0);
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("prestige.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private JobsModule jobs() {
        return plugin.getModuleManager().get("jobs") instanceof JobsModule jm ? jm : null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        JobsModule jm = jobs();
        if (jm == null) {
            plugin.getMessageUtil().send(p, "&cDie Jobs schlafen gerade.");
            return true;
        }
        PlayerData pd = jm.getPlayerDataManager().get(p.getUniqueId());
        if (args.length == 0) {
            plugin.getMessageUtil().sendRaw(p, "&8&l☠ &7Prestige &8(Job neu beginnen, dauerhaft &f+" + bonus() + "% &8pro Stufe)");
            for (String job : jm.getJobManager().getAvailableJobs()) {
                JobData d = pd.getOrCreateJob(job);
                int max = jm.getJobManager().getMaxLevelForJob(job);
                int pr = get(p.getUniqueId(), job);
                String state = d.getLevel() >= max ? "&a✔ bereit: &f/prestige " + job : "&7Level " + d.getLevel() + "/" + max;
                plugin.getMessageUtil().sendRaw(p, "&e" + jm.getJobManager().getJobDisplayName(job) + " &8- &d★" + pr + "&8/" + max() + " &8- " + state);
            }
            return true;
        }
        String job = args[0].toLowerCase(Locale.ROOT);
        if (!jm.getJobManager().isValidJob(job)) {
            plugin.getMessageUtil().send(p, "&cDiesen Job kennen die Geister nicht. &7Siehe &f/prestige");
            return true;
        }
        JobData d = pd.getOrCreateJob(job);
        int maxLevel = jm.getJobManager().getMaxLevelForJob(job);
        if (d.getLevel() < maxLevel) {
            plugin.getMessageUtil().send(p, "&cDafür brauchst du Level &f" + maxLevel + "&c in diesem Job (du hast &f" + d.getLevel() + "&c).");
            return true;
        }
        int now = get(p.getUniqueId(), job);
        if (now >= max()) {
            plugin.getMessageUtil().send(p, "&cDu hast die höchste Prestige-Stufe (&f" + max() + "&c) schon erreicht.");
            return true;
        }
        if (args.length < 2 || !args[1].equalsIgnoreCase("bestaetigen")) {
            plugin.getMessageUtil().send(p, "&c&lAchtung: &cDein Job geht zurück auf Level 1. Du bekommst dafür dauerhaft &f+" + bonus()
                    + "% &cJob-Geld in diesem Job.");
            plugin.getMessageUtil().send(p, "&7Bestätigen mit: &f/prestige " + job + " bestaetigen");
            return true;
        }
        d.setLevel(1);
        d.setXp(0);
        jm.getPlayerDataManager().save(p.getUniqueId());
        data.set(p.getUniqueId() + "." + job, now + 1);
        save();
        long crystals = plugin.getConfig().getLong("prestige.reward-crystals", 5) * (now + 1);
        if (crystals > 0 && plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
            cm.getCrystals().add(p.getUniqueId(), crystals);
        }
        plugin.getMessageUtil().send(p, "&d★ Wiedergeboren! &7" + jm.getJobManager().getJobDisplayName(job) + " &7ist jetzt Prestige &d" + (now + 1)
                + "&7. Bonus: &f+" + (bonus() * (now + 1)) + "% &7Geld" + (crystals > 0 ? ", &f+" + crystals + " Kristalle" : "") + ".");
        p.playSound(p.getLocation(), "ui.toast.challenge_complete", 1f, 1f);
        Bukkit.broadcastMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                "&8[&d★&8] &f" + p.getName() + " &7ist jetzt &d" + jm.getJobManager().getJobDisplayName(job) + " &7Prestige &d" + (now + 1) + "&7!"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        JobsModule jm = jobs();
        if (jm == null) return List.of();
        if (a.length == 1) {
            List<String> out = new ArrayList<>();
            for (String j : jm.getJobManager().getAvailableJobs()) if (j.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(j);
            return out;
        }
        if (a.length == 2) return List.of("bestaetigen");
        return List.of();
    }
}
