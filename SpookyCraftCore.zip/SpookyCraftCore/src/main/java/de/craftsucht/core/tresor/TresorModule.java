package de.craftsucht.core.tresor;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.StaffCheck;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /tresor - grosse Endertruhe mit mehreren Seiten (je 45 Plaetze). Wie viele Seiten man hat, haengt vom Rang ab:
 * config tresor.default-pages, Rechte spookycraft.tresor.pages.<1-10>, Team: tresor.max-pages.
 * Inhalte liegen pro Spieler in plugins/.../tresor/<uuid>.yml. Zwei Spieler sehen dieselbe Seite immer im selben Fenster
 * (kein Duplizieren).
 */
public class TresorModule implements Module, CommandExecutor, Listener {

    private static final int MAX_PAGES = 10;
    private static final int SLOTS = 45;

    private static final class TresorHolder implements InventoryHolder {
        final UUID owner;
        final int page;
        final int pages;

        TresorHolder(UUID owner, int page, int pages) {
            this.owner = owner;
            this.page = page;
            this.pages = pages;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final class Account {
        final ItemStack[][] pages = new ItemStack[MAX_PAGES][];
    }

    private final SpookyCraftCore plugin;
    private File dir;
    private final Map<UUID, Account> accounts = new HashMap<>();
    private final Map<String, Inventory> open = new HashMap<>();

    public TresorModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "tresor";
    }

    @Override
    public void enable() {
        dir = new File(plugin.getDataFolder(), "tresor");
        dir.mkdirs();
        plugin.getCommand("tresor").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        for (Inventory inv : new ArrayList<>(open.values())) {
            if (inv.getHolder() instanceof TresorHolder h) {
                store(h, inv);
                for (var v : new ArrayList<>(inv.getViewers())) v.closeInventory();
            }
        }
        open.clear();
    }

    // ------------------------------------------------------------------ Daten

    private File fileOf(UUID id) {
        return new File(dir, id + ".yml");
    }

    private Account account(UUID id) {
        Account acc = accounts.get(id);
        if (acc != null) return acc;
        acc = new Account();
        File f = fileOf(id);
        if (f.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            for (int i = 0; i < MAX_PAGES; i++) {
                String b64 = y.getString("p" + (i + 1));
                if (b64 == null || b64.isEmpty()) continue;
                try {
                    acc.pages[i] = ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(b64));
                } catch (RuntimeException e) {
                    plugin.getLogger().severe("Tresor von " + id + " Seite " + (i + 1) + " ist unlesbar: " + e.getMessage());
                    File bad = new File(dir, id + "-defekt-seite" + (i + 1) + ".txt");
                    try {
                        java.nio.file.Files.writeString(bad.toPath(), b64);
                    } catch (IOException ignored) {
                        // nur Sicherung
                    }
                }
            }
        }
        accounts.put(id, acc);
        return acc;
    }

    private void saveAccount(UUID id) {
        Account acc = accounts.get(id);
        if (acc == null) return;
        YamlConfiguration y = new YamlConfiguration();
        for (int i = 0; i < MAX_PAGES; i++) {
            ItemStack[] items = acc.pages[i];
            boolean any = false;
            if (items != null) for (ItemStack it : items) if (it != null && !it.getType().isAir()) any = true;
            if (any) y.set("p" + (i + 1), Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(items)));
        }
        try {
            y.save(fileOf(id));
        } catch (IOException e) {
            plugin.getLogger().severe("Tresor von " + id + " konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private void store(TresorHolder h, Inventory inv) {
        Account acc = account(h.owner);
        ItemStack[] copy = new ItemStack[SLOTS];
        for (int i = 0; i < SLOTS; i++) {
            ItemStack it = inv.getItem(i);
            copy[i] = it == null ? null : it.clone();
        }
        acc.pages[h.page - 1] = copy;
        saveAccount(h.owner);
    }

    // ------------------------------------------------------------------ Seitenzahl nach Rang

    private int maxPages() {
        return Math.max(1, Math.min(MAX_PAGES, plugin.getConfig().getInt("tresor.max-pages", 6)));
    }

    private int pagesOf(Player p) {
        if (StaffCheck.isStaff(plugin, p)) return maxPages();
        int pages = Math.max(0, plugin.getConfig().getInt("tresor.default-pages", 1));
        for (int n = MAX_PAGES; n >= 1; n--) {
            if (p.hasPermission("spookycraft.tresor.pages." + n)) {
                pages = Math.max(pages, n);
                break;
            }
        }
        return Math.min(pages, maxPages());
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    // ------------------------------------------------------------------ Befehl

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length >= 1) {
            if (!StaffCheck.isStaff(plugin, p) && !p.hasPermission("spookycraft.tresor.admin")) {
                plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
                return true;
            }
            OfflinePlayer t = Bukkit.getPlayerExact(args[0]);
            if (t == null) t = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (t == null || (!t.hasPlayedBefore() && !t.isOnline())) {
                plugin.getMessageUtil().send(p, "&cDen Spieler kennen die Geister nicht.");
                return true;
            }
            int page = 1;
            if (args.length >= 2) {
                try {
                    page = Math.max(1, Math.min(maxPages(), Integer.parseInt(args[1])));
                } catch (NumberFormatException ignored) {
                    page = 1;
                }
            }
            open(p, t.getUniqueId(), page, maxPages());
            return true;
        }
        int pages = pagesOf(p);
        if (pages < 1) {
            plugin.getMessageUtil().send(p, "&cDein Rang hat keinen Tresor. Aufsteigen im &f/rangshop&c.");
            return true;
        }
        open(p, p.getUniqueId(), 1, pages);
        return true;
    }

    private void open(Player viewer, UUID owner, int page, int pages) {
        String key = owner + "|" + page;
        Inventory inv = open.get(key);
        if (inv == null) {
            inv = Bukkit.createInventory(new TresorHolder(owner, page, pages), 54, c("&5&l☠ &dTresor &8(" + page + "/" + pages + ")"));
            ItemStack[] saved = account(owner).pages[page - 1];
            if (saved != null) {
                for (int i = 0; i < SLOTS && i < saved.length; i++) inv.setItem(i, saved[i] == null ? null : saved[i].clone());
            }
            ItemStack pane = named(Material.BLACK_STAINED_GLASS_PANE, " ");
            for (int i = SLOTS; i < 54; i++) inv.setItem(i, pane);
            if (page > 1) inv.setItem(45, named(Material.ARROW, c("&7« Seite " + (page - 1))));
            if (page < pages) inv.setItem(53, named(Material.ARROW, c("&7Seite " + (page + 1) + " »")));
            inv.setItem(49, named(Material.ENDER_CHEST, c("&5Seite &f" + page + "&5 von &f" + pages)));
            open.put(key, inv);
        }
        viewer.openInventory(inv);
        viewer.playSound(viewer.getLocation(), "block.ender_chest.open", 0.6f, 1.0f);
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        it.setItemMeta(meta);
        return it;
    }

    // ------------------------------------------------------------------ Fenster-Ereignisse

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof TresorHolder h)) return;
        if (e.getRawSlot() >= SLOTS && e.getRawSlot() < 54) {
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player p)) return;
            int target = e.getRawSlot() == 45 && h.page > 1 ? h.page - 1 : e.getRawSlot() == 53 && h.page < h.pages ? h.page + 1 : 0;
            if (target > 0) {
                Bukkit.getScheduler().runTask(plugin, () -> open(p, h.owner, target, h.pages));
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof TresorHolder)) return;
        for (int raw : e.getRawSlots()) {
            if (raw >= SLOTS && raw < 54) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (!(inv.getHolder() instanceof TresorHolder h)) return;
        store(h, inv);
        if (inv.getViewers().size() <= 1) open.remove(h.owner + "|" + h.page);
    }
}
