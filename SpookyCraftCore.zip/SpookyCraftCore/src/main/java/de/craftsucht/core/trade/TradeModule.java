package de.craftsucht.core.trade;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sicherer Handel: /trade <spieler>, der andere tippt /trade accept. Beide legen Items in ihre Haelfte (links),
 * sehen das Angebot des anderen (rechts) und muessen mit dem gruenen Knopf bestaetigen. Aendert sich ein Angebot,
 * ist die Bestaetigung wieder weg. Bei Abbruch/Schliessen bekommt jeder seine Items zurueck.
 */
public class TradeModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static final int SIZE = 54;
    private static final int READY_OWN = 45;
    private static final int READY_OTHER = 53;
    private static final int CANCEL = 49;

    private record Request(UUID from, long expires) {
    }

    private static final class Session {
        final Player a;
        final Player b;
        Inventory ia;
        Inventory ib;
        boolean ra;
        boolean rb;
        boolean done;
        boolean closing;

        Session(Player a, Player b) {
            this.a = a;
            this.b = b;
        }

        Inventory invOf(Player p) {
            return p.equals(a) ? ia : ib;
        }

        Inventory otherInv(Player p) {
            return p.equals(a) ? ib : ia;
        }

        Player other(Player p) {
            return p.equals(a) ? b : a;
        }

        boolean ready(Player p) {
            return p.equals(a) ? ra : rb;
        }

        void setReady(Player p, boolean v) {
            if (p.equals(a)) ra = v;
            else rb = v;
        }
    }

    private static final class TradeHolder implements InventoryHolder {
        final Session session;
        final Player viewer;

        TradeHolder(Session s, Player viewer) {
            this.session = s;
            this.viewer = viewer;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, Request> requests = new ConcurrentHashMap<>();   // Ziel -> Anfrage
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();

    public TradeModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "trade";
    }

    @Override
    public void enable() {
        plugin.getCommand("trade").setExecutor(this);
        plugin.getCommand("trade").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        for (Session s : new ArrayList<>(sessions.values())) cancel(s, "&cDer Handel wurde abgebrochen (Neustart).");
        requests.clear();
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    /** Eigene Angebots-Slots: Spalten 0-3, Reihen 0-4. */
    private static boolean isOwnSlot(int slot) {
        return slot >= 0 && slot < 45 && slot % 9 <= 3;
    }

    private static int mirror(int ownSlot) {
        return ownSlot + 5;   // Spalten 5-8
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /trade <spieler> &7| &c/trade accept &7| &c/trade deny");
            return true;
        }
        if (args[0].equalsIgnoreCase("accept")) {
            Request r = requests.remove(p.getUniqueId());
            if (r == null || r.expires() < System.currentTimeMillis()) {
                plugin.getMessageUtil().send(p, "&cKein Geisterruf wartet auf dich.");
                return true;
            }
            Player from = Bukkit.getPlayer(r.from());
            if (from == null || sessions.containsKey(p.getUniqueId()) || sessions.containsKey(from.getUniqueId())) {
                plugin.getMessageUtil().send(p, "&cDer Handel ist nicht mehr möglich.");
                return true;
            }
            startSession(from, p);
            return true;
        }
        if (args[0].equalsIgnoreCase("deny")) {
            Request r = requests.remove(p.getUniqueId());
            plugin.getMessageUtil().send(p, r == null ? "&cKein Geisterruf wartet auf dich." : "&7Du hast den Handel ausgeschlagen.");
            if (r != null) {
                Player from = Bukkit.getPlayer(r.from());
                if (from != null) plugin.getMessageUtil().send(from, "&7" + p.getName() + " hat den Handel ausgeschlagen.");
            }
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[0]);
        if (t == null || t.equals(p)) {
            plugin.getMessageUtil().send(p, "&cDieser Spieler wandelt nicht in der Geisterwelt (oder du selbst).");
            return true;
        }
        if (sessions.containsKey(p.getUniqueId()) || sessions.containsKey(t.getUniqueId())) {
            plugin.getMessageUtil().send(p, "&cEiner von euch handelt bereits.");
            return true;
        }
        if (p.getWorld() != t.getWorld() || p.getLocation().distanceSquared(t.getLocation()) > 40 * 40) {
            plugin.getMessageUtil().send(p, "&cDie Seelen müssen sich für den Handel nahe sein (max. 40 Blöcke).");
            return true;
        }
        requests.put(t.getUniqueId(), new Request(p.getUniqueId(), System.currentTimeMillis() + 30_000L));
        plugin.getMessageUtil().send(p, "&aDein Ruf hallt zu " + t.getName() + ".");
        plugin.getMessageUtil().send(t, "&5☠ &f" + p.getName() + " &dmöchte mit dir handeln! &a/trade accept &7oder &c/trade deny &7(30 Sek.)");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = TabCompleteUtil.onlinePlayers(args[0]);
            out.addAll(TabCompleteUtil.filter(args[0], "accept", "deny"));
            return out;
        }
        return Collections.emptyList();
    }

    // ------------------------------------------------------------------ Sitzung

    private void startSession(Player a, Player b) {
        Session s = new Session(a, b);
        s.ia = Bukkit.createInventory(new TradeHolder(s, a), SIZE, c("&5☠ &dHandel mit " + b.getName()));
        s.ib = Bukkit.createInventory(new TradeHolder(s, b), SIZE, c("&5☠ &dHandel mit " + a.getName()));
        sessions.put(a.getUniqueId(), s);
        sessions.put(b.getUniqueId(), s);
        refresh(s);
        a.openInventory(s.ia);
        b.openInventory(s.ib);
    }

    private ItemStack named(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(c(name));
        if (lore.length > 0) {
            List<String> l = new ArrayList<>();
            for (String x : lore) l.add(c(x));
            meta.setLore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    /** Zeichnet Trennlinie, Knoepfe und das Angebot des anderen in beide Fenster neu. */
    private void refresh(Session s) {
        for (Player p : new Player[]{s.a, s.b}) {
            Inventory mine = s.invOf(p);
            Inventory theirs = s.otherInv(p);
            ItemStack divider = named(Material.PURPLE_STAINED_GLASS_PANE, " ");
            for (int row = 0; row < 5; row++) mine.setItem(row * 9 + 4, divider);
            for (int slot = 0; slot < 45; slot++) {
                if (isOwnSlot(slot)) {
                    ItemStack other = theirs.getItem(slot);
                    mine.setItem(mirror(slot), other == null ? null : other.clone());
                }
            }
            ItemStack filler = named(Material.BLACK_STAINED_GLASS_PANE, " ");
            for (int i = 45; i < 54; i++) mine.setItem(i, filler);
            boolean me = s.ready(p);
            boolean they = s.ready(s.other(p));
            mine.setItem(READY_OWN, me
                    ? named(Material.LIME_CONCRETE, "&a✔ Du hast bestätigt", "&7Klicken zum Zurücknehmen")
                    : named(Material.RED_CONCRETE, "&c✖ Noch nicht bestätigt", "&7Klicken zum Bestätigen"));
            mine.setItem(READY_OTHER, they
                    ? named(Material.LIME_CONCRETE, "&a✔ " + s.other(p).getName() + " hat bestätigt")
                    : named(Material.RED_CONCRETE, "&c✖ " + s.other(p).getName() + " wartet noch"));
            mine.setItem(CANCEL, named(Material.BARRIER, "&cHandel abbrechen"));
        }
    }

    private void resetReady(Session s) {
        s.ra = false;
        s.rb = false;
    }

    private void giveItems(Player to, List<ItemStack> items) {
        for (ItemStack it : items) {
            if (it == null || it.getType().isAir()) continue;
            Map<Integer, ItemStack> left = to.getInventory().addItem(it);
            for (ItemStack l : left.values()) to.getWorld().dropItemNaturally(to.getLocation(), l);
        }
    }

    private List<ItemStack> takeOffer(Inventory inv) {
        List<ItemStack> out = new ArrayList<>();
        for (int slot = 0; slot < 45; slot++) {
            if (!isOwnSlot(slot)) continue;
            ItemStack it = inv.getItem(slot);
            if (it != null && !it.getType().isAir()) out.add(it.clone());
            inv.setItem(slot, null);
        }
        return out;
    }

    private void closeIfTrade(Player p, Session s) {
        if (p.isOnline() && p.getOpenInventory().getTopInventory().getHolder() instanceof TradeHolder th && th.session == s) {
            p.closeInventory();
        }
    }

    private void finish(Session s) {
        if (s.done || s.closing) return;
        s.done = true;
        sessions.remove(s.a.getUniqueId());
        sessions.remove(s.b.getUniqueId());
        List<ItemStack> fromA = takeOffer(s.ia);
        List<ItemStack> fromB = takeOffer(s.ib);
        closeIfTrade(s.a, s);
        closeIfTrade(s.b, s);
        giveItems(s.b, fromA);
        giveItems(s.a, fromB);
        for (Player p : new Player[]{s.a, s.b}) {
            p.playSound(p.getLocation(), "entity.player.levelup", 0.8f, 1.2f);
            plugin.getMessageUtil().send(p, "&5☠ &dDer Handel ist besiegelt – die Geister sind zufrieden!");
        }
    }

    private void cancel(Session s, String reason) {
        if (s.done) return;
        s.done = true;
        sessions.remove(s.a.getUniqueId());
        sessions.remove(s.b.getUniqueId());
        List<ItemStack> backA = takeOffer(s.ia);
        List<ItemStack> backB = takeOffer(s.ib);
        closeIfTrade(s.a, s);
        closeIfTrade(s.b, s);
        giveItems(s.a, backA);
        giveItems(s.b, backB);
        if (reason != null) {
            if (s.a.isOnline()) plugin.getMessageUtil().send(s.a, reason);
            if (s.b.isOnline()) plugin.getMessageUtil().send(s.b, reason);
        }
    }

    // ------------------------------------------------------------------ Events

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!(e.getView().getTopInventory().getHolder() instanceof TradeHolder h)) return;
        Session s = h.session;
        if (s.done || s.closing) {
            e.setCancelled(true);
            return;
        }
        if (e.getClick() == ClickType.DOUBLE_CLICK || e.getClick() == ClickType.CREATIVE) {
            e.setCancelled(true);
            return;
        }
        Inventory top = e.getView().getTopInventory();
        if (e.getClickedInventory() == top) {
            int slot = e.getSlot();
            if (isOwnSlot(slot)) {
                scheduleSync(s);
                return;   // normal erlaubt
            }
            e.setCancelled(true);
            if (slot == READY_OWN) {
                s.setReady(p, !s.ready(p));
                refresh(s);
                if (s.ra && s.rb) finish(s);
            } else if (slot == CANCEL) {
                cancel(s, "&c" + p.getName() + " hat den Handel abgebrochen.");
            }
            return;
        }
        // Klick im eigenen Inventar unten
        if (e.isShiftClick()) {
            e.setCancelled(true);
            ItemStack moving = e.getCurrentItem();
            if (moving == null || moving.getType().isAir()) return;
            Inventory mine = s.invOf(p);
            for (int slot = 0; slot < 45; slot++) {
                if (isOwnSlot(slot) && (mine.getItem(slot) == null || mine.getItem(slot).getType().isAir())) {
                    mine.setItem(slot, moving.clone());
                    e.setCurrentItem(null);
                    scheduleSync(s);
                    return;
                }
            }
            return;
        }
        scheduleSync(s);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof TradeHolder h)) return;
        int topSize = e.getView().getTopInventory().getSize();
        for (int raw : e.getRawSlots()) {
            if (raw < topSize && !isOwnSlot(raw)) {
                e.setCancelled(true);
                return;
            }
        }
        scheduleSync(h.session);
    }

    private void scheduleSync(Session s) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (s.done) return;
            resetReady(s);
            refresh(s);
        });
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof TradeHolder h)) return;
        Session s = h.session;
        if (s.done || s.closing) return;
        s.closing = true;   // nicht innerhalb des Close-Events weiter schliessen: im naechsten Tick abbrechen
        resetReady(s);
        Bukkit.getScheduler().runTask(plugin, () -> cancel(s, "&cDer Handel wurde abgebrochen."));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        requests.remove(e.getPlayer().getUniqueId());
        requests.values().removeIf(r -> r.from().equals(e.getPlayer().getUniqueId()));
        Session s = sessions.get(e.getPlayer().getUniqueId());
        if (s != null) cancel(s, "&cDer Handel wurde abgebrochen.");
    }
}
