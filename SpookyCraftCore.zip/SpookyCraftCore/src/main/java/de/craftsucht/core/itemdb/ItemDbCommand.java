package de.craftsucht.core.itemdb;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.List;

public class ItemDbCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final ItemDbManager manager;

    public ItemDbCommand(SpookyCraftCore plugin, ItemDbManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }

        if (args.length == 0) {
            sendUsage(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "add" -> handleAdd(player);
            case "search" -> handleSearch(player, args);
            case "see" -> handleSee(player);
            default -> sendUsage(player);
        }
        return true;
    }

    private void handleAdd(Player player) {
        if (!player.isOp() && !player.hasPermission("itemdb.add")) {
            plugin.getMessageUtil().send(player, "&cDu hast keine Berechtigung, Items hinzuzufügen.");
            return;
        }

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            plugin.getMessageUtil().send(player, "&cDu musst ein Item in der Hand halten.");
            return;
        }

        ItemStack single = hand.clone();
        single.setAmount(1);

        String displayName;
        if (single.hasItemMeta() && single.getItemMeta().hasDisplayName()) {
            displayName = single.getItemMeta().getDisplayName();
        } else {
            displayName = prettifyMaterialName(single.getType().name());
        }

        boolean success = manager.addItem(displayName, single, player.getName());
        if (success) {
            plugin.getMessageUtil().send(player, "&aItem &f" + displayName + " &awurde zur Datenbank hinzugefügt.");
        } else {
            plugin.getMessageUtil().send(player, "&cItem konnte nicht gespeichert werden. Siehe Konsole für Details.");
        }
    }

    private void handleSearch(Player player, String[] args) {
        if (!player.isOp() && !player.hasPermission("itemdb.use")) {
            plugin.getMessageUtil().send(player, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        if (args.length < 2) {
            plugin.getMessageUtil().send(player, "&cNutzung: /db search <name>");
            return;
        }
        String query = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

        List<DBEntry> results = manager.search(query);
        if (results.isEmpty()) {
            plugin.getMessageUtil().send(player, "&eKeine Items gefunden für: " + query);
            return;
        }
        player.openInventory(GuiBuilder.build(results, 0, "&8Suche: " + query));
    }

    private void handleSee(Player player) {
        if (!player.isOp() && !player.hasPermission("itemdb.use")) {
            plugin.getMessageUtil().send(player, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        List<DBEntry> all = manager.getAll();
        if (all.isEmpty()) {
            plugin.getMessageUtil().send(player, "&eDie Datenbank ist noch leer.");
            return;
        }
        player.openInventory(GuiBuilder.build(all, 0, "&8Item-Datenbank"));
    }

    private void sendUsage(Player player) {
        plugin.getMessageUtil().sendRaw(player, "&6--- ItemDB ---");
        plugin.getMessageUtil().sendRaw(player, "&e/db add &7- Item aus der Hand hinzufügen");
        plugin.getMessageUtil().sendRaw(player, "&e/db search <name> &7- Items durchsuchen");
        plugin.getMessageUtil().sendRaw(player, "&e/db see &7- Alle Items ansehen");
    }

    private String prettifyMaterialName(String raw) {
        String[] parts = raw.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return TabCompleteUtil.filter(args[0], "add", "search", "see");
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("search")) {
            return manager.getKnownWords(args[args.length - 1]);
        }
        return Collections.emptyList();
    }
}
