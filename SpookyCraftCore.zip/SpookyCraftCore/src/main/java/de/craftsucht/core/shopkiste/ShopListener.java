package de.craftsucht.core.shopkiste;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.WallSign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Schild-Erstellung, Klicks auf Shop-Schilder, Anzahl-Menü und Schutz der Shopkisten. */
public class ShopListener implements Listener {

    private final SpookyCraftCore plugin;
    private final ShopRepository repo;
    private final ShopService service;

    public ShopListener(SpookyCraftCore plugin, ShopRepository repo, ShopService service) {
        this.plugin = plugin;
        this.repo = repo;
        this.service = service;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    private static String clean(String s) {
        return s == null ? "" : ChatColor.stripColor(s).trim();
    }

    public static boolean isContainer(Block b) {
        Material m = b.getType();
        return m == Material.CHEST || m == Material.TRAPPED_CHEST || m == Material.BARREL;
    }

    /** Kiste, an der das Schild hängt (bevorzugt die Wand, an der es befestigt ist). */
    public static Block findContainer(Block signBlock) {
        BlockData data = signBlock.getBlockData();
        if (data instanceof WallSign wall) {
            Block attached = signBlock.getRelative(wall.getFacing().getOppositeFace());
            if (isContainer(attached)) return attached;
        }
        for (BlockFace face : new BlockFace[]{BlockFace.DOWN, BlockFace.UP, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block n = signBlock.getRelative(face);
            if (isContainer(n)) return n;
        }
        return null;
    }

    private boolean isShopBlock(Block b) {
        return repo.atSign(b) != null || repo.atContainer(b) != null;
    }

    // ------------------------------------------------------------------ Shop erstellen (Schild beschriften)

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    @SuppressWarnings("deprecation")
    public void onSignChange(SignChangeEvent event) {
        String line0 = clean(event.getLine(0));
        String line1 = clean(event.getLine(1));
        String line2 = clean(event.getLine(2));
        String line3 = clean(event.getLine(3));

        int amount;
        try {
            amount = Integer.parseInt(line1);
        } catch (NumberFormatException e) {
            return; // kein Shop-Schild
        }
        double[] prices = ShopService.parsePrices(line2);
        if (prices == null) return; // kein Shop-Schild

        Player player = event.getPlayer();
        Block signBlock = event.getBlock();
        Block container = findContainer(signBlock);
        if (container == null) {
            msg(player, "&cFür einen Shop muss das Schild direkt an einer Kiste oder einem Fass hängen.");
            return;
        }
        if (amount < 1 || amount > ShopService.MAX_AMOUNT) {
            msg(player, "&cDie Menge (Zeile 2) muss zwischen 1 und " + ShopService.MAX_AMOUNT + " liegen.");
            event.setCancelled(true);
            return;
        }
        ShopRecord existing = repo.atContainer(container);
        if (existing != null) {
            msg(player, "&cDiese Kiste ist bereits ein Shop.");
            event.setCancelled(true);
            return;
        }

        // Besitzer: leer = du selbst; fremder Name nur für Admins
        UUID ownerUuid = player.getUniqueId();
        String ownerName = player.getName();
        if (!line0.isEmpty() && !line0.equalsIgnoreCase(player.getName()) && service.isAdmin(player)) {
            OfflinePlayer other = Bukkit.getOfflinePlayer(line0);
            ownerUuid = other.getUniqueId();
            ownerName = other.getName() != null ? other.getName() : line0;
        }

        // Item: "?" oder leer = erstes Item aus der Kiste, sonst Item-Name
        ItemStack template = null;
        if (line3.isEmpty() || line3.equals("?")) {
            if (container.getState() instanceof Container c) {
                for (ItemStack stack : c.getInventory().getStorageContents()) {
                    if (stack != null && !stack.getType().isAir()) {
                        template = stack.clone();
                        break;
                    }
                }
            }
            if (template == null) {
                msg(player, "&cLege das Item zuerst in die Kiste (oder schreibe den Item-Namen in Zeile 4).");
                event.setCancelled(true);
                return;
            }
        } else {
            Material material = Material.matchMaterial(line3.replace(' ', '_'));
            if (material == null || !material.isItem() || material.isAir()) {
                msg(player, "&cUnbekanntes Item: &f" + line3 + "&c. Nutze den englischen Namen (z.B. DIAMOND) oder &f?&c.");
                event.setCancelled(true);
                return;
            }
            template = new ItemStack(material);
        }
        template.setAmount(1);

        ShopRecord shop = repo.insert(signBlock.getWorld().getName(), signBlock, container, ownerUuid, ownerName, template,
                amount, prices[0], prices[1]);
        if (shop == null) {
            msg(player, "&cDer Shop konnte nicht gespeichert werden.");
            event.setCancelled(true);
            return;
        }
        event.setLine(0, ownerName);
        event.setLine(1, String.valueOf(amount));
        event.setLine(2, ShopService.priceLine(prices[0], prices[1]));
        event.setLine(3, ShopService.signItemLine(template));
        msg(player, "&aShopkiste erstellt: &f" + amount + "x " + ShopService.itemName(template)
                + (prices[0] >= 0 ? " &7| Kauf $" + ShopService.fmt(prices[0]) : "")
                + (prices[1] >= 0 ? " &7| Ankauf $" + ShopService.fmt(prices[1]) : ""));
    }

    // ------------------------------------------------------------------ Klicks auf Schild / Kiste

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.LEFT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || repo.isEmpty()) return;
        Player player = event.getPlayer();

        if (Tag.SIGNS.isTagged(block.getType())) {
            ShopRecord shop = repo.atSign(block);
            if (shop == null) return;
            boolean owner = shop.owner().equals(player.getUniqueId());
            if (action == Action.LEFT_CLICK_BLOCK) {
                if (owner || (service.isAdmin(player) && player.isSneaking())) return; // Besitzer/Admin darf das Schild abbauen
                event.setCancelled(true);
                service.transact(player, shop, false, shop.amount()); // Linksklick = verkaufen
                return;
            }
            event.setCancelled(true);
            if (player.isSneaking()) {
                openMenu(player, shop, shop.amount());
            } else {
                service.transact(player, shop, true, shop.amount()); // Rechtsklick = kaufen
            }
            return;
        }

        if (action == Action.RIGHT_CLICK_BLOCK) {
            ShopRecord shop = repo.atContainer(block);
            if (shop != null && !shop.owner().equals(player.getUniqueId()) && !service.isAdmin(player)) {
                event.setCancelled(true);
                msg(player, "&cDas ist die Shopkiste von &f" + shop.ownerName() + "&c. Rechtsklick aufs Schild zum Kaufen, Linksklick zum Verkaufen.");
            }
        }
    }

    // ------------------------------------------------------------------ Schutz

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (repo.isEmpty()) return;
        Block block = event.getBlock();
        ShopRecord shop = repo.atSign(block);
        if (shop == null) shop = repo.atContainer(block);
        if (shop == null) return;
        Player player = event.getPlayer();
        if (!shop.owner().equals(player.getUniqueId()) && !service.isAdmin(player)) {
            event.setCancelled(true);
            msg(player, "&cDas gehört zu der Shopkiste von &f" + shop.ownerName() + "&c.");
            return;
        }
        repo.delete(shop);
        msg(player, "&eShopkiste von &f" + shop.ownerName() + " &eentfernt.");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (repo.isEmpty()) return;
        Block placed = event.getBlockPlaced();
        if (placed.getType() != Material.CHEST && placed.getType() != Material.TRAPPED_CHEST) return;
        Player player = event.getPlayer();
        for (BlockFace face : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block neighbour = placed.getRelative(face);
            if (neighbour.getType() != placed.getType()) continue;
            ShopRecord shop = repo.atContainer(neighbour);
            if (shop != null && !shop.owner().equals(player.getUniqueId()) && !service.isAdmin(player)) {
                event.setCancelled(true);
                msg(player, "&cDu kannst keine Kiste an die Shopkiste von &f" + shop.ownerName() + " &cbauen.");
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (!repo.isEmpty()) event.blockList().removeIf(this::isShopBlock);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (!repo.isEmpty()) event.blockList().removeIf(this::isShopBlock);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (!repo.isEmpty() && event.getBlocks().stream().anyMatch(this::isShopBlock)) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (!repo.isEmpty() && event.getBlocks().stream().anyMatch(this::isShopBlock)) event.setCancelled(true);
    }

    /** Trichter dürfen keine Items aus Shopkisten ziehen oder hineinlegen. */
    @EventHandler(ignoreCancelled = true)
    public void onHopper(InventoryMoveItemEvent event) {
        if (repo.isEmpty()) return;
        if (isShopInventory(event.getSource()) || isShopInventory(event.getDestination())) event.setCancelled(true);
    }

    private boolean isShopInventory(Inventory inv) {
        org.bukkit.Location loc = inv.getLocation();
        return loc != null && repo.atContainer(loc.getBlock()) != null;
    }

    // ------------------------------------------------------------------ Menü "Anzahl wählen"

    private static ItemStack button(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        List<String> colored = new ArrayList<>();
        for (String line : lore) colored.add(ChatColor.translateAlternateColorCodes('&', line));
        meta.setLore(colored);
        stack.setItemMeta(meta);
        return stack;
    }

    private void openMenu(Player player, ShopRecord shop, int count) {
        count = Math.max(1, Math.min(ShopService.MAX_AMOUNT, count));
        Inventory inv = Bukkit.createInventory(new ShopMenuHolder(shop, count), 27,
                ChatColor.translateAlternateColorCodes('&', "&8Anzahl wählen"));
        ItemStack pane = button(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);

        inv.setItem(10, button(Material.RED_STAINED_GLASS_PANE, "&c-64"));
        inv.setItem(11, button(Material.RED_STAINED_GLASS_PANE, "&c-10"));
        inv.setItem(12, button(Material.RED_STAINED_GLASS_PANE, "&c-1"));
        inv.setItem(14, button(Material.LIME_STAINED_GLASS_PANE, "&a+1"));
        inv.setItem(15, button(Material.LIME_STAINED_GLASS_PANE, "&a+10"));
        inv.setItem(16, button(Material.LIME_STAINED_GLASS_PANE, "&a+64"));

        ItemStack display = shop.item().clone();
        display.setAmount(Math.min(64, count));
        ItemMeta meta = display.getItemMeta();
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Anzahl: &f" + count));
        if (shop.canBuy()) {
            lore.add(ChatColor.translateAlternateColorCodes('&', "&aKaufen: &f$" + ShopService.fmt(ShopService.round2(shop.buy() * count / shop.amount()))));
        }
        if (shop.canSell()) {
            lore.add(ChatColor.translateAlternateColorCodes('&', "&6Verkaufen: &f$" + ShopService.fmt(ShopService.round2(shop.sell() * count / shop.amount()))));
        }
        meta.setLore(lore);
        display.setItemMeta(meta);
        inv.setItem(13, display);

        if (shop.canBuy()) inv.setItem(21, button(Material.LIME_CONCRETE, "&aKaufen", "&7" + count + " Stück kaufen"));
        inv.setItem(22, button(Material.BARRIER, "&cSchließen"));
        if (shop.canSell()) inv.setItem(23, button(Material.ORANGE_CONCRETE, "&6Verkaufen", "&7" + count + " Stück verkaufen"));
        player.openInventory(inv);
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ShopMenuHolder) event.setCancelled(true);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof ShopMenuHolder holder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getView().getTopInventory().getSize()) return;

        ShopRecord shop = repo.allBySign().get(ShopRepository.key(holder.getShop().world(), holder.getShop().sx(),
                holder.getShop().sy(), holder.getShop().sz()));
        if (shop == null) {
            player.closeInventory();
            msg(player, "&cDieser Shop existiert nicht mehr.");
            return;
        }
        int count = holder.getCount();
        switch (slot) {
            case 10 -> openMenu(player, shop, count - 64);
            case 11 -> openMenu(player, shop, count - 10);
            case 12 -> openMenu(player, shop, count - 1);
            case 14 -> openMenu(player, shop, count + 1);
            case 15 -> openMenu(player, shop, count + 10);
            case 16 -> openMenu(player, shop, count + 64);
            case 21 -> {
                if (shop.canBuy()) {
                    player.closeInventory();
                    service.transact(player, shop, true, count);
                }
            }
            case 23 -> {
                if (shop.canSell()) {
                    player.closeInventory();
                    service.transact(player, shop, false, count);
                }
            }
            case 22 -> player.closeInventory();
            default -> {
            }
        }
    }
}
