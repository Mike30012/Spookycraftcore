package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Spielermarkt-Logik nach OPSUCHT-Vorbild:
 * - Kaufaufträge: Geld wird sofort in Treuhand genommen, andere Spieler verkaufen hinein.
 * - Verkaufsangebote: Items werden sofort in Treuhand genommen, andere Spieler kaufen daraus.
 * - Gekaufte/zurückgegebene Items landen im Abholungs-Lager (/markt abholen) und gehen bei vollem Inventar nicht verloren.
 * - Passende Gegenangebote werden beim Erstellen sofort ausgeführt (zum Preis des älteren Auftrags).
 * Es sind nur Items ohne Zusatzdaten handelbar (keine verzauberten/benannten Custom-Items).
 */
public class MarketService {

    private final SpookyCraftCore plugin;
    private final MarketRepository repo;
    private final ShopManager shop;

    public MarketService(SpookyCraftCore plugin, MarketRepository repo, ShopManager shop) {
        this.plugin = plugin;
        this.repo = repo;
        this.shop = shop;
    }

    // ------------------------------------------------------------------ Hilfen

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private EconomyManager eco() {
        EconomyModule module = (EconomyModule) plugin.getModuleManager().get("economy");
        return module != null ? module.getManager() : null;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    public static double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    public static String fmt(double value) {
        return String.format(Locale.GERMANY, "%,.2f", value);
    }

    public static String name(Material material) {
        StringBuilder sb = new StringBuilder();
        for (String part : material.name().toLowerCase().split("_")) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    /** Mindestpreis pro Stück laut config (markt.min-prices), 0 = keiner. Gilt für Kaufaufträge UND Verkaufsangebote. */
    public double minPriceOf(Material material) {
        String n = material.name();
        double floor = cfg().getDouble("markt.min-prices." + n); // ohne Default-Parameter: nutzt auch die Jar-Defaults
        if (floor <= 0 && n.endsWith("_SPAWN_EGG")) floor = cfg().getDouble("markt.min-prices.SPAWN_EGG_DEFAULT");
        return Math.max(0.0, floor);
    }

    /**
     * Preis pro Stück, zu dem der SERVER das Item sofort verkauft (0 = kein Server-Angebot).
     * Reihenfolge: config markt.server-prices -> buy-price aus shop.yml -> Mindestpreis (z.B. Besonderes).
     */
    public double serverPriceOf(Material material) {
        if (!cfg().getBoolean("markt.server-sofortkauf", true)) return 0.0;
        if (!shop.isTradable(material)) return 0.0;
        double price = cfg().getDouble("markt.server-prices." + material.name());
        if (price <= 0) price = shop.getServerBuyPrice(material);
        if (price <= 0) price = minPriceOf(material);
        return Math.max(0.0, price);
    }

    /** Günstigster Kaufpreis für den Spieler: Server-Preis oder günstigstes fremdes Angebot (0 = nichts verfügbar). */
    public double cheapestBuyPrice(UUID viewer, Material material) {
        double best = serverPriceOf(material);
        for (MarketOrder offer : repo.getOrders(material, false)) {
            if (offer.owner().equals(viewer)) continue;
            if (best <= 0 || offer.price() < best) best = offer.price();
            break; // Liste ist nach Preis sortiert
        }
        return best;
    }

    public boolean isTradable(Material material) {
        return shop.isTradable(material);
    }

    public static boolean isPlain(ItemStack stack, Material material) {
        return stack != null && stack.getType() == material && !stack.hasItemMeta();
    }

    public int countPlain(Player p, Material material) {
        int count = 0;
        for (ItemStack stack : p.getInventory().getStorageContents()) {
            if (isPlain(stack, material)) count += stack.getAmount();
        }
        return count;
    }

    private boolean removePlain(Player p, Material material, int amount) {
        if (countPlain(p, material) < amount) return false;
        ItemStack[] contents = p.getInventory().getStorageContents();
        int left = amount;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack stack = contents[i];
            if (!isPlain(stack, material)) continue;
            int take = Math.min(left, stack.getAmount());
            if (take == stack.getAmount()) {
                contents[i] = null;
            } else {
                stack.setAmount(stack.getAmount() - take);
            }
            left -= take;
        }
        p.getInventory().setStorageContents(contents);
        return true;
    }

    /** @return wie viele Items tatsächlich ins Inventar gepasst haben */
    private int giveToInventory(Player p, Material material, int amount) {
        int given = 0;
        int maxStack = Math.max(1, material.getMaxStackSize());
        while (given < amount) {
            int n = Math.min(maxStack, amount - given);
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(material, n));
            if (!left.isEmpty()) {
                int notAdded = 0;
                for (ItemStack stack : left.values()) notAdded += stack.getAmount();
                given += n - notAdded;
                break;
            }
            given += n;
        }
        return given;
    }

    private void notifyOwner(UUID owner, String text) {
        Player online = Bukkit.getPlayer(owner);
        if (online != null) msg(online, text);
    }

    private boolean validate(Player p, Material material, int amount, double price) {
        if (!shop.isTradable(material)) {
            msg(p, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return false;
        }
        // Wie bei OPSUCHT: kein Auftragslimit und keine Preisgrenzen (0 = unbegrenzt). Nur technische Mindestwerte.
        int maxAmount = cfg().getInt("markt.max-amount-per-order", 0);
        int cap = maxAmount > 0 ? maxAmount : 10_000_000;
        if (amount < 1 || amount > cap) {
            msg(p, "&cDie Menge muss zwischen 1 und " + cap + " liegen.");
            return false;
        }
        double minPrice = cfg().getDouble("markt.min-price", 0.01);
        double maxPrice = cfg().getDouble("markt.max-price", 0.0);
        if (price < minPrice || (maxPrice > 0 && price > maxPrice)) {
            msg(p, "&cUngültiger Preis pro Stück (mindestens $" + fmt(minPrice) + ").");
            return false;
        }
        double floor = minPriceOf(material);
        if (floor > 0 && price + 1e-9 < floor) {
            msg(p, "&cDer Mindestpreis für &f" + name(material) + " &cist &f$" + fmt(floor) + " &cpro Stück.");
            return false;
        }
        int maxOrders = cfg().getInt("markt.max-orders-per-player", 0);
        if (maxOrders > 0 && repo.countOrdersOf(p.getUniqueId()) >= maxOrders) {
            msg(p, "&cDu hast bereits die maximale Anzahl an Aufträgen (" + maxOrders + ").");
            return false;
        }
        return true;
    }

    /** 1 % (Standard) des Auftragswerts beim Erstellen eines Angebots. */
    private double creationFeeRate() {
        return Math.max(0.0, cfg().getDouble("markt.creation-fee-percent", 1.0)) / 100.0;
    }

    /** 2 % (Standard) beim Durchführen eines Kaufs - zahlt der Käufer zusätzlich, der Verkäufer bekommt den vollen Preis. */
    private double purchaseFeeRate() {
        return Math.max(0.0, cfg().getDouble("markt.purchase-fee-percent", 2.0)) / 100.0;
    }

    // ------------------------------------------------------------------ Aufträge erstellen

    public boolean createBuyOrder(Player p, Material material, int amount, double price) {
        price = round2(price);
        if (!validate(p, material, amount, price)) return false;
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        UUID uuid = p.getUniqueId();
        double pf = purchaseFeeRate();
        double cf = creationFeeRate();
        // Treuhand: Preis + 2 % Kaufgebühr werden sofort reserviert (wie bei OPSUCHT wird das Geld bei Erstellung abgebucht).
        double escrow = round2(amount * price * (1.0 + pf));
        double creationFeeMax = round2(amount * price * cf);
        if (eco.getBalance(uuid) + 1e-9 < escrow + creationFeeMax) {
            msg(p, "&cDir fehlen &f$" + fmt(escrow + creationFeeMax - eco.getBalance(uuid)) + "&c (Auftrag $" + fmt(escrow)
                    + " inkl. Kaufgebühr + max. $" + fmt(creationFeeMax) + " Erstellungsgebühr).");
            return false;
        }
        if (!eco.withdraw(uuid, escrow)) {
            msg(p, "&cDie Zahlung ist fehlgeschlagen.");
            return false;
        }

        int remaining = amount;
        double spent = 0;
        for (MarketOrder offer : repo.getOrders(material, false)) { // günstigste zuerst
            if (remaining <= 0 || offer.price() > price + 1e-9) break;
            if (offer.owner().equals(uuid)) continue;
            int take = Math.min(remaining, offer.remaining());
            double cost = round2(take * offer.price());
            double fee = round2(cost * pf);
            eco.deposit(offer.owner(), cost); // Verkäufer bekommt den vollen Preis
            double refund = round2(round2(take * price * (1.0 + pf)) - cost - fee); // Differenz zum Gebotspreis zurück
            if (refund > 0) eco.deposit(uuid, refund);
            repo.addPickup(uuid, material, take);
            repo.setRemaining(offer.id(), offer.remaining() - take);
            notifyOwner(offer.owner(), "&aDein Verkaufsangebot: &f" + take + "x " + name(material) + " &averkauft für &f$" + fmt(cost));
            spent += cost + fee;
            remaining -= take;
        }

        int bought = amount - remaining;
        if (bought > 0) {
            msg(p, "&a" + bought + "x " + name(material) + " sofort gekauft für &f$" + fmt(spent) + " &7(inkl. Gebühr, Abholen im Markt-Menü)");
        }
        if (remaining > 0) {
            double creationFee = round2(remaining * price * cf);
            if (creationFee > 0) eco.withdraw(uuid, creationFee);
            if (!repo.insert(uuid, p.getName(), material, true, price, remaining)) {
                eco.deposit(uuid, round2(remaining * price * (1.0 + pf)) + creationFee);
                msg(p, "&cDer Auftrag konnte nicht gespeichert werden. Dein Geld wurde zurückgegeben.");
                return bought > 0;
            }
            msg(p, "&aKaufauftrag erstellt: &f" + remaining + "x " + name(material) + " &afür &f$" + fmt(price) + " &apro Stück"
                    + " &7(Erstellungsgebühr $" + fmt(creationFee) + ")");
        }
        return true;
    }

    public boolean createSellOffer(Player p, Material material, int amount, double price) {
        price = round2(price);
        if (!validate(p, material, amount, price)) return false;
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        UUID uuid = p.getUniqueId();
        double cf = creationFeeRate();
        double creationFeeMax = round2(amount * price * cf);
        if (eco.getBalance(uuid) + 1e-9 < creationFeeMax) {
            msg(p, "&cFür die Erstellungsgebühr fehlen dir &f$" + fmt(creationFeeMax - eco.getBalance(uuid)) + "&c (1 % des Angebotswerts).");
            return false;
        }
        if (!removePlain(p, material, amount)) {
            msg(p, "&cDu hast nicht genug &f" + name(material) + " &c(ohne Verzauberung/Namen) im Inventar. Du brauchst " + amount + ".");
            return false;
        }

        int remaining = amount;
        double earned = 0;
        for (MarketOrder order : repo.getOrders(material, true)) { // höchster Preis zuerst
            if (remaining <= 0 || order.price() < price - 1e-9) break;
            if (order.owner().equals(uuid)) continue;
            int take = Math.min(remaining, order.remaining());
            double gain = round2(take * order.price());
            eco.deposit(uuid, gain);
            repo.addPickup(order.owner(), material, take);
            repo.setRemaining(order.id(), order.remaining() - take);
            notifyOwner(order.owner(), "&aDein Kaufauftrag: &f" + take + "x " + name(material) + " &agekauft für &f$" + fmt(gain)
                    + " &7(Abholen im Markt-Menü)");
            earned += gain;
            remaining -= take;
        }

        int sold = amount - remaining;
        if (sold > 0) {
            msg(p, "&a" + sold + "x " + name(material) + " sofort verkauft für &f$" + fmt(earned));
        }
        if (remaining > 0) {
            double creationFee = round2(remaining * price * cf);
            if (creationFee > 0 && !eco.withdraw(uuid, creationFee)) {
                repo.addPickup(uuid, material, remaining);
                msg(p, "&cDie Erstellungsgebühr konnte nicht bezahlt werden. Deine Items liegen im Abholungs-Lager.");
                return sold > 0;
            }
            if (!repo.insert(uuid, p.getName(), material, false, price, remaining)) {
                repo.addPickup(uuid, material, remaining);
                if (creationFee > 0) eco.deposit(uuid, creationFee);
                msg(p, "&cDas Angebot konnte nicht gespeichert werden. Deine Items liegen im Abholungs-Lager.");
                return sold > 0;
            }
            msg(p, "&aVerkaufsangebot erstellt: &f" + remaining + "x " + name(material) + " &afür &f$" + fmt(price) + " &apro Stück"
                    + " &7(Erstellungsgebühr $" + fmt(creationFee) + ")");
        }
        return true;
    }

    // ------------------------------------------------------------------ Direkt aus der Liste handeln

    /**
     * Sofortkauf: kauft immer zum günstigsten Preis - aus Spieler-Angeboten oder direkt vom Server (unbegrenzter Vorrat).
     * Server-Käufe landen direkt im Inventar (was nicht passt, im Abholen-Menü), Spieler-Angebote im Abholen-Menü.
     */
    public boolean buyInstant(Player p, Material material, int amount) {
        if (!shop.isTradable(material)) {
            msg(p, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return false;
        }
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        amount = Math.max(1, Math.min(amount, 2304));
        UUID uuid = p.getUniqueId();
        double serverPrice = serverPriceOf(material);
        List<MarketOrder> offers = repo.getOrders(material, false);

        int remaining = amount;
        int fromPlayers = 0;
        int fromServer = 0;
        double spent = 0;
        boolean noMoney = false;
        int index = 0;
        while (remaining > 0) {
            while (index < offers.size() && offers.get(index).owner().equals(uuid)) index++;
            MarketOrder offer = index < offers.size() ? offers.get(index) : null;
            boolean useOffer = offer != null && (serverPrice <= 0 || offer.price() <= serverPrice);
            if (useOffer) {
                int take = Math.min(remaining, offer.remaining());
                double cost = round2(take * offer.price());
                double fee = round2(cost * purchaseFeeRate());
                if (!eco.withdraw(uuid, cost + fee)) {
                    noMoney = true;
                    break;
                }
                eco.deposit(offer.owner(), cost);
                repo.addPickup(uuid, material, take);
                repo.setRemaining(offer.id(), offer.remaining() - take);
                notifyOwner(offer.owner(), "&aDein Verkaufsangebot: &f" + take + "x " + name(material) + " &averkauft für &f$" + fmt(cost));
                spent += cost + fee;
                remaining -= take;
                fromPlayers += take;
                index++;
            } else if (serverPrice > 0) {
                int affordable = (int) Math.floor((eco.getBalance(uuid) + 1e-9) / serverPrice);
                int take = Math.min(remaining, affordable);
                if (take <= 0) {
                    noMoney = true;
                    break;
                }
                double cost = round2(take * serverPrice);
                if (!eco.withdraw(uuid, cost)) {
                    noMoney = true;
                    break;
                }
                int given = giveToInventory(p, material, take);
                if (given < take) repo.addPickup(uuid, material, take - given);
                spent += cost;
                remaining -= take;
                fromServer += take;
                if (remaining > 0) { // nicht alles bezahlbar -> Schleife beenden
                    noMoney = true;
                    break;
                }
            } else {
                break;
            }
        }

        int bought = amount - remaining;
        if (bought > 0) {
            StringBuilder detail = new StringBuilder();
            if (fromServer > 0) detail.append(fromServer).append("x vom Server");
            if (fromPlayers > 0) {
                if (detail.length() > 0) detail.append(", ");
                detail.append(fromPlayers).append("x von Spielern (Abholen im Markt-Menü)");
            }
            msg(p, "&a" + bought + "x " + name(material) + " gekauft für &f$" + fmt(spent) + " &7(" + detail + ")");
        }
        if (remaining > 0) {
            if (noMoney) {
                msg(p, "&cDir fehlt Geld für " + remaining + "x " + name(material) + ".");
            } else {
                msg(p, "&cKein " + (bought > 0 ? "weiteres " : "") + "Angebot für " + name(material) + " verfügbar"
                        + (bought == 0 ? " &7- erstelle einen Kaufauftrag im Handelsmenü (Rechtsklick)." : "."));
            }
        }
        return bought > 0;
    }

    /** Kauft aus einem bestehenden Verkaufsangebot. */
    public boolean buyFromOffer(Player p, int offerId, int amount) {
        MarketOrder offer = repo.getOrder(offerId);
        if (offer == null || offer.buy()) {
            msg(p, "&cDieses Angebot gibt es nicht mehr.");
            return false;
        }
        EconomyManager eco = eco();
        if (eco == null) return false;
        UUID uuid = p.getUniqueId();
        if (offer.owner().equals(uuid)) {
            msg(p, "&cDu kannst nicht bei dir selbst kaufen.");
            return false;
        }
        int take = Math.min(Math.max(1, amount), offer.remaining());
        double cost = round2(take * offer.price());
        double fee = round2(cost * purchaseFeeRate());
        if (!eco.withdraw(uuid, cost + fee)) {
            msg(p, "&cDir fehlen &f$" + fmt(cost + fee - eco.getBalance(uuid)) + "&c (Preis $" + fmt(cost) + " + Gebühr $" + fmt(fee) + ").");
            return false;
        }
        eco.deposit(offer.owner(), cost); // Verkäufer bekommt den vollen Preis, die Gebühr geht an den Server
        repo.addPickup(uuid, offer.material(), take);
        repo.setRemaining(offer.id(), offer.remaining() - take);
        notifyOwner(offer.owner(), "&aDein Verkaufsangebot: &f" + take + "x " + name(offer.material()) + " &averkauft für &f$" + fmt(cost));
        msg(p, "&a" + take + "x " + name(offer.material()) + " gekauft für &f$" + fmt(cost + fee) + " &7(inkl. $" + fmt(fee) + " Gebühr, Abholen im Markt-Menü)");
        return true;
    }

    /** Verkauft Items aus dem Inventar in einen bestehenden Kaufauftrag. */
    public boolean sellToBuyOrder(Player p, int orderId, int amount) {
        MarketOrder order = repo.getOrder(orderId);
        if (order == null || !order.buy()) {
            msg(p, "&cDieser Auftrag existiert nicht mehr.");
            return false;
        }
        EconomyManager eco = eco();
        if (eco == null) return false;
        UUID uuid = p.getUniqueId();
        if (order.owner().equals(uuid)) {
            msg(p, "&cDu kannst nicht an dich selbst verkaufen.");
            return false;
        }
        int take = Math.min(Math.max(1, amount), order.remaining());
        take = Math.min(take, countPlain(p, order.material()));
        if (take <= 0) {
            msg(p, "&cDu hast kein &f" + name(order.material()) + " &c(ohne Verzauberung/Namen) im Inventar.");
            return false;
        }
        if (!removePlain(p, order.material(), take)) return false;
        double gain = round2(take * order.price());
        eco.deposit(uuid, gain);
        repo.addPickup(order.owner(), order.material(), take);
        repo.setRemaining(order.id(), order.remaining() - take);
        notifyOwner(order.owner(), "&aDein Kaufauftrag: &f" + take + "x " + name(order.material()) + " &agekauft für &f$" + fmt(gain)
                + " &7(Abholen im Markt-Menü)");
        msg(p, "&a" + take + "x " + name(order.material()) + " verkauft für &f$" + fmt(gain));
        return true;
    }

    /** Bricht einen eigenen Auftrag ab: Geld zurück bzw. Items ins Abholungs-Lager. */
    public boolean cancelOrder(Player p, int orderId) {
        MarketOrder order = repo.getOrder(orderId);
        if (order == null) {
            msg(p, "&cDieser Auftrag existiert nicht mehr.");
            return false;
        }
        if (!order.owner().equals(p.getUniqueId())) {
            msg(p, "&cDas ist nicht dein Auftrag.");
            return false;
        }
        repo.delete(orderId);
        if (order.buy()) {
            EconomyManager eco = eco();
            double refund = round2(order.remaining() * order.price() * (1.0 + purchaseFeeRate()));
            if (eco != null) eco.deposit(p.getUniqueId(), refund);
            msg(p, "&aKaufauftrag abgebrochen. Zurück: &f$" + fmt(refund));
        } else {
            repo.addPickup(p.getUniqueId(), order.material(), order.remaining());
            msg(p, "&aVerkaufsangebot abgebrochen. &f" + order.remaining() + "x " + name(order.material()) + " &aliegen zur Abholung bereit.");
        }
        return true;
    }

    // ------------------------------------------------------------------ Abholen

    /** @param only null = alles abholen. @return Anzahl der abgeholten Items */
    public int claim(Player p, Material only) {
        UUID uuid = p.getUniqueId();
        int total = 0;
        boolean full = false;
        for (Map.Entry<Material, Integer> entry : repo.getPickups(uuid).entrySet()) {
            if (only != null && entry.getKey() != only) continue;
            int given = giveToInventory(p, entry.getKey(), entry.getValue());
            if (given > 0) repo.removePickup(uuid, entry.getKey(), given);
            if (given < entry.getValue()) full = true;
            total += given;
        }
        if (total > 0) msg(p, "&a" + total + " Item(s) abgeholt.");
        if (full) msg(p, "&eDein Inventar ist voll - der Rest bleibt im Abholungs-Lager.");
        if (total == 0 && !full) msg(p, "&7Es liegt nichts zur Abholung bereit.");
        return total;
    }

    // ------------------------------------------------------------------ /sell (Schnellverkauf)

    /** Verkauft sofort an die höchsten Kaufaufträge. Nicht verkaufte Items gehen zurück ins Inventar. */
    public int quickSell(Player p, Material material, int amount) {
        if (!shop.isTradable(material)) {
            msg(p, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return 0;
        }
        EconomyManager eco = eco();
        if (eco == null) return 0;
        UUID uuid = p.getUniqueId();
        int toSell = Math.min(amount, countPlain(p, material));
        if (toSell <= 0) {
            msg(p, "&cDu hast kein &f" + name(material) + " &c(ohne Verzauberung/Namen) im Inventar.");
            return 0;
        }
        if (!removePlain(p, material, toSell)) return 0;

        int remaining = toSell;
        double earned = 0;
        for (MarketOrder order : repo.getOrders(material, true)) {
            if (remaining <= 0) break;
            if (order.owner().equals(uuid)) continue;
            int take = Math.min(remaining, order.remaining());
            double gain = round2(take * order.price());
            eco.deposit(uuid, gain);
            repo.addPickup(order.owner(), material, take);
            repo.setRemaining(order.id(), order.remaining() - take);
            notifyOwner(order.owner(), "&aDein Kaufauftrag: &f" + take + "x " + name(material) + " &agekauft für &f$" + fmt(gain)
                    + " &7(Abholen im Markt-Menü)");
            earned += gain;
            remaining -= take;
        }

        int sold = toSell - remaining;
        if (remaining > 0) {
            int back = giveToInventory(p, material, remaining);
            if (back < remaining) repo.addPickup(uuid, material, remaining - back);
        }
        if (sold > 0) {
            msg(p, "&a" + sold + "x " + name(material) + " verkauft für &f$" + fmt(earned));
        } else {
            msg(p, "&cFür &f" + name(material) + " &cgibt es gerade keine Kaufaufträge.");
        }
        return sold;
    }
}
