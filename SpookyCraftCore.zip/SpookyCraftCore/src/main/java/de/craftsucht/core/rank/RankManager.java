package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.sql.*;
import java.util.*;

/**
 * Minimal LuckPerms-style rank system: named ranks with a prefix, a weight
 * (for scoreboard/tab ordering) and a single parent for permission
 * inheritance. Each online player gets a PermissionAttachment recomputed
 * from their rank's own + inherited permissions.
 */
public class RankManager {

    private final SpookyCraftCore plugin;
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();

    public RankManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    /**
     * true = Raenge/Prefixe kommen von LuckPerms (Chat, Scoreboard, Tab, Staff-Checks).
     * Config rank.provider: auto (Standard: LuckPerms wenn installiert), luckperms, internal.
     */
    public boolean usesLuckPerms() {
        String mode = plugin.getConfig().getString("rank.provider", "auto").toLowerCase();
        if (mode.equals("internal")) return false;
        return org.bukkit.Bukkit.getPluginManager().isPluginEnabled("LuckPerms");
    }

    public void ensureDefaultRank() {
        if (getRank("default") == null) {
            createRank("default", "&7", 0, null);
        }
    }

    /**
     * Der Rang, den neue Spieler beim ersten Join automatisch bekommen -
     * konfigurierbar über config.yml (rank.default-rank), Standard "default".
     * So kann z.B. ein eigener Rang wie "spieler" statt dem eingebauten
     * "default" als Start-Rang genutzt werden, ohne Code-Änderung.
     */
    public String getDefaultRankName() {
        return plugin.getConfig().getString("rank.default-rank", "default").toLowerCase();
    }

    public boolean createRank(String name, String prefix, int weight, String parent) {
        String sql = "INSERT OR IGNORE INTO ranks (name, prefix, weight, parent) VALUES (?,?,?,?)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name.toLowerCase());
            ps.setString(2, prefix);
            ps.setInt(3, weight);
            ps.setString(4, parent);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Aktualisiert den Prefix eines bereits existierenden Rangs. WICHTIG:
     * createRank() nutzt INSERT OR IGNORE und tut bei einem bereits
     * existierenden Rang NICHTS - das war der Bug hinter /rank setprefix,
     * das bisher nie wirklich etwas geändert hat. Diese Methode hier macht
     * ein echtes UPDATE.
     */
    public boolean updatePrefix(String rankName, String newPrefix) {
        String sql = "UPDATE ranks SET prefix = ? WHERE name = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, newPrefix);
            ps.setString(2, rankName.toLowerCase());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /** Generisches Update für einen bereits existierenden Rang (Prefix, Gewicht, Elternrang). */
    public boolean updateRank(String name, String prefix, int weight, String parent) {
        String sql = "UPDATE ranks SET prefix = ?, weight = ?, parent = ? WHERE name = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, prefix);
            ps.setInt(2, weight);
            ps.setString(3, parent);
            ps.setString(4, name.toLowerCase());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Ändert NUR die Farbe eines Rang-Prefixes, Rest (Bold, Text) bleibt
     * gleich - z.B. "&4&lOwner" + "&b" -> "&b&lOwner". Wird von /prefix
     * genutzt, damit ein per Job/Hex gewählter Farbwert direkt die
     * Rang-Farbe umfärbt (betrifft dann ALLE mit diesem Rang).
     */
    public boolean setRankColorCode(String rankName, String newColorCode) {
        RankData rank = getRank(rankName);
        if (rank == null) return false;
        String prefix = rank.prefix() != null ? rank.prefix() : "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("&[0-9A-Fa-f]").matcher(prefix);
        String newPrefix = m.find() ? prefix.substring(0, m.start()) + newColorCode + prefix.substring(m.end())
                : newColorCode + prefix;
        return updatePrefix(rankName, newPrefix);
    }

    public boolean deleteRank(String name) {
        try (Connection c = plugin.getDatabase().getConnection()) {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM ranks WHERE name=?")) {
                ps.setString(1, name.toLowerCase());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM rank_permissions WHERE rank=?")) {
                ps.setString(1, name.toLowerCase());
                ps.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public RankData getRank(String name) {
        if (usesLuckPerms()) {
            try {
                Object[] g = LuckPermsBridge.group(name);
                return g == null ? null : new RankData((String) g[0], (String) g[1], (Integer) g[2], null);
            } catch (Throwable t) {
                return null;
            }
        }
        String sql = "SELECT name, prefix, weight, parent FROM ranks WHERE name=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name.toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new RankData(rs.getString("name"), rs.getString("prefix"), rs.getInt("weight"), rs.getString("parent"));
                }
            }
        } catch (SQLException ignored) {
        }
        return null;
    }

    public List<RankData> listRanks() {
        List<RankData> list = new ArrayList<>();
        String sql = "SELECT name, prefix, weight, parent FROM ranks ORDER BY weight DESC";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new RankData(rs.getString("name"), rs.getString("prefix"), rs.getInt("weight"), rs.getString("parent")));
            }
        } catch (SQLException ignored) {
        }
        return list;
    }

    /** Alte Rechte "craftsucht.*" heißen jetzt "spookycraft.*" - alte Eingaben werden automatisch umgeschrieben. */
    private static String normalize(String permission) {
        String p = permission.toLowerCase();
        return p.startsWith("craftsucht.") ? "spookycraft." + p.substring("craftsucht.".length()) : p;
    }

    /** Benennt bereits gespeicherte Rang-Rechte von craftsucht.* in spookycraft.* um (einmalig beim Start, harmlos bei Wiederholung). */
    public void migrateLegacyPermissions() {
        try (Connection c = plugin.getDatabase().getConnection()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE OR IGNORE rank_permissions SET permission = 'spookycraft.' || substr(permission, 12) WHERE permission LIKE 'craftsucht.%'")) {
                int moved = ps.executeUpdate();
                if (moved > 0) plugin.getLogger().info("[rank] " + moved + " Rang-Rechte von craftsucht.* auf spookycraft.* umgestellt.");
            }
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM rank_permissions WHERE permission LIKE 'craftsucht.%'")) {
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("[rank] Umstellung der alten Rechte fehlgeschlagen: " + e.getMessage());
        }
    }

    public void setPermission(String rank, String permission, boolean value) {
        String sql = "INSERT INTO rank_permissions (rank, permission, value) VALUES (?,?,?) " +
                "ON CONFLICT(rank, permission) DO UPDATE SET value=excluded.value";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, rank.toLowerCase());
            ps.setString(2, normalize(permission));
            ps.setInt(3, value ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }

    public void unsetPermission(String rank, String permission) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM rank_permissions WHERE rank=? AND permission=?")) {
            ps.setString(1, rank.toLowerCase());
            ps.setString(2, normalize(permission));
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }

    /** Own permissions of a single rank (no inheritance). */
    public Map<String, Boolean> getOwnPermissions(String rank) {
        Map<String, Boolean> perms = new LinkedHashMap<>();
        String sql = "SELECT permission, value FROM rank_permissions WHERE rank=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, rank.toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    perms.put(rs.getString("permission"), rs.getInt("value") == 1);
                }
            }
        } catch (SQLException ignored) {
        }
        return perms;
    }

    /** Walks the parent chain (child overrides parent) and merges all permissions. */
    public Map<String, Boolean> getEffectivePermissions(String rankName) {
        LinkedList<String> chain = new LinkedList<>();
        Set<String> seen = new HashSet<>();
        String current = rankName;
        while (current != null && seen.add(current.toLowerCase())) {
            chain.addFirst(current);
            RankData data = getRank(current);
            current = data != null ? data.parent() : null;
        }
        Map<String, Boolean> result = new LinkedHashMap<>();
        for (String rank : chain) {
            result.putAll(getOwnPermissions(rank));
        }
        return result;
    }

    public void setUserRank(UUID uuid, String rank) {
        String sql = "INSERT INTO user_ranks (uuid, rank) VALUES (?,?) " +
                "ON CONFLICT(uuid) DO UPDATE SET rank=excluded.rank";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, rank.toLowerCase());
            ps.executeUpdate();
        } catch (SQLException ignored) {
        }
    }

    public String getUserRank(UUID uuid) {
        if (usesLuckPerms()) {
            try {
                String g = LuckPermsBridge.primaryGroup(uuid);
                return g != null ? g : getDefaultRankName();
            } catch (Throwable t) {
                return getDefaultRankName();
            }
        }
        String sql = "SELECT rank FROM user_ranks WHERE uuid=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("rank");
            }
        } catch (SQLException ignored) {
        }
        return getDefaultRankName();
    }

    /** (Re)builds the player's PermissionAttachment from their effective rank permissions. */
    public void apply(Player player) {
        if (usesLuckPerms()) return;   // Rechte verwaltet LuckPerms
        PermissionAttachment attachment = attachments.get(player.getUniqueId());
        if (attachment != null) {
            player.removeAttachment(attachment);
        }
        attachment = player.addAttachment(plugin);
        attachments.put(player.getUniqueId(), attachment);

        String rank = getUserRank(player.getUniqueId());
        Map<String, Boolean> perms = getEffectivePermissions(rank);

        // Echtes "*"-Wildcard (wie man's von LuckPerms kennt): schaltet ALLE
        // bekannten Permission-Nodes frei, nicht nur eine bedeutungslose
        // Permission namens "*". Explizite Einträge unten können das gezielt
        // wieder überschreiben (z.B. "*"=true aber "spookycraft.core.admin"=false).
        if (Boolean.TRUE.equals(perms.get("*"))) {
            for (String perm : KnownPermissions.all()) {
                attachment.setPermission(perm, true);
            }
        }

        // Teil-Wildcards wie "spookycraft.*" oder "essentials.*": alle bekannten Nodes mit diesem Anfang setzen
        for (Map.Entry<String, Boolean> entry : perms.entrySet()) {
            String key = entry.getKey();
            if (key.endsWith(".*") && key.length() > 2) {
                String prefix = key.substring(0, key.length() - 1).toLowerCase();
                for (String perm : KnownPermissions.all()) {
                    if (perm.toLowerCase().startsWith(prefix)) attachment.setPermission(perm, entry.getValue());
                }
            }
        }

        for (Map.Entry<String, Boolean> entry : perms.entrySet()) {
            attachment.setPermission(entry.getKey(), entry.getValue());
        }
        player.recalculatePermissions();
    }

    public void remove(Player player) {
        PermissionAttachment attachment = attachments.remove(player.getUniqueId());
        if (attachment != null) {
            player.removeAttachment(attachment);
        }
    }

    private static final java.util.regex.Pattern COLOR_CODE = java.util.regex.Pattern.compile(
            "(&#[0-9A-Fa-f]{6})|((§|&)x((§|&)[0-9A-Fa-f]){6})|((§|&)[0-9A-Fa-f])");

    /** Persönliche Prefix-Farben einzelner Spieler (nur für diesen Spieler, nicht für den ganzen Rang). */
    private final java.util.Map<UUID, String> personalColor = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Set<UUID> personalLoaded = java.util.concurrent.ConcurrentHashMap.newKeySet();

    private String personalColorOf(UUID uuid) {
        if (personalLoaded.add(uuid)) {
            try (Connection c = plugin.getDatabase().getConnection();
                 PreparedStatement ps = c.prepareStatement("SELECT color FROM rank_player_color WHERE uuid=?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) personalColor.put(uuid, rs.getString(1));
                }
            } catch (SQLException e) {
                personalLoaded.remove(uuid);
            }
        }
        return personalColor.get(uuid);
    }

    /** Setzt die Prefix-Farbe NUR für diesen Spieler (colorCode z.B. "&6" oder "§x§F§F§0§0§A§A"). */
    public boolean setPlayerColor(UUID uuid, String colorCode) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO rank_player_color (uuid, color) VALUES (?,?) ON CONFLICT(uuid) DO UPDATE SET color = excluded.color")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, colorCode);
            ps.executeUpdate();
            personalColor.put(uuid, colorCode);
            personalLoaded.add(uuid);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /** Entfernt die persönliche Farbe - der Spieler hat wieder die normale Farbe seines Rangs. */
    public boolean clearPlayerColor(UUID uuid) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM rank_player_color WHERE uuid=?")) {
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
            personalColor.remove(uuid);
            personalLoaded.add(uuid);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public String getPrefix(UUID uuid) {
        if (usesLuckPerms()) {
            String raw;
            try {
                raw = LuckPermsBridge.prefix(uuid);
            } catch (Throwable t) {
                raw = "";
            }
            if (raw.isEmpty()) return raw;
            String own = personalColorOf(uuid);
            if (own == null) return raw;
            java.util.regex.Matcher m = COLOR_CODE.matcher(raw);
            return m.find() ? raw.substring(0, m.start()) + own + raw.substring(m.end()) : own + raw;
        }
        RankData rank = getRank(getUserRank(uuid));
        String raw = rank != null && rank.prefix() != null ? rank.prefix() : "";
        if (raw.isEmpty()) return raw;
        String own = personalColorOf(uuid);
        if (own == null) return raw;
        java.util.regex.Matcher m = COLOR_CODE.matcher(raw);
        return m.find() ? raw.substring(0, m.start()) + own + raw.substring(m.end()) : own + raw;
    }

    /** Fertig eingefärbter Prefix (z.B. für Chat/Tab/Nametag), leer wenn keiner gesetzt ist. */
    public String getColoredPrefix(UUID uuid) {
        String raw = getPrefix(uuid);
        String colored = raw.isEmpty() ? "" : plugin.getMessageUtil().color(raw);
        // Rang ohne sichtbaren Text (leer oder nur Farbcodes): Standard-Name anzeigen, damit auch normale Spieler einen Rang im Chat haben
        if (org.bukkit.ChatColor.stripColor(colored).trim().isEmpty()) {
            String label = plugin.getConfig().getString("rank.empty-prefix-text", "&7Spieler");
            return label.isEmpty() ? "" : plugin.getMessageUtil().color(label);
        }
        return colored;
    }

    private static final java.util.regex.Pattern NAME_COLOR = java.util.regex.Pattern.compile(
            "(§x(§[0-9a-fA-F]){6})|(§[0-9a-fA-F])");

    /** Farbcode des Rang-Prefixes (erste Farbe), zum Einfaerben des ganzen Spielernamens. Leer wenn keine. */
    public String getNameColor(UUID uuid) {
        java.util.regex.Matcher m = NAME_COLOR.matcher(getColoredPrefix(uuid));
        return m.find() ? m.group() : "";
    }

    /** Wie getNameColor, aber als klassische Team-Farbe (Nametag). null bei Hex-Farben/keiner Farbe. */
    public org.bukkit.ChatColor getNameTeamColor(UUID uuid) {
        String c = getNameColor(uuid);
        if (c.length() != 2) return null;
        return org.bukkit.ChatColor.getByChar(c.charAt(1));
    }

    public record RankData(String name, String prefix, int weight, String parent) {
    }
}
