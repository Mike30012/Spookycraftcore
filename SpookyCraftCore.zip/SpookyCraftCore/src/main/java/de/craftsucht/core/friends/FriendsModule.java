package de.craftsucht.core.friends;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class FriendsModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter {

    private final SpookyCraftCore plugin;
    private final Map<UUID, UUID> pendingRequests = new HashMap<>(); // target -> requester

    public FriendsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "friends";
    }

    @Override
    public void enable() {
        plugin.getCommand("friend").setExecutor(this);
        plugin.getCommand("friend").setTabCompleter(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "add", "accept", "deny", "remove", "list");
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            return de.craftsucht.core.util.TabCompleteUtil.onlinePlayers(args[1]);
        }
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /friend <add|accept|deny|remove|list> [spieler]");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "add" -> add(p, args);
            case "accept" -> accept(p);
            case "deny" -> deny(p);
            case "remove" -> remove(p, args);
            case "list" -> list(p);
            default -> plugin.getMessageUtil().send(p, "&cUnbekannter Befehl.");
        }
        return true;
    }

    private void add(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /friend add <spieler>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            plugin.getMessageUtil().send(p, "&cSpieler nicht online.");
            return;
        }
        pendingRequests.put(target.getUniqueId(), p.getUniqueId());
        plugin.getMessageUtil().send(target, "&b" + p.getName() + " &7möchte dich als Freund hinzufügen. /friend accept oder /friend deny");
        plugin.getMessageUtil().send(p, "&aAnfrage gesendet.");
    }

    private void accept(Player p) {
        UUID requesterId = pendingRequests.remove(p.getUniqueId());
        if (requesterId == null) {
            plugin.getMessageUtil().send(p, "&cKeine offene Anfrage.");
            return;
        }
        String sql1 = "INSERT OR IGNORE INTO friends (uuid, friend_uuid, since) VALUES (?, ?, ?)";
        long now = System.currentTimeMillis();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps1 = c.prepareStatement(sql1);
             PreparedStatement ps2 = c.prepareStatement(sql1)) {
            ps1.setString(1, p.getUniqueId().toString());
            ps1.setString(2, requesterId.toString());
            ps1.setLong(3, now);
            ps1.executeUpdate();
            ps2.setString(1, requesterId.toString());
            ps2.setString(2, p.getUniqueId().toString());
            ps2.setLong(3, now);
            ps2.executeUpdate();
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Speichern.");
            return;
        }
        Player requester = Bukkit.getPlayer(requesterId);
        plugin.getMessageUtil().send(p, "&aIhr seid jetzt Freunde.");
        if (requester != null) plugin.getMessageUtil().send(requester, "&a" + p.getName() + " hat deine Freundschaftsanfrage akzeptiert.");
    }

    private void deny(Player p) {
        if (pendingRequests.remove(p.getUniqueId()) == null) {
            plugin.getMessageUtil().send(p, "&cKeine offene Anfrage.");
            return;
        }
        plugin.getMessageUtil().send(p, "&cAnfrage abgelehnt.");
    }

    private void remove(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /friend remove <spieler>");
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        String sql = "DELETE FROM friends WHERE (uuid=? AND friend_uuid=?) OR (uuid=? AND friend_uuid=?)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            ps.setString(2, target.getUniqueId().toString());
            ps.setString(3, target.getUniqueId().toString());
            ps.setString(4, p.getUniqueId().toString());
            ps.executeUpdate();
            plugin.getMessageUtil().send(p, "&aFreund entfernt.");
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Entfernen.");
        }
    }

    private void list(Player p) {
        String sql = "SELECT friend_uuid FROM friends WHERE uuid=?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            try (ResultSet rs = ps.executeQuery()) {
                plugin.getMessageUtil().sendRaw(p, "&8--- &bFreunde &8---");
                boolean any = false;
                while (rs.next()) {
                    any = true;
                    OfflinePlayer friend = Bukkit.getOfflinePlayer(UUID.fromString(rs.getString("friend_uuid")));
                    String status = friend.isOnline() ? "&aOnline" : "&7Offline";
                    plugin.getMessageUtil().sendRaw(p, "&b" + friend.getName() + " &7- " + status);
                }
                if (!any) plugin.getMessageUtil().send(p, "&7Du hast noch keine Freunde hinzugefügt.");
            }
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Laden.");
        }
    }
}
