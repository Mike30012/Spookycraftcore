package de.craftsucht.core.dungeon;

import java.util.concurrent.ConcurrentLinkedQueue;

/** Thread-sicherer Eingang: Der Generator meldet hier neue Dungeons, das Modul speichert sie. */
public final class DungeonRegistry {
    public record Dungeon(String world, int x, int y, int z, boolean graveyard) {
    }

    public static final ConcurrentLinkedQueue<Dungeon> NEW = new ConcurrentLinkedQueue<>();

    private DungeonRegistry() {
    }

    public static void add(String world, int x, int y, int z, boolean graveyard) {
        NEW.add(new Dungeon(world, x, y, z, graveyard));
    }
}
