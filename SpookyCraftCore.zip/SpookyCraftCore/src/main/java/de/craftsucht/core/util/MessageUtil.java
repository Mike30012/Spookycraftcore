package de.craftsucht.core.util;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class MessageUtil {

    private final SpookyCraftCore plugin;
    private String prefix;

    public MessageUtil(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.prefix = "&8[&6☠ SpookyCraft&8] &r";
    }

    public void reloadPrefix() {
        this.prefix = plugin.getConfig().getString("prefix", "&8[&6☠ SpookyCraft&8] &r");
    }

    /** Haeufige Standardtexte werden zentral spooky umformuliert (gilt fuer alle send()/sendRaw()-Meldungen). */
    private static final java.util.LinkedHashMap<String, String> SPOOKY = new java.util.LinkedHashMap<>();

    static {
        String deny = "Die Geister verwehren dir den Zutritt!";
        SPOOKY.put("Dazu hast du keine Berechtigung.", deny);
        SPOOKY.put("Du hast keine Berechtigung dazu.", deny);
        SPOOKY.put("Du hast keine Berechtigung.", deny);
        SPOOKY.put("Du hast keine Rechte für diesen Befehl!", deny);
        SPOOKY.put("Keine Berechtigung.", deny);
        SPOOKY.put("Spieler nicht online.", "Dieser Spieler wandelt nicht in der Geisterwelt.");
        SPOOKY.put("ist nicht online.", "wandelt nicht in der Geisterwelt.");
        SPOOKY.put("Spieler nicht gefunden.", "Die Geister kennen diesen Spieler nicht.");
        SPOOKY.put("Nur als Spieler nutzbar.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Nur Spieler können diesen Befehl nutzen.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Dieser Befehl kann nur von Spielern genutzt werden.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Dieser Befehl geht nur ingame.", "Dieser Zauber wirkt nur in der Geisterwelt (ingame).");
        SPOOKY.put("Unbekannter Befehl.", "Dieser Zauberspruch ist unbekannt.");
        SPOOKY.put("Du hast nicht genug Geld!", "Deine Taschen sind zu leer – nicht genug Geld!");
        SPOOKY.put("Nicht genug Geld.", "Deine Taschen sind zu leer – nicht genug Geld!");
        SPOOKY.put("Bitte gib eine gültige Zahl ein.", "Das ist keine gültige Zahl, Sterblicher.");
        SPOOKY.put("Ungültige Zahl.", "Das ist keine gültige Zahl, Sterblicher.");
        SPOOKY.put("Ungültiger Betrag.", "Dieser Betrag ist verflucht (ungültig).");
        SPOOKY.put("Halte ein Item in der Hand!", "Halte einen Gegenstand in deiner Hand!");
        SPOOKY.put("Halte ein Item in der Hand.", "Halte einen Gegenstand in deiner Hand.");
        SPOOKY.put("Nutzung:", "Zauberformel:");
        SPOOKY.put("Fehler beim Laden.", "Die Geister haben das Laden verhext.");
        SPOOKY.put("Keine offene Anfrage.", "Kein Geisterruf wartet auf dich.");
        SPOOKY.put("Anfrage akzeptiert.", "Der Pakt ist besiegelt.");
        SPOOKY.put("Anfrage gesendet.", "Dein Ruf hallt durch die Nacht.");
        SPOOKY.put("Anfrage abgelehnt.", "Der Pakt wurde ausgeschlagen.");
        SPOOKY.put("Die Anfrage ist abgelaufen.", "Der Ruf ist im Nebel verhallt.");
        SPOOKY.put("Einladung gesendet.", "Die Einladung flattert als Fledermaus davon.");
        SPOOKY.put("Keine offene Einladung.", "Keine Fledermaus mit Einladung in Sicht.");
        SPOOKY.put("Erledigt.", "Der Zauber ist vollbracht.");
        SPOOKY.put("Du bist satt.", "Die Geister haben deinen Hunger gestillt.");
        SPOOKY.put("Du wurdest geheilt.", "Die Geister haben deine Wunden geheilt.");
        SPOOKY.put("Du bist jetzt AFK.", "Du bist in die Schattenwelt entschwunden (AFK).");
        SPOOKY.put("Du bist nicht mehr AFK.", "Du bist aus der Schattenwelt zurückgekehrt.");
        SPOOKY.put("Du bist jetzt unsichtbar", "Du bist zum Geist geworden – unsichtbar");
        SPOOKY.put("Du bist wieder sichtbar.", "Du nimmst wieder Gestalt an.");
        SPOOKY.put("Zufällig teleportiert.", "Der Nebel hat dich irgendwohin getragen.");
        SPOOKY.put("Teleportiert zu", "Ein Nebel trägt dich zu");
        SPOOKY.put("Gekauft für", "Der Handel ist besiegelt für");
        SPOOKY.put("Item repariert.", "Die Geister haben dein Item geflickt.");
        SPOOKY.put("Aufgesetzt.", "Du trägst es nun als Haupt-Fluch.");
        SPOOKY.put("Keine neuen Mails.", "Keine Geisterpost für dich.");
        SPOOKY.put("Mail gesendet an", "Geisterpost entsandt an");
        SPOOKY.put("Du kannst dir nicht selbst schreiben.", "Mit dir selbst zu flüstern wäre... gruselig.");
        SPOOKY.put("Es ist sonst niemand online.", "Du wandelst allein durch die Geisterwelt.");
        SPOOKY.put("Es gibt niemanden zum Antworten.", "Niemand wartet im Nebel auf deine Antwort.");
        SPOOKY.put("Du bist in keinem Clan.", "Du gehörst keinem Geisterzirkel an.");
        SPOOKY.put("Du bist in keiner Party.", "Du wanderst in keiner Geisterschar.");
        SPOOKY.put("Du hast noch keine Freunde hinzugefügt.", "Noch kein Geist hat sich mit dir verbündet.");
        SPOOKY.put("Kein Home mit diesem Namen.", "Kein Unterschlupf mit diesem Namen.");
        SPOOKY.put("Warp existiert nicht.", "Dieses Portal existiert nicht.");
        SPOOKY.put("Unbekannter Unterbefehl.", "Dieser Unterzauber ist unbekannt.");
        SPOOKY.put("Unbekannte Aktion.", "Diese Beschwörung ist unbekannt.");
        SPOOKY.put("Du musst ein Item in der Hand halten.", "Halte einen Gegenstand in deiner Hand, Sterblicher.");
        SPOOKY.put("Du hältst kein Item in der Hand.", "Halte einen Gegenstand in deiner Hand, Sterblicher.");
        SPOOKY.put("Die Welt ist nicht geladen.", "Diese Welt schläft noch tief im Nebel.");
        SPOOKY.put("Diese Nummer gibt es nicht.", "Diese Nummer kennt kein Geist.");
        SPOOKY.put("Nur im Spiel nutzbar.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Der Spieler ist nicht mehr online.", "Dieser Spieler ist im Nebel verschwunden.");
        SPOOKY.put("Spieler nicht mehr online.", "Dieser Spieler ist im Nebel verschwunden.");
        SPOOKY.put("Betrag muss positiv sein.", "Der Betrag muss positiv sein – Geister kennen keine Schulden.");
        SPOOKY.put("Gamemode geändert zu", "Deine Gestalt wandelt sich zu");
        SPOOKY.put("Unbekannter Gamemode.", "Diese Gestalt kennen die Geister nicht.");
        SPOOKY.put("Geschwindigkeit auf", "Deine Geisterschritte sind jetzt auf");
        SPOOKY.put("Nickname gesetzt:", "Du trägst nun den Geisternamen:");
        SPOOKY.put("Nickname zurückgesetzt.", "Dein wahrer Name ist zurück.");
        SPOOKY.put("Markt neu geladen.", "Der Markt wurde neu beschworen.");
        SPOOKY.put("Prefix gesetzt.", "Dein Geistertitel wurde gesetzt.");
        SPOOKY.put("Rang gesetzt.", "Der Rang wurde von den Geistern verliehen.");
        SPOOKY.put("Rang gelöscht.", "Der Rang wurde in die Dunkelheit verbannt.");
        SPOOKY.put("Elternrang gesetzt.", "Die Geister haben es vermerkt.");
        SPOOKY.put("Gewicht gesetzt.", "Die Geister haben es vermerkt.");
        SPOOKY.put("SpookyCraftCore neu geladen.", "SpookyCraftCore wurde neu beschworen.");
        SPOOKY.put("Keine Items gefunden für", "Keine Gegenstände in den Schatten gefunden für");
        SPOOKY.put("Die Datenbank ist noch leer.", "Die Schatten-Datenbank ist noch leer.");
        SPOOKY.put("Die Farmwelt wird zurückgesetzt", "Die Farmwelt wird von den Geistern verschlungen und neu erschaffen");
        SPOOKY.put("Du bist bereits in dieser Welt.", "Du wandelst bereits in dieser Welt, Wanderer.");
        SPOOKY.put("Du kannst /rtp erst in", "Die Geister brauchen Ruhe – /rtp erst in");
        SPOOKY.put("Freund entfernt.", "Das Band zu diesem Geist ist zerrissen.");
        SPOOKY.put("Ihr seid jetzt Freunde.", "Ein Geisterbund wurde geschlossen.");
        SPOOKY.put("Party beigetreten.", "Du bist der Geisterschar beigetreten.");
        SPOOKY.put("Party verlassen.", "Du hast die Geisterschar verlassen.");
        SPOOKY.put("Du hast deinen Clan verlassen.", "Du hast deinen Geisterzirkel verlassen.");
        SPOOKY.put("Report eingereicht. Ein Teammitglied wird sich darum kümmern.", "Dein Hilferuf erreichte die Wächter. Einer wird sich darum kümmern.");
        SPOOKY.put("Zinsen gutgeschrieben:", "Die Geister haben Zinsen vergraben:");
        SPOOKY.put("auf dein Bankkonto eingezahlt.", "in die Gruft deines Bankkontos gelegt.");
        SPOOKY.put("von deinem Bankkonto abgehoben.", "aus der Gruft deines Bankkontos geholt.");
        SPOOKY.put("Dein Bankkonto hat nicht genug Guthaben!", "In deiner Gruft liegt nicht genug Gold!");
        SPOOKY.put("Danke fürs Voten!", "Die Geister danken dir fürs Voten!");
        SPOOKY.put("Inventar voll - Item konnte nicht übergeben werden.", "Dein Beutel ist voll – das Item konnte nicht übergeben werden.");
        SPOOKY.put("Monitor deaktiviert", "Der Späher-Geist ruht");
        SPOOKY.put("Monitor aktiviert", "Der Späher-Geist wacht");
        SPOOKY.put("Performance", "Pulsschlag der Geisterwelt");
        SPOOKY.put("Fehler beim ", "Ein Fluch verhinderte: ");
        SPOOKY.put("Fehler.", "Ein Fluch ist dazwischengekommen.");
    }

    public static String spookify(String text) {
        String r = text;
        for (java.util.Map.Entry<String, String> e : SPOOKY.entrySet()) {
            if (r.contains(e.getKey())) r = r.replace(e.getKey(), e.getValue());
        }
        return r;
    }

    public String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    /** Fehler (&c), Erfolg (&a) und Info bekommen ein eigenes Spooky-Symbol vor dem Text. */
    public void send(CommandSender sender, String message) {
        String m = message;
        if (m.startsWith("&c")) m = "&c✖ " + m;
        else if (m.startsWith("&a")) m = "&a✔ " + m;
        sender.sendMessage(color(prefix + spookify(m)));
    }

    public void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(color(spookify(message)));
    }
}
