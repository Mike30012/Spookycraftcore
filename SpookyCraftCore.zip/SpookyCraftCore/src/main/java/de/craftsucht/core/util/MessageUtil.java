package de.craftsucht.core.util;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class MessageUtil {

    private final SpookyCraftCore plugin;
    private String prefix;

    public MessageUtil(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.prefix = "&8[&6☠ SpookyCraft&8] &r";
    }

    public void reloadPrefix() {
        this.prefix = plugin.getConfig().getString("prefix", "&8[&6☠ SpookyCraft&8] &r");
    }

    public String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    /** Fehler (&c), Erfolg (&a) und Info bekommen ein eigenes Spooky-Symbol vor dem Text. */
    public void send(CommandSender sender, String message) {
        String m = message;
        if (m.startsWith("&c")) m = "&c✖ " + m;
        else if (m.startsWith("&a")) m = "&a✔ " + m;
        sender.sendMessage(color(prefix + m));
    }

    public void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(color(message));
    }
}
