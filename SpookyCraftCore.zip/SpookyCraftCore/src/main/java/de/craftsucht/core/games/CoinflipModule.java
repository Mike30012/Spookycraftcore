package de.craftsucht.core.games;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * /cf <spieler> <betrag> fordert zum Muenzwurf heraus, /cf accept | deny antwortet.
 * Der Gewinner bekommt den doppelten Einsatz abzueglich coinflip.tax-percent (Geld-Senke).
 */
public class CoinflipModule implements Module, CommandExecutor, TabCompleter, Listener {

    private record Challenge(UUID from, double amount, long expires) {
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, Challenge> open = new ConcurrentHashMap<>();   // Ziel -> Herausforderung

    public CoinflipModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "coinflip";
    }

    @Override
    public void enable() {
        plugin.getCommand("coinflip").setExecutor(this);
        plugin.getCommand("coinflip").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        open.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        open.remove(e.getPlayer().getUniqueId());
        open.values().removeIf(c -> c.from().equals(e.getPlayer().getUniqueId()));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            plugin.getMessageUtil().send(p, "&cNutzung: /cf <spieler> <betrag> &7| &c/cf accept &7| &c/cf deny");
            return true;
        }
        if (args[0].equalsIgnoreCase("accept")) {
            accept(p);
            return true;
        }
        if (args[0].equalsIgnoreCase("deny")) {
            Challenge c = open.remove(p.getUniqueId());
            plugin.getMessageUtil().send(p, c == null ? "&cKein Geisterruf wartet auf dich." : "&7Du hast die Herausforderung ausgeschlagen.");
            if (c != null) {
                Player from = Bukkit.getPlayer(c.from());
                if (from != null) plugin.getMessageUtil().send(from, "&7" + p.getName() + " hat deine Herausforderung ausgeschlagen.");
            }
            return true;
        }
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /cf <spieler> <betrag>");
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[0]);
        if (t == null || t.equals(p)) {
            plugin.getMessageUtil().send(p, "&cDieser Spieler wandelt nicht in der Geisterwelt (oder du selbst).");
            return true;
        }
        double amount = GameUtil.parseAmount(args[1]);
        double min = plugin.getConfig().getDouble("coinflip.min", 100);
        double max = plugin.getConfig().getDouble("coinflip.max", 1_000_000);
        if (amount < min || amount > max) {
            plugin.getMessageUtil().send(p, "&cDer Einsatz muss zwischen &e" + GameUtil.money(min) + " &cund &e" + GameUtil.money(max) + " &cliegen.");
            return true;
        }
        EconomyManager eco = GameUtil.eco(plugin);
        if (eco == null || eco.getBalance(p.getUniqueId()) < amount) {
            plugin.getMessageUtil().send(p, "&cDeine Taschen sind zu leer – nicht genug Geld!");
            return true;
        }
        open.put(t.getUniqueId(), new Challenge(p.getUniqueId(), amount, System.currentTimeMillis() + 30_000L));
        plugin.getMessageUtil().send(p, "&aDein Ruf hallt zu " + t.getName() + " – Einsatz &e" + GameUtil.money(amount) + "&a.");
        plugin.getMessageUtil().send(t, "&5☠ &f" + p.getName() + " &dfordert dich zum Münzwurf um &e" + GameUtil.money(amount)
                + " &dheraus! &a/cf accept &7oder &c/cf deny &7(30 Sek.)");
        return true;
    }

    private void accept(Player p) {
        Challenge c = open.remove(p.getUniqueId());
        if (c == null || c.expires() < System.currentTimeMillis()) {
            plugin.getMessageUtil().send(p, "&cKein Geisterruf wartet auf dich.");
            return;
        }
        Player from = Bukkit.getPlayer(c.from());
        EconomyManager eco = GameUtil.eco(plugin);
        if (from == null || eco == null) {
            plugin.getMessageUtil().send(p, "&cDein Gegner ist im Nebel verschwunden.");
            return;
        }
        if (eco.getBalance(p.getUniqueId()) < c.amount() || eco.getBalance(from.getUniqueId()) < c.amount()) {
            plugin.getMessageUtil().send(p, "&cEiner von euch hat nicht genug Geld für den Einsatz.");
            plugin.getMessageUtil().send(from, "&cEiner von euch hat nicht genug Geld für den Einsatz.");
            return;
        }
        if (!eco.withdraw(from.getUniqueId(), c.amount())) return;
        if (!eco.withdraw(p.getUniqueId(), c.amount())) {
            eco.deposit(from.getUniqueId(), c.amount());
            return;
        }
        double tax = Math.max(0, Math.min(100, plugin.getConfig().getDouble("coinflip.tax-percent", 5)));
        double prize = Math.floor(c.amount() * 2 * (1 - tax / 100.0));
        Player winner = ThreadLocalRandom.current().nextBoolean() ? from : p;
        Player loser = winner == from ? p : from;
        eco.deposit(winner.getUniqueId(), prize);
        Bukkit.broadcastMessage(plugin.getMessageUtil().color("&5☠ &dDie Münze der Geister fiel! &f" + winner.getName()
                + " &dgewinnt &e" + GameUtil.money(prize) + " &dgegen &f" + loser.getName() + "&d."));
        winner.playSound(winner.getLocation(), "entity.player.levelup", 0.8f, 1.2f);
        loser.playSound(loser.getLocation(), "entity.wither.hurt", 0.5f, 1.0f);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = TabCompleteUtil.onlinePlayers(args[0]);
            out.addAll(TabCompleteUtil.filter(args[0], "accept", "deny"));
            return out;
        }
        return Collections.emptyList();
    }
}
