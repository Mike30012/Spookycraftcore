package de.craftsucht.core.immobilien;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Immobilienmarkt (/immo): Spieler stellen ihr PlotSquared-Grundstueck mit Preis ein, andere sehen eine Liste,
 * schauen sich das Grundstueck per Teleport an und kaufen es per Klick. Verkaeufer bekommt das Geld (minus Steuer).
 * Angebote liegen in immobilien.yml.
 */
public class ImmobilienModule implements Module, CommandExecutor, TabCompleter, Listener {

    private record Listing(int id, UUID seller, String sellerName, double price, String key, String world,
                           double x, double y, double z, long listedAt) {
    }

    private static class MarketHolder implements InventoryHolder {
        final int page;
        final boolean mine;
        final List<Listing> shown;

        MarketHolder(int page, boolean mine, List<Listing> shown) {
            this.page = page;
            this.mine = mine;
            this.shown = shown;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static class HubHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final int PER_PAGE = 45;
    private final Map<UUID, String> awaiting = new HashMap<>();   // Spieler -> "sell" oder "price" (Preis per Chat)

    private final SpookyCraftCore plugin;
    private final PlotBridge bridge = new PlotBridge();
    private File file;
    private YamlConfiguration data;
    private final Map<UUID, long[]> pendingBuy = new HashMap<>();   // Spieler -> {Angebots-ID, Ablaufzeit}

    public ImmobilienModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "immobilien";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "immobilien.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("immo").setExecutor(this);
        plugin.getCommand("immo").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        save();
    }

    // ------------------------------------------------------------------ Daten

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("immobilien.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private List<Listing> listings() {
        List<Listing> out = new ArrayList<>();
        ConfigurationSection sec = data.getConfigurationSection("listings");
        if (sec == null) return out;
        for (String k : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(k);
            if (s == null) continue;
            try {
                out.add(new Listing(Integer.parseInt(k), UUID.fromString(s.getString("seller", "")), s.getString("seller-name", "?"),
                        s.getDouble("price"), s.getString("key", ""), s.getString("world", ""),
                        s.getDouble("x"), s.getDouble("y"), s.getDouble("z"), s.getLong("listed-at")));
            } catch (IllegalArgumentException ignored) {
                // kaputter Eintrag wird uebersprungen
            }
        }
        out.sort(Comparator.comparingLong(Listing::listedAt).reversed());
        return out;
    }

    private Listing listing(int id) {
        for (Listing l : listings()) if (l.id == id) return l;
        return null;
    }

    private void remove(int id) {
        data.set("listings." + id, null);
        save();
    }

    private int nextId() {
        int n = data.getInt("next-id", 1);
        data.set("next-id", n + 1);
        return n;
    }

    private EconomyManager eco() {
        return plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
    }

    private static String money(double v) {
        return String.format(Locale.GERMANY, "%,.0f", v) + "$";
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    // ------------------------------------------------------------------ Befehl

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (!bridge.init()) {
            plugin.getMessageUtil().send(p, "&c" + bridge.error());
            return true;
        }
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "verkaufen", "sell" -> sell(p, args);
            case "abbrechen", "cancel" -> cancelHere(p);
            case "hilfe", "help" -> help(p);
            default -> openHub(p);
        }
        return true;
    }

    private void help(Player p) {
        plugin.getMessageUtil().sendRaw(p, "&8&l☠ &7Immobilienmarkt");
        plugin.getMessageUtil().sendRaw(p, "&f/immo &7- alle Grundstücke ansehen, besichtigen und kaufen");
        plugin.getMessageUtil().sendRaw(p, "&f/immo verkaufen <Preis> &7- dein Grundstück einstellen (steh darauf)");
        plugin.getMessageUtil().sendRaw(p, "&f/immo abbrechen &7- dein Angebot zurückziehen (steh darauf)");
    }

    private void sell(Player p, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(p, "&cNutzung: /immo verkaufen <Preis> &7(z.B. 25000, 50k, 1m)");
            return;
        }
        double price = parsePrice(args[1]);
        double min = plugin.getConfig().getDouble("immobilien.min-price", 1000);
        if (price < min) {
            plugin.getMessageUtil().send(p, "&cDer Mindestpreis ist &f" + money(min) + "&c.");
            return;
        }
        if (price > 1_000_000_000_000L) {
            plugin.getMessageUtil().send(p, "&cDieser Preis ist selbst für Geister zu hoch.");
            return;
        }
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            plugin.getMessageUtil().send(p, "&cDu stehst auf keinem Grundstück.");
            return;
        }
        if (ref.owner() == null || !ref.owner().equals(p.getUniqueId())) {
            plugin.getMessageUtil().send(p, "&cDieses Grundstück gehört nicht dir.");
            return;
        }
        int max = plugin.getConfig().getInt("immobilien.max-listings", 3);
        int mine = 0;
        for (Listing l : listings()) {
            if (l.key.equals(ref.key())) {
                plugin.getMessageUtil().send(p, "&cDieses Grundstück steht schon im Angebot.");
                return;
            }
            if (l.seller.equals(p.getUniqueId())) mine++;
        }
        if (mine >= max && !p.isOp()) {
            plugin.getMessageUtil().send(p, "&cDu kannst höchstens &f" + max + " &cGrundstücke gleichzeitig anbieten.");
            return;
        }
        final String key = ref.key();
        final UUID uid = p.getUniqueId();
        final String name = p.getName();
        bridge.center(ref, center -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (center == null || center.getWorld() == null) {
                plugin.getMessageUtil().send(p, "&cDie Mitte des Grundstücks konnte nicht bestimmt werden.");
                return;
            }
            int id = nextId();
            String base = "listings." + id;
            data.set(base + ".seller", uid.toString());
            data.set(base + ".seller-name", name);
            data.set(base + ".price", price);
            data.set(base + ".key", key);
            data.set(base + ".world", center.getWorld().getName());
            data.set(base + ".x", center.getX());
            data.set(base + ".y", center.getY());
            data.set(base + ".z", center.getZ());
            data.set(base + ".listed-at", System.currentTimeMillis());
            save();
            plugin.getMessageUtil().send(p, "&aDein Grundstück steht jetzt für &f" + money(price) + " &aim Immobilienmarkt (&f/immo&a).");
            Bukkit.broadcastMessage(c("&8[&a☠&8] &7" + name + " &7bietet ein Grundstück für &e" + money(price) + " &7an &8(&f/immo&8)"));
        }));
    }

    private void cancelHere(Player p) {
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            plugin.getMessageUtil().send(p, "&cDu stehst auf keinem Grundstück.");
            return;
        }
        for (Listing l : listings()) {
            if (l.key.equals(ref.key())) {
                if (!l.seller.equals(p.getUniqueId()) && !p.isOp()) {
                    plugin.getMessageUtil().send(p, "&cDas ist nicht dein Angebot.");
                    return;
                }
                remove(l.id);
                plugin.getMessageUtil().send(p, "&7Das Angebot wurde zurückgezogen.");
                return;
            }
        }
        plugin.getMessageUtil().send(p, "&cFür dieses Grundstück gibt es kein Angebot.");
    }

    private static double parsePrice(String s) {
        String t = s.trim().toLowerCase(Locale.ROOT).replace(",", ".");
        double mult = 1;
        if (t.endsWith("k")) {
            mult = 1_000;
            t = t.substring(0, t.length() - 1);
        } else if (t.endsWith("m")) {
            mult = 1_000_000;
            t = t.substring(0, t.length() - 1);
        }
        try {
            double v = Double.parseDouble(t) * mult;
            return Double.isNaN(v) || Double.isInfinite(v) ? -1 : Math.floor(v);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ------------------------------------------------------------------ GUI

    private void open(Player p, int page, boolean mineOnly) {
        List<Listing> all = new ArrayList<>();
        for (Listing l : listings()) if (!mineOnly || l.seller.equals(p.getUniqueId())) all.add(l);
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        int pg = Math.max(0, Math.min(page, pages - 1));
        List<Listing> shown = new ArrayList<>(all.subList(pg * PER_PAGE, Math.min(all.size(), (pg + 1) * PER_PAGE)));
        Inventory inv = Bukkit.createInventory(new MarketHolder(pg, mineOnly, shown), 54, c((mineOnly ? "&2&l☠ &aMeine Angebote &8(" : "&2&l☠ &aAlle Angebote &8(") + (pg + 1) + "/" + pages + ")"));
        for (int i = 0; i < shown.size(); i++) {
            Listing l = shown.get(i);
            boolean mine = l.seller.equals(p.getUniqueId());
            ItemStack it = new ItemStack(mine ? Material.GOLD_BLOCK : Material.GRASS_BLOCK);
            ItemMeta m = it.getItemMeta();
            m.setDisplayName(c("&a&lGrundstück &f" + l.key.substring(l.key.indexOf('|') + 1)));
            List<String> lore = new ArrayList<>();
            lore.add(c("&7Verkäufer: &f" + l.sellerName));
            lore.add(c("&7Preis: &e" + money(l.price)));
            lore.add(c("&7Welt: &f" + l.world));
            lore.add("");
            lore.add(c("&eLinksklick: &7Besichtigen (Teleport)"));
            lore.add(c(mine ? "&cRechtsklick: &7Angebot zurückziehen" : "&aRechtsklick: &7Kaufen &8(2x klicken)"));
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(i, it);
        }
        ItemStack bar = named(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, bar);
        if (pg > 0) inv.setItem(45, named(Material.ARROW, c("&7« Vorherige Seite")));
        if (pg < pages - 1) inv.setItem(53, named(Material.ARROW, c("&7Nächste Seite »")));
        inv.setItem(49, named(Material.BARRIER, c("&cZurück zum Hauptmenü")));
        p.openInventory(inv);
    }

    private ItemStack named(Material mat, String name) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        it.setItemMeta(m);
        return it;
    }

    // ------------------------------------------------------------------ Hauptmenue (wie das Immobilien-Menue grosser Server: 6 Knoepfe)

    private void openHub(Player p) {
        Inventory inv = Bukkit.createInventory(new HubHolder(), 45, c("&2&l☠ &aImmobilien Markt"));
        ItemStack pane = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 45; i++) inv.setItem(i, pane);
        inv.setItem(11, button(Material.PAPER, "&a&lDieses Grundstück", hereInfo(p)));
        inv.setItem(13, button(Material.GRASS_BLOCK, "&a&lAlle Angebote",
                List.of("&7Grundstücke ansehen, besichtigen", "&7und kaufen.", "", "&eKlick: &7Liste öffnen")));
        inv.setItem(15, button(Material.COARSE_DIRT, "&a&lMeine Angebote",
                List.of("&7Deine eingestellten Grundstücke.", "", "&eKlick: &7Liste öffnen")));
        inv.setItem(29, button(Material.GOLD_INGOT, "&6&lGrundstück verkaufen",
                List.of("&7Du musst auf deinem Grundstück stehen.", "&7Danach den Preis in den Chat schreiben.",
                        "&7Steuer: &f" + plugin.getConfig().getInt("immobilien.tax-percent", 5) + "%", "", "&eKlick: &7Verkauf starten")));
        inv.setItem(31, button(Material.NAME_TAG, "&e&lPreis ändern",
                List.of("&7Ändert den Preis deines Angebots", "&7auf dem Grundstück, auf dem du stehst.", "", "&eKlick: &7neuen Preis eingeben")));
        inv.setItem(33, button(Material.CHEST, "&c&lAngebot zurückziehen",
                List.of("&7Nimmt dein Angebot auf dem", "&7Grundstück, auf dem du stehst, vom Markt.", "", "&eKlick: &7zurückziehen")));
        p.openInventory(inv);
    }

    private List<String> hereInfo(Player p) {
        List<String> l = new ArrayList<>();
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            l.add("&7Du stehst auf keinem Grundstück.");
            return l;
        }
        l.add("&7Grundstück: &f" + ref.key().substring(ref.key().indexOf('|') + 1));
        l.add("&7Besitzer: &f" + (ref.owner() == null ? "niemand" : ref.owner().equals(p.getUniqueId()) ? "du" : nameOf(ref.owner())));
        for (Listing x : listings()) {
            if (x.key.equals(ref.key())) {
                l.add("&7Angebot: &e" + money(x.price));
                return l;
            }
        }
        l.add("&7Angebot: &8keins");
        return l;
    }

    private String nameOf(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "?" : n;
    }

    private ItemStack button(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(c(name));
        List<String> out = new ArrayList<>();
        for (String x : lore) out.add(c(x));
        m.setLore(out);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onHubDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof HubHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onHubClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof HubHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.0f);
        switch (e.getSlot()) {
            case 13 -> open(p, 0, false);
            case 15 -> open(p, 0, true);
            case 29 -> {
                p.closeInventory();
                awaiting.put(p.getUniqueId(), "sell");
                plugin.getMessageUtil().send(p, "&eSchreibe den Preis in den Chat &7(z.B. 25000, 50k, 1m) &eoder &fabbrechen&e.");
            }
            case 31 -> {
                p.closeInventory();
                awaiting.put(p.getUniqueId(), "price");
                plugin.getMessageUtil().send(p, "&eSchreibe den neuen Preis in den Chat &7(z.B. 30k) &eoder &fabbrechen&e.");
            }
            case 33 -> {
                p.closeInventory();
                cancelHere(p);
            }
            default -> {
            }
        }
    }

    @EventHandler(priority = org.bukkit.event.EventPriority.LOWEST)
    public void onPriceChat(org.bukkit.event.player.AsyncPlayerChatEvent e) {
        String mode = awaiting.get(e.getPlayer().getUniqueId());
        if (mode == null) return;
        e.setCancelled(true);
        awaiting.remove(e.getPlayer().getUniqueId());
        final String text = e.getMessage().trim();
        final Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (text.equalsIgnoreCase("abbrechen") || text.equalsIgnoreCase("cancel")) {
                plugin.getMessageUtil().send(p, "&7Abgebrochen.");
            } else if (mode.equals("sell")) {
                sell(p, new String[]{"verkaufen", text});
            } else {
                changePrice(p, text);
            }
        });
    }

    @EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent e) {
        awaiting.remove(e.getPlayer().getUniqueId());
        pendingBuy.remove(e.getPlayer().getUniqueId());
    }

    private void changePrice(Player p, String text) {
        double price = parsePrice(text);
        double min = plugin.getConfig().getDouble("immobilien.min-price", 1000);
        if (price < min || price > 1_000_000_000_000L) {
            plugin.getMessageUtil().send(p, "&cUngültiger Preis (mindestens &f" + money(min) + "&c).");
            return;
        }
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            plugin.getMessageUtil().send(p, "&cDu stehst auf keinem Grundstück.");
            return;
        }
        for (Listing l : listings()) {
            if (l.key.equals(ref.key())) {
                if (!l.seller.equals(p.getUniqueId()) && !p.isOp()) {
                    plugin.getMessageUtil().send(p, "&cDas ist nicht dein Angebot.");
                    return;
                }
                data.set("listings." + l.id + ".price", price);
                save();
                plugin.getMessageUtil().send(p, "&aNeuer Preis: &f" + money(price));
                return;
            }
        }
        plugin.getMessageUtil().send(p, "&cFür dieses Grundstück gibt es kein Angebot.");
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MarketHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof MarketHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot == 49) {
            openHub(p);
            return;
        }
        if (slot == 45 && holder.page > 0) {
            open(p, holder.page - 1, holder.mine);
            return;
        }
        if (slot == 53) {
            open(p, holder.page + 1, holder.mine);
            return;
        }
        if (slot < 0 || slot >= holder.shown.size()) return;
        Listing l = holder.shown.get(slot);
        p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.0f);
        if (e.getClick() == ClickType.LEFT || e.getClick() == ClickType.SHIFT_LEFT) {
            preview(p, l);
        } else if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) {
            if (l.seller.equals(p.getUniqueId())) {
                remove(l.id);
                plugin.getMessageUtil().send(p, "&7Dein Angebot wurde zurückgezogen.");
                open(p, holder.page, holder.mine);
            } else {
                buy(p, l);
            }
        }
    }

    private void preview(Player p, Listing l) {
        World w = Bukkit.getWorld(l.world);
        if (w == null) {
            plugin.getMessageUtil().send(p, "&cDiese Welt ist gerade nicht da.");
            return;
        }
        p.closeInventory();
        p.teleport(new Location(w, l.x, l.y + 1, l.z));
        plugin.getMessageUtil().send(p, "&aDu besichtigst das Grundstück von &f" + l.sellerName + "&a. Zurück mit &f/back&a. Kaufen über &f/immo&a.");
    }

    private void buy(Player p, Listing l) {
        long now = System.currentTimeMillis();
        long[] pend = pendingBuy.get(p.getUniqueId());
        if (pend == null || pend[0] != l.id || pend[1] < now) {
            pendingBuy.put(p.getUniqueId(), new long[]{l.id, now + 10_000});
            plugin.getMessageUtil().send(p, "&eKauf bestätigen: klicke innerhalb von 10 Sekunden nochmal mit Rechtsklick (&f" + money(l.price) + "&e).");
            return;
        }
        pendingBuy.remove(p.getUniqueId());
        EconomyManager eco = eco();
        if (eco == null) {
            plugin.getMessageUtil().send(p, "&cDas Wirtschaftssystem schläft gerade.");
            return;
        }
        Listing fresh = listing(l.id);
        if (fresh == null) {
            plugin.getMessageUtil().send(p, "&cDieses Angebot gibt es nicht mehr.");
            open(p, 0, false);
            return;
        }
        World w = Bukkit.getWorld(fresh.world);
        PlotBridge.PlotRef ref = w == null ? null : bridge.plotAt(new Location(w, fresh.x, fresh.y, fresh.z));
        if (ref == null || ref.owner() == null || !ref.owner().equals(fresh.seller)) {
            remove(fresh.id);
            plugin.getMessageUtil().send(p, "&cDas Grundstück gehört dem Verkäufer nicht mehr. Das Angebot wurde entfernt.");
            open(p, 0, false);
            return;
        }
        if (!eco.withdraw(p.getUniqueId(), fresh.price)) {
            plugin.getMessageUtil().send(p, "&cDafür fehlt dir das Geld (&f" + money(fresh.price) + "&c).");
            return;
        }
        if (!bridge.transfer(ref, p.getUniqueId())) {
            eco.deposit(p.getUniqueId(), fresh.price);
            plugin.getMessageUtil().send(p, "&c" + bridge.error() + " &7Dein Geld wurde zurückgegeben.");
            return;
        }
        double tax = Math.floor(fresh.price * plugin.getConfig().getInt("immobilien.tax-percent", 5) / 100.0);
        eco.deposit(fresh.seller, fresh.price - tax);
        remove(fresh.id);
        p.closeInventory();
        plugin.getMessageUtil().send(p, "&aDas Grundstück gehört jetzt dir! &7Zahl: &f" + money(fresh.price));
        p.playSound(p.getLocation(), "entity.player.levelup", 0.8f, 1.2f);
        Player seller = Bukkit.getPlayer(fresh.seller);
        if (seller != null) {
            plugin.getMessageUtil().send(seller, "&a" + p.getName() + " hat dein Grundstück gekauft: &f" + money(fresh.price - tax) + " &7(nach " + money(tax) + " Steuer)");
        }
        Bukkit.broadcastMessage(c("&8[&a☠&8] &7Ein Grundstück wurde für &e" + money(fresh.price) + " &7verkauft."));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) {
            List<String> out = new ArrayList<>(List.of("verkaufen", "abbrechen", "hilfe"));
            out.removeIf(x -> !x.startsWith(a[0].toLowerCase(Locale.ROOT)));
            return out;
        }
        return List.of();
    }
}
