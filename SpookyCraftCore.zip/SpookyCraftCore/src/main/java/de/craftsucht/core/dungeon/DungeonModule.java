package de.craftsucht.core.dungeon;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** /dungeon near | tp <nr> | list: zeigt Koordinaten der erzeugten Dungeons (nur Admin). Daten: dungeons.yml */
public class DungeonModule implements Module, CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private File file;
    private final List<DungeonRegistry.Dungeon> all = new ArrayList<>();
    private BukkitTask task;

    public DungeonModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "dungeon";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "dungeons.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String k : y.getKeys(false)) {
            all.add(new DungeonRegistry.Dungeon(y.getString(k + ".world", ""), y.getInt(k + ".x"), y.getInt(k + ".y"),
                    y.getInt(k + ".z"), y.getBoolean(k + ".graveyard")));
        }
        plugin.getCommand("dungeon").setExecutor(this);
        plugin.getCommand("dungeon").setTabCompleter(this);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::flush, 200L, 600L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        flush();
    }

    private void flush() {
        boolean changed = false;
        DungeonRegistry.Dungeon d;
        while ((d = DungeonRegistry.NEW.poll()) != null) {
            all.add(d);
            changed = true;
        }
        if (!changed) return;
        YamlConfiguration y = new YamlConfiguration();
        for (int i = 0; i < all.size(); i++) {
            DungeonRegistry.Dungeon e = all.get(i);
            y.set(i + ".world", e.world());
            y.set(i + ".x", e.x());
            y.set(i + ".y", e.y());
            y.set(i + ".z", e.z());
            y.set(i + ".graveyard", e.graveyard());
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("dungeons.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    private String line(int nr, DungeonRegistry.Dungeon d, Player p) {
        String dist = "";
        if (p != null && p.getWorld().getName().equals(d.world())) {
            double dx = p.getLocation().getX() - d.x(), dz = p.getLocation().getZ() - d.z();
            dist = " &8(" + (int) Math.sqrt(dx * dx + dz * dz) + " Blöcke)";
        }
        return " &8#" + nr + " &d" + (d.graveyard() ? "Friedhof-Gruft" : "Dungeon") + " &7in &f" + d.world()
                + " &7bei &fX " + d.x() + " Y " + d.y() + " Z " + d.z() + dist;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender.isOp() || sender.hasPermission("spookycraft.core.admin"))) {
            plugin.getMessageUtil().send(sender, "&cKeine Berechtigung.");
            return true;
        }
        flush();
        Player p = sender instanceof Player pl ? pl : null;
        String sub = args.length == 0 ? "near" : args[0].toLowerCase();
        switch (sub) {
            case "near" -> {
                if (p == null) return true;
                List<DungeonRegistry.Dungeon> sorted = new ArrayList<>();
                for (DungeonRegistry.Dungeon d : all) if (d.world().equals(p.getWorld().getName())) sorted.add(d);
                if (sorted.isEmpty()) {
                    plugin.getMessageUtil().send(p, "&7In dieser Welt wurden noch keine Dungeons erzeugt (nur neue Chunks!).");
                    return true;
                }
                sorted.sort(Comparator.comparingDouble(d -> Math.pow(d.x() - p.getLocation().getX(), 2) + Math.pow(d.z() - p.getLocation().getZ(), 2)));
                plugin.getMessageUtil().send(p, "&5☠ &dNächste Dungeons:");
                for (int i = 0; i < Math.min(5, sorted.size()); i++)
                    plugin.getMessageUtil().sendRaw(p, line(all.indexOf(sorted.get(i)) + 1, sorted.get(i), p));
            }
            case "list" -> {
                plugin.getMessageUtil().send(sender, "&5☠ &dDungeons insgesamt: &f" + all.size());
                for (int i = Math.max(0, all.size() - 10); i < all.size(); i++)
                    plugin.getMessageUtil().sendRaw(sender, line(i + 1, all.get(i), p));
            }
            case "tp" -> {
                if (p == null || args.length < 2) {
                    plugin.getMessageUtil().send(sender, "&cNutzung: /dungeon tp <nummer>");
                    return true;
                }
                int nr;
                try {
                    nr = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    plugin.getMessageUtil().send(p, "&cUngültige Zahl.");
                    return true;
                }
                if (nr < 1 || nr > all.size()) {
                    plugin.getMessageUtil().send(p, "&cDiese Nummer gibt es nicht.");
                    return true;
                }
                DungeonRegistry.Dungeon d = all.get(nr - 1);
                org.bukkit.World w = Bukkit.getWorld(d.world());
                if (w == null) {
                    plugin.getMessageUtil().send(p, "&cDie Welt ist nicht geladen.");
                    return true;
                }
                // Dungeons: in den Raum (y + 1); Gruft: ueber die Oberflaeche
                int y = d.graveyard() ? w.getHighestBlockYAt(d.x(), d.z()) + 2 : d.y() + 1;
                p.teleport(new Location(w, d.x() + 0.5, y, d.z() + 0.5));
                plugin.getMessageUtil().send(p, "&aTeleportiert zu #" + nr + ".");
            }
            default -> plugin.getMessageUtil().send(sender, "&cNutzung: /dungeon near|list|tp <nummer>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "near", "list", "tp");
        return List.of();
    }
}
