package de.craftsucht.core.markt;

import org.bukkit.Material;

import java.util.UUID;

/**
 * Ein Eintrag im Spielermarkt.
 * buy == true  -> Kaufauftrag (Geld liegt bereits im Treuhand-Topf, andere Spieler verkaufen hinein)
 * buy == false -> Verkaufsangebot (Items liegen bereits im Treuhand-Topf, andere Spieler kaufen daraus)
 */
public record MarketOrder(int id, UUID owner, String ownerName, Material material, boolean buy,
                          double price, int remaining, long createdAt) {
}
