package de.craftsucht.core.markt;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Baut die Markt-Kategorien automatisch aus allen Vanilla-Items auf (wie beim OPSUCHT-Marktplatz,
 * der "Ressourcen und Vanilla-Items" handelt). Werkzeuge, Waffen, Rüstungen und Spawn-Eier gehören bei
 * OPSUCHT ins Auktionshaus und sind hier ausgeschlossen.
 * Kategorien: Bergbau, Holz, Nahrung, Kampf, Besonderes, Sonstiges.
 */
public final class MarketCatalog {

    private MarketCatalog() {
    }

    private static final Pattern EXCLUDED = Pattern.compile(
            "SPAWNER|TRIAL_SPAWNER|VAULT|.+_SHULKER_BOX|COMMAND_BLOCK.*|CHAIN_COMMAND_BLOCK|REPEATING_COMMAND_BLOCK|"
                    + "BARRIER|LIGHT|STRUCTURE_BLOCK|STRUCTURE_VOID|JIGSAW|DEBUG_STICK|KNOWLEDGE_BOOK|END_PORTAL_FRAME|"
                    + "REINFORCED_DEEPSLATE|PETRIFIED_OAK_SLAB|FARMLAND|DIRT_PATH|CHORUS_PLANT|FROGSPAWN|TEST_.*|"
                    + "ENCHANTED_BOOK|POTION|SPLASH_POTION|LINGERING_POTION|TIPPED_ARROW|WRITTEN_BOOK|FILLED_MAP|"
                    + "PLAYER_HEAD|SUSPICIOUS_STEW|MACE|TRIDENT|AIR|CAVE_AIR|VOID_AIR");

    /** Kategorie "Besonderes": Netherstern, Totem, Bedrock, Beacons, Elytren, die Standard-Shulkerkiste (keine gefärbten) und alle Spawn-Eier. */
    private static final Set<String> SPECIAL = Set.of("NETHER_STAR", "TOTEM_OF_UNDYING", "BEDROCK", "BEACON", "SHULKER_BOX", "ELYTRA");

    private static boolean isSpecial(String n) {
        return SPECIAL.contains(n) || n.endsWith("_SPAWN_EGG");
    }

    private static final Set<String> MINING = Set.of(
            "COAL", "CHARCOAL", "DIAMOND", "EMERALD", "LAPIS_LAZULI", "REDSTONE", "QUARTZ", "AMETHYST_SHARD",
            "NETHERITE_SCRAP", "ANCIENT_DEBRIS", "GLOWSTONE_DUST", "GLOWSTONE", "OBSIDIAN", "CRYING_OBSIDIAN",
            "COAL_BLOCK", "IRON_BLOCK", "GOLD_BLOCK", "DIAMOND_BLOCK", "EMERALD_BLOCK", "LAPIS_BLOCK",
            "REDSTONE_BLOCK", "COPPER_BLOCK", "NETHERITE_BLOCK", "AMETHYST_BLOCK", "QUARTZ_BLOCK", "RAW_IRON_BLOCK",
            "RAW_GOLD_BLOCK", "RAW_COPPER_BLOCK", "FLINT", "COPPER_INGOT", "IRON_NUGGET", "GOLD_NUGGET");

    private static final Set<String> COMBAT = Set.of(
            "ENDER_PEARL", "GUNPOWDER", "ROTTEN_FLESH", "BONE", "BONE_BLOCK", "STRING", "SPIDER_EYE", "BLAZE_ROD",
            "BLAZE_POWDER", "SLIME_BALL", "SLIME_BLOCK", "MAGMA_CREAM", "GHAST_TEAR", "ENDER_EYE", "PHANTOM_MEMBRANE",
            "LEATHER", "FEATHER", "ARROW", "SPECTRAL_ARROW", "HONEYCOMB", "SHULKER_SHELL", "PRISMARINE_SHARD",
            "PRISMARINE_CRYSTALS", "INK_SAC", "GLOW_INK_SAC", "RABBIT_HIDE", "RABBIT_FOOT", "TURTLE_SCUTE",
            "ARMADILLO_SCUTE", "NAUTILUS_SHELL", "HEART_OF_THE_SEA", "DRAGON_BREATH", "FIRE_CHARGE", "TNT",
            "END_CRYSTAL", "EXPERIENCE_BOTTLE", "WITHER_SKELETON_SKULL", "ECHO_SHARD", "GLASS_BOTTLE", "FERMENTED_SPIDER_EYE",
            "BLAZE_SPAWN", "NETHER_WART", "PUFFERFISH_BUCKET");

    private static final Set<String> FOOD_EXTRA = Set.of(
            "WHEAT", "WHEAT_SEEDS", "BEETROOT_SEEDS", "MELON_SEEDS", "PUMPKIN_SEEDS", "TORCHFLOWER_SEEDS", "MELON",
            "PUMPKIN", "HAY_BLOCK", "EGG", "MILK_BUCKET", "COCOA_BEANS", "SWEET_BERRIES", "GLOW_BERRIES", "KELP",
            "DRIED_KELP_BLOCK", "BROWN_MUSHROOM", "RED_MUSHROOM", "CAKE", "SUGAR", "BEETROOT", "CARROT", "POTATO",
            "NETHER_WART_BLOCK", "SEA_PICKLE", "BAKED_POTATO", "HONEY_BLOCK", "HONEY_BOTTLE");

    /** @return Kategorie-Key oder null, wenn das Item nicht handelbar ist */
    public static String classify(Material m) {
        String n = m.name();
        if (!m.isItem() || m.isLegacy()) return null;
        if (m.getMaxDurability() > 0 && !n.equals("ELYTRA")) return null; // Werkzeuge/Waffen/Rüstung -> Auktionshaus
        if (EXCLUDED.matcher(n).matches()) return null;

        if (isSpecial(n)) return "besonderes";
        if (COMBAT.contains(n)) return "kampf";
        if (n.endsWith("_ORE") || n.startsWith("RAW_") || n.endsWith("_INGOT") || MINING.contains(n)) return "bergbau";
        if (n.endsWith("_LOG") || n.endsWith("_WOOD") || n.endsWith("_PLANKS") || n.endsWith("_STEM")
                || n.endsWith("_HYPHAE") || n.endsWith("_SAPLING") || n.equals("STICK") || n.equals("BAMBOO")
                || n.equals("BAMBOO_BLOCK") || n.equals("STRIPPED_BAMBOO_BLOCK") || n.equals("MANGROVE_PROPAGULE")) {
            return "holz";
        }
        if (m.isEdible() || FOOD_EXTRA.contains(n)) return "nahrung";
        return "sonstiges";
    }

    /** Alle handelbaren Items je Kategorie, alphabetisch sortiert. */
    public static Map<String, List<Material>> build() {
        Map<String, List<Material>> result = new LinkedHashMap<>();
        for (String key : new String[]{"bergbau", "holz", "nahrung", "kampf", "besonderes", "sonstiges"}) {
            result.put(key, new ArrayList<>());
        }
        for (Material m : Material.values()) {
            String key = classify(m);
            if (key != null) result.get(key).add(m);
        }
        result.values().forEach(list -> list.sort(Comparator.comparing(Material::name)));
        return result;
    }
}
