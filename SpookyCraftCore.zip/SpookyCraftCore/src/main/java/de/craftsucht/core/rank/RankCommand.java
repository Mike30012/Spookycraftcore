package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.*;

public class RankCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final RankManager manager;

    public RankCommand(SpookyCraftCore plugin, RankManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length == 0) {
            plugin.getMessageUtil().send(sender, "&7/rank create|delete|setprefix|setweight|setparent|setpermission|unsetpermission|addpermissions|info|list|user");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> create(sender, args);
            case "delete" -> delete(sender, args);
            case "setprefix" -> setPrefix(sender, args);
            case "setweight" -> setWeight(sender, args);
            case "setparent" -> setParent(sender, args);
            case "setpermission" -> setPermission(sender, args, true);
            case "unsetpermission" -> setPermission(sender, args, false);
            case "addpermissions" -> {
                if (args.length < 3) {
                    plugin.getMessageUtil().send(sender, "&cNutzung: /rank addpermissions <name> <perm1> <perm2> ...");
                } else if (manager.getRank(args[1]) == null) {
                    plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
                } else {
                    for (int i = 2; i < args.length; i++) manager.setPermission(args[1], args[i], true);
                    refreshOnlinePlayers();
                    plugin.getMessageUtil().send(sender, "&a" + (args.length - 2) + " Rechte hinzugefügt.");
                }
            }
            case "info" -> info(sender, args);
            case "list" -> list(sender);
            case "user" -> user(sender, args);
            default -> plugin.getMessageUtil().send(sender, "&cUnbekannter Unterbefehl.");
        }
        return true;
    }

    private void create(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank create <&farbe&lName, z.B. &4&lOwner> [gewicht]");
            return;
        }
        String prefix = args[1];
        String plainName = org.bukkit.ChatColor.stripColor(
                org.bukkit.ChatColor.translateAlternateColorCodes('&', prefix));
        if (plainName == null || plainName.isBlank()) {
            plugin.getMessageUtil().send(sender, "&cDer Rang braucht auch sichtbaren Text, nicht nur Farbcodes.");
            return;
        }
        int weight = args.length > 2 ? parseIntOr(args[2], 0) : 0;
        boolean ok = manager.createRank(plainName, prefix, weight, null);
        if (ok) {
            plugin.getMessageUtil().send(sender, "&aRang &r" + plugin.getMessageUtil().color(prefix) + " &aerstellt.");
            refreshVisuals();
        } else {
            plugin.getMessageUtil().send(sender, "&cRang existiert bereits.");
        }
    }

    private void delete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank delete <name>");
            return;
        }
        manager.deleteRank(args[1]);
        plugin.getMessageUtil().send(sender, "&aRang gelöscht.");
        refreshVisuals();
    }

    private void setPrefix(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setprefix <name> <prefix>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        manager.updatePrefix(rank.name(), args[2]);
        plugin.getMessageUtil().send(sender, "&aPrefix gesetzt.");
        refreshVisuals();
    }

    private void setWeight(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setweight <name> <zahl>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        manager.updateRank(rank.name(), rank.prefix(), parseIntOr(args[2], rank.weight()), rank.parent());
        plugin.getMessageUtil().send(sender, "&aGewicht gesetzt.");
    }

    private void setParent(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setparent <name> <elternrang>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        manager.updateRank(rank.name(), rank.prefix(), rank.weight(), args[2].equalsIgnoreCase("none") ? null : args[2]);
        plugin.getMessageUtil().send(sender, "&aElternrang gesetzt.");
    }

    private void setPermission(CommandSender sender, String[] args, boolean set) {
        if (set && args.length < 4) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setpermission <name> <permission> <true|false>");
            return;
        }
        if (!set && args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank unsetpermission <name> <permission>");
            return;
        }
        if (set) {
            manager.setPermission(args[1], args[2], Boolean.parseBoolean(args[3]));
        } else {
            manager.unsetPermission(args[1], args[2]);
        }
        refreshOnlinePlayers();
        plugin.getMessageUtil().send(sender, "&aErledigt.");
    }

    private void info(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank info <name>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        plugin.getMessageUtil().sendRaw(sender, "&8--- &bRang " + rank.name() + " &8---");
        plugin.getMessageUtil().sendRaw(sender, "&7Prefix: " + rank.prefix() + " &7Gewicht: &b" + rank.weight() + " &7Eltern: &b" + (rank.parent() != null ? rank.parent() : "-"));
        Map<String, Boolean> perms = manager.getOwnPermissions(rank.name());
        for (Map.Entry<String, Boolean> entry : perms.entrySet()) {
            plugin.getMessageUtil().sendRaw(sender, (entry.getValue() ? "&a+ " : "&c- ") + entry.getKey());
        }
    }

    private void list(CommandSender sender) {
        plugin.getMessageUtil().sendRaw(sender, "&8--- &bRänge &8---");
        for (RankManager.RankData rank : manager.listRanks()) {
            plugin.getMessageUtil().sendRaw(sender, rank.prefix() + rank.name() + " &7(Gewicht " + rank.weight() + ")");
        }
    }

    private void user(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank user <spieler> <set <rang>|info>");
            return;
        }
        OfflinePlayer target = resolveTarget(args[1]);
        if (args[2].equalsIgnoreCase("info")) {
            plugin.getMessageUtil().send(sender, "&7" + target.getName() + " hat Rang &b" + manager.getUserRank(target.getUniqueId())
                    + " &8(UUID " + target.getUniqueId() + ")");
            return;
        }
        if (args[2].equalsIgnoreCase("set")) {
            if (args.length < 4) {
                plugin.getMessageUtil().send(sender, "&cNutzung: /rank user <spieler> set <rang>");
                return;
            }
            if (manager.getRank(args[3]) == null) {
                plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
                return;
            }
            manager.setUserRank(target.getUniqueId(), args[3]);
            if (target.isOnline() && target.getPlayer() != null) {
                manager.apply(target.getPlayer());
            }
            plugin.getMessageUtil().send(sender, "&aRang gesetzt.");
            refreshVisuals();
        }
    }

    /**
     * Findet den Spieler auch bei Bedrock-Namen (Floodgate setzt einen Punkt davor, z.B. ".Tavrox12345"):
     * erst online (mit oder ohne Punkt), dann unter den bekannten Spielern, zuletzt wie bisher.
     * So landet der Rang bei der echten Bedrock-UUID und nicht bei einer errechneten Offline-UUID.
     */
    private OfflinePlayer resolveTarget(String input) {
        for (var p : Bukkit.getOnlinePlayers()) {
            String n = p.getName();
            if (n.equalsIgnoreCase(input) || n.equalsIgnoreCase("." + input) || (n.startsWith(".") && n.substring(1).equalsIgnoreCase(input))) {
                return p;
            }
        }
        for (OfflinePlayer op : Bukkit.getOfflinePlayers()) {
            String n = op.getName();
            if (n == null) continue;
            if (n.equalsIgnoreCase(input) || n.equalsIgnoreCase("." + input) || (n.startsWith(".") && n.substring(1).equalsIgnoreCase(input))) {
                return op;
            }
        }
        return Bukkit.getOfflinePlayer(input);
    }

    private void refreshOnlinePlayers() {
        for (var p : Bukkit.getOnlinePlayers()) {
            manager.apply(p);
        }
    }

    /** Aktualisiert Tabliste/Nametag/Scoreboard sofort, statt auf den nächsten Tick zu warten. */
    private void refreshVisuals() {
        de.craftsucht.core.module.Module m = plugin.getModuleManager().get("scoreboard");
        if (m instanceof de.craftsucht.core.scoreboard.ScoreboardModule sm) {
            sm.refreshNow();
        }
    }

    private int parseIntOr(String s, int fallback) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return TabCompleteUtil.filter(args[0], "create", "delete", "setprefix", "setweight", "setparent",
                    "setpermission", "unsetpermission", "addpermissions", "info", "list", "user");
        }
        if (args.length == 2 && List.of("delete", "setprefix", "setweight", "setparent", "setpermission", "unsetpermission", "info").contains(args[0].toLowerCase())) {
            List<String> names = new ArrayList<>();
            for (RankManager.RankData r : manager.listRanks()) names.add(r.name());
            return names;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("user")) {
            return TabCompleteUtil.onlinePlayers(args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("user")) {
            return TabCompleteUtil.filter(args[2], "set", "info");
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("user") && args[2].equalsIgnoreCase("set")) {
            List<String> names = new ArrayList<>();
            for (RankManager.RankData r : manager.listRanks()) names.add(r.name());
            return names;
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("setpermission") || args[0].equalsIgnoreCase("unsetpermission"))) {
            List<String> results = new ArrayList<>(KnownPermissions.search(args[2]));
            if ("*".startsWith(args[2])) results.add(0, "*");
            return results;
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("setpermission")) {
            return TabCompleteUtil.filter(args[3], "true", "false");
        }
        return Collections.emptyList();
    }
}
