package de.craftsucht.core.shopkiste;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Eine Shopkiste: Kiste + Schild. buy/sell sind Preise für "amount" Items; -1 = gibt es nicht.
 * buy  = Preis, zu dem andere Spieler bei dem Besitzer KAUFEN (Rechtsklick auf das Schild)
 * sell = Preis, zu dem andere Spieler an den Besitzer VERKAUFEN (Linksklick auf das Schild)
 */
public record ShopRecord(int id, String world, int sx, int sy, int sz, int cx, int cy, int cz,
                         UUID owner, String ownerName, ItemStack item, int amount, double buy, double sell) {

    public boolean canBuy() {
        return buy >= 0;
    }

    public boolean canSell() {
        return sell >= 0;
    }
}
