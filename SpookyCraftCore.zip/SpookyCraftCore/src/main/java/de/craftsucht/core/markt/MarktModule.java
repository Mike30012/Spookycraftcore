package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * /markt - Spielermarkt nach OPSUCHT-Vorbild: Kategorien durchstöbern, Kaufaufträge und
 * Verkaufsangebote erstellen, Items im Markt-Menü abholen. /sell verkauft schnell an bestehende Kaufaufträge.
 * Welche Items handelbar sind, steht in shop.yml (Kategorien + Items; die Preise dort werden nicht mehr benutzt).
 */
public class MarktModule implements Module, CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private ShopManager shopManager;
    private MarketRepository repository;
    private MarketService service;
    private GuiManager gui;
    private GuiListener guiListener;
    private MarktNpc npc;

    public MarktModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "markt";
    }

    @Override
    public void enable() {
        this.shopManager = new ShopManager(plugin);
        shopManager.load();
        this.repository = new MarketRepository(plugin);
        repository.init();
        this.service = new MarketService(plugin, repository, shopManager);
        this.gui = new GuiManager(plugin, shopManager, repository, service);
        this.guiListener = new GuiListener(plugin, repository, service, gui);
        Bukkit.getPluginManager().registerEvents(guiListener, plugin);
        this.npc = new MarktNpc(plugin, gui);
        Bukkit.getPluginManager().registerEvents(npc, plugin);

        for (String name : new String[]{"markt", "sell"}) {
            PluginCommand command = plugin.getCommand(name);
            if (command != null) {
                command.setExecutor(this);
                command.setTabCompleter(this);
            }
        }
    }

    @Override
    public void disable() {
        if (guiListener != null) HandlerList.unregisterAll(guiListener);
        if (npc != null) HandlerList.unregisterAll(npc);
    }

    public ShopManager getShopManager() {
        return shopManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessageUtil().send(sender, "&cNur Spieler können den Markt benutzen.");
            return true;
        }
        if (command.getName().equalsIgnoreCase("sell")) {
            return handleSell(player, args);
        }

        if (args.length == 0) {
            gui.openMain(player);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                if (!player.isOp() && !player.hasPermission("spookycraft.core.admin")) {
                    plugin.getMessageUtil().send(player, "&cKeine Berechtigung.");
                    return true;
                }
                shopManager.load();
                plugin.getMessageUtil().send(player, "&aMarkt neu geladen.");
            }
            case "npc" -> {
                if (!player.isOp() && !player.hasPermission("spookycraft.core.admin") && !player.hasPermission("spookycraft.markt.npc")) {
                    plugin.getMessageUtil().send(player, "&cKeine Berechtigung.");
                    return true;
                }
                String sub = args.length > 1 ? args[1].toLowerCase() : "";
                if (sub.equals("spawn")) {
                    if (npc.spawn(player)) {
                        plugin.getMessageUtil().send(player, "&aMarkt-NPC erstellt. Rechtsklick öffnet den Markt. Entfernen: &e/markt npc remove &a(nächster NPC im Umkreis von 6 Blöcken).");
                    } else {
                        plugin.getMessageUtil().send(player, "&cDer NPC konnte nicht erstellt werden. Wahrscheinlich blockiert ein anderes Plugin das Spawnen - Details stehen in der Server-Konsole.");
                    }
                } else if (sub.equals("remove")) {
                    plugin.getMessageUtil().send(player, npc.removeNearest(player, 6.0)
                            ? "&aMarkt-NPC entfernt." : "&cKein Markt-NPC im Umkreis von 6 Blöcken gefunden.");
                } else {
                    plugin.getMessageUtil().send(player, "&cNutzung: /markt npc <spawn|remove>");
                }
            }
            case "abholen", "pickup" -> gui.openPickup(player);
            case "auftraege", "aufträge", "orders" -> gui.openOrders(player);
            default -> {
                Material material = Material.matchMaterial(args[0]);
                if (material != null && service.isTradable(material)) {
                    gui.openItem(player, material, null);
                } else {
                    plugin.getMessageUtil().send(player, "&cDieses Item wird im Markt nicht gehandelt. &7Nutze &e/markt &7und stöbere durch die Kategorien.");
                }
            }
        }
        return true;
    }

    /** /sell [alle|menge] - verkauft das Item in der Hand sofort an die höchsten Kaufaufträge. */
    private boolean handleSell(Player player, String[] args) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) {
            plugin.getMessageUtil().send(player, "&cDu hältst kein Item in der Hand.");
            return true;
        }
        if (hand.hasItemMeta() || !service.isTradable(hand.getType())) {
            plugin.getMessageUtil().send(player, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return true;
        }
        int amount = hand.getAmount();
        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("alle") || args[0].equalsIgnoreCase("all")) {
                amount = service.countPlain(player, hand.getType());
            } else {
                try {
                    amount = Math.max(1, Integer.parseInt(args[0]));
                } catch (NumberFormatException e) {
                    plugin.getMessageUtil().send(player, "&cNutzung: /sell [alle|menge]");
                    return true;
                }
            }
        }
        service.quickSell(player, hand.getType(), amount);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 2 && command.getName().equalsIgnoreCase("markt") && args[0].equalsIgnoreCase("npc")) {
            return TabCompleteUtil.filter(args[1], "spawn", "remove");
        }
        if (args.length != 1) return Collections.emptyList();
        if (command.getName().equalsIgnoreCase("sell")) {
            return TabCompleteUtil.filter(args[0], "alle");
        }
        List<String> options = new ArrayList<>(List.of("abholen", "auftraege"));
        if (sender.isOp() || sender.hasPermission("spookycraft.core.admin")) {
            options.add("reload");
            options.add("npc");
        }
        for (Material material : shopManager.getTradableMaterials()) {
            options.add(material.name().toLowerCase());
        }
        return TabCompleteUtil.filter(args[0], options.toArray(new String[0]));
    }
}
