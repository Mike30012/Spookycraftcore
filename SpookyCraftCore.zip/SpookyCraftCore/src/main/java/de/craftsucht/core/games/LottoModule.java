package de.craftsucht.core.games;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Geister-Lotto: /lotto buy [anzahl]. Alle lotto.draw-hours Stunden wird ein Los gezogen,
 * der Gewinner bekommt den Topf (abzueglich lotto.tax-percent als Geld-Senke). Ohne Lose geht der Topf in die naechste Runde.
 * Daten: lotto.yml
 */
public class LottoModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private final Map<UUID, Integer> tickets = new LinkedHashMap<>();
    private long nextDraw;
    private double pot;
    private BukkitTask task;

    public LottoModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "lotto";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "lotto.yml");
        data = YamlConfiguration.loadConfiguration(file);
        tickets.clear();
        if (data.getConfigurationSection("tickets") != null) {
            for (String k : data.getConfigurationSection("tickets").getKeys(false)) {
                try {
                    tickets.put(UUID.fromString(k), data.getInt("tickets." + k));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        pot = data.getDouble("pot", plugin.getConfig().getDouble("lotto.start-pot", 5000));
        nextDraw = data.getLong("next-draw", 0);
        if (nextDraw <= 0) nextDraw = System.currentTimeMillis() + drawMillis();
        plugin.getCommand("lotto").setExecutor(this);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L * 30, 20L * 30);
        save();
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        save();
    }

    private long drawMillis() {
        return Math.max(1, plugin.getConfig().getLong("lotto.draw-hours", 24)) * 3_600_000L;
    }

    private void save() {
        data.set("pot", pot);
        data.set("next-draw", nextDraw);
        data.set("tickets", null);
        for (Map.Entry<UUID, Integer> e : tickets.entrySet()) data.set("tickets." + e.getKey(), e.getValue());
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("lotto.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    private int total() {
        int t = 0;
        for (int v : tickets.values()) t += v;
        return t;
    }

    private void tick() {
        if (System.currentTimeMillis() < nextDraw) return;
        draw();
    }

    private void draw() {
        int total = total();
        nextDraw = System.currentTimeMillis() + drawMillis();
        if (total == 0) {
            Bukkit.broadcastMessage(plugin.getMessageUtil().color("&5☠ &dDas Lotto der Geister: &7Niemand hat ein Los gekauft. Der Topf wächst auf &e"
                    + GameUtil.money(pot) + "&7!"));
            save();
            return;
        }
        int pick = ThreadLocalRandom.current().nextInt(total);
        UUID winner = null;
        for (Map.Entry<UUID, Integer> e : tickets.entrySet()) {
            pick -= e.getValue();
            if (pick < 0) {
                winner = e.getKey();
                break;
            }
        }
        double tax = Math.max(0, Math.min(100, plugin.getConfig().getDouble("lotto.tax-percent", 10)));
        double prize = Math.floor(pot * (1 - tax / 100.0));
        EconomyManager eco = GameUtil.eco(plugin);
        if (winner != null && eco != null) {
            eco.deposit(winner, prize);
            String name = Bukkit.getOfflinePlayer(winner).getName();
            Bukkit.broadcastMessage(plugin.getMessageUtil().color("&5☠ &dDie Geister haben gezogen! &f" + (name == null ? "Ein Unbekannter" : name)
                    + " &dgewinnt &e" + GameUtil.money(prize) + " &dim Lotto! &7(" + total + " Lose im Topf)"));
            Player w = Bukkit.getPlayer(winner);
            if (w != null) w.playSound(w.getLocation(), "entity.witch.celebrate", 1.0f, 1.0f);
        }
        tickets.clear();
        pot = plugin.getConfig().getDouble("lotto.start-pot", 5000);
        save();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        double price = plugin.getConfig().getDouble("lotto.ticket-price", 500);
        int max = Math.max(1, plugin.getConfig().getInt("lotto.max-tickets-per-player", 20));
        if (args.length >= 1 && args[0].equalsIgnoreCase("buy")) {
            int amount = 1;
            if (args.length >= 2) {
                try {
                    amount = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    plugin.getMessageUtil().send(p, "&cDas ist keine gültige Zahl, Sterblicher.");
                    return true;
                }
            }
            int own = tickets.getOrDefault(p.getUniqueId(), 0);
            if (amount < 1 || own + amount > max) {
                plugin.getMessageUtil().send(p, "&cDu darfst höchstens &f" + max + " &cLose haben (du hast &f" + own + "&c).");
                return true;
            }
            EconomyManager eco = GameUtil.eco(plugin);
            double cost = price * amount;
            if (eco == null || !eco.withdraw(p.getUniqueId(), cost)) {
                plugin.getMessageUtil().send(p, "&cDeine Taschen sind zu leer – " + amount + " Lose kosten &e" + GameUtil.money(cost) + "&c.");
                return true;
            }
            tickets.merge(p.getUniqueId(), amount, Integer::sum);
            double tax = Math.max(0, Math.min(100, plugin.getConfig().getDouble("lotto.tax-percent", 10)));
            pot += cost * (1 - tax / 100.0);
            save();
            p.playSound(p.getLocation(), "entity.experience_orb.pickup", 0.8f, 1.2f);
            plugin.getMessageUtil().send(p, "&5☠ &dDu hast &f" + amount + " &dLos(e) gekauft. Viel Glück!");
            return true;
        }
        long mins = Math.max(0, (nextDraw - System.currentTimeMillis()) / 60_000L);
        plugin.getMessageUtil().sendRaw(p, "&8--- &5☠ &dGeister-Lotto &8---");
        plugin.getMessageUtil().sendRaw(p, "&8» &7Topf: &e" + GameUtil.money(pot));
        plugin.getMessageUtil().sendRaw(p, "&8» &7Lospreis: &e" + GameUtil.money(price) + " &8(max. " + max + " pro Spieler)");
        plugin.getMessageUtil().sendRaw(p, "&8» &7Deine Lose: &f" + tickets.getOrDefault(p.getUniqueId(), 0) + " &8| &7Alle Lose: &f" + total());
        plugin.getMessageUtil().sendRaw(p, "&8» &7Ziehung in: &f" + (mins / 60) + " Std. " + (mins % 60) + " Min.");
        plugin.getMessageUtil().sendRaw(p, "&8» &7Kaufen: &e/lotto buy [anzahl]");
        return true;
    }
}
