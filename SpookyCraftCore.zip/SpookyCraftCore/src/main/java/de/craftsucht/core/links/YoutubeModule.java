package de.craftsucht.core.links;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/** /youtube: zeigt den klickbaren Link zum YouTube-Kanal (config: youtube.url). */
public class YoutubeModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;

    public YoutubeModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "youtube";
    }

    @Override
    public void enable() {
        plugin.getCommand("youtube").setExecutor(this);
    }

    @Override
    public void disable() {
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String url = plugin.getConfig().getString("youtube.url", "https://youtube.com/@LikeMike3008");
        String name = plugin.getConfig().getString("youtube.name", "LikeMike3008");
        sender.sendMessage(Component.text(""));
        sender.sendMessage(Component.text("☠ ", NamedTextColor.DARK_PURPLE)
                .append(Component.text("YouTube-Kanal von ", NamedTextColor.LIGHT_PURPLE))
                .append(Component.text(name, NamedTextColor.RED, TextDecoration.BOLD)));
        sender.sendMessage(Component.text("▶ ", NamedTextColor.RED)
                .append(Component.text(url, NamedTextColor.AQUA, TextDecoration.UNDERLINED)
                        .clickEvent(ClickEvent.openUrl(url))));
        sender.sendMessage(Component.text("Abonniere und lass ein Like da – die Geister danken es dir!", NamedTextColor.GRAY));
        sender.sendMessage(Component.text(""));
        return true;
    }
}
