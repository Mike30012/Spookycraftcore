package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Material;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Datenbankzugriff des Spielermarkts (Aufträge + Abholungs-Lager). */
public class MarketRepository {

    /** Beste Preise je Item. Preis < 0 bedeutet: gibt es nicht. */
    public record Stat(double bestOffer, int offerAmount, double bestBuy, int buyAmount) {
    }

    private final SpookyCraftCore plugin;

    public MarketRepository(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    private Connection conn() throws SQLException {
        return plugin.getDatabase().getConnection();
    }

    public void init() {
        try (Connection c = conn(); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS market_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "owner TEXT NOT NULL, owner_name TEXT, material TEXT NOT NULL, type TEXT NOT NULL, "
                    + "price REAL NOT NULL, remaining INTEGER NOT NULL, created_at INTEGER NOT NULL)");
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_market_material ON market_orders (material, type, price)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS market_pickup (owner TEXT NOT NULL, material TEXT NOT NULL, "
                    + "amount INTEGER NOT NULL, PRIMARY KEY (owner, material))");
        } catch (SQLException e) {
            plugin.getLogger().severe("Markt: Tabellen konnten nicht erstellt werden: " + e.getMessage());
        }
    }

    private MarketOrder map(ResultSet rs) throws SQLException {
        Material material = Material.matchMaterial(rs.getString("material"));
        if (material == null) return null;
        return new MarketOrder(rs.getInt("id"), UUID.fromString(rs.getString("owner")), rs.getString("owner_name"),
                material, "BUY".equals(rs.getString("type")), rs.getDouble("price"), rs.getInt("remaining"),
                rs.getLong("created_at"));
    }

    private static final String COLUMNS = "id, owner, owner_name, material, type, price, remaining, created_at";

    /** Verkaufsangebote: günstigste zuerst. Kaufaufträge: höchster Preis zuerst. Bei Gleichstand der Ältere. */
    public List<MarketOrder> getOrders(Material material, boolean buy) {
        String sql = "SELECT " + COLUMNS + " FROM market_orders WHERE material = ? AND type = ? ORDER BY price "
                + (buy ? "DESC" : "ASC") + ", id ASC";
        List<MarketOrder> result = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, material.name());
            ps.setString(2, buy ? "BUY" : "SELL");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MarketOrder order = map(rs);
                    if (order != null) result.add(order);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt getOrders fehlgeschlagen: " + e.getMessage());
        }
        return result;
    }

    public List<MarketOrder> getOrdersOf(UUID owner) {
        String sql = "SELECT " + COLUMNS + " FROM market_orders WHERE owner = ? ORDER BY id ASC";
        List<MarketOrder> result = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, owner.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MarketOrder order = map(rs);
                    if (order != null) result.add(order);
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt getOrdersOf fehlgeschlagen: " + e.getMessage());
        }
        return result;
    }

    public int countOrdersOf(UUID owner) {
        String sql = "SELECT COUNT(*) FROM market_orders WHERE owner = ?";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, owner.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt countOrdersOf fehlgeschlagen: " + e.getMessage());
        }
        return 0;
    }

    public MarketOrder getOrder(int id) {
        String sql = "SELECT " + COLUMNS + " FROM market_orders WHERE id = ?";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt getOrder fehlgeschlagen: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(UUID owner, String ownerName, Material material, boolean buy, double price, int remaining) {
        String sql = "INSERT INTO market_orders (owner, owner_name, material, type, price, remaining, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, owner.toString());
            ps.setString(2, ownerName);
            ps.setString(3, material.name());
            ps.setString(4, buy ? "BUY" : "SELL");
            ps.setDouble(5, price);
            ps.setInt(6, remaining);
            ps.setLong(7, System.currentTimeMillis());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt insert fehlgeschlagen: " + e.getMessage());
            return false;
        }
    }

    /** remaining <= 0 löscht den Auftrag. */
    public void setRemaining(int id, int remaining) {
        String sql = remaining <= 0 ? "DELETE FROM market_orders WHERE id = ?"
                : "UPDATE market_orders SET remaining = ? WHERE id = ?";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (remaining <= 0) {
                ps.setInt(1, id);
            } else {
                ps.setInt(1, remaining);
                ps.setInt(2, id);
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt setRemaining fehlgeschlagen: " + e.getMessage());
        }
    }

    public void delete(int id) {
        setRemaining(id, 0);
    }

    /** Beste Preise und Mengen aller Items in einer Abfrage (für die Kategorie-Ansicht). */
    public Map<Material, Stat> getStats() {
        String sql = "SELECT material, type, MIN(price) AS minp, MAX(price) AS maxp, SUM(remaining) AS total "
                + "FROM market_orders GROUP BY material, type";
        Map<Material, double[]> raw = new EnumMap<>(Material.class);
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Material m = Material.matchMaterial(rs.getString("material"));
                if (m == null) continue;
                double[] a = raw.computeIfAbsent(m, k -> new double[]{-1, 0, -1, 0});
                if ("BUY".equals(rs.getString("type"))) {
                    a[2] = rs.getDouble("maxp");
                    a[3] = rs.getInt("total");
                } else {
                    a[0] = rs.getDouble("minp");
                    a[1] = rs.getInt("total");
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt getStats fehlgeschlagen: " + e.getMessage());
        }
        Map<Material, Stat> result = new EnumMap<>(Material.class);
        raw.forEach((m, a) -> result.put(m, new Stat(a[0], (int) a[1], a[2], (int) a[3])));
        return result;
    }

    // ------------------------------------------------------------------ Abholungs-Lager

    public Map<Material, Integer> getPickups(UUID owner) {
        String sql = "SELECT material, amount FROM market_pickup WHERE owner = ? AND amount > 0 ORDER BY material";
        Map<Material, Integer> result = new LinkedHashMap<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, owner.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Material m = Material.matchMaterial(rs.getString("material"));
                    if (m != null) result.put(m, rs.getInt("amount"));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt getPickups fehlgeschlagen: " + e.getMessage());
        }
        return result;
    }

    public int countPickupItems(UUID owner) {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM market_pickup WHERE owner = ?";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, owner.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt countPickupItems fehlgeschlagen: " + e.getMessage());
        }
        return 0;
    }

    public void addPickup(UUID owner, Material material, int amount) {
        String sql = "INSERT INTO market_pickup (owner, material, amount) VALUES (?, ?, ?) "
                + "ON CONFLICT(owner, material) DO UPDATE SET amount = amount + excluded.amount";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, owner.toString());
            ps.setString(2, material.name());
            ps.setInt(3, amount);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt addPickup fehlgeschlagen: " + e.getMessage());
        }
    }

    public void removePickup(UUID owner, Material material, int amount) {
        try (Connection c = conn()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE market_pickup SET amount = amount - ? WHERE owner = ? AND material = ?")) {
                ps.setInt(1, amount);
                ps.setString(2, owner.toString());
                ps.setString(3, material.name());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM market_pickup WHERE amount <= 0")) {
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Markt removePickup fehlgeschlagen: " + e.getMessage());
        }
    }
}
