package de.craftsucht.core.jobs;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Jobs-Actionbar: erscheint nur kurz nach einer passenden Tätigkeit (Block abbauen, Mob töten, angeln)
 * und verschwindet danach wieder von selbst.
 */
public class JobsBar {

    /** So lange bleibt die Bar nach der letzten Tätigkeit sichtbar. */
    private static final long VISIBLE_MILLIS = 4000L;

    private static final class Active {
        String jobId;
        int xp;
        double money;
        long expiresAt;
    }

    private final JobsModule jobs;
    private final Map<UUID, Active> active = new HashMap<>();
    private BukkitTask task;

    public JobsBar(JobsModule jobs) {
        this.jobs = jobs;
    }

    public void start() {
        stop();
        // Hält die Anzeige nur so lange aktiv, wie die Tätigkeit noch frisch ist.
        task = Bukkit.getScheduler().runTaskTimer(jobs.plugin, () -> {
            long now = System.currentTimeMillis();
            Iterator<Map.Entry<UUID, Active>> it = active.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Active> entry = it.next();
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player == null) {
                    it.remove();
                    continue;
                }
                if (now >= entry.getValue().expiresAt) {
                    player.sendActionBar(Component.empty());
                    it.remove();
                } else {
                    render(player, entry.getValue());
                }
            }
        }, 20L, 20L);
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        active.clear();
    }

    /** Wird bei jeder bezahlten Tätigkeit aufgerufen und zeigt die Bar sofort an. */
    public void notifyAction(Player player, String jobId, int xp, double money) {
        Active a = active.computeIfAbsent(player.getUniqueId(), k -> new Active());
        a.jobId = jobId;
        a.xp = xp;
        a.money = money;
        a.expiresAt = System.currentTimeMillis() + VISIBLE_MILLIS;
        render(player, a);
    }

    private void render(Player player, Active a) {
        PlayerData data = jobs.getPlayerDataManager().get(player.getUniqueId());
        JobData jd = data.getOrCreateJob(a.jobId);
        int xp = jd.getXp();
        int needed = jd.getXpForNextLevel();
        double percent = needed <= 0 ? 1.0 : Math.min(1.0, (double) xp / needed);
        int bars = 20;
        int filled = (int) Math.round(percent * bars);
        StringBuilder progress = new StringBuilder();
        for (int i = 0; i < bars; i++) progress.append(i < filled ? "§a▌" : "§7▌");

        String symbol = jobs.getJobManager().getCurrencySymbol();
        String display = jobs.getJobManager().getJobDisplayName(a.jobId);
        String bar = ChatColor.WHITE + "+" + a.xp + " XP"
                + ChatColor.DARK_GRAY + " • " + ChatColor.GREEN + "+" + symbol + String.format("%.2f", a.money)
                + ChatColor.DARK_GRAY + " • " + display + ChatColor.WHITE + " Level " + jd.getLevel()
                + ChatColor.DARK_GRAY + " • " + progress
                + ChatColor.GRAY + " " + xp + "/" + needed;
        player.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(bar));
    }
}
