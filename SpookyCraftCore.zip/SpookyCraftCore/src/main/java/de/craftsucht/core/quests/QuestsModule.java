package de.craftsucht.core.quests;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * /quests: jeden Tag 3 neue Aufgaben (abbauen, toeten, angeln) mit Belohnung. Die Auswahl pro Tag ist fuer alle gleich.
 * Eigene Aufgaben unter quests.list: [{id, name, type: blocks|kills|fish, amount, money, crystals}]. Stand in quests.yml.
 */
public class QuestsModule implements Module, CommandExecutor, Listener {

    private record Q(String id, String name, String type, int amount, long money, long crystals) {
    }

    private static final class QHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public QuestsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "quests";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "quests.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("quests").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        save();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("quests.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private List<Q> pool() {
        List<Q> out = new ArrayList<>();
        for (var m : plugin.getConfig().getMapList("quests.list")) {
            try {
                out.add(new Q(String.valueOf(m.get("id")), String.valueOf(m.get("name")), String.valueOf(m.get("type")),
                        Integer.parseInt(String.valueOf(m.get("amount"))), num(m.get("money")), num(m.get("crystals"))));
            } catch (NumberFormatException ignored) {
                // kaputter Eintrag
            }
        }
        if (!out.isEmpty()) return out;
        out.add(new Q("b1", "&6Steinbrecher: 300 Blöcke abbauen", "blocks", 300, 3000, 0));
        out.add(new Q("b2", "&6Tiefengräber: 800 Blöcke abbauen", "blocks", 800, 8000, 1));
        out.add(new Q("b3", "&6Grabegeist: 1500 Blöcke abbauen", "blocks", 1500, 15000, 2));
        out.add(new Q("k1", "&cGeisterjagd: 15 Monster töten", "kills", 15, 3000, 0));
        out.add(new Q("k2", "&cSeelenernte: 40 Monster töten", "kills", 40, 8000, 1));
        out.add(new Q("k3", "&cNachtschlächter: 80 Monster töten", "kills", 80, 15000, 2));
        out.add(new Q("f1", "&bAngler: 10 Fische fangen", "fish", 10, 3000, 0));
        out.add(new Q("f2", "&bNetzwerfer: 25 Fische fangen", "fish", 25, 8000, 1));
        return out;
    }

    private static long num(Object o) {
        try {
            return o == null ? 0 : Long.parseLong(String.valueOf(o));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String today() {
        return LocalDate.now(ZoneId.of("Europe/Berlin")).toString();
    }

    /** Die 3 Tages-Aufgaben, fuer alle Spieler gleich. */
    private List<Q> todays() {
        List<Q> pool = pool();
        List<Q> out = new ArrayList<>();
        Random r = new Random(LocalDate.now(ZoneId.of("Europe/Berlin")).toEpochDay() * 31L + 7L);
        int n = Math.min(Math.max(1, plugin.getConfig().getInt("quests.per-day", 3)), pool.size());
        List<Q> copy = new ArrayList<>(pool);
        while (out.size() < n) out.add(copy.remove(r.nextInt(copy.size())));
        return out;
    }

    private String pkey(UUID id) {
        return "players." + id;
    }

    private void ensureDay(UUID id) {
        if (!today().equals(data.getString(pkey(id) + ".day"))) {
            data.set(pkey(id), null);
            data.set(pkey(id) + ".day", today());
        }
    }

    private void progress(Player p, String type, int amount) {
        UUID id = p.getUniqueId();
        ensureDay(id);
        for (Q q : todays()) {
            if (!q.type.equals(type)) continue;
            String base = pkey(id) + ".q." + q.id;
            if (data.getBoolean(base + ".done")) continue;
            int now = data.getInt(base + ".n") + amount;
            if (now >= q.amount) {
                data.set(base + ".n", q.amount);
                data.set(base + ".done", true);
                if (q.money > 0 && plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
                    em.getManager().deposit(id, q.money);
                }
                if (q.crystals > 0 && plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
                    cm.getCrystals().add(id, q.crystals);
                }
                plugin.getMessageUtil().send(p, "&6☠ Aufgabe erfüllt: " + q.name + " &7(&e" + GuiUtil.money(q.money)
                        + (q.crystals > 0 ? " &7+ &d" + q.crystals + " Kristalle" : "") + "&7)");
                p.playSound(p.getLocation(), "entity.experience_orb.pickup", 1f, 1f);
                save();
            } else {
                data.set(base + ".n", now);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        progress(e.getPlayer(), "blocks", 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKill(EntityDeathEvent e) {
        Player p = e.getEntity().getKiller();
        if (p != null && !(e.getEntity() instanceof Player)) progress(p, "kills", 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onFish(PlayerFishEvent e) {
        if (e.getState() == PlayerFishEvent.State.CAUGHT_FISH) progress(e.getPlayer(), "fish", 1);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        ensureDay(p.getUniqueId());
        List<Q> qs = todays();
        Inventory inv = Bukkit.createInventory(new QHolder(), 27, GuiUtil.c("&5&l☠ &dTages-Aufgaben"));
        ItemStack pane = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);
        int[] slots = {10, 12, 14, 16, 11, 13, 15};
        for (int i = 0; i < qs.size() && i < slots.length; i++) {
            Q q = qs.get(i);
            String base = pkey(p.getUniqueId()) + ".q." + q.id;
            boolean done = data.getBoolean(base + ".done");
            int n = Math.min(q.amount, data.getInt(base + ".n"));
            List<String> lore = new ArrayList<>();
            lore.add(done ? "&a✔ erledigt" : "&7Fortschritt: &f" + n + "&8/&f" + q.amount);
            lore.add("&7Belohnung: &e" + GuiUtil.money(q.money) + (q.crystals > 0 ? " &7+ &d" + q.crystals + " Kristalle" : ""));
            Material m = switch (q.type) {
                case "kills" -> Material.IRON_SWORD;
                case "fish" -> Material.FISHING_ROD;
                default -> Material.IRON_PICKAXE;
            };
            ItemStack it = GuiUtil.item(done ? Material.EMERALD : m, q.name, lore);
            inv.setItem(slots[i], done ? GuiUtil.glow(it) : it);
        }
        inv.setItem(22, GuiUtil.item(Material.CLOCK, "&7Neue Aufgaben um Mitternacht"));
        p.openInventory(inv);
        return true;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof QHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof QHolder) e.setCancelled(true);
    }
}
