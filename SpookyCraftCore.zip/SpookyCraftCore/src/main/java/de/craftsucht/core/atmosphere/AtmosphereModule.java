package de.craftsucht.core.atmosphere;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Bat;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.Random;

/**
 * Spooky-Atmosphaere: Nachts (und bei Gewitter) schweben Seelen-/Aschepartikel um Spieler,
 * leise Gruselgeraeusche ertoenen und ab und zu flattern kurzlebige Fledermaeuse vorbei.
 * Nur Dekoration - keine Mobs, die etwas anfassen. Config: atmosphere.* in config.yml.
 */
public class AtmosphereModule implements Module {

    private final SpookyCraftCore plugin;
    private final Random rnd = new Random();
    private BukkitTask task;
    private int tick;

    public AtmosphereModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "atmosphere";
    }

    @Override
    public void enable() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::run, 40L, 40L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
    }

    private boolean isDark(World w) {
        long t = w.getTime();
        return (t >= 13000 && t <= 23000) || w.isThundering();
    }

    private void run() {
        tick++;
        List<String> worlds = plugin.getConfig().getStringList("atmosphere.worlds");
        boolean particles = plugin.getConfig().getBoolean("atmosphere.particles", true);
        boolean sounds = plugin.getConfig().getBoolean("atmosphere.sounds", true);
        boolean bats = plugin.getConfig().getBoolean("atmosphere.bats", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            World w = p.getWorld();
            if (w.getEnvironment() != World.Environment.NORMAL) continue;
            if (!worlds.isEmpty() && !worlds.contains(w.getName())) continue;
            if (!isDark(w)) continue;
            Location l = p.getLocation();
            if (particles) {
                // Nebel/Seelen: im Umkreis verteilt, nicht im Gesicht
                for (int i = 0; i < 6; i++) {
                    double dx = (rnd.nextDouble() - 0.5) * 18, dz = (rnd.nextDouble() - 0.5) * 18;
                    double dy = rnd.nextDouble() * 3 - 0.5;
                    Location q = l.clone().add(dx, dy, dz);
                    p.spawnParticle(Particle.SOUL, q, 1, 0.1, 0.2, 0.1, 0.01);
                    if (i % 2 == 0) p.spawnParticle(Particle.WHITE_ASH, q, 6, 1.5, 0.6, 1.5, 0.0);
                }
            }
            if (sounds && rnd.nextInt(8) == 0) {
                String[] s = {"ambient.cave", "entity.ghast.ambient", "entity.wolf.ambient", "entity.phantom.ambient", "block.bell.resonate"};
                String snd = s[rnd.nextInt(s.length)];
                Location at = l.clone().add((rnd.nextDouble() - 0.5) * 40, 0, (rnd.nextDouble() - 0.5) * 40);
                p.playSound(at, snd, 0.35f, 0.7f + rnd.nextFloat() * 0.4f);
            }
            if (bats && rnd.nextInt(10) == 0 && l.getY() > w.getSeaLevel() - 5
                    && w.getEntitiesByClass(Bat.class).size() < 30) {
                Location at = l.clone().add((rnd.nextDouble() - 0.5) * 20, 3 + rnd.nextDouble() * 4, (rnd.nextDouble() - 0.5) * 20);
                if (at.getBlock().isPassable()) {
                    Bat b = (Bat) w.spawnEntity(at, EntityType.BAT);
                    b.setPersistent(false);
                    b.setRemoveWhenFarAway(true);
                    // Kurzlebig: nach 30 Sekunden wieder weg
                    Bukkit.getScheduler().runTaskLater(plugin, () -> { if (b.isValid()) b.remove(); }, 600L);
                }
            }
        }
    }
}
