package de.craftsucht.core.plots;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

/** Flache Welt mit Grundstuecks-Raster: Gras-Plots, Strassen, Rand aus Halbplatten. */
final class PlotGenerator extends ChunkGenerator {

    private final PlotGrid grid;

    PlotGenerator(PlotGrid grid) {
        this.grid = grid;
    }

    @Override
    public void generateNoise(WorldInfo info, Random random, int cx, int cz, ChunkData data) {
        int minY = info.getMinHeight();
        int top = Math.max(minY + 2, Math.min(info.getMaxHeight() - 3, grid.top));
        data.setRegion(0, minY + 1, 0, 16, top, 16, grid.fill);
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = cx * 16 + lx;
                int z = cz * 16 + lz;
                data.setBlock(lx, minY, lz, Material.BEDROCK);
                if (grid.isPlot(x, z)) {
                    data.setBlock(lx, top, lz, grid.floor);
                } else {
                    data.setBlock(lx, top, lz, grid.roadMat);
                    if (grid.isBorder(x, z)) data.setBlock(lx, top + 1, lz, grid.borderFree);
                }
            }
        }
    }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, 0, grid.top + 2, 0);
    }
}
