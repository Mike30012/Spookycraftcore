package de.craftsucht.core.plots;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import de.craftsucht.core.util.StaffCheck;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Registry;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Biome;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.GameMode;
import org.bukkit.WeatherType;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Eigenes Plot-System (wie PlotSquared, aber eingebaut) mit mehreren Plot-Welten. /plot setup legt neue Welten an
 * (Assistent), /plot claim|auto|home|info|trust|add|deny|remove|kick|clear|delete|list|visit|setowner.
 * Texte aus plots-messages.json (MiniMessage). Schuetzt Bauen, Interaktion, Fluessigkeiten, Kolben, Explosionen, Feuer.
 * Schaltet sich ab, wenn das echte PlotSquared installiert ist. Dazu: merge/unlink, move/copy/swap, set/biome, rate/like,
 * comment/inbox, done/continue, music, target, alias, desc, sethome, purge, reload.
 */
public class PlotsModule implements Module, TabExecutor, Listener {

    private static final class Plot {
        final String world;
        final int px;
        final int pz;
        UUID owner;
        long created;
        final Set<UUID> trusted = new HashSet<>();
        final Set<UUID> added = new HashSet<>();
        final Set<UUID> denied = new HashSet<>();
        final Map<String, String> flags = new HashMap<>();

        Plot(String world, int px, int pz, UUID owner, long created) {
            this.world = world;
            this.px = px;
            this.pz = pz;
            this.owner = owner;
            this.created = created;
        }

        String key() {
            return world + ";" + px + ";" + pz;
        }

        String id() {
            return px + ";" + pz;
        }
    }

    private static final class Setup {
        int step = 0;
        final String[] vals = new String[9];
    }

    private static final String[] STEP_DESC = {"<gray>Weltname</gray>", "setup.plot_width", "setup.road_width", "setup.plot_height",
            "setup.plot_block", "setup.plot_block_floor", "setup.road_block", "setup.top_wall_block", "setup.wall_block_claimed"};
    private static final String[] STEP_TYPE = {"Text", "Zahl", "Zahl", "Zahl", "Block", "Block", "Block", "Block", "Block"};
    private static final String[] STEP_DEFAULT = {"plots", "42", "7", "64", "DIRT", "GRASS_BLOCK", "STONE_BRICKS", "STONE_BRICK_SLAB", "BIRCH_SLAB"};

    private static final class Pending {
        final Runnable run;
        final long expires;

        Pending(Runnable run, long expires) {
            this.run = run;
            this.expires = expires;
        }
    }

    private static final List<String> SUBS = List.of("claim", "auto", "home", "info", "trust", "add", "deny", "remove", "kick",
            "clear", "delete", "list", "visit", "setowner", "setup", "flag", "help", "confirm", "alias", "desc", "near",
            "sethome", "middle", "leave", "merge", "unlink", "move", "copy", "swap", "set", "biome", "rate", "like", "dislike",
            "comment", "inbox", "done", "continue", "music", "target", "reload", "purge");
    private static final List<String> HELP = List.of("auto", "claim", "home", "info", "trust", "add", "deny", "remove", "kick",
            "clear", "delete", "list", "visit", "setowner", "setup", "flag", "alias", "desc", "near", "sethome", "middle", "leave",
            "merge", "unlink", "move", "copy", "swap", "set", "biome", "rate", "like", "dislike", "comment", "inbox", "done",
            "continue", "music", "target", "reload", "purge", "confirm");

    private final SpookyCraftCore plugin;
    private PlotMessages txt;
    private final Map<String, PlotGrid> grids = new LinkedHashMap<>();
    private final Map<String, Plot> plots = new LinkedHashMap<>();
    private final Set<String> clearing = new HashSet<>();
    private final Map<UUID, Long> lastMsg = new HashMap<>();
    private final Map<UUID, Setup> setups = new HashMap<>();
    private final Map<UUID, Pending> pending = new HashMap<>();
    private final Map<UUID, String> presence = new HashMap<>();
    private final Map<UUID, GameMode> prevMode = new HashMap<>();
    private final Map<UUID, Boolean> prevFlight = new HashMap<>();
    private File worldsFile;
    private boolean active;

    public PlotsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "plots";
    }

    @Override
    public void enable() {
        if (Bukkit.getPluginManager().getPlugin("PlotSquared") != null) {
            plugin.getLogger().info("PlotSquared gefunden - das eingebaute Plot-System bleibt aus.");
            return;
        }
        txt = new PlotMessages(plugin);
        worldsFile = new File(plugin.getDataFolder(), "plots-worlds.yml");
        loadWorlds();
        createTables();
        load();
        plugin.getCommand("plot").setExecutor(this);
        plugin.getCommand("plot").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        active = true;
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Map.Entry<String, PlotGrid> e : grids.entrySet()) {
                if (Bukkit.getWorld(e.getKey()) == null) makeWorld(e.getKey(), e.getValue());
            }
        });
    }

    @Override
    public void disable() {
        active = false;
    }

    // ------------------------------------------------------------------ Welten

    private PlotGrid gridFrom(ConfigurationSection s) {
        int size = Math.max(8, Math.min(200, s.getInt("size", 42)));
        int road = Math.max(3, Math.min(30, s.getInt("road", 7)));
        return new PlotGrid(size, road, s.getInt("height", 64),
                GuiUtil.mat(s.getString("floor", "GRASS_BLOCK"), Material.GRASS_BLOCK),
                GuiUtil.mat(s.getString("fill", "DIRT"), Material.DIRT),
                GuiUtil.mat(s.getString("road-block", "STONE_BRICKS"), Material.STONE_BRICKS),
                GuiUtil.mat(s.getString("border-free", "STONE_BRICK_SLAB"), Material.STONE_BRICK_SLAB),
                GuiUtil.mat(s.getString("border-claimed", "BIRCH_SLAB"), Material.BIRCH_SLAB));
    }

    private void loadWorlds() {
        grids.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(worldsFile);
        ConfigurationSection sec = y.getConfigurationSection("worlds");
        if (sec != null) {
            for (String name : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(name);
                if (s != null) grids.put(name, gridFrom(s));
            }
        }
        if (grids.isEmpty()) {
            // Erster Start: eine Standard-Welt aus der config.yml
            String name = plugin.getConfig().getString("plots.world", "plots");
            var c = plugin.getConfig();
            y.set("worlds." + name + ".size", c.getInt("plots.plot-size", 42));
            y.set("worlds." + name + ".road", c.getInt("plots.road-width", 7));
            y.set("worlds." + name + ".height", c.getInt("plots.height", 64));
            y.set("worlds." + name + ".floor", c.getString("plots.floor", "GRASS_BLOCK"));
            y.set("worlds." + name + ".fill", c.getString("plots.fill", "DIRT"));
            y.set("worlds." + name + ".road-block", c.getString("plots.road", "STONE_BRICKS"));
            y.set("worlds." + name + ".border-free", c.getString("plots.border-free", "STONE_BRICK_SLAB"));
            y.set("worlds." + name + ".border-claimed", c.getString("plots.border-claimed", "BIRCH_SLAB"));
            try {
                y.save(worldsFile);
            } catch (IOException e) {
                plugin.getLogger().warning("plots-worlds.yml konnte nicht gespeichert werden: " + e.getMessage());
            }
            grids.put(name, gridFrom(y.getConfigurationSection("worlds." + name)));
        }
    }

    private World makeWorld(String name, PlotGrid g) {
        World w = new WorldCreator(name).generator(new PlotGenerator(g)).createWorld();
        if (w == null) plugin.getLogger().warning("Plot-Welt " + name + " konnte nicht erstellt werden.");
        return w;
    }

    private PlotGrid gridOf(World w) {
        return w == null ? null : grids.get(w.getName());
    }

    private boolean inPlotWorld(World w) {
        return w != null && grids.containsKey(w.getName());
    }

    // ------------------------------------------------------------------ Datenbank

    private void exec(String sql, Object... params) {
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Plot-Datenbank: " + e.getMessage());
        }
    }

    private void createTables() {
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS plot2_data (world TEXT, px INTEGER, pz INTEGER, owner TEXT, created INTEGER, PRIMARY KEY (world, px, pz))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS plot2_flags (world TEXT, px INTEGER, pz INTEGER, flag TEXT, value TEXT, PRIMARY KEY (world, px, pz, flag))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS plot2_members (world TEXT, px INTEGER, pz INTEGER, uuid TEXT, type TEXT, PRIMARY KEY (world, px, pz, uuid))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS plot2_ratings (world TEXT, px INTEGER, pz INTEGER, uuid TEXT, kind TEXT, value INTEGER, PRIMARY KEY (world, px, pz, uuid, kind))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS plot2_comments (id INTEGER PRIMARY KEY AUTOINCREMENT, world TEXT, px INTEGER, pz INTEGER, inbox TEXT, sender TEXT, comment TEXT, time INTEGER)");
        } catch (SQLException e) {
            plugin.getLogger().warning("Plot-Tabellen: " + e.getMessage());
        }
    }

    private void load() {
        plots.clear();
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT world, px, pz, owner, created FROM plot2_data ORDER BY created")) {
            while (rs.next()) {
                try {
                    Plot p = new Plot(rs.getString(1), rs.getInt(2), rs.getInt(3), UUID.fromString(rs.getString(4)), rs.getLong(5));
                    plots.put(p.key(), p);
                } catch (IllegalArgumentException ignored) {
                    // kaputte UUID
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Plots laden: " + e.getMessage());
        }
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT world, px, pz, uuid, type FROM plot2_members")) {
            while (rs.next()) {
                Plot p = plots.get(rs.getString(1) + ";" + rs.getInt(2) + ";" + rs.getInt(3));
                if (p == null) continue;
                try {
                    UUID u = UUID.fromString(rs.getString(4));
                    switch (rs.getString(5)) {
                        case "trusted" -> p.trusted.add(u);
                        case "added" -> p.added.add(u);
                        case "denied" -> p.denied.add(u);
                        default -> {
                        }
                    }
                } catch (IllegalArgumentException ignored) {
                    // kaputte UUID
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Plot-Mitglieder laden: " + e.getMessage());
        }
        try (Connection c = plugin.getDatabase().getConnection(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT world, px, pz, flag, value FROM plot2_flags")) {
            while (rs.next()) {
                Plot p = plots.get(rs.getString(1) + ";" + rs.getInt(2) + ";" + rs.getInt(3));
                if (p != null) p.flags.put(rs.getString(4), rs.getString(5));
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Plot-Flags laden: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Hilfen

    private boolean admin(CommandSender s) {
        return s.hasPermission("spookycraft.plots.admin") || s.hasPermission("plots.admin") || StaffCheck.isStaff(plugin, s);
    }

    private String nameOf(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? id.toString().substring(0, 8) : n;
    }

    private String names(Set<UUID> set) {
        return set.isEmpty() ? "-" : set.stream().map(this::nameOf).collect(Collectors.joining(", "));
    }

    private List<Plot> ownedBy(UUID id) {
        List<Plot> out = new ArrayList<>();
        for (Plot p : plots.values()) if (p.owner.equals(id)) out.add(p);
        return out;
    }

    private Plot plotAt(Location l) {
        PlotGrid g = l == null ? null : gridOf(l.getWorld());
        if (g == null) return null;
        long k = g.keyAt(l.getBlockX(), l.getBlockZ());
        if (k == PlotGrid.NONE) return mergedRoadPlot(g, l.getWorld().getName(), l.getBlockX(), l.getBlockZ());
        return plots.get(l.getWorld().getName() + ";" + PlotGrid.px(k) + ";" + PlotGrid.pz(k));
    }

    private String pkey(String world, int px, int pz) {
        return world + ";" + px + ";" + pz;
    }

    private boolean linkE(Plot a) {
        String m = a.flags.get("_merge");
        return m != null && m.contains("e");
    }

    private boolean linkS(Plot a) {
        String m = a.flags.get("_merge");
        return m != null && m.contains("s");
    }

    /** Das Plot, zu dem ein verbundenes Strassenstueck (zwischen zusammengelegten Plots) gehoert, sonst null. */
    private Plot mergedRoadPlot(PlotGrid g, String world, int x, int z) {
        int cx = Math.floorDiv(x, g.cell);
        int cz = Math.floorDiv(z, g.cell);
        boolean rx = Math.floorMod(x, g.cell) < g.road;
        boolean rz = Math.floorMod(z, g.cell) < g.road;
        if (rx && !rz) {
            Plot a = plots.get(pkey(world, cx - 1, cz));
            return a != null && linkE(a) ? plots.get(pkey(world, cx, cz)) : null;
        }
        if (!rx && rz) {
            Plot a = plots.get(pkey(world, cx, cz - 1));
            return a != null && linkS(a) ? plots.get(pkey(world, cx, cz)) : null;
        }
        if (rx && rz) {
            Plot a = plots.get(pkey(world, cx - 1, cz - 1));
            Plot b = plots.get(pkey(world, cx, cz - 1));
            Plot c = plots.get(pkey(world, cx - 1, cz));
            Plot d = plots.get(pkey(world, cx, cz));
            if (a != null && b != null && c != null && d != null && linkE(a) && linkS(a) && linkS(b) && linkE(c)) return d;
        }
        return null;
    }

    /** null = darf bauen, sonst der Rechte-Name fuer die Meldung. */
    private String buildNode(Player p, Location l) {
        if (admin(p)) return null;
        PlotGrid g = gridOf(l.getWorld());
        if (g == null) return null;
        Plot plot = plotAt(l);
        if (plot == null) {
            return g.keyAt(l.getBlockX(), l.getBlockZ()) == PlotGrid.NONE ? "plots.admin.build.road" : "plots.admin.build.unowned";
        }
        UUID id = p.getUniqueId();
        boolean ok = plot.owner.equals(id) || plot.trusted.contains(id)
                || (plot.added.contains(id) && Bukkit.getPlayer(plot.owner) != null);
        if (!ok) return "plots.admin.build.other";
        return plot.flags.containsKey("_done") ? "done" : null;
    }

    private void denyMsg(Player p, String node) {
        long now = System.currentTimeMillis();
        Long last = lastMsg.get(p.getUniqueId());
        if (last != null && now - last < 1500) return;
        lastMsg.put(p.getUniqueId(), now);
        if (node.equals("done")) txt.send(p, "done.building_restricted");
        else txt.send(p, "permission.no_permission_event", "node", node);
    }

    private Location home(Plot plot) {
        World w = Bukkit.getWorld(plot.world);
        PlotGrid g = grids.get(plot.world);
        if (w == null || g == null) return null;
        String h = plot.flags.get("_home");
        if (h != null) {
            try {
                String[] a = h.split(";");
                return new Location(w, g.minX(plot.px) + Double.parseDouble(a[0]), Double.parseDouble(a[1]),
                        g.minZ(plot.pz) + Double.parseDouble(a[2]));
            } catch (RuntimeException ignored) {
                // kaputter Wert: Standard-Position nutzen
            }
        }
        return middle(plot);
    }

    private Location middle(Plot plot) {
        World w = Bukkit.getWorld(plot.world);
        PlotGrid g = grids.get(plot.world);
        if (w == null || g == null) return null;
        int x = g.centerX(plot.px);
        int z = g.centerZ(plot.pz);
        return new Location(w, x + 0.5, w.getHighestBlockYAt(x, z) + 1, z + 0.5);
    }

    private void tp(Player p, Plot plot) {
        Location l = home(plot);
        if (l == null) {
            txt.send(p, "errors.not_valid_world");
            return;
        }
        p.teleport(l);
        txt.send(p, "teleport.teleported_to_plot");
    }

    private void setBorder(Plot plot, Material m) {
        World w = Bukkit.getWorld(plot.world);
        PlotGrid g = grids.get(plot.world);
        if (w == null || g == null) return;
        int x0 = g.minX(plot.px) - 1;
        int x1 = g.maxX(plot.px) + 1;
        int z0 = g.minZ(plot.pz) - 1;
        int z1 = g.maxZ(plot.pz) + 1;
        int y = g.top + 1;
        for (int x = x0; x <= x1; x++) {
            borderBlock(w, g, x, y, z0, m);
            borderBlock(w, g, x, y, z1, m);
        }
        for (int z = z0; z <= z1; z++) {
            borderBlock(w, g, x0, y, z, m);
            borderBlock(w, g, x1, y, z, m);
        }
    }

    /** Setzt einen Randblock, ausser das Stueck liegt auf einer verbundenen Strasse. */
    private void borderBlock(World w, PlotGrid g, int x, int y, int z, Material m) {
        if (mergedRoadPlot(g, w.getName(), x, z) != null) return;
        w.getBlockAt(x, y, z).setType(m, false);
    }

    private int maxPlots(Player p) {
        if (p.hasPermission("spookycraft.plots.unlimited") || admin(p)) return Integer.MAX_VALUE;
        return plugin.getConfig().getInt("plots.max-per-player", 2);
    }

    private boolean claim(Player p, String world, int px, int pz) {
        String key = world + ";" + px + ";" + pz;
        if (plots.containsKey(key)) {
            txt.send(p, "working.plot_is_claimed");
            return false;
        }
        int max = maxPlots(p);
        if (ownedBy(p.getUniqueId()).size() >= max) {
            txt.send(p, "permission.cant_claim_more_plots", "amount", String.valueOf(max));
            return false;
        }
        long price = plugin.getConfig().getLong("plots.claim-price", 0);
        if (price > 0 && !admin(p)) {
            if (!(plugin.getModuleManager().get("economy") instanceof EconomyModule em) || em.getManager() == null
                    || !em.getManager().withdraw(p.getUniqueId(), price)) {
                txt.send(p, "economy.cannot_afford_plot", "money", GuiUtil.money(price), "balance", balanceText(p));
                return false;
            }
        }
        Plot plot = new Plot(world, px, pz, p.getUniqueId(), System.currentTimeMillis());
        plots.put(plot.key(), plot);
        exec("INSERT INTO plot2_data (world, px, pz, owner, created) VALUES (?, ?, ?, ?, ?)", world, px, pz, p.getUniqueId().toString(), plot.created);
        PlotGrid g = grids.get(world);
        if (g != null) setBorder(plot, g.borderClaimed);
        txt.send(p, "working.claimed", "world", world, "plot", plot.id());
        return true;
    }

    private String balanceText(Player p) {
        if (plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
            return GuiUtil.money(em.getManager().getBalance(p.getUniqueId()));
        }
        return "-";
    }

    /** Sicherheitsabfrage wie bei PlotSquared: /plot confirm fuehrt die Aktion aus. */
    private void confirm(Player p, String command, Runnable run) {
        pending.put(p.getUniqueId(), new Pending(run, System.currentTimeMillis() + 20000L));
        txt.send(p, "confirm.requires_confirm", "command", command, "value", "/plot confirm", "timeout", "20");
    }

    /** Das Plot, auf dem der Spieler steht, wenn es ihm gehoert (oder er Admin ist). Sonst Meldung und null. */
    private Plot ownPlotHere(Player p, Plot here, PlotGrid g) {
        if (g == null) {
            txt.send(p, "errors.not_in_plot_world");
            return null;
        }
        if (here == null) {
            txt.send(p, g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ()) == PlotGrid.NONE ? "errors.not_in_plot" : "working.plot_not_claimed");
            return null;
        }
        if (!(here.owner.equals(p.getUniqueId()) || admin(p))) {
            txt.send(p, "permission.no_plot_perms");
            return null;
        }
        return here;
    }

    private void setMember(Plot plot, UUID u, String type) {
        plot.trusted.remove(u);
        plot.added.remove(u);
        plot.denied.remove(u);
        switch (type) {
            case "trusted" -> plot.trusted.add(u);
            case "added" -> plot.added.add(u);
            case "denied" -> plot.denied.add(u);
            default -> {
            }
        }
        if (type.isEmpty()) {
            exec("DELETE FROM plot2_members WHERE world=? AND px=? AND pz=? AND uuid=?", plot.world, plot.px, plot.pz, u.toString());
        } else {
            exec("INSERT INTO plot2_members (world, px, pz, uuid, type) VALUES (?, ?, ?, ?, ?) ON CONFLICT(world, px, pz, uuid) DO UPDATE SET type=excluded.type",
                    plot.world, plot.px, plot.pz, u.toString(), type);
        }
    }

    private void clear(Plot plot, Player who, boolean deleted) {
        World w = Bukkit.getWorld(plot.world);
        PlotGrid g = grids.get(plot.world);
        if (w == null || g == null || !clearing.add(plot.key())) return;
        final long start = System.currentTimeMillis();
        int x0 = g.minX(plot.px);
        int x1 = g.maxX(plot.px);
        int z0 = g.minZ(plot.pz);
        int z1 = g.maxZ(plot.pz);
        BoundingBox box = new BoundingBox(x0, w.getMinHeight(), z0, x1 + 1, w.getMaxHeight(), z1 + 1);
        for (Entity e : w.getNearbyEntities(box)) if (!(e instanceof Player)) e.remove();
        final int minY = w.getMinHeight();
        final int maxY = w.getMaxHeight() - 1;
        final int[] x = {x0};
        final BukkitTask[] task = new BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (int z = z0; z <= z1; z++) {
                for (int y = minY; y <= maxY; y++) {
                    Material target = y == minY ? Material.BEDROCK : y < g.top ? g.fill : y == g.top ? g.floor : Material.AIR;
                    Block b = w.getBlockAt(x[0], y, z);
                    if (b.getType() != target) b.setType(target, false);
                }
            }
            if (++x[0] > x1) {
                task[0].cancel();
                clearing.remove(plot.key());
                if (who != null && who.isOnline()) {
                    txt.send(who, deleted ? "working.deleting_done" : "working.clearing_done", "world", plot.world, "plot", plot.id(),
                            "amount", String.valueOf(System.currentTimeMillis() - start));
                }
            }
        }, 1L, 1L);
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur Spieler.");
            return true;
        }
        if (!active) {
            txt.send(p, "errors.command_went_wrong");
            return true;
        }
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        Plot here = plotAt(p.getLocation());
        PlotGrid g = gridOf(p.getWorld());
        switch (sub) {
            case "setup" -> setup(p, args);
            case "flag", "flags" -> flagCmd(p, here, g, args);
            case "claim" -> {
                if (g == null) {
                    txt.send(p, "errors.not_in_plot_world");
                    return true;
                }
                long k = g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ());
                if (k == PlotGrid.NONE) {
                    txt.send(p, "errors.not_in_plot");
                    return true;
                }
                claim(p, p.getWorld().getName(), PlotGrid.px(k), PlotGrid.pz(k));
            }
            case "auto" -> auto(p, args);
            case "home" -> {
                List<Plot> own = ownedBy(p.getUniqueId());
                int n = number(args, 1);
                if (own.isEmpty()) {
                    txt.send(p, "errors.no_plots");
                } else if (n < 1 || n > own.size()) {
                    txt.send(p, "invalid.number_not_in_range", "min", "1", "max", String.valueOf(own.size()));
                } else {
                    tp(p, own.get(n - 1));
                }
            }
            case "list" -> {
                List<Plot> own = ownedBy(p.getUniqueId());
                if (own.isEmpty()) {
                    txt.send(p, "errors.no_plots");
                } else {
                    txt.send(p, "list.plot_list_header", "word", "deine");
                    int nr = 1;
                    for (Plot o : own) {
                        String alias = o.flags.get("_alias");
                        txt.sendText(p, "<dark_gray>[</dark_gray><aqua>" + nr++ + "</aqua><dark_gray>]</dark_gray> " + txt.raw("info.plot_list_owned_by"),
                                "plot", o.world + ";" + o.id() + (alias == null ? "" : " (" + alias + ")"));
                    }
                }
            }
            case "visit" -> {
                if (args.length < 2) {
                    txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot visit \\<Spieler> [Nummer]</aqua>");
                    return true;
                }
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                List<Plot> own = ownedBy(t.getUniqueId());
                int n = number(args, 2);
                if (own.isEmpty()) {
                    txt.send(p, "errors.player_no_plots");
                } else if (n < 1 || n > own.size()) {
                    txt.send(p, "invalid.number_not_in_range", "min", "1", "max", String.valueOf(own.size()));
                } else {
                    tp(p, own.get(n - 1));
                }
            }
            case "info" -> info(p, g, here);
            case "trust", "add", "deny", "remove", "kick" -> member(p, here, g, sub, args);
            case "clear", "delete" -> {
                if (g == null) {
                    txt.send(p, "errors.not_in_plot_world");
                    return true;
                }
                if (here == null) {
                    txt.send(p, g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ()) == PlotGrid.NONE ? "errors.not_in_plot" : "working.plot_not_claimed");
                    return true;
                }
                if (!(here.owner.equals(p.getUniqueId()) || admin(p))) {
                    txt.send(p, "permission.no_plot_perms");
                    return true;
                }
                final Plot target = here;
                final PlotGrid grid = g;
                final boolean del = sub.equals("delete");
                Runnable action = () -> {
                    if (del) unlinkGroup(target);
                    clear(target, p, del);
                    if (del) {
                        removePlot(target);
                        setBorder(target, grid.borderFree);
                    }
                };
                // Owner-/Admin-Rang (OP, *, plots.admin): sofort ohne Bestaetigung, alle anderen muessen /plot confirm tippen
                if (p.isOp() || p.hasPermission("*") || p.hasPermission("plots.admin") || p.hasPermission("spookycraft.plots.admin")) {
                    action.run();
                } else {
                    confirm(p, "/plot " + sub, action);
                }
            }
            case "confirm" -> {
                Pending pc = pending.remove(p.getUniqueId());
                if (pc == null) {
                    txt.send(p, "confirm.failed_confirm");
                } else if (pc.expires < System.currentTimeMillis()) {
                    txt.send(p, "confirm.expired_confirm");
                } else {
                    pc.run.run();
                }
            }
            case "alias" -> {
                Plot pl = ownPlotHere(p, here, g);
                if (pl == null) return true;
                String val = args.length < 2 ? "" : String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
                String old = pl.flags.get("_alias");
                if (val.isEmpty()) {
                    if (old == null) {
                        txt.send(p, "alias.no_alias_set");
                    } else {
                        saveFlag(pl, "_alias", null);
                        txt.send(p, "alias.alias_removed", "alias", old);
                    }
                } else if (val.length() > 50) {
                    txt.send(p, "alias.alias_too_long");
                } else {
                    boolean taken = false;
                    for (Plot o : plots.values()) {
                        if (o != pl && o.world.equals(pl.world) && val.equalsIgnoreCase(o.flags.get("_alias"))) taken = true;
                    }
                    if (taken) {
                        txt.send(p, "alias.alias_is_taken", "alias", val);
                    } else {
                        saveFlag(pl, "_alias", val);
                        txt.send(p, "alias.alias_set_to", "alias", val);
                    }
                }
            }
            case "desc", "setdescription" -> {
                Plot pl = ownPlotHere(p, here, g);
                if (pl == null) return true;
                String val = args.length < 2 ? "" : String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
                if (val.isEmpty()) {
                    saveFlag(pl, "description", null);
                    txt.send(p, "desc.desc_unset");
                } else {
                    saveFlag(pl, "description", val);
                    txt.send(p, "desc.desc_set");
                }
            }
            case "near" -> {
                if (here == null) {
                    txt.send(p, "errors.not_in_plot");
                    return true;
                }
                List<String> near = new ArrayList<>();
                for (Player o : p.getWorld().getPlayers()) if (plotAt(o.getLocation()) == here) near.add(o.getName());
                txt.send(p, "near.plot_near", "list", String.join(", ", near));
            }
            case "sethome" -> {
                Plot pl = ownPlotHere(p, here, g);
                if (pl == null) return true;
                if (args.length > 1 && (args[1].equalsIgnoreCase("none") || args[1].equalsIgnoreCase("reset"))) {
                    saveFlag(pl, "_home", null);
                    txt.send(p, "position.position_unset");
                } else {
                    Location l = p.getLocation();
                    saveFlag(pl, "_home", (l.getX() - g.minX(pl.px)) + ";" + l.getY() + ";" + (l.getZ() - g.minZ(pl.pz)));
                    txt.send(p, "position.position_set");
                }
            }
            case "middle" -> {
                if (g == null) {
                    txt.send(p, "errors.not_in_plot_world");
                } else if (here == null) {
                    txt.send(p, g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ()) == PlotGrid.NONE ? "errors.not_in_plot" : "working.plot_not_claimed");
                } else {
                    Location l = middle(here);
                    if (l == null) {
                        txt.send(p, "errors.not_valid_world");
                    } else {
                        p.teleport(l);
                        txt.send(p, "teleport.teleported_to_plot");
                    }
                }
            }
            case "leave" -> {
                if (here == null) {
                    txt.send(p, "errors.not_in_plot");
                } else if (here.owner.equals(p.getUniqueId())) {
                    txt.send(p, "member.plot_cant_leave_owner");
                } else if (!here.trusted.contains(p.getUniqueId()) && !here.added.contains(p.getUniqueId())) {
                    txt.send(p, "member.player_not_removed", "player", p.getName());
                } else {
                    setMember(here, p.getUniqueId(), "");
                    txt.send(p, "member.plot_left");
                }
            }
            case "merge" -> mergeCmd(p, here, g, args);
            case "unlink" -> unlinkCmd(p, here, g);
            case "move", "copy", "swap" -> regionCmd(p, here, g, sub, args);
            case "set" -> setCmd(p, here, g, args);
            case "biome", "setbiome" -> biomeCmd(p, here, g, args.length > 1 ? args[1] : null);
            case "rate", "like", "dislike" -> rateCmd(p, here, g, sub, args);
            case "comment" -> commentCmd(p, here, args);
            case "inbox" -> inboxCmd(p, here, args);
            case "done" -> {
                Plot pl = ownPlotHere(p, here, g);
                if (pl == null) return true;
                if (pl.flags.containsKey("_done")) {
                    txt.send(p, "done.done_already_done");
                } else {
                    saveFlag(pl, "_done", String.valueOf(System.currentTimeMillis()));
                    txt.send(p, "done.done_success");
                }
            }
            case "continue" -> {
                Plot pl = ownPlotHere(p, here, g);
                if (pl == null) return true;
                if (!pl.flags.containsKey("_done")) {
                    txt.send(p, "done.done_not_done");
                } else {
                    saveFlag(pl, "_done", null);
                    exec("DELETE FROM plot2_ratings WHERE world=? AND px=? AND pz=?", pl.world, pl.px, pl.pz);
                    txt.send(p, "done.done_removed");
                    txt.send(p, "ratings.ratings_purged");
                }
            }
            case "music" -> musicCmd(p, here, g, args);
            case "target" -> targetCmd(p, g, args);
            case "reload" -> {
                if (!admin(p)) {
                    txt.send(p, "permission.no_permission", "node", "spookycraft.plots.admin");
                } else {
                    try {
                        txt = new PlotMessages(plugin);
                        txt.send(p, "reload.reloaded_configs");
                    } catch (RuntimeException e) {
                        txt.send(p, "reload.reload_failed");
                    }
                }
            }
            case "purge" -> purgeCmd(p, args);
            case "setowner" -> {
                if (!admin(p)) {
                    txt.send(p, "permission.no_permission", "node", "spookycraft.plots.admin");
                } else if (here == null || args.length < 2) {
                    txt.sendText(p, "<prefix><gray>Stelle dich auf ein vergebenes Plot: </gray><aqua>/plot setowner \\<Spieler></aqua>");
                } else {
                    OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                    if (!t.isOnline() && !t.hasPlayedBefore()) {
                        txt.send(p, "errors.invalid_player", "value", args[1]);
                        return true;
                    }
                    here.owner = t.getUniqueId();
                    exec("UPDATE plot2_data SET owner=? WHERE world=? AND px=? AND pz=?", t.getUniqueId().toString(), here.world, here.px, here.pz);
                    txt.send(p, "owner.set_owner");
                }
            }
            default -> {
                String title = txt.raw("help.help_header").replace("PlotSquared-Hilfe", "Plot-Hilfe");
                txt.sendText(p, title);
                for (String c : HELP) {
                    String desc = txt.raw("commands.description." + (c.equals("desc") ? "setdescription" : c.equals("biome") ? "setbiome" : c));
                    txt.sendText(p, "<aqua>/plot " + c + "</aqua> <dark_gray>- </dark_gray>" + desc);
                }
                txt.sendText(p, txt.raw("help.help_footer").replace("PlotSquared-Hilfe", "Plot-Hilfe"));
            }
        }
        return true;
    }

    private int number(String[] args, int idx) {
        if (args.length <= idx) return 1;
        try {
            return Integer.parseInt(args[idx]);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void auto(Player p, String[] args) {
        String world = inPlotWorld(p.getWorld()) ? p.getWorld().getName() : grids.keySet().iterator().next();
        if (args.length > 1 && grids.containsKey(args[1])) world = args[1];
        for (int r = 0; r < 500; r++) {
            for (int x = -r; x <= r; x++) {
                for (int z = -r; z <= r; z++) {
                    if (Math.max(Math.abs(x), Math.abs(z)) != r || plots.containsKey(world + ";" + x + ";" + z)) continue;
                    if (claim(p, world, x, z)) tp(p, plots.get(world + ";" + x + ";" + z));
                    return;
                }
            }
        }
        txt.send(p, "errors.no_free_plots");
    }

    private void info(Player p, PlotGrid g, Plot here) {
        if (g == null) {
            txt.send(p, "errors.not_in_plot_world");
            return;
        }
        long k = g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ());
        if (k == PlotGrid.NONE && here == null) {
            txt.send(p, "errors.not_in_plot");
            return;
        }
        if (here == null) {
            txt.send(p, "info.plot_info_unclaimed", "plot", PlotGrid.px(k) + ";" + PlotGrid.pz(k));
            return;
        }
        UUID me = p.getUniqueId();
        boolean member = here.owner.equals(me) || here.trusted.contains(me) || here.added.contains(me) || admin(p);
        if (flagBool(here, "hide-info") && !member) {
            txt.send(p, "info.plot_info_hidden");
            return;
        }
        String flagText = here.flags.keySet().stream().allMatch(fk -> fk.startsWith("_")) ? "-"
                : here.flags.entrySet().stream().filter(e -> !e.getKey().startsWith("_")).map(e -> e.getKey() + ": " + e.getValue()).collect(Collectors.joining(", "));
        String date = new SimpleDateFormat("dd.MM.yyyy HH:mm").format(new Date(here.created));
        txt.send(p, "info.plot_info_format",
                "~header", txt.raw("info.plot_info_header"), "~footer", txt.raw("info.plot_info_footer"),
                "id", here.id(), "creationdate", date, "area", here.world, "alias", here.flags.getOrDefault("_alias", "-"), "owner", nameOf(here.owner),
                "biome", "-", "build", here.flags.containsKey("_done") ? "Fertig" : "-", "rating", ratingText(here), "seen", "-",
                "trusted", names(here.trusted), "members", names(here.added), "denied", names(here.denied),
                "flags", flagText, "desc", here.flags.getOrDefault("description", "-"));
    }

    private void member(Player p, Plot here, PlotGrid g, String sub, String[] args) {
        if (g == null) {
            txt.send(p, "errors.not_in_plot_world");
            return;
        }
        if (here == null) {
            txt.send(p, g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ()) == PlotGrid.NONE ? "errors.not_in_plot" : "working.plot_not_claimed");
            return;
        }
        if (!(here.owner.equals(p.getUniqueId()) || admin(p))) {
            txt.send(p, "permission.no_plot_perms");
            return;
        }
        if (args.length < 2) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot " + sub + " \\<Spieler></aqua>");
            return;
        }
        OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
        UUID u = t.getUniqueId();
        if (!t.isOnline() && !t.hasPlayedBefore()) {
            txt.send(p, "errors.invalid_player", "value", args[1]);
            return;
        }
        if (u.equals(here.owner)) {
            txt.send(p, sub.equals("deny") ? "deny.cant_remove_owner" : "member.already_owner", "player", args[1]);
            return;
        }
        Player online = Bukkit.getPlayer(u);
        switch (sub) {
            case "trust" -> {
                if (here.trusted.contains(u)) {
                    txt.send(p, "member.already_added", "player", args[1]);
                    return;
                }
                setMember(here, u, "trusted");
                txt.send(p, "trusted.trusted_added");
            }
            case "add" -> {
                if (here.added.contains(u)) {
                    txt.send(p, "member.already_added", "player", args[1]);
                    return;
                }
                setMember(here, u, "added");
                txt.send(p, "member.member_added");
            }
            case "deny" -> {
                if (here.denied.contains(u)) {
                    txt.send(p, "member.already_added", "player", args[1]);
                    return;
                }
                setMember(here, u, "denied");
                txt.send(p, "deny.denied_added");
                if (online != null && plotAt(online.getLocation()) == here) {
                    online.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                    txt.send(online, "deny.you_got_denied");
                }
            }
            case "remove" -> {
                if (!here.trusted.contains(u) && !here.added.contains(u) && !here.denied.contains(u)) {
                    txt.send(p, "member.player_not_removed", "player", args[1]);
                    return;
                }
                setMember(here, u, "");
                txt.send(p, "member.removed_players", "amount", "1");
            }
            default -> {
                if (online == null || plotAt(online.getLocation()) != here) {
                    txt.send(p, "kick.player_not_in_plot", "player", args[1]);
                    return;
                }
                online.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                txt.send(online, "kick.you_got_kicked");
            }
        }
    }

    // ------------------------------------------------------------------ Daten-Hilfen

    private void deleteRows(Plot p) {
        exec("DELETE FROM plot2_data WHERE world=? AND px=? AND pz=?", p.world, p.px, p.pz);
        exec("DELETE FROM plot2_members WHERE world=? AND px=? AND pz=?", p.world, p.px, p.pz);
        exec("DELETE FROM plot2_flags WHERE world=? AND px=? AND pz=?", p.world, p.px, p.pz);
    }

    private void removePlot(Plot p) {
        plots.remove(p.key());
        deleteRows(p);
        exec("DELETE FROM plot2_ratings WHERE world=? AND px=? AND pz=?", p.world, p.px, p.pz);
        exec("DELETE FROM plot2_comments WHERE world=? AND px=? AND pz=?", p.world, p.px, p.pz);
    }

    /** Schreibt ein Plot komplett (Besitzer, Mitglieder, Flags) neu in die Datenbank. */
    private void persist(Plot p) {
        deleteRows(p);
        exec("INSERT INTO plot2_data (world, px, pz, owner, created) VALUES (?, ?, ?, ?, ?)", p.world, p.px, p.pz, p.owner.toString(), p.created);
        for (UUID u : p.trusted) {
            exec("INSERT INTO plot2_members (world, px, pz, uuid, type) VALUES (?, ?, ?, ?, ?)", p.world, p.px, p.pz, u.toString(), "trusted");
        }
        for (UUID u : p.added) {
            exec("INSERT INTO plot2_members (world, px, pz, uuid, type) VALUES (?, ?, ?, ?, ?)", p.world, p.px, p.pz, u.toString(), "added");
        }
        for (UUID u : p.denied) {
            exec("INSERT INTO plot2_members (world, px, pz, uuid, type) VALUES (?, ?, ?, ?, ?)", p.world, p.px, p.pz, u.toString(), "denied");
        }
        for (Map.Entry<String, String> e : p.flags.entrySet()) {
            exec("INSERT INTO plot2_flags (world, px, pz, flag, value) VALUES (?, ?, ?, ?, ?)", p.world, p.px, p.pz, e.getKey(), e.getValue());
        }
    }

    private int scalarInt(String sql, Object... params) {
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Plot-Datenbank: " + e.getMessage());
            return 0;
        }
    }

    /** Fuehrt eine Aufgabe in jedem Tick fuer eine X-Scheibe aus (kein Lag bei grossen Plots). */
    private void slices(int x0, int x1, java.util.function.IntConsumer perX, Runnable done) {
        final int[] x = {x0};
        final BukkitTask[] task = new BukkitTask[1];
        task[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            perX.accept(x[0]);
            if (++x[0] > x1) {
                task[0].cancel();
                if (done != null) done.run();
            }
        }, 1L, 1L);
    }

    private String ratingText(Plot plot) {
        int count = scalarInt("SELECT COUNT(*) FROM plot2_ratings WHERE world=? AND px=? AND pz=? AND kind='rate'", plot.world, plot.px, plot.pz);
        int likes = scalarInt("SELECT COALESCE(SUM(value), 0) FROM plot2_ratings WHERE world=? AND px=? AND pz=? AND kind='like'", plot.world, plot.px, plot.pz);
        if (count == 0 && likes == 0) return "-";
        String out = "";
        if (count > 0) {
            int tenths = scalarInt("SELECT CAST(ROUND(AVG(value) * 10) AS INTEGER) FROM plot2_ratings WHERE world=? AND px=? AND pz=? AND kind='rate'",
                    plot.world, plot.px, plot.pz);
            out = (tenths / 10) + "." + (tenths % 10) + "/10";
        }
        if (likes != 0) out = (out.isEmpty() ? "" : out + " ") + (likes > 0 ? "+" : "") + likes;
        return out;
    }

    // ------------------------------------------------------------------ Verbinden / Trennen

    private void setLink(Plot a, char dir, boolean on) {
        String m = a.flags.getOrDefault("_merge", "").replace(String.valueOf(dir), "");
        if (on) m = m + dir;
        saveFlag(a, "_merge", m.isEmpty() ? null : m);
    }

    private boolean isMerged(Plot p) {
        if (linkE(p) || linkS(p)) return true;
        Plot w = plots.get(pkey(p.world, p.px - 1, p.pz));
        if (w != null && linkE(w)) return true;
        Plot n = plots.get(pkey(p.world, p.px, p.pz - 1));
        return n != null && linkS(n);
    }

    private List<Plot> group(Plot start) {
        List<Plot> out = new ArrayList<>();
        out.add(start);
        for (int i = 0; i < out.size(); i++) {
            Plot c = out.get(i);
            List<Plot> cand = new ArrayList<>();
            Plot e = plots.get(pkey(c.world, c.px + 1, c.pz));
            if (e != null && linkE(c)) cand.add(e);
            Plot s = plots.get(pkey(c.world, c.px, c.pz + 1));
            if (s != null && linkS(c)) cand.add(s);
            Plot w = plots.get(pkey(c.world, c.px - 1, c.pz));
            if (w != null && linkE(w)) cand.add(w);
            Plot n = plots.get(pkey(c.world, c.px, c.pz - 1));
            if (n != null && linkS(n)) cand.add(n);
            for (Plot x : cand) if (!out.contains(x)) out.add(x);
        }
        return out;
    }

    private int[] stripE(PlotGrid g, Plot a) {
        return new int[]{g.maxX(a.px) + 1, g.minX(a.px + 1) - 1, g.minZ(a.pz), g.maxZ(a.pz)};
    }

    private int[] stripS(PlotGrid g, Plot a) {
        return new int[]{g.minX(a.px), g.maxX(a.px), g.maxZ(a.pz) + 1, g.minZ(a.pz + 1) - 1};
    }

    private int[] corner(PlotGrid g, int cx, int cz) {
        return new int[]{cx * g.cell, cx * g.cell + g.road - 1, cz * g.cell, cz * g.cell + g.road - 1};
    }

    /** Verbundene Strasse = Plot-Boden ohne Rand, getrennte Strasse = Strassenblock mit freiem Rand. */
    private void paintRegion(World w, PlotGrid g, int x0, int x1, int z0, int z1, boolean merged) {
        int y = g.top;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                w.getBlockAt(x, y, z).setType(merged ? g.floor : g.roadMat, false);
                Material above = merged ? Material.AIR : (g.isBorder(x, z) ? g.borderFree : Material.AIR);
                w.getBlockAt(x, y + 1, z).setType(above, false);
            }
        }
    }

    private void unionMembers(Plot a, Plot b) {
        for (UUID u : new HashSet<>(a.trusted)) if (!b.trusted.contains(u)) setMember(b, u, "trusted");
        for (UUID u : new HashSet<>(a.added)) if (!b.added.contains(u) && !b.trusted.contains(u)) setMember(b, u, "added");
        for (UUID u : new HashSet<>(a.denied)) if (!b.denied.contains(u)) setMember(b, u, "denied");
        for (UUID u : new HashSet<>(b.trusted)) if (!a.trusted.contains(u)) setMember(a, u, "trusted");
        for (UUID u : new HashSet<>(b.added)) if (!a.added.contains(u) && !a.trusted.contains(u)) setMember(a, u, "added");
        for (UUID u : new HashSet<>(b.denied)) if (!a.denied.contains(u)) setMember(a, u, "denied");
    }

    /** a liegt westlich (dir 'e') bzw. noerdlich (dir 's') von b. */
    private void applyMerge(Plot a, Plot b, char dir) {
        World w = Bukkit.getWorld(a.world);
        PlotGrid g = grids.get(a.world);
        setLink(a, dir, true);
        unionMembers(a, b);
        if (w == null || g == null) return;
        int[] r = dir == 'e' ? stripE(g, a) : stripS(g, a);
        paintRegion(w, g, r[0], r[1], r[2], r[3], true);
        for (Plot pl : new Plot[]{a, b}) {
            for (int cx = pl.px; cx <= pl.px + 1; cx++) {
                for (int cz = pl.pz; cz <= pl.pz + 1; cz++) {
                    if (mergedRoadPlot(g, a.world, cx * g.cell, cz * g.cell) != null) {
                        int[] c = corner(g, cx, cz);
                        paintRegion(w, g, c[0], c[1], c[2], c[3], true);
                    }
                }
            }
        }
    }

    private boolean mergeDir(Plot a, int dx, int dz) {
        Plot b = plots.get(pkey(a.world, a.px + dx, a.pz + dz));
        if (b == null || !b.owner.equals(a.owner)) return false;
        boolean aFirst = dx > 0 || dz > 0;
        Plot first = aFirst ? a : b;
        Plot second = aFirst ? b : a;
        char dir = dx != 0 ? 'e' : 's';
        if (dir == 'e' ? linkE(first) : linkS(first)) return false;
        applyMerge(first, second, dir);
        return true;
    }

    private String facing(Player p) {
        float yaw = (p.getLocation().getYaw() % 360 + 360) % 360;
        if (yaw >= 45 && yaw < 135) return "west";
        if (yaw >= 135 && yaw < 225) return "north";
        if (yaw >= 225 && yaw < 315) return "east";
        return "south";
    }

    private void mergeCmd(Player p, Plot here, PlotGrid g, String[] args) {
        Plot a = ownPlotHere(p, here, g);
        if (a == null) return;
        String d = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : facing(p);
        boolean any = false;
        switch (d) {
            case "all", "auto" -> {
                any |= mergeDir(a, 1, 0);
                any |= mergeDir(a, -1, 0);
                any |= mergeDir(a, 0, 1);
                any |= mergeDir(a, 0, -1);
            }
            case "east", "e" -> any = mergeDir(a, 1, 0);
            case "west", "w" -> any = mergeDir(a, -1, 0);
            case "south", "s" -> any = mergeDir(a, 0, 1);
            case "north", "n" -> any = mergeDir(a, 0, -1);
            default -> {
                txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot merge [north|south|east|west|all]</aqua>");
                return;
            }
        }
        txt.send(p, any ? "merge.success_merge" : "merge.no_available_automerge");
    }

    private void unlinkCmd(Player p, Plot here, PlotGrid g) {
        Plot a = ownPlotHere(p, here, g);
        if (a == null) return;
        if (!isMerged(a)) {
            txt.send(p, "merge.unlink_impossible");
            return;
        }
        confirm(p, "/plot unlink", () -> {
            unlinkGroup(a);
            txt.send(p, "merge.unlink_success");
        });
    }

    private void unlinkGroup(Plot start) {
        World w = Bukkit.getWorld(start.world);
        PlotGrid g = grids.get(start.world);
        List<Plot> grp = group(start);
        List<int[]> regions = new ArrayList<>();
        if (g != null) {
            for (Plot pl : grp) {
                if (linkE(pl)) regions.add(stripE(g, pl));
                if (linkS(pl)) regions.add(stripS(g, pl));
                for (int cx = pl.px; cx <= pl.px + 1; cx++) {
                    for (int cz = pl.pz; cz <= pl.pz + 1; cz++) {
                        if (mergedRoadPlot(g, pl.world, cx * g.cell, cz * g.cell) != null) regions.add(corner(g, cx, cz));
                    }
                }
            }
        }
        for (Plot pl : grp) saveFlag(pl, "_merge", null);
        if (w == null || g == null) return;
        for (int[] r : regions) paintRegion(w, g, r[0], r[1], r[2], r[3], false);
        for (Plot pl : grp) setBorder(pl, g.borderClaimed);
    }

    // ------------------------------------------------------------------ Verschieben / Kopieren / Tauschen

    private int[] parseId(Player p, String s) {
        String[] parts = s.split("[;,]");
        try {
            if (parts.length == 3) {
                if (!parts[0].equals(p.getWorld().getName())) {
                    txt.send(p, "errors.plotworld_incompatible");
                    return null;
                }
                return new int[]{Integer.parseInt(parts[1].trim()), Integer.parseInt(parts[2].trim())};
            }
            if (parts.length == 2) return new int[]{Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim())};
        } catch (NumberFormatException ignored) {
            // faellt unten auf die Fehlermeldung
        }
        txt.send(p, "invalid.not_valid_plot_id");
        return null;
    }

    private void copyBlock(Block s, Block d) {
        if (s.getType().isAir() && d.getType().isAir()) return;
        BlockState st = s.getState();
        st.copy(d.getLocation()).update(true, false);
    }

    private void copySlice(World w, PlotGrid g, Plot src, int x, int ox, int oz) {
        int minY = w.getMinHeight() + 1;
        int maxY = w.getMaxHeight() - 1;
        for (int z = g.minZ(src.pz); z <= g.maxZ(src.pz); z++) {
            for (int y = minY; y <= maxY; y++) {
                copyBlock(w.getBlockAt(x, y, z), w.getBlockAt(x + ox, y, z + oz));
            }
        }
    }

    private void swapSlice(World w, PlotGrid g, Plot src, int x, int ox, int oz) {
        int minY = w.getMinHeight() + 1;
        int maxY = w.getMaxHeight() - 1;
        int z0 = g.minZ(src.pz);
        int z1 = g.maxZ(src.pz);
        int n = (z1 - z0 + 1) * (maxY - minY + 1);
        BlockState[] a = new BlockState[n];
        BlockState[] b = new BlockState[n];
        int i = 0;
        for (int z = z0; z <= z1; z++) {
            for (int y = minY; y <= maxY; y++) {
                a[i] = w.getBlockAt(x, y, z).getState();
                b[i] = w.getBlockAt(x + ox, y, z + oz).getState();
                i++;
            }
        }
        i = 0;
        for (int z = z0; z <= z1; z++) {
            for (int y = minY; y <= maxY; y++) {
                if (!(a[i].getType().isAir() && b[i].getType().isAir())) {
                    a[i].copy(new Location(w, x + ox, y, z + oz)).update(true, false);
                    b[i].copy(new Location(w, x, y, z)).update(true, false);
                }
                i++;
            }
        }
    }

    private void swapData(Plot a, Plot b) {
        UUID o = a.owner;
        a.owner = b.owner;
        b.owner = o;
        long c = a.created;
        a.created = b.created;
        b.created = c;
        Set<UUID> t1 = new HashSet<>(a.trusted);
        Set<UUID> m1 = new HashSet<>(a.added);
        Set<UUID> d1 = new HashSet<>(a.denied);
        Map<String, String> f1 = new HashMap<>(a.flags);
        a.trusted.clear();
        a.trusted.addAll(b.trusted);
        a.added.clear();
        a.added.addAll(b.added);
        a.denied.clear();
        a.denied.addAll(b.denied);
        a.flags.clear();
        a.flags.putAll(b.flags);
        b.trusted.clear();
        b.trusted.addAll(t1);
        b.added.clear();
        b.added.addAll(m1);
        b.denied.clear();
        b.denied.addAll(d1);
        b.flags.clear();
        b.flags.putAll(f1);
        persist(a);
        persist(b);
    }

    private void regionCmd(Player p, Plot here, PlotGrid g, String sub, String[] args) {
        Plot a = ownPlotHere(p, here, g);
        if (a == null) return;
        if (args.length < 2) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot " + sub + " \\<X;Z></aqua>");
            return;
        }
        int[] id = parseId(p, args[1]);
        if (id == null) return;
        if (id[0] == a.px && id[1] == a.pz) {
            txt.send(p, "invalid.origin_cant_be_target");
            return;
        }
        final boolean swap = sub.equals("swap");
        final boolean move = sub.equals("move");
        Plot b = plots.get(pkey(a.world, id[0], id[1]));
        if (isMerged(a) || (b != null && isMerged(b))) {
            txt.send(p, swap ? "swap.swap_merged" : "move.move_merged");
            return;
        }
        if (swap) {
            if (b == null) {
                txt.send(p, "working.plot_not_claimed");
                return;
            }
            if (!(b.owner.equals(p.getUniqueId()) || admin(p))) {
                txt.send(p, "permission.no_plot_perms");
                return;
            }
        } else if (move && b != null) {
            txt.send(p, "move.requires_unowned");
            return;
        } else if (b != null && !(b.owner.equals(p.getUniqueId()) || admin(p))) {
            txt.send(p, "permission.no_plot_perms");
            return;
        }
        World w = Bukkit.getWorld(a.world);
        PlotGrid grid = grids.get(a.world);
        if (w == null || grid == null) {
            txt.send(p, "errors.not_valid_world");
            return;
        }
        final String ak = a.key();
        final String bk = pkey(a.world, id[0], id[1]);
        if (clearing.contains(ak) || clearing.contains(bk)) {
            txt.send(p, "errors.wait_for_timer");
            return;
        }
        clearing.add(ak);
        clearing.add(bk);
        final int tx = id[0];
        final int tz = id[1];
        final int ox = grid.minX(tx) - grid.minX(a.px);
        final int oz = grid.minZ(tz) - grid.minZ(a.pz);
        final String from = a.id();
        final String to = tx + ";" + tz;
        final Plot target = b;
        slices(grid.minX(a.px), grid.maxX(a.px), x -> {
            if (swap) swapSlice(w, grid, a, x, ox, oz);
            else copySlice(w, grid, a, x, ox, oz);
        }, () -> {
            clearing.remove(ak);
            clearing.remove(bk);
            if (swap) {
                swapData(a, target);
                txt.send(p, "swap.swap_success", "origin", from, "target", to);
            } else if (move) {
                Plot n = new Plot(a.world, tx, tz, a.owner, a.created);
                n.trusted.addAll(a.trusted);
                n.added.addAll(a.added);
                n.denied.addAll(a.denied);
                n.flags.putAll(a.flags);
                plots.put(n.key(), n);
                persist(n);
                removePlot(a);
                setBorder(n, grid.borderClaimed);
                setBorder(a, grid.borderFree);
                clear(a, null, false);
                txt.send(p, "move.move_success", "origin", from, "target", to);
            } else {
                txt.send(p, "move.copy_success", "origin", from, "target", to);
            }
        });
    }

    // ------------------------------------------------------------------ Setzen (Biom, Boeden, ...)

    private Biome findBiome(String name) {
        if (name == null) return null;
        try {
            return Registry.BIOME.get(NamespacedKey.minecraft(name.toLowerCase(Locale.ROOT)));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private void biomeCmd(Player p, Plot here, PlotGrid g, String name) {
        Plot pl = ownPlotHere(p, here, g);
        if (pl == null) return;
        final Biome biome = findBiome(name);
        World w = Bukkit.getWorld(pl.world);
        PlotGrid grid = grids.get(pl.world);
        if (biome == null || w == null || grid == null) {
            txt.send(p, "biome.need_biome");
            return;
        }
        final int z0 = grid.minZ(pl.pz);
        final int z1 = grid.maxZ(pl.pz);
        slices(grid.minX(pl.px), grid.maxX(pl.px), x -> {
            for (int z = z0; z <= z1; z++) {
                for (int y = w.getMinHeight(); y < w.getMaxHeight(); y += 4) w.setBiome(x, y, z, biome);
            }
        }, () -> txt.send(p, "biome.biome_set_to", "value", name));
    }

    private void setCmd(Player p, Plot here, PlotGrid g, String[] args) {
        if (args.length < 3) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot set \\<floor|main|air|all|border|wall|biome> \\<Wert></aqua>");
            return;
        }
        String what = args[1].toLowerCase(Locale.ROOT);
        if (what.equals("biome")) {
            biomeCmd(p, here, g, args[2]);
            return;
        }
        Plot pl = ownPlotHere(p, here, g);
        if (pl == null) return;
        final Material m = Material.matchMaterial(args[2]);
        if (m == null || !m.isBlock()) {
            txt.send(p, "invalid.not_valid_block", "value", args[2]);
            return;
        }
        World w = Bukkit.getWorld(pl.world);
        PlotGrid grid = grids.get(pl.world);
        if (w == null || grid == null) {
            txt.send(p, "errors.not_valid_world");
            return;
        }
        if (what.equals("border") || what.equals("wall")) {
            setBorder(pl, m);
            txt.send(p, "set.set_attribute", "attribute", what, "value", m.name());
            return;
        }
        int[] range = switch (what) {
            case "floor" -> new int[]{grid.top, grid.top};
            case "main" -> new int[]{w.getMinHeight() + 1, grid.top - 1};
            case "air" -> new int[]{grid.top + 1, w.getMaxHeight() - 1};
            case "all" -> new int[]{w.getMinHeight() + 1, w.getMaxHeight() - 1};
            default -> null;
        };
        if (range == null) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot set \\<floor|main|air|all|border|wall|biome> \\<Wert></aqua>");
            return;
        }
        final int lo = range[0];
        final int hi = range[1];
        final int z0 = grid.minZ(pl.pz);
        final int z1 = grid.maxZ(pl.pz);
        slices(grid.minX(pl.px), grid.maxX(pl.px), x -> {
            for (int z = z0; z <= z1; z++) {
                for (int y = lo; y <= hi; y++) {
                    Block b = w.getBlockAt(x, y, z);
                    if (b.getType() != m) b.setType(m, false);
                }
            }
        }, () -> txt.send(p, "set.set_attribute", "attribute", what, "value", m.name()));
    }

    // ------------------------------------------------------------------ Bewerten / Kommentare

    private static final List<String> INBOXES = List.of("public", "owner", "report");

    private void rateCmd(Player p, Plot here, PlotGrid g, String sub, String[] args) {
        if (here == null) {
            txt.send(p, g == null ? "errors.not_in_plot_world" : g.keyAt(p.getLocation().getBlockX(), p.getLocation().getBlockZ()) == PlotGrid.NONE
                    ? "errors.not_in_plot" : "ratings.rating_not_owned");
            return;
        }
        if (here.owner.equals(p.getUniqueId())) {
            txt.send(p, "ratings.rating_not_your_own");
            return;
        }
        if (!here.flags.containsKey("_done")) {
            txt.send(p, "ratings.rating_not_done");
            return;
        }
        String kind = sub.equals("rate") ? "rate" : "like";
        int val;
        if (sub.equals("rate")) {
            if (args.length < 2) {
                txt.send(p, "ratings.rating_not_valid");
                return;
            }
            try {
                val = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                txt.send(p, "ratings.rating_not_valid");
                return;
            }
            if (val < 1 || val > 10) {
                txt.send(p, "ratings.rating_not_valid");
                return;
            }
        } else {
            val = sub.equals("like") ? 1 : -1;
        }
        String uid = p.getUniqueId().toString();
        if (scalarInt("SELECT COUNT(*) FROM plot2_ratings WHERE world=? AND px=? AND pz=? AND uuid=? AND kind=?",
                here.world, here.px, here.pz, uid, kind) > 0) {
            txt.send(p, "ratings.rating_already_exists", "plot", here.id());
            return;
        }
        exec("INSERT INTO plot2_ratings (world, px, pz, uuid, kind, value) VALUES (?, ?, ?, ?, ?, ?)", here.world, here.px, here.pz, uid, kind, val);
        txt.send(p, sub.equals("rate") ? "ratings.rating_applied" : sub.equals("like") ? "ratings.rating_liked" : "ratings.rating_disliked", "plot", here.id());
    }

    private void commentCmd(Player p, Plot here, String[] args) {
        if (here == null) {
            txt.send(p, "comment.no_plot_inbox");
            return;
        }
        if (args.length < 3) {
            txt.send(p, "comment.comment_syntax", "command", "/plot comment", "list", String.join("|", INBOXES));
            return;
        }
        String inbox = args[1].toLowerCase(Locale.ROOT);
        if (!INBOXES.contains(inbox)) {
            txt.send(p, "comment.invalid_inbox", "list", String.join(", ", INBOXES));
            return;
        }
        String text = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        exec("INSERT INTO plot2_comments (world, px, pz, inbox, sender, comment, time) VALUES (?, ?, ?, ?, ?, ?, ?)",
                here.world, here.px, here.pz, inbox, p.getName(), text, System.currentTimeMillis());
        txt.send(p, "comment.comment_added");
        Player o = Bukkit.getPlayer(here.owner);
        if (o != null && o != p && !inbox.equals("report")) {
            txt.send(o, "comment.inbox_notification", "amount", "1", "command", "/plot inbox " + inbox);
        }
    }

    private void inboxCmd(Player p, Plot here, String[] args) {
        if (here == null) {
            txt.send(p, "comment.no_plot_inbox");
            return;
        }
        boolean owner = here.owner.equals(p.getUniqueId());
        boolean adm = admin(p);
        String inbox = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "public";
        if (!INBOXES.contains(inbox)) {
            txt.send(p, "comment.invalid_inbox", "list", String.join(", ", INBOXES));
            return;
        }
        boolean canRead = inbox.equals("public") || (inbox.equals("owner") && (owner || adm)) || (inbox.equals("report") && adm);
        if (!canRead) {
            txt.send(p, "comment.no_perm_inbox");
            return;
        }
        if (args.length > 2 && args[2].equalsIgnoreCase("clear")) {
            if (!(owner || adm)) {
                txt.send(p, "comment.no_perm_inbox_modify");
                return;
            }
            int n = scalarInt("SELECT COUNT(*) FROM plot2_comments WHERE world=? AND px=? AND pz=? AND inbox=?", here.world, here.px, here.pz, inbox);
            exec("DELETE FROM plot2_comments WHERE world=? AND px=? AND pz=? AND inbox=?", here.world, here.px, here.pz, inbox);
            txt.send(p, "comment.comment_removed_success", "value", String.valueOf(n));
            return;
        }
        List<String> lines = new ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT sender, comment FROM plot2_comments WHERE world=? AND px=? AND pz=? AND inbox=? ORDER BY id")) {
            ps.setString(1, here.world);
            ps.setInt(2, here.px);
            ps.setInt(3, here.pz);
            ps.setString(4, inbox);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lines.add(rs.getString(1) + ": " + rs.getString(2));
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Plot-Kommentare: " + e.getMessage());
        }
        if (lines.isEmpty()) {
            txt.send(p, "comment.inbox_empty");
            return;
        }
        for (String line : lines) txt.send(p, "comment.inbox_item", "value", line);
    }

    // ------------------------------------------------------------------ Musik, Kompass, Bereinigen

    private void musicCmd(Player p, Plot here, PlotGrid g, String[] args) {
        Plot pl = ownPlotHere(p, here, g);
        if (pl == null) return;
        if (args.length < 2) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot music \\<Schallplatte|reset></aqua>");
            return;
        }
        String old = pl.flags.get("_music");
        if (args[1].equalsIgnoreCase("reset") || args[1].equalsIgnoreCase("off")) {
            if (old != null) {
                for (Player o : Bukkit.getOnlinePlayers()) if (plotAt(o.getLocation()) == pl) o.stopSound(old, SoundCategory.RECORDS);
            }
            saveFlag(pl, "_music", null);
            txt.send(p, "set.set_attribute", "attribute", "music", "value", "-");
            return;
        }
        Material m = Material.matchMaterial("MUSIC_DISC_" + args[1]);
        if (m == null) m = Material.matchMaterial(args[1]);
        if (m == null || !m.name().startsWith("MUSIC_DISC_")) {
            txt.send(p, "invalid.not_valid_block", "value", args[1]);
            return;
        }
        String sound = "minecraft:music_disc." + m.name().substring("MUSIC_DISC_".length()).toLowerCase(Locale.ROOT);
        if (old != null) {
            for (Player o : Bukkit.getOnlinePlayers()) if (plotAt(o.getLocation()) == pl) o.stopSound(old, SoundCategory.RECORDS);
        }
        saveFlag(pl, "_music", sound);
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (plotAt(o.getLocation()) == pl) o.playSound(o.getLocation(), sound, SoundCategory.RECORDS, 1f, 1f);
        }
        txt.send(p, "set.set_attribute", "attribute", "music", "value", m.name());
    }

    private void targetCmd(Player p, PlotGrid g, String[] args) {
        if (g == null) {
            txt.send(p, "errors.not_in_plot_world");
            return;
        }
        int px;
        int pz;
        if (args.length > 1 && !args[1].equalsIgnoreCase("nearest")) {
            int[] id = parseId(p, args[1]);
            if (id == null) return;
            px = id[0];
            pz = id[1];
        } else {
            int cx = Math.floorDiv(p.getLocation().getBlockX(), g.cell);
            int cz = Math.floorDiv(p.getLocation().getBlockZ(), g.cell);
            px = cx;
            pz = cz;
            double best = Double.MAX_VALUE;
            for (int dx = -15; dx <= 15; dx++) {
                for (int dz = -15; dz <= 15; dz++) {
                    if (plots.containsKey(pkey(p.getWorld().getName(), cx + dx, cz + dz))) continue;
                    double dist = dx * dx + dz * dz;
                    if (dist < best) {
                        best = dist;
                        px = cx + dx;
                        pz = cz + dz;
                    }
                }
            }
        }
        p.setCompassTarget(new Location(p.getWorld(), g.centerX(px) + 0.5, p.getLocation().getY(), g.centerZ(pz) + 0.5));
        txt.send(p, "compass.compass_target", "target", px + ";" + pz);
    }

    private void purgeCmd(Player p, String[] args) {
        if (!admin(p)) {
            txt.send(p, "permission.no_permission", "node", "spookycraft.plots.admin");
            return;
        }
        if (args.length < 2 || !grids.containsKey(args[1])) {
            txt.send(p, "errors.not_valid_plot_world", "value", args.length < 2 ? "-" : args[1]);
            return;
        }
        final String world = args[1];
        confirm(p, "/plot purge " + world, () -> {
            List<Plot> list = new ArrayList<>();
            for (Plot pl : plots.values()) if (pl.world.equals(world)) list.add(pl);
            PlotGrid grid = grids.get(world);
            for (Plot pl : list) unlinkGroup(pl);
            long delay = 0;
            for (Plot pl : list) {
                removePlot(pl);
                if (grid != null) setBorder(pl, grid.borderFree);
                final Plot target = pl;
                Bukkit.getScheduler().runTaskLater(plugin, () -> clear(target, null, true), delay);
                delay += 60L;
            }
            txt.send(p, "purge.purge_success", "amount", String.valueOf(list.size()));
        });
    }

    // ------------------------------------------------------------------ Setup-Assistent

    private void showStep(Player p, Setup s) {
        String d = STEP_DESC[s.step];
        if (d.startsWith("setup.")) d = txt.raw(d);
        if (s.step == 0) txt.send(p, "setup.setup_world_name");
        txt.send(p, "setup.setup_step", "step", String.valueOf(s.step + 1), "~description", d, "type", STEP_TYPE[s.step], "value", STEP_DEFAULT[s.step]);
    }

    private void setup(Player p, String[] args) {
        if (!admin(p)) {
            txt.send(p, "permission.no_permission", "node", "spookycraft.plots.admin");
            return;
        }
        Setup s = setups.get(p.getUniqueId());
        if (args.length < 2) {
            if (s == null) {
                s = new Setup();
                setups.put(p.getUniqueId(), s);
            }
            txt.send(p, "setup.setup_init");
            showStep(p, s);
            return;
        }
        if (s == null) {
            txt.send(p, "setup.setup_not_started");
            return;
        }
        String v = args[1];
        if (v.equalsIgnoreCase("cancel")) {
            setups.remove(p.getUniqueId());
            txt.send(p, "setup.setup_cancelled");
            return;
        }
        if (v.equalsIgnoreCase("back")) {
            s.step = Math.max(0, s.step - 1);
            showStep(p, s);
            return;
        }
        if (v.equalsIgnoreCase("default")) v = STEP_DEFAULT[s.step];
        switch (s.step) {
            case 0 -> {
                String name = v.toLowerCase(Locale.ROOT);
                if (!name.matches("[a-z0-9_.-]+")) {
                    txt.send(p, "setup.setup_world_name_format");
                    return;
                }
                if (Bukkit.getWorld(name) != null || grids.containsKey(name)) {
                    txt.send(p, "setup.setup_world_taken", "value", name);
                    return;
                }
                v = name;
            }
            case 1, 2, 3 -> {
                int lo = s.step == 1 ? 8 : s.step == 2 ? 3 : 5;
                int hi = s.step == 1 ? 200 : s.step == 2 ? 30 : 250;
                try {
                    int n = Integer.parseInt(v);
                    if (n < lo || n > hi) throw new NumberFormatException();
                } catch (NumberFormatException e) {
                    txt.send(p, "invalid.number_not_in_range", "min", String.valueOf(lo), "max", String.valueOf(hi));
                    return;
                }
            }
            default -> {
                Material m = Material.matchMaterial(v);
                if (m == null || !m.isBlock()) {
                    txt.send(p, "invalid.not_valid_block", "value", v);
                    return;
                }
                v = m.name();
            }
        }
        s.vals[s.step] = v;
        String d = STEP_DESC[s.step];
        if (d.startsWith("setup.")) d = txt.raw(d);
        txt.send(p, "setup.setup_valid_arg", "~description", d, "value", v);
        s.step++;
        if (s.step < s.vals.length) {
            showStep(p, s);
            return;
        }
        setups.remove(p.getUniqueId());
        String name = s.vals[0];
        YamlConfiguration y = YamlConfiguration.loadConfiguration(worldsFile);
        String b = "worlds." + name + ".";
        y.set(b + "size", Integer.parseInt(s.vals[1]));
        y.set(b + "road", Integer.parseInt(s.vals[2]));
        y.set(b + "height", Integer.parseInt(s.vals[3]));
        y.set(b + "fill", s.vals[4]);
        y.set(b + "floor", s.vals[5]);
        y.set(b + "road-block", s.vals[6]);
        y.set(b + "border-free", s.vals[7]);
        y.set(b + "border-claimed", s.vals[8]);
        try {
            y.save(worldsFile);
        } catch (IOException e) {
            plugin.getLogger().warning("plots-worlds.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
        PlotGrid g = gridFrom(y.getConfigurationSection("worlds." + name));
        grids.put(name, g);
        World w = makeWorld(name, g);
        if (w == null) {
            grids.remove(name);
            txt.send(p, "errors.error_create", "world", name);
            return;
        }
        p.teleport(new Location(w, 0.5, g.top + 2, 0.5));
        txt.send(p, "setup.setup_finished");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return SUBS.stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (args.length == 2) {
            String a = args[0].toLowerCase(Locale.ROOT);
            if (List.of("trust", "add", "deny", "remove", "kick", "visit", "setowner").contains(a)) {
                return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                        .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
            if (a.equals("sethome")) return List.of("reset");
            if (a.equals("merge")) return List.of("north", "south", "east", "west", "all");
            if (a.equals("set")) return List.of("floor", "main", "air", "all", "border", "wall", "biome");
            if (a.equals("rate")) return List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
            if (a.equals("comment") || a.equals("inbox")) return INBOXES;
            if (a.equals("target")) return List.of("nearest");
            if (a.equals("purge")) return new ArrayList<>(grids.keySet());
            if (a.equals("music")) {
                List<String> discs = new ArrayList<>();
                for (Material m : Material.values()) {
                    if (m.name().startsWith("MUSIC_DISC_")) discs.add(m.name().substring("MUSIC_DISC_".length()).toLowerCase(Locale.ROOT));
                }
                discs.add("reset");
                return discs;
            }
            if (a.equals("biome")) {
                List<String> biomes = new ArrayList<>();
                for (Biome b : Registry.BIOME) biomes.add(b.getKey().getKey());
                return biomes.stream().filter(n -> n.startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
            if (a.equals("setup")) return List.of("cancel", "back", "default");
            if (a.equals("auto")) return new ArrayList<>(grids.keySet());
            if (a.equals("flag")) return List.of("set", "add", "remove", "list", "info");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("flag")) {
            return PlotFlags.ALL.keySet().stream().filter(n -> n.startsWith(args[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("flag")) {
            PlotFlags.Def d = PlotFlags.ALL.get(PlotFlags.normalize(args[2]));
            return d == null ? List.of() : d.values();
        }
        return List.of();
    }

    // ------------------------------------------------------------------ Flags

    private boolean flagBool(Plot plot, String name) {
        PlotFlags.Def d = PlotFlags.ALL.get(name);
        String v = plot == null ? null : plot.flags.get(name);
        if (v == null) v = d == null ? "false" : d.def();
        return v.equals("true");
    }

    private boolean flagHas(Plot plot, String name, String item) {
        return plot != null && PlotFlags.items(plot.flags.get(name)).contains(item.toLowerCase(Locale.ROOT));
    }

    private void saveFlag(Plot plot, String name, String value) {
        if (value == null) {
            plot.flags.remove(name);
            exec("DELETE FROM plot2_flags WHERE world=? AND px=? AND pz=? AND flag=?", plot.world, plot.px, plot.pz, name);
        } else {
            plot.flags.put(name, value);
            exec("INSERT INTO plot2_flags (world, px, pz, flag, value) VALUES (?, ?, ?, ?, ?) ON CONFLICT(world, px, pz, flag) DO UPDATE SET value=excluded.value",
                    plot.world, plot.px, plot.pz, name, value);
        }
    }

    private void flagError(Player p, String key) {
        txt.sendText(p, "<prefix><red>" + txt.raw(key) + "</red>");
    }

    private void flagCmd(Player p, Plot here, PlotGrid g, String[] args) {
        String sub = args.length < 2 ? "" : args[1].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            txt.sendText(p, txt.raw("flag.flag_info_header").replace("PlotSquared-Flags", "Plot-Flags"));
            Map<String, List<String>> byCat = new LinkedHashMap<>();
            for (PlotFlags.Def d : PlotFlags.ALL.values()) byCat.computeIfAbsent(d.category(), x -> new ArrayList<>()).add(d.name());
            for (Map.Entry<String, List<String>> e : byCat.entrySet()) {
                txt.sendText(p, "<aqua>" + e.getKey() + "</aqua><gray>: </gray><aqua>" + String.join("</aqua><gray>, </gray><aqua>", e.getValue()) + "</aqua>");
            }
            return;
        }
        if (sub.equals("info")) {
            PlotFlags.Def d = args.length > 2 ? PlotFlags.ALL.get(PlotFlags.normalize(args[2])) : null;
            if (d == null) {
                txt.send(p, "flag.not_valid_flag");
                return;
            }
            txt.send(p, "flag.flag_info_name", "flag", d.name());
            txt.send(p, "flag.flag_info_category", "value", d.category());
            txt.sendText(p, txt.raw("flag.flag_info_description") + txt.raw("flags.flag_description_" + d.name().replace('-', '_')));
            txt.send(p, "flag.flag_info_default_value", "value", d.def().isEmpty() ? "-" : d.def());
            txt.send(p, "flag.flag_info_example", "command", "/plot flag set", "flag", d.name(),
                    "value", d.values().isEmpty() ? "text" : d.values().get(0));
            return;
        }
        if (sub.isEmpty()) {
            if (g == null || here == null) {
                txt.send(p, "errors.not_in_plot");
                return;
            }
            String shown = here.flags.entrySet().stream().filter(e -> !e.getKey().startsWith("_"))
                    .map(e -> e.getKey() + "=" + e.getValue()).collect(Collectors.joining(", "));
            txt.sendText(p, "<prefix><gray>Flags: </gray><aqua>" + (shown.isEmpty() ? "-" : shown) + "</aqua>");
            return;
        }
        if (!sub.equals("set") && !sub.equals("add") && !sub.equals("remove")) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot flag set|add|remove|list|info \\<Flag> [Wert]</aqua>");
            return;
        }
        if (g == null || here == null) {
            txt.send(p, "errors.not_in_plot");
            return;
        }
        if (!(here.owner.equals(p.getUniqueId()) || admin(p))) {
            txt.send(p, "permission.no_plot_perms");
            return;
        }
        PlotFlags.Def d = args.length > 2 ? PlotFlags.ALL.get(PlotFlags.normalize(args[2])) : null;
        if (d == null) {
            txt.send(p, "flag.not_valid_flag");
            return;
        }
        String value = args.length > 3 ? String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length)) : "";
        boolean list = d.type() == PlotFlags.Type.BLOCKS || d.type() == PlotFlags.Type.LIST;
        if (sub.equals("remove")) {
            String cur = here.flags.get(d.name());
            if (cur == null) {
                txt.send(p, "flag.flag_not_removed");
                return;
            }
            if (list && !value.isEmpty()) {
                List<String> items = PlotFlags.items(cur);
                if (!items.remove(value.toLowerCase(Locale.ROOT))) {
                    txt.send(p, "flag.flag_not_removed");
                    return;
                }
                saveFlag(here, d.name(), items.isEmpty() ? null : String.join(",", items));
                txt.send(p, "flag.flag_partially_removed");
            } else {
                saveFlag(here, d.name(), null);
                txt.send(p, "flag.flag_removed", "flag", d.name(), "value", cur);
            }
            applyHere(here);
            return;
        }
        if (value.isEmpty()) {
            txt.sendText(p, "<prefix><gray>Verwendung: </gray><aqua>/plot flag " + sub + " " + d.name() + " \\<Wert></aqua>");
            return;
        }
        if (d.type() != PlotFlags.Type.TEXT) value = value.toLowerCase(Locale.ROOT).replace(" ", "");
        String err = PlotFlags.validate(d, value);
        if (err != null) {
            flagError(p, err);
            return;
        }
        if (sub.equals("add") && list) {
            List<String> items = PlotFlags.items(here.flags.get(d.name()));
            for (String it : PlotFlags.items(value)) if (!items.contains(it)) items.add(it);
            value = String.join(",", items);
        }
        saveFlag(here, d.name(), value);
        txt.send(p, "flag.flag_added", "flag", d.name(), "value", value);
        applyHere(here);
    }

    /** Wirkt Zeit/Wetter/Spielmodus/Flug sofort auf alle, die gerade auf dem Plot stehen. */
    private void applyHere(Plot plot) {
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (plot.key().equals(presence.get(pl.getUniqueId()))) {
                leaveEffects(pl, plot);
                enterEffects(pl, plot, false);
            }
        }
    }

    private boolean isMember(Plot plot, Player p) {
        UUID id = p.getUniqueId();
        return plot.owner.equals(id) || plot.trusted.contains(id) || plot.added.contains(id);
    }

    private void enterEffects(Player p, Plot plot, boolean announce) {
        if (admin(p) && !announce) return;
        if (announce) {
            String greet = plot.flags.get("greeting");
            if (greet != null) p.sendMessage(GuiUtil.c(greet));
            if (flagBool(plot, "notify-enter") && !plot.owner.equals(p.getUniqueId())) {
                Player o = Bukkit.getPlayer(plot.owner);
                if (o != null) txt.send(o, "notification.notify_enter", "player", p.getName(), "area", plot.world, "plot", plot.id());
            }
            String music = plot.flags.get("_music");
            if (music != null) p.playSound(p.getLocation(), music, SoundCategory.RECORDS, 1f, 1f);
        }
        String time = plot.flags.get("time");
        if (time != null) p.setPlayerTime(PlotFlags.timeTicks(time), false);
        String weather = plot.flags.get("weather");
        if (weather != null) p.setPlayerWeather(weather.equals("rain") ? WeatherType.DOWNFALL : WeatherType.CLEAR);
        String mode = plot.flags.get(isMember(plot, p) ? "gamemode" : "guest-gamemode");
        if (mode != null && !admin(p)) {
            try {
                GameMode gm = GameMode.valueOf(mode.toUpperCase(Locale.ROOT));
                prevMode.putIfAbsent(p.getUniqueId(), p.getGameMode());
                p.setGameMode(gm);
            } catch (IllegalArgumentException ignored) {
                // unbekannter Modus
            }
        }
        if (flagBool(plot, "flight") && !admin(p)) {
            prevFlight.putIfAbsent(p.getUniqueId(), p.getAllowFlight());
            p.setAllowFlight(true);
        }
    }

    private void leaveEffects(Player p, Plot plot) {
        String music = plot.flags.get("_music");
        if (music != null) p.stopSound(music, SoundCategory.RECORDS);
        if (plot.flags.containsKey("time")) p.resetPlayerTime();
        if (plot.flags.containsKey("weather")) p.resetPlayerWeather();
        GameMode gm = prevMode.remove(p.getUniqueId());
        if (gm != null) p.setGameMode(gm);
        Boolean fl = prevFlight.remove(p.getUniqueId());
        if (fl != null) {
            p.setAllowFlight(fl);
            if (!fl) p.setFlying(false);
        }
    }

    private void updatePresence(Player p, Location to) {
        Plot now = inPlotWorld(to.getWorld()) ? plotAt(to) : null;
        String nowKey = now == null ? null : now.key();
        String old = presence.get(p.getUniqueId());
        if ((old == null && nowKey == null) || (old != null && old.equals(nowKey))) return;
        Plot prev = old == null ? null : plots.get(old);
        if (prev != null) {
            leaveEffects(p, prev);
            String bye = prev.flags.get("farewell");
            if (bye != null) p.sendMessage(GuiUtil.c(bye));
            if (flagBool(prev, "notify-leave") && !prev.owner.equals(p.getUniqueId())) {
                Player o = Bukkit.getPlayer(prev.owner);
                if (o != null) txt.sendText(o, "<prefix><aqua>" + p.getName() + "</aqua><gray> verlässt dein Plot " + prev.id() + ".</gray>");
            }
        }
        if (nowKey == null) presence.remove(p.getUniqueId());
        else presence.put(p.getUniqueId(), nowKey);
        if (now != null) enterEffects(p, now, true);
    }

    // ------------------------------------------------------------------ Schutz

    /** Wie buildNode, beruecksichtigt aber die Erlaubnis-Flags use/break/place/device-interact. */
    private String nodeFor(Player p, Location l, String action, Material m) {
        String node = buildNode(p, l);
        if (node == null || !node.equals("plots.admin.build.other")) return node;
        Plot plot = plotAt(l);
        if (plot == null) return node;
        if (flagHas(plot, action, m.name())) return null;
        if (action.equals("use") && flagBool(plot, "device-interact")) {
            String n = m.name();
            if (n.endsWith("_BUTTON") || n.equals("LEVER") || n.endsWith("_PRESSURE_PLATE") || n.endsWith("_DOOR") || n.endsWith("_TRAPDOOR") || n.endsWith("_FENCE_GATE")) {
                return null;
            }
        }
        return node;
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        String node = nodeFor(e.getPlayer(), e.getBlock().getLocation(), "break", e.getBlock().getType());
        if (node != null) {
            e.setCancelled(true);
            denyMsg(e.getPlayer(), node);
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        String node = nodeFor(e.getPlayer(), e.getBlock().getLocation(), "place", e.getBlock().getType());
        if (node != null) {
            e.setCancelled(true);
            denyMsg(e.getPlayer(), node);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!active || e.getClickedBlock() == null || !inPlotWorld(e.getClickedBlock().getWorld())) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK && e.getAction() != Action.LEFT_CLICK_BLOCK && e.getAction() != Action.PHYSICAL) return;
        String node = nodeFor(e.getPlayer(), e.getClickedBlock().getLocation(), "use", e.getClickedBlock().getType());
        if (node != null) {
            e.setUseInteractedBlock(Event.Result.DENY);
            if (e.getAction() != Action.PHYSICAL) denyMsg(e.getPlayer(), node);
        }
    }

    @EventHandler
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        String node = buildNode(e.getPlayer(), e.getBlock().getLocation());
        if (node != null) {
            e.setCancelled(true);
            denyMsg(e.getPlayer(), node);
        }
    }

    @EventHandler
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        String node = buildNode(e.getPlayer(), e.getBlock().getLocation());
        if (node != null) {
            e.setCancelled(true);
            denyMsg(e.getPlayer(), node);
        }
    }

    @EventHandler
    public void onFlow(BlockFromToEvent e) {
        PlotGrid g = active ? gridOf(e.getBlock().getWorld()) : null;
        if (g == null) return;
        Block a = e.getBlock();
        Block b = e.getToBlock();
        if (g.keyAt(a.getX(), a.getZ()) != g.keyAt(b.getX(), b.getZ())) {
            e.setCancelled(true);
            return;
        }
        Plot plot = plotAt(a.getLocation());
        if (plot != null && !flagBool(plot, "liquid-flow") && (a.isLiquid())) e.setCancelled(true);
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (active && inPlotWorld(e.getBlock().getWorld()) && crosses(e.getBlock(), e.getBlocks(), e.getDirection())) e.setCancelled(true);
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (active && inPlotWorld(e.getBlock().getWorld()) && crosses(e.getBlock(), e.getBlocks(), e.getDirection())) e.setCancelled(true);
    }

    private boolean crosses(Block piston, List<Block> blocks, BlockFace dir) {
        PlotGrid g = gridOf(piston.getWorld());
        if (g == null) return false;
        long k = g.keyAt(piston.getX(), piston.getZ());
        Block front = piston.getRelative(dir);
        if (g.keyAt(front.getX(), front.getZ()) != k) return true;
        for (Block b : blocks) {
            if (g.keyAt(b.getX(), b.getZ()) != k) return true;
            Block f = b.getRelative(dir);
            Block r = b.getRelative(dir.getOppositeFace());
            if (g.keyAt(f.getX(), f.getZ()) != k || g.keyAt(r.getX(), r.getZ()) != k) return true;
        }
        return false;
    }

    private void explode(Location origin, List<Block> blocks) {
        Plot plot = plotAt(origin);
        if (plot != null && flagBool(plot, "explosion")) {
            PlotGrid g = gridOf(origin.getWorld());
            long k = g.keyAt(origin.getBlockX(), origin.getBlockZ());
            blocks.removeIf(b -> g.keyAt(b.getX(), b.getZ()) != k);
        } else {
            blocks.clear();
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        if (active && inPlotWorld(e.getEntity().getWorld())) explode(e.getLocation(), e.blockList());
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        if (active && inPlotWorld(e.getBlock().getWorld())) explode(e.getBlock().getLocation(), e.blockList());
    }

    @EventHandler
    public void onBurn(BlockBurnEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        if (!flagBool(plotAt(e.getBlock().getLocation()), "block-burn")) e.setCancelled(true);
    }

    @EventHandler
    public void onIgnite(BlockIgniteEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        if (e.getCause() == BlockIgniteEvent.IgniteCause.SPREAD || e.getCause() == BlockIgniteEvent.IgniteCause.LAVA
                || e.getCause() == BlockIgniteEvent.IgniteCause.LIGHTNING) {
            if (!flagBool(plotAt(e.getBlock().getLocation()), "block-ignition")) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onSpread(BlockSpreadEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        Material m = e.getNewState().getType();
        if (m == Material.GRASS_BLOCK || m == Material.MYCELIUM) {
            Plot plot = plotAt(e.getBlock().getLocation());
            if (plot != null && !flagBool(plot, "grass-grow")) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onLeaves(LeavesDecayEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        Plot plot = plotAt(e.getBlock().getLocation());
        if (plot != null && !flagBool(plot, "leaf-decay")) e.setCancelled(true);
    }

    @EventHandler
    public void onRedstone(BlockRedstoneEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        Plot plot = plotAt(e.getBlock().getLocation());
        if (plot != null && !flagBool(plot, "redstone")) e.setNewCurrent(e.getOldCurrent());
    }

    @EventHandler
    public void onPhysics(BlockPhysicsEvent e) {
        if (!active || !inPlotWorld(e.getBlock().getWorld())) return;
        Plot plot = plotAt(e.getBlock().getLocation());
        if (plot != null && flagBool(plot, "disable-physics")) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (!active || !inPlotWorld(e.getPlayer().getWorld())) return;
        Plot plot = plotAt(e.getPlayer().getLocation());
        if (plot != null && !flagBool(plot, "item-drop")) e.setCancelled(true);
    }

    @EventHandler
    public void onCommandBlocked(PlayerCommandPreprocessEvent e) {
        if (!active || !inPlotWorld(e.getPlayer().getWorld()) || admin(e.getPlayer())) return;
        Plot plot = plotAt(e.getPlayer().getLocation());
        if (plot == null || !plot.flags.containsKey("blocked-cmds")) return;
        String cmd = e.getMessage().trim().toLowerCase(Locale.ROOT).substring(1).split(" ")[0];
        if (flagHas(plot, "blocked-cmds", cmd)) {
            e.setCancelled(true);
            txt.send(e.getPlayer(), "permission.no_permission", "node", "plots.flag.blocked-cmds");
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!active || !inPlotWorld(e.getEntity().getWorld())) return;
        Plot plot = plotAt(e.getEntity().getLocation());
        if (plot != null && flagBool(plot, "keep-inventory")) {
            e.setKeepInventory(true);
            e.getDrops().clear();
            e.setKeepLevel(true);
            e.setDroppedExp(0);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!active || !(e.getEntity() instanceof Player p) || !inPlotWorld(p.getWorld())) return;
        Plot plot = plotAt(p.getLocation());
        if (plot != null && flagBool(plot, "invincible")) e.setCancelled(true);
    }

    @EventHandler
    public void onCombat(EntityDamageByEntityEvent e) {
        if (!active || !inPlotWorld(e.getEntity().getWorld())) return;
        Entity damager = e.getDamager();
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Entity shooter) damager = shooter;
        if (!(damager instanceof Player attacker) || admin(attacker)) return;
        Plot plot = plotAt(e.getEntity().getLocation());
        Entity victim = e.getEntity();
        if (victim instanceof Player) {
            if (plot == null || !flagBool(plot, "pvp")) {
                e.setCancelled(true);
                denyMsg(attacker, "plots.flag.pvp");
            }
            return;
        }
        if (plot == null || !(victim instanceof LivingEntity) || isMember(plot, attacker)) return;
        boolean allowed = flagBool(plot, "pve");
        if (victim instanceof Monster) allowed = allowed || flagBool(plot, "hostile-attack");
        else if (victim instanceof Tameable t && t.isTamed()) allowed = allowed || flagBool(plot, "tamed-attack");
        else if (victim instanceof Animals) allowed = allowed || flagBool(plot, "animal-attack");
        if (!allowed) {
            e.setCancelled(true);
            denyMsg(attacker, "plots.flag.pve");
        }
    }

    // ------------------------------------------------------------------ Bewegen

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!active || e.getTo() == null) return;
        Location f = e.getFrom();
        Location t = e.getTo();
        if (f.getBlockX() == t.getBlockX() && f.getBlockZ() == t.getBlockZ() && f.getWorld() == t.getWorld()) return;
        Player p = e.getPlayer();
        if (!inPlotWorld(t.getWorld()) && !inPlotWorld(f.getWorld())) return;
        Plot from = plotAt(f);
        Plot plot = plotAt(t);
        if (plot != from && !admin(p)) {
            if (from != null && flagBool(from, "deny-exit") && !from.owner.equals(p.getUniqueId())) {
                e.setTo(f);
                txt.sendText(p, "<prefix><red>Du kannst dieses Plot nicht verlassen.</red>");
                return;
            }
            if (plot != null && (plot.denied.contains(p.getUniqueId()) || (!flagBool(plot, "untrusted") && !isMember(plot, p)))) {
                e.setTo(f);
                txt.send(p, "deny.no_enter", "plot", plot.id());
                return;
            }
        }
        updatePresence(p, t);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        if (!active || e.getTo() == null) return;
        updatePresence(e.getPlayer(), e.getTo());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (active) updatePresence(e.getPlayer(), e.getPlayer().getLocation());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        String key = presence.remove(p.getUniqueId());
        Plot plot = key == null ? null : plots.get(key);
        if (plot != null) leaveEffects(p, plot);
        else {
            GameMode gm = prevMode.remove(p.getUniqueId());
            if (gm != null) p.setGameMode(gm);
            prevFlight.remove(p.getUniqueId());
        }
    }
}
