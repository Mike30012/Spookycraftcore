package de.craftsucht.core.plots;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import de.craftsucht.core.SpookyCraftCore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

/**
 * Texte des Plot-Systems im MiniMessage-Format (Schluessel wie bei PlotSquared, z.B. working.claimed). Die eingebaute Datei
 * wird nach plugins/SpookyCraftCore/plots-messages.json kopiert und kann dort frei geaendert werden.
 * Platzhalter: kv = "name", "wert", ...; ein "~" vor dem Namen heisst: Wert enthaelt selbst MiniMessage.
 */
final class PlotMessages {

    private final Map<String, String> map = new HashMap<>();
    private final MiniMessage mm = MiniMessage.miniMessage();

    PlotMessages(SpookyCraftCore plugin) {
        try (InputStream in = plugin.getResource("plots-messages.json")) {
            if (in != null) read(new InputStreamReader(in, StandardCharsets.UTF_8));
        } catch (IOException | RuntimeException e) {
            plugin.getLogger().warning("Eingebaute Plot-Texte nicht lesbar: " + e.getMessage());
        }
        File f = new File(plugin.getDataFolder(), "plots-messages.json");
        if (!f.exists()) {
            try {
                plugin.saveResource("plots-messages.json", false);
            } catch (IllegalArgumentException ignored) {
                // Datei fehlt im Paket
            }
        }
        if (f.exists()) {
            try (Reader r = Files.newBufferedReader(f.toPath(), StandardCharsets.UTF_8)) {
                read(r);
            } catch (IOException | RuntimeException e) {
                plugin.getLogger().warning("plots-messages.json nicht lesbar, nutze eingebaute Texte: " + e.getMessage());
            }
        }
    }

    private void read(Reader r) {
        JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
        for (Map.Entry<String, com.google.gson.JsonElement> e : o.entrySet()) {
            if (e.getValue().isJsonPrimitive()) map.put(e.getKey(), e.getValue().getAsString());
        }
    }

    String raw(String key) {
        return map.getOrDefault(key, "");
    }

    Component component(String template, String... kv) {
        TagResolver.Builder b = TagResolver.builder();
        b.resolver(Placeholder.parsed("prefix", map.getOrDefault("core.prefix", "")));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            String name = kv[i];
            if (name.startsWith("~")) b.resolver(Placeholder.parsed(name.substring(1), kv[i + 1]));
            else b.resolver(Placeholder.unparsed(name, kv[i + 1]));
        }
        return mm.deserialize(template, b.build());
    }

    void send(CommandSender s, String key, String... kv) {
        String t = map.get(key);
        s.sendMessage(component(t == null ? "<prefix><red>" + key : t, kv));
    }

    /** Eigener MiniMessage-Text (mit dem Prefix aus den Texten). */
    void sendText(CommandSender s, String text, String... kv) {
        s.sendMessage(component(text, kv));
    }
}
