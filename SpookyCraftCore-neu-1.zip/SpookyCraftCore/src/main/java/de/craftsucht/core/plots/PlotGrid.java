package de.craftsucht.core.plots;

import org.bukkit.Material;

/** Geometrie der Plot-Welt: Raster aus Grundstuecken (size) und Strassen (road). */
final class PlotGrid {

    static final long NONE = Long.MIN_VALUE;

    final int size;
    final int road;
    final int cell;
    final int top;
    final Material floor;
    final Material fill;
    final Material roadMat;
    final Material borderFree;
    final Material borderClaimed;

    PlotGrid(int size, int road, int top, Material floor, Material fill, Material roadMat, Material borderFree, Material borderClaimed) {
        this.size = size;
        this.road = road;
        this.cell = size + road;
        this.top = top;
        this.floor = floor;
        this.fill = fill;
        this.roadMat = roadMat;
        this.borderFree = borderFree;
        this.borderClaimed = borderClaimed;
    }

    boolean isPlot(int x, int z) {
        return Math.floorMod(x, cell) >= road && Math.floorMod(z, cell) >= road;
    }

    boolean isBorder(int x, int z) {
        if (isPlot(x, z)) return false;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (isPlot(x + dx, z + dz)) return true;
            }
        }
        return false;
    }

    static long key(int px, int pz) {
        return ((long) px << 32) | (pz & 0xffffffffL);
    }

    static int px(long key) {
        return (int) (key >> 32);
    }

    static int pz(long key) {
        return (int) key;
    }

    /** Schluessel des Grundstuecks an dieser Stelle oder NONE (Strasse). */
    long keyAt(int x, int z) {
        if (!isPlot(x, z)) return NONE;
        return key(Math.floorDiv(x, cell), Math.floorDiv(z, cell));
    }

    int minX(int px) {
        return px * cell + road;
    }

    int minZ(int pz) {
        return pz * cell + road;
    }

    int maxX(int px) {
        return minX(px) + size - 1;
    }

    int maxZ(int pz) {
        return minZ(pz) + size - 1;
    }

    int centerX(int px) {
        return minX(px) + size / 2;
    }

    int centerZ(int pz) {
        return minZ(pz) + size / 2;
    }
}
