package de.craftsucht.core.plots;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Flags eines Plots: Name, Typ, Standardwert, Kategorie, Pruefung. Namen mit Bindestrich wie bei PlotSquared. */
final class PlotFlags {

    enum Type { BOOL, ENUM, TIME, TEXT, LIST, BLOCKS }

    record Def(String name, Type type, String def, String category, List<String> values) {
    }

    static final Map<String, Def> ALL = new LinkedHashMap<>();

    private static void bool(String n, boolean d, String cat) {
        ALL.put(n, new Def(n, Type.BOOL, String.valueOf(d), cat, List.of("true", "false")));
    }

    private static void add(String n, Type t, String d, String cat, String... vals) {
        ALL.put(n, new Def(n, t, d, cat, List.of(vals)));
    }

    static {
        bool("pvp", false, "Kampf");
        bool("pve", false, "Kampf");
        bool("invincible", false, "Kampf");
        bool("hostile-attack", false, "Kampf");
        bool("animal-attack", false, "Kampf");
        bool("tamed-attack", false, "Kampf");
        bool("keep-inventory", false, "Kampf");
        bool("explosion", false, "Schutz");
        bool("block-burn", false, "Schutz");
        bool("block-ignition", false, "Schutz");
        bool("untrusted", true, "Zutritt");
        bool("deny-exit", false, "Zutritt");
        bool("notify-enter", false, "Zutritt");
        bool("notify-leave", false, "Zutritt");
        bool("hide-info", false, "Zutritt");
        bool("flight", false, "Spieler");
        bool("item-drop", true, "Spieler");
        bool("liquid-flow", true, "Natur");
        bool("grass-grow", true, "Natur");
        bool("leaf-decay", true, "Natur");
        bool("redstone", true, "Technik");
        bool("disable-physics", false, "Technik");
        bool("device-interact", false, "Erlaubnisse");
        add("weather", Type.ENUM, "", "Welt", "clear", "rain");
        add("time", Type.TIME, "", "Welt", "day", "noon", "night", "midnight");
        add("gamemode", Type.ENUM, "", "Spieler", "survival", "creative", "adventure", "spectator");
        add("guest-gamemode", Type.ENUM, "", "Spieler", "survival", "creative", "adventure", "spectator");
        add("greeting", Type.TEXT, "", "Texte");
        add("farewell", Type.TEXT, "", "Texte");
        add("description", Type.TEXT, "", "Texte");
        add("use", Type.BLOCKS, "", "Erlaubnisse");
        add("break", Type.BLOCKS, "", "Erlaubnisse");
        add("place", Type.BLOCKS, "", "Erlaubnisse");
        add("blocked-cmds", Type.LIST, "", "Zutritt");
    }

    static String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).replace('_', '-');
    }

    static int timeTicks(String v) {
        return switch (v) {
            case "day" -> 1000;
            case "noon" -> 6000;
            case "night" -> 13000;
            case "midnight" -> 18000;
            default -> {
                try {
                    yield Math.floorMod(Integer.parseInt(v), 24000);
                } catch (NumberFormatException e) {
                    yield -1;
                }
            }
        };
    }

    /** null = gueltig, sonst der Text-Schluessel des Fehlers. */
    static String validate(Def d, String value) {
        switch (d.type()) {
            case BOOL:
                return value.equals("true") || value.equals("false") ? null : "flags.flag_error_boolean";
            case ENUM:
                return d.values().contains(value) ? null : "flags.flag_error_enum";
            case TIME:
                return timeTicks(value) >= 0 ? null : "flags.flag_error_integer";
            case BLOCKS:
                for (String part : value.split(",")) {
                    Material m = Material.matchMaterial(part.trim());
                    if (m == null || !m.isBlock()) return "flags.flag_error_invalid_block";
                }
                return null;
            default:
                return value.length() <= 300 ? null : "flag.not_valid_value";
        }
    }

    /** Gibt die Elemente einer Listen-Flag zurueck (kleingeschrieben). */
    static List<String> items(String v) {
        List<String> out = new ArrayList<>();
        if (v == null || v.isEmpty()) return out;
        for (String s : v.split(",")) if (!s.isBlank()) out.add(s.trim().toLowerCase(Locale.ROOT));
        return out;
    }
}
