package de.craftsucht.core.punish;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public class PunishCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final PunishManager manager;

    public PunishCommand(SpookyCraftCore plugin, PunishManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String lbl = label.toLowerCase();
        // Entbannen/Entmuten nur durch echte Spieler oder die Konsole - nie per Commandblock/Command-Minecart.
        if ((lbl.equals("unban") || lbl.equals("unmute") || lbl.equals("unipban") || lbl.equals("cbclear"))
                && (sender instanceof org.bukkit.command.BlockCommandSender
                    || sender instanceof org.bukkit.entity.minecart.CommandMinecart)) {
            plugin.getMessageUtil().send(sender, "&c/" + lbl + " funktioniert nicht über Commandblöcke.");
            return true;
        }
        if (!sender.isOp() && !sender.hasPermission("spookycraft.punish." + label.toLowerCase()) && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (lbl.equals("cbclear") && !sender.isOp() && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        switch (label.toLowerCase()) {
            case "punish": return handlePunish(sender, args);
            case "ban": return handleBan(sender, args, false);
            case "tempban": return handleBan(sender, args, true);
            case "unban": return handleUnban(sender, args);
            case "warn": return handleWarn(sender, args);
            case "kick": return handleKick(sender, args);
            case "mute": return handleMute(sender, args);
            case "unmute": return handleUnmute(sender, args);
            case "history": return handleHistory(sender, args);
            case "ipban": return handleIpBan(sender, args);
            case "unipban": return handleUnIpBan(sender, args);
            case "cbclear": return handleCbClear(sender, args);
        }
        return false;
    }

    private PunishCatalog catalog() {
        return new PunishCatalog(plugin.getConfig()); // bei jedem Aufruf frisch, damit /reload der Config greift
    }

    private void sendCatalog(CommandSender sender) {
        plugin.getMessageUtil().send(sender, "&7--- &6Strafkatalog &7---");
        for (PunishCatalog.Reason r : catalog().all()) {
            String dur;
            if (r.baseMillis() <= 0) dur = "Permanent";
            else if (r.stepMillis() > 0) dur = manager.formatDuration(r.baseMillis()) + " &8(+" + manager.formatDuration(r.stepMillis()) + " pro Wiederholung)";
            else dur = manager.formatDuration(r.baseMillis()) + " &8(x2 bis " + r.maxRepeats() + "x, dann perm.)";
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&e" + r.id() + " &8| " + (r.ban() ? "&cBan" : "&6Mute") + " &8| &f" + r.name() + " &8| &7" + dur));
        }
    }

    // ------------------------------------------------------------------ Chat-Ankündigungen (Ban/Mute/Unban)

    /** Kürzt "Griefing (§5.4.2)" auf "Griefing" für die öffentliche Meldung. */
    private static String cleanReason(String reason) {
        if (reason == null) return "Kein Grund angegeben";
        return reason.replaceAll("\\s*\\(§[^)]*\\)", "").trim();
    }

    private static String untilText(long ms) {
        long min = Math.max(1, (ms + 59_999L) / 60_000L);
        long weeks = min / (60 * 24 * 7);
        long days = min / (60 * 24);
        long hours = min / 60;
        if (weeks >= 1) return weeks + (weeks == 1 ? " Woche" : " Wochen");
        if (days >= 1) return days + (days == 1 ? " Tag" : " Tagen");
        if (hours >= 1) return hours + (hours == 1 ? " Stunde" : " Stunden");
        return min + (min == 1 ? " Minute" : " Minuten");
    }

    /** z.B. "[SpookyCraft] BAN » Spieler v. Staff: Griefing (bis in 2 Wochen)" an alle Spieler + Konsole. */
    private void announce(String label, String color, String target, String staff, String reason, boolean permanent, long durationMs) {
        if (!plugin.getConfig().getBoolean("punishment.broadcast.enabled", true)) return;
        String prefix = plugin.getConfig().getString("punishment.broadcast.prefix", "&8[&5SpookyCraft&8] ");
        StringBuilder sb = new StringBuilder(prefix).append(color).append("&l").append(label)
                .append(" &8» &f").append(target).append(" &7v. &f").append(staff);
        if (reason != null) {
            sb.append("&7: &f").append(cleanReason(reason));
            sb.append(" &7(").append(permanent ? "bis permanent" : "bis in " + untilText(durationMs)).append(")");
        }
        Bukkit.getServer().broadcast(plugin.getMessageUtil().styled(ChatColor.translateAlternateColorCodes('&', sb.toString())));
    }

    // ------------------------------------------------------------------ /cbclear: alle Commandblöcke entfernen
    private final java.util.Map<String, Long> cbPending = new java.util.HashMap<>();

    private java.util.List<org.bukkit.block.Block> findCommandBlocks() {
        java.util.List<org.bukkit.block.Block> out = new java.util.ArrayList<>();
        for (org.bukkit.World w : Bukkit.getWorlds()) {
            for (org.bukkit.Chunk ch : w.getLoadedChunks()) {
                for (org.bukkit.block.BlockState st : ch.getTileEntities()) {
                    if (st instanceof org.bukkit.block.CommandBlock) out.add(st.getBlock());
                }
            }
        }
        return out;
    }

    private java.util.List<org.bukkit.entity.Entity> findCommandMinecarts() {
        java.util.List<org.bukkit.entity.Entity> out = new java.util.ArrayList<>();
        for (org.bukkit.World w : Bukkit.getWorlds()) {
            out.addAll(w.getEntitiesByClass(org.bukkit.entity.minecart.CommandMinecart.class));
        }
        return out;
    }

    private boolean handleCbClear(CommandSender sender, String[] args) {
        String key = sender.getName();
        java.util.List<org.bukkit.block.Block> blocks = findCommandBlocks();
        java.util.List<org.bukkit.entity.Entity> carts = findCommandMinecarts();
        boolean confirm = args.length > 0 && args[0].equalsIgnoreCase("confirm");
        Long asked = cbPending.get(key);
        if (!confirm || asked == null || System.currentTimeMillis() - asked > 60_000L) {
            cbPending.put(key, System.currentTimeMillis());
            plugin.getMessageUtil().send(sender, "&eGefunden (nur geladene Chunks): &f" + blocks.size()
                    + " &eCommandblöcke und &f" + carts.size() + " &eCommand-Minecarts.");
            plugin.getMessageUtil().send(sender, "&cZum Löschen innerhalb von 60 Sekunden: &f/cbclear confirm");
            return true;
        }
        cbPending.remove(key);
        for (org.bukkit.block.Block b : blocks) b.setType(org.bukkit.Material.AIR, false);
        for (org.bukkit.entity.Entity e : carts) e.remove();
        plugin.getLogger().warning("[cbclear] " + sender.getName() + " hat " + blocks.size() + " Commandblöcke und " + carts.size() + " Command-Minecarts entfernt.");
        plugin.getMessageUtil().send(sender, "&a" + blocks.size() + " Commandblöcke und " + carts.size() + " Command-Minecarts wurden entfernt.");
        return true;
    }

    private boolean handlePunish(CommandSender sender, String[] args) {
        PunishCatalog catalog = catalog();
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /punish <spieler> <grund> [notiz]  |  /punish list");
            sendCatalog(sender);
            return true;
        }
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /punish <spieler> <grund> [notiz]  |  /punish list");
            return true;
        }
        PunishCatalog.Reason reason = catalog.get(args[1]);
        if (reason == null) {
            plugin.getMessageUtil().send(sender, "&cUnbekannter Grund: &7" + args[1] + " &c- siehe /punish list");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.isOnline() && !target.hasPlayedBefore()) {
            plugin.getMessageUtil().send(sender, "&cSpieler &7" + args[0] + " &cwar noch nie auf dem Server.");
            return true;
        }

        // Steigerung je Wiederholung desselben Grundes (linear "+14d" oder Verdopplung, siehe config.yml)
        int prior = manager.countReasonHistory(target.getUniqueId(), reason.name(), reason.ban());
        boolean permanent = reason.isPermanent(prior);
        long duration = permanent ? 0 : reason.durationFor(prior);
        long expiresAt = permanent ? 0 : System.currentTimeMillis() + duration;

        String note = args.length > 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "";
        String storedReason = note.isEmpty() ? reason.name() : reason.name() + " - " + note;
        String type = reason.ban() ? (permanent ? "BAN" : "TEMPBAN") : "MUTE";
        manager.addPunishment(target.getUniqueId(), type, storedReason, sender.getName(), expiresAt);

        String durationText = permanent ? "Permanent" : manager.formatDuration(duration);
        if (reason.ban()) {
            if (target.isOnline() && target.getPlayer() != null) {
                PunishManager.BanRecord ban = manager.getActiveBan(target.getUniqueId());
                target.getPlayer().kickPlayer(ban != null ? manager.buildBanScreen(ban)
                        : ChatColor.translateAlternateColorCodes('&', "&cDu wurdest gebannt: &7" + storedReason));
            }
        } else if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(),
                    "&cDu wurdest stummgeschaltet: &7" + reason.name() + " &8(Dauer: " + durationText + ")");
        }
        announce(reason.ban() ? "BAN" : "MUTE", reason.ban() ? "&c" : "&6", (target.getName() != null ? target.getName() : args[0]), sender.getName(), reason.name(), permanent, duration);
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde " + (reason.ban() ? "gebannt" : "gemutet")
                + ": &7" + reason.name() + " &8| &f" + durationText + " &8| &7" + (prior + 1) + ". Verstoß mit diesem Grund");
        return true;
    }

    private boolean handleBan(CommandSender sender, String[] args, boolean temp) {
        int minArgs = temp ? 2 : 1;
        if (args.length < minArgs) {
            plugin.getMessageUtil().send(sender, temp ? "&cNutzung: /tempban <spieler> <dauer z.B. 1d> [grund]" : "&cNutzung: /ban <spieler> [grund]");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        long expiresAt = 0;
        int reasonStart = 1;
        if (temp) {
            expiresAt = System.currentTimeMillis() + parseDuration(args[1]);
            reasonStart = 2;
        }
        String reason = args.length > reasonStart ? String.join(" ", java.util.Arrays.copyOfRange(args, reasonStart, args.length)) : "Kein Grund angegeben";
        manager.addPunishment(target.getUniqueId(), temp ? "TEMPBAN" : "BAN", reason, sender.getName(), expiresAt);
        if (target.isOnline() && target.getPlayer() != null) {
            PunishManager.BanRecord ban = manager.getActiveBan(target.getUniqueId());
            String screen = ban != null ? manager.buildBanScreen(ban)
                    : ChatColor.translateAlternateColorCodes('&', "&cDu wurdest gebannt: &7" + reason);
            target.getPlayer().kickPlayer(screen);
        }
        announce("BAN", "&c", (target.getName() != null ? target.getName() : args[0]), sender.getName(), reason, !temp, temp ? expiresAt - System.currentTimeMillis() : 0);
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde gebannt: &7" + reason);
        return true;
    }

    private boolean handleUnban(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /unban <spieler>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        manager.clearBans(target.getUniqueId(), sender.getName());
        announce("UNBAN", "&a", (target.getName() != null ? target.getName() : args[0]), sender.getName(), null, false, 0);
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde entbannt.");
        return true;
    }

    private boolean handleWarn(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /warn <spieler> [grund]");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Kein Grund angegeben";
        manager.addPunishment(target.getUniqueId(), "WARN", reason, sender.getName(), 0);
        if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(), "&eDu wurdest verwarnt: &7" + reason);
        }
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde verwarnt.");
        return true;
    }

    private boolean handleKick(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /kick <spieler> [grund]");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.getMessageUtil().send(sender, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
            return true;
        }
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Kein Grund angegeben";
        target.kickPlayer(ChatColor.translateAlternateColorCodes('&', "&cDu wurdest gekickt: &7" + reason));
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde gekickt.");
        return true;
    }

    private boolean handleMute(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /mute <spieler> [dauer z.B. 1h] [grund]");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        long expiresAt = 0;
        int reasonStart = 1;
        if (args.length > 1 && isDuration(args[1])) {
            expiresAt = System.currentTimeMillis() + parseDuration(args[1]);
            reasonStart = 2;
        }
        String reason = args.length > reasonStart ? String.join(" ", java.util.Arrays.copyOfRange(args, reasonStart, args.length)) : "Kein Grund angegeben";
        manager.addPunishment(target.getUniqueId(), "MUTE", reason, sender.getName(), expiresAt);
        if (target.isOnline() && target.getPlayer() != null) {
            plugin.getMessageUtil().send(target.getPlayer(), "&cDu wurdest stummgeschaltet: &7" + reason);
        }
        announce("MUTE", "&6", (target.getName() != null ? target.getName() : args[0]), sender.getName(), reason, expiresAt == 0, expiresAt == 0 ? 0 : expiresAt - System.currentTimeMillis());
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde stummgeschaltet: &7" + reason);
        return true;
    }

    private boolean handleUnmute(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /unmute <spieler>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        manager.clearMutes(target.getUniqueId(), sender.getName());
        announce("UNMUTE", "&a", (target.getName() != null ? target.getName() : args[0]), sender.getName(), null, false, 0);
        plugin.getMessageUtil().send(sender, "&a" + target.getName() + " wurde entmutet.");
        return true;
    }

    private boolean handleHistory(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /history <spieler>");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        List<PunishManager.PunishmentRecord> history = manager.getHistory(target.getUniqueId(), 10);
        if (history.isEmpty()) {
            plugin.getMessageUtil().send(sender, "&7" + target.getName() + " hat keine Einträge.");
            return true;
        }
        plugin.getMessageUtil().send(sender, "&7--- Strafhistorie von &b" + target.getName() + " &7---");
        java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
        for (PunishManager.PunishmentRecord r : history) {
            String status = r.active() ? "&aaktiv" : "&7erledigt";
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&8[" + fmt.format(new java.util.Date(r.createdAt())) + "] &e" + r.type()
                            + " &7von &b" + r.staff() + " &7(" + status + "&7): &f" + r.reason()));
        }
        return true;
    }

    /** Erkennt Kurzformen wie 10m, 1h, 7d - alles andere zählt als Freitext-Grund. */
    private boolean isDuration(String input) {
        return input.matches("\\d+[smhd]");
    }

    /** Parses simple durations like 1d, 12h, 30m, 45s. */
    private long parseDuration(String input) {
        try {
            char unit = input.charAt(input.length() - 1);
            long value = Long.parseLong(input.substring(0, input.length() - 1));
            return switch (unit) {
                case 's' -> value * 1000L;
                case 'm' -> value * 60_000L;
                case 'h' -> value * 3_600_000L;
                case 'd' -> value * 86_400_000L;
                default -> value * 60_000L;
            };
        } catch (Exception e) {
            return 60_000L * 10; // default 10 minutes if unparseable
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("punish")) {
            if (args.length == 1) {
                List<String> result = TabCompleteUtil.onlinePlayers(args[0]);
                result.addAll(TabCompleteUtil.filter(args[0], "list"));
                return result;
            }
            if (args.length == 2) return TabCompleteUtil.filter(args[1], catalog().ids());
            return Collections.emptyList();
        }
        if (args.length == 1) {
            switch (label.toLowerCase()) {
                case "ban", "warn", "unban", "mute", "unmute", "history": return TabCompleteUtil.onlinePlayers(args[0]);
                case "tempban", "kick", "ipban": return TabCompleteUtil.onlinePlayers(args[0]);
            }
        }
        if (args.length == 2 && label.equalsIgnoreCase("tempban")) {
            return TabCompleteUtil.filter(args[1], "10m", "30m", "1h", "12h", "1d", "7d", "30d");
        }
        if (args.length == 2 && label.equalsIgnoreCase("mute")) {
            return TabCompleteUtil.filter(args[1], "10m", "30m", "1h", "12h", "1d", "7d", "30d");
        }
        return Collections.emptyList();
    }

    private boolean handleIpBan(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /ipban <Spieler|IP> [Grund]");
            return true;
        }
        String ip = args[0];
        org.bukkit.entity.Player target = org.bukkit.Bukkit.getPlayerExact(args[0]);
        if (target != null) {
            if (target.getAddress() == null || target.getAddress().getAddress() == null) {
                plugin.getMessageUtil().send(sender, "&cIP von " + target.getName() + " unbekannt.");
                return true;
            }
            ip = target.getAddress().getAddress().getHostAddress();
        } else if (!ip.matches("[0-9a-fA-F:.]+")) {
            plugin.getMessageUtil().send(sender, "&cSpieler nicht online. Gib stattdessen die IP an.");
            return true;
        }
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "IP-Bann";
        org.bukkit.Bukkit.dispatchCommand(org.bukkit.Bukkit.getConsoleSender(), "ban-ip " + ip + " " + reason);
        plugin.getMessageUtil().send(sender, "&aIP &f" + ip + " &awurde aus der Geisterwelt verbannt.");
        return true;
    }

    private boolean handleUnIpBan(CommandSender sender, String[] args) {
        if (args.length < 1) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /unipban <IP>");
            return true;
        }

        // Bei IPv4-Eingaben wie 91.50.199.88:51117 den Client-Port entfernen.
        String ip = args[0].trim();
        if (ip.matches("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}:[0-9]{1,5}")) {
            String[] parts = ip.split(":", 2);
            int port;
            try {
                port = Integer.parseInt(parts[1]);
            } catch (NumberFormatException ex) {
                plugin.getMessageUtil().send(sender, "&cUngültiger Port.");
                return true;
            }
            if (port < 1 || port > 65535) {
                plugin.getMessageUtil().send(sender, "&cUngültiger Port.");
                return true;
            }
            ip = parts[0];
        }

        // Nur IP-Zeichen zulassen, damit keine zusätzlichen Command-Argumente eingeschleust werden.
        if (!ip.matches("[0-9a-fA-F:.]+") || (!ip.contains(".") && !ip.contains(":"))) {
            plugin.getMessageUtil().send(sender, "&cUngültige IP-Adresse.");
            return true;
        }

        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pardon-ip " + ip);
        plugin.getMessageUtil().send(sender, "&aIP &f" + ip + " &awurde begnadigt.");
        return true;
    }
}
