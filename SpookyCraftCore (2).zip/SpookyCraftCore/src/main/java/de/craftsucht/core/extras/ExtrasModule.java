package de.craftsucht.core.extras;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Ersatz für die früheren Skripte: /dailyreward, /regeln, /code, /codecreate, /freeze, /scale, /vd, /chatclear,
 * /antilag, /serversign, /fakejoin, /fakequit, /moneyitem, /end, /admin, /owner, Item-Befehle (/sign, /rename, /lore ...),
 * Admin-Panel (/adminpanel) und Plot-Bewertung (/rateplot, /clearplotrate).
 * Daten (Codes, Daily-Reward, eingefrorene Spieler) liegen in plugins/SpookyCraftCore/extras.yml.
 */
public class ExtrasModule implements Module, CommandExecutor, Listener {

    private static final String[] COMMANDS = {
            "dailyreward", "regeln", "code", "codecreate", "freeze", "scale", "vd", "chatclear", "antilag", "serversign",
            "fakejoin", "fakequit", "moneyitem", "end", "admin", "owner", "adminpanel", "rateplot", "clearplotrate",
            "sign", "signieren", "rename", "setname", "name", "itemname", "lore"};

    private final SpookyCraftCore plugin;
    private final NamespacedKey moneyKey;
    private File dataFile;
    private YamlConfiguration data;
    private final Set<UUID> frozen = new HashSet<>();
    private boolean chatMuted;
    private AdminPanel panel;

    public ExtrasModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.moneyKey = new NamespacedKey(plugin, "money_note");
    }

    @Override
    public String getId() {
        return "extras";
    }

    // ------------------------------------------------------------------ Start / Stop

    @Override
    public void enable() {
        dataFile = new File(plugin.getDataFolder(), "extras.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        frozen.clear();
        for (String id : data.getStringList("frozen")) {
            try {
                frozen.add(UUID.fromString(id));
            } catch (IllegalArgumentException ignored) {
            }
        }
        for (String name : COMMANDS) {
            if (plugin.getCommand(name) != null) plugin.getCommand(name).setExecutor(this);
        }
        panel = new AdminPanel(plugin, this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getPluginManager().registerEvents(panel, plugin);
        startMobCleaner();
    }

    private org.bukkit.scheduler.BukkitTask mobCleaner;

    /** Natürliches Spawnen in den Aufräum-Welten gleich verhindern (spart zusätzlich Arbeit). Plugin-/Spawn-Ei-Spawns bleiben erlaubt. */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.HIGH, ignoreCancelled = true)
    public void onNaturalSpawn(org.bukkit.event.entity.CreatureSpawnEvent event) {
        if (!plugin.getConfig().getBoolean("extras.mob-cleaner.enabled", true)) return;
        org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason r = event.getSpawnReason();
        if (r != org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.NATURAL
                && r != org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.CHUNK_GEN
                && r != org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.BREEDING) return;
        if (plugin.getConfig().getStringList("extras.mob-cleaner.worlds").contains(event.getLocation().getWorld().getName())) {
            event.setCancelled(true);
        }
    }

    /** Entfernt jede Sekunde alle Mobs in den Welten aus extras.mob-cleaner.worlds (Standard: Lobby). NPCs/Benannte/Unverwundbare bleiben. */
    private void startMobCleaner() {
        if (!plugin.getConfig().getBoolean("extras.mob-cleaner.enabled", true)) return;
        long interval = Math.max(1, plugin.getConfig().getInt("extras.mob-cleaner.interval-seconds", 1)) * 20L;
        mobCleaner = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (String name : plugin.getConfig().getStringList("extras.mob-cleaner.worlds")) {
                org.bukkit.World world = Bukkit.getWorld(name);
                if (world == null) continue;
                for (org.bukkit.entity.LivingEntity e : world.getLivingEntities()) {
                    if (e instanceof Player || e instanceof org.bukkit.entity.ArmorStand) continue;
                    if (e.isInvulnerable() || e.customName() != null || !e.hasAI()) continue; // Markt-NPC, Hologramme, benannte Tiere
                    e.remove();
                }
            }
        }, interval, interval);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (panel != null) HandlerList.unregisterAll(panel);
        if (mobCleaner != null) mobCleaner.cancel();
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("extras.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Hilfen

    boolean isChatMuted() {
        return chatMuted;
    }

    void setChatMuted(boolean muted) {
        this.chatMuted = muted;
    }

    /** OP, spookycraft.core.admin oder eines der genannten Rechte. */
    boolean has(CommandSender s, String... perms) {
        if (s.isOp() || s.hasPermission("spookycraft.core.admin")) return true;
        for (String perm : perms) if (s.hasPermission(perm)) return true;
        return false;
    }

    boolean isStaff(CommandSender s) {
        return has(s, "skript.adminpanel");
    }

    private String serverName() {
        return plugin.getConfig().getString("extras.server-name", "SpookyCraft");
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void deposit(Player p, double amount) {
        if (plugin.getModuleManager().get("economy") instanceof EconomyModule eco && eco.getManager() != null) {
            eco.getManager().deposit(p.getUniqueId(), amount);
        } else {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "eco give " + p.getName() + " " + (long) amount);
        }
    }

    private void giveOrDrop(Player p, ItemStack item) {
        for (ItemStack left : p.getInventory().addItem(item).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
    }

    private String fmt(double amount) {
        return String.format(Locale.GERMANY, "%,.0f", amount);
    }

    void broadcastClear(Player by) {
        for (int i = 0; i < 100; i++) Bukkit.broadcastMessage(" ");
        Bukkit.broadcastMessage(color("&c&lSystem &8| &7Der Chat wurde von &c" + by.getName() + " &7geleert!"));
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase();
        switch (cmd) {
            case "regeln" -> rules(sender);
            case "fakejoin", "fakequit" -> {
                if (!has(sender, "fake.use")) return noPerm(sender);
                String who = sender.getName();
                Bukkit.broadcastMessage("§e" + who + (cmd.equals("fakejoin") ? " hat das Spiel betreten!" : " hat das Spiel verlassen!"));
            }
            case "admin", "owner" -> setRank(sender, cmd, args);
            case "code" -> {
                if (sender instanceof Player p) redeemCode(p, args);
            }
            case "codecreate" -> createCode(sender, args);
            case "freeze" -> freeze(sender, args);
            case "scale" -> {
                if (sender instanceof Player p) scale(p, args);
            }
            case "vd" -> {
                if (sender instanceof Player p) viewDistance(p, args);
            }
            case "chatclear" -> {
                if (!has(sender, "chatclear.use")) return noPerm(sender);
                for (int i = 0; i < 100; i++) Bukkit.broadcastMessage(" ");
                Bukkit.broadcastMessage(color("&c&l" + serverName() + " &8» &a" + sender.getName() + " &fhat den Chat geleert!"));
            }
            default -> {
                if (!(sender instanceof Player p)) {
                    msg(sender, "&cDieser Zauber wirkt nur in der Geisterwelt (ingame).");
                    return true;
                }
                playerCommand(p, cmd, args);
            }
        }
        return true;
    }

    private boolean noPerm(CommandSender s) {
        msg(s, "&cDie Geister verwehren dir den Zutritt!");
        return true;
    }

    private void playerCommand(Player p, String cmd, String[] args) {
        switch (cmd) {
            case "dailyreward" -> dailyReward(p);
            case "antilag" -> antiLag(p);
            case "serversign" -> serverSign(p);
            case "moneyitem" -> moneyItem(p, args);
            case "end" -> {
                String target = plugin.getConfig().getString("extras.end-target", "end-1");
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mv tp " + p.getName() + " " + target);
                msg(p, "&aDu wurdest ins End teleportiert!");
            }
            case "adminpanel" -> {
                if (!isStaff(p)) {
                    plugin.getMessageUtil().send(p, "&c&lSystem &8| &cDie Geister verwehren dir den Zutritt!");
                    return;
                }
                panel.open(p);
            }
            case "rateplot" -> {
                if (!isStaff(p)) {
                    plugin.getMessageUtil().send(p, "&c&lSystem &8| &cDie Geister verwehren dir den Zutritt!");
                    return;
                }
                panel.openRating(p);
            }
            case "clearplotrate" -> {
                if (!isStaff(p)) {
                    plugin.getMessageUtil().send(p, "&c&lSystem &8| &cDie Geister verwehren dir den Zutritt!");
                    return;
                }
                panel.clearRatings(p);
            }
            case "sign", "signieren" -> signItem(p, args);
            case "rename", "setname", "name" -> renameItem(p, args);
            case "lore" -> loreItem(p, args);
            case "itemname" -> {
                String h = "&8&m---------&r &c&lSystem &8&m---------";
                p.sendMessage(color(h));
                p.sendMessage(color("&b/sign &8»&7 Signieren ohne Text"));
                p.sendMessage(color("&b/signieren &8»&7 Signieren ohne Text"));
                p.sendMessage(color("&b/sign <text> &8»&7 Signieren mit Text"));
                p.sendMessage(color("&b/signieren <text> &8»&7 Signieren mit Text"));
                p.sendMessage(color("&b/setname <name> &8»&7 Ändere den Item-Namen"));
                p.sendMessage(color("&b/rename <name> &8»&7 Ändere den Item-Namen"));
                p.sendMessage(color("&b/name <name> &8»&7 Ändere den Item-Namen"));
                p.sendMessage(color("&b/lore <set/remove> <nummer> <text> &8» &7Setze eine Lore"));
                p.sendMessage(color(h));
            }
            default -> { }
        }
    }

    private void rules(CommandSender s) {
        String line = "&6&l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";
        s.sendMessage(color(line));
        s.sendMessage(color("&e&l☠ DIE GESETZE DER GEISTERWELT ☠"));
        for (String rule : plugin.getConfig().getStringList("extras.rules")) s.sendMessage(color(rule));
        s.sendMessage(color(line));
    }

    private void dailyReward(Player p) {
        String today = LocalDate.now().toString();
        String path = "daily." + p.getUniqueId();
        if (today.equals(data.getString(path))) {
            msg(p, "&cDu hast deine tägliche Belohnung heute schon erhalten. Komm morgen wieder!");
            return;
        }
        giveOrDrop(p, new ItemStack(Material.DIAMOND));
        p.giveExp(100);
        data.set(path, today);
        save();
        msg(p, "&aDu hast deine tägliche Die Geister schenken dir: 1 Diamant und 100 Erfahrungspunkte!");
    }

    private void redeemCode(Player p, String[] args) {
        if (args.length < 1) {
            msg(p, "&e/code <name>");
            return;
        }
        String code = args[0].toLowerCase();
        String amountPath = "codes." + code;
        if (!data.contains(amountPath)) {
            msg(p, "&cDiesen Code gibt es nicht.");
            return;
        }
        List<String> used = data.getStringList("used." + p.getUniqueId());
        if (used.contains(code)) {
            msg(p, "&cDu hast diesen Code bereits eingelöst.");
            return;
        }
        if (code.equals("spooky") && !data.getStringList("newplayers").contains(p.getUniqueId().toString())) {
            msg(p, "&cNur neue Spieler können diesen Code einlösen.");
            return;
        }
        double amount = data.getDouble(amountPath);
        deposit(p, amount);
        used.add(code);
        data.set("used." + p.getUniqueId(), used);
        save();
        msg(p, "&aCode erfolgreich eingelöst! +" + fmt(amount) + "$");
    }

    private void createCode(CommandSender s, String[] args) {
        if (!has(s, "code.create")) {
            noPerm(s);
            return;
        }
        if (args.length < 2) {
            msg(s, "&e/codecreate <name> <amount>");
            return;
        }
        double amount;
        try {
            amount = Double.parseDouble(args[1].replace(',', '.'));
        } catch (NumberFormatException e) {
            msg(s, "&cBitte gib eine gültige Zahl an.");
            return;
        }
        data.set("codes." + args[0].toLowerCase(), amount);
        save();
        msg(s, "&aNeuer Code erstellt: " + args[0] + " (" + fmt(amount) + "$)");
    }

    private void freeze(CommandSender s, String[] args) {
        if (!has(s, "freeze.use")) {
            noPerm(s);
            return;
        }
        if (args.length < 1) {
            msg(s, "&cNutzung: /freeze <spieler>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            msg(s, "&cSpieler '" + args[0] + "' wandelt nicht in der Geisterwelt.");
            return;
        }
        if (frozen.remove(target.getUniqueId())) {
            msg(s, "&aDu hast &e" + target.getName() + " &aaufgetaut.");
            msg(target, "&aDu wurdest aufgetaut.");
        } else {
            frozen.add(target.getUniqueId());
            msg(s, "&aDu hast &e" + target.getName() + " &aeingefroren.");
            msg(target, "&cDu wurdest eingefroren.");
        }
        List<String> ids = new ArrayList<>();
        for (UUID id : frozen) ids.add(id.toString());
        data.set("frozen", ids);
        save();
    }

    private void scale(Player p, String[] args) {
        if (!has(p, "playersize.use")) {
            noPerm(p);
            return;
        }
        if (args.length < 1) {
            msg(p, "&cNutzung: /scale <0.0625-16>");
            return;
        }
        double value;
        try {
            value = Double.parseDouble(args[0].replace(',', '.'));
        } catch (NumberFormatException e) {
            msg(p, "&cBitte gib eine Zahl an (z.B. 0.5 oder 2).");
            return;
        }
        if (value < 0.0625 || value > 16) {
            msg(p, "&cDie Größe muss zwischen 0.0625 und 16 liegen.");
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "attribute " + p.getName() + " minecraft:scale base set " + value);
        msg(p, "&aDeine Größe wurde auf " + value + " gesetzt.");
    }

    private void viewDistance(Player p, String[] args) {
        if (!has(p, "vd.use")) {
            noPerm(p);
            return;
        }
        if (args.length < 1) {
            msg(p, "&eBenutzung: /vd <CHUNKS>");
            return;
        }
        int value;
        try {
            value = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            msg(p, "&cBitte gib eine gültige Zahl ein!");
            return;
        }
        if (value < 2 || value > 32) {
            msg(p, "&cDie Sichtweite muss zwischen 2 und 32 Chunks liegen!");
            return;
        }
        p.setViewDistance(value);
        msg(p, "&aDeine &cSichtweite &awurde auf &c" + value + " Chunks &cgesetzt!");
    }

    private void antiLag(Player p) {
        if (!has(p)) {
            noPerm(p);
            return;
        }
        int removed = 0;
        for (Entity e : new ArrayList<>(p.getWorld().getEntities())) {
            if (e instanceof Player || e instanceof Villager || e instanceof WanderingTrader || e instanceof ArmorStand) continue;
            boolean remove = false;
            if (e instanceof Item) {
                remove = true;
            } else if (e instanceof LivingEntity le) {
                boolean tamed = le instanceof Tameable t && t.isTamed();
                boolean leashed = le instanceof Mob m && m.isLeashed();
                remove = !tamed && !leashed && le.getCustomName() == null;
            }
            if (remove) {
                e.remove();
                removed++;
            }
        }
        plugin.getMessageUtil().send(p, "&a[AntiLag] &e" + removed + " &aEntities entfernt.");
    }

    private void serverSign(Player p) {
        if (!has(p)) {
            noPerm(p);
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            msg(p, "&cHalte einen Gegenstand in deiner Hand!");
            return;
        }
        ItemMeta meta = hand.getItemMeta();
        List<String> lore = new ArrayList<>();
        lore.add(color("&7Signiert von &c&l" + serverName().toUpperCase()));
        lore.add(color("&7Signiert am &c&l" + LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))));
        meta.setLore(lore);
        hand.setItemMeta(meta);
        msg(p, "&aItem erfolgreich signiert.");
    }

    private void moneyItem(Player p, String[] args) {
        if (!has(p)) {
            noPerm(p);
            return;
        }
        double amount = 10000;
        if (args.length > 0) {
            try {
                amount = Double.parseDouble(args[0].replace(',', '.'));
            } catch (NumberFormatException e) {
                msg(p, "&cNutzung: /moneyitem [betrag]");
                return;
            }
        }
        if (amount <= 0) {
            msg(p, "&cDer Betrag muss größer als 0 sein.");
            return;
        }
        ItemStack paper = new ItemStack(Material.PAPER);
        ItemMeta meta = paper.getItemMeta();
        meta.setDisplayName(color("&a$" + fmt(amount) + " Schein"));
        meta.setLore(List.of(color("&7Rechtsklick zum Einlösen!")));
        meta.getPersistentDataContainer().set(moneyKey, PersistentDataType.DOUBLE, amount);
        paper.setItemMeta(meta);
        giveOrDrop(p, paper);
        msg(p, "&aDu hast einen &e$" + fmt(amount) + " Schein &aerhalten.");
    }

    private void setRank(CommandSender s, String rank, String[] args) {
        if (!has(s, "rang.set")) {
            noPerm(s);
            return;
        }
        if (args.length < 1) {
            msg(s, "&cNutzung: /" + rank + " <spieler>");
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "rank user " + args[0] + " set " + rank);
        msg(s, "&aRang &c" + rank + " &awurde an &e" + args[0] + " &agesetzt.");
    }

    // ------------------------------------------------------------------ Item-Befehle

    private ItemStack hand(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            msg(p, "&cHalte einen Gegenstand in deiner Hand!");
            return null;
        }
        return hand;
    }

    private void signItem(Player p, String[] args) {
        if (!has(p, "item.sign")) {
            msg(p, "&7Keine Rechte!");
            return;
        }
        ItemStack hand = hand(p);
        if (hand == null) return;
        ItemMeta meta = hand.getItemMeta();
        List<String> lore = new ArrayList<>();
        if (args.length == 0) {
            lore.add(color("&7Signiert von &c" + p.getName() + "&7."));
        } else {
            lore.add(color("&7" + String.join(" ", args)));
            lore.add(color("&8&l&m----------------------"));
            lore.add(color("&7Signiert von &c" + p.getName() + "&7"));
        }
        meta.setLore(lore);
        hand.setItemMeta(meta);
        msg(p, "&7Item erfolgreich signiert.");
    }

    private void renameItem(Player p, String[] args) {
        if (!has(p, "item.changename")) {
            msg(p, "&7Keine Rechte!");
            return;
        }
        if (args.length == 0) {
            msg(p, "&7Benutze: &b/rename <name>");
            return;
        }
        ItemStack hand = hand(p);
        if (hand == null) return;
        String name = color(String.join(" ", args));
        ItemMeta meta = hand.getItemMeta();
        meta.setDisplayName(name);
        hand.setItemMeta(meta);
        msg(p, "&7Name geändert zu: &b" + name);
    }

    private void loreItem(Player p, String[] args) {
        if (!has(p, "item.lore")) {
            msg(p, "&7Keine Rechte!");
            return;
        }
        if (args.length < 2) {
            msg(p, "&7Benutze: &b/lore <set/remove> <nummer> <text>");
            return;
        }
        int line;
        try {
            line = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            msg(p, "&cDie Zeilennummer muss eine Zahl sein.");
            return;
        }
        if (line < 1 || line > 30) {
            msg(p, "&cDie Zeilennummer muss zwischen 1 und 30 liegen.");
            return;
        }
        boolean set = args[0].equalsIgnoreCase("set");
        boolean remove = args[0].equalsIgnoreCase("remove");
        if (!set && !remove) {
            msg(p, "&7Benutze: &b/lore <set/remove> <nummer> <text>");
            return;
        }
        if (set && args.length < 3) {
            msg(p, "&7Benutze: &b/lore set <nummer> <text>");
            return;
        }
        ItemStack hand = hand(p);
        if (hand == null) return;
        ItemMeta meta = hand.getItemMeta();
        List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        while (lore.size() < line) lore.add(" ");
        String text = set ? color(String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length))) : " ";
        lore.set(line - 1, text);
        meta.setLore(lore);
        hand.setItemMeta(meta);
        msg(p, set ? "&7Lore erfolgreich gesetzt zu: &b" + text : "&7Lore erfolgreich gelöscht.");
    }

    // ------------------------------------------------------------------ Events

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        if (!p.hasPlayedBefore()) {
            List<String> list = data.getStringList("newplayers");
            list.add(p.getUniqueId().toString());
            data.set("newplayers", list);
            save();
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (frozen.isEmpty() || !frozen.contains(event.getPlayer().getUniqueId())) return;
        if (event.getTo() == null) return;
        if (event.getFrom().getX() != event.getTo().getX() || event.getFrom().getY() != event.getTo().getY()
                || event.getFrom().getZ() != event.getTo().getZ()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!chatMuted || isStaff(event.getPlayer())) return;
        event.setCancelled(true);
        plugin.getMessageUtil().send(event.getPlayer(), "&c&lSystem &8| &7Der globale Chat ist aktuell &4stummgeschaltet&7!");
    }

    @EventHandler
    public void onMoneyNote(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;
        Double amount = item.getItemMeta().getPersistentDataContainer().get(moneyKey, PersistentDataType.DOUBLE);
        if (amount == null) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        item.setAmount(item.getAmount() - 1);
        deposit(p, amount);
        p.playSound(p.getLocation(), "entity.lightning_bolt.thunder", 1.0f, 1.0f);
        msg(p, "&aDu hast " + fmt(amount) + "$ eingelöst!");
    }
}
