package de.craftsucht.core.afk;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * AFK-Raum: /setafkroom [radius] setzt den Raum. Wer drin ist, bekommt jede Sekunde 1 AFK-Punkt
 * (afk.points-per-second). Im /afkshop tauscht man Punkte gegen Kristalle, Geld, Kisten usw.
 * Punkte liegen in plugins/SpookyCraftCore/afk.yml.
 */
public class AfkModule implements Module, CommandExecutor, TabCompleter, Listener {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private final Map<UUID, Double> points = new HashMap<>();
    private BukkitTask task;
    private int saveTicker;

    public AfkModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "afk";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "afk.yml");
        data = YamlConfiguration.loadConfiguration(file);
        if (data.getConfigurationSection("points") != null) {
            for (String k : data.getConfigurationSection("points").getKeys(false)) {
                try {
                    points.put(UUID.fromString(k), data.getDouble("points." + k));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        plugin.getCommand("setafkroom").setExecutor(this);
        plugin.getCommand("afkshop").setExecutor(this);
        plugin.getCommand("afkshop").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        org.bukkit.event.HandlerList.unregisterAll(this);
        save();
    }

    private void save() {
        for (Map.Entry<UUID, Double> e : points.entrySet()) data.set("points." + e.getKey(), e.getValue());
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("afk.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private double get(UUID id) {
        return points.getOrDefault(id, 0.0);
    }

    // ------------------------------------------------------------------ Raum

    private boolean inRoom(Player p) {
        if (!data.contains("room.world")) return false;
        Location l = p.getLocation();
        if (!l.getWorld().getName().equals(data.getString("room.world"))) return false;
        double r = data.getDouble("room.radius", 8);
        double dx = Math.abs(l.getX() - data.getDouble("room.x"));
        double dy = Math.abs(l.getY() - data.getDouble("room.y"));
        double dz = Math.abs(l.getZ() - data.getDouble("room.z"));
        return dx <= r && dz <= r && dy <= r;
    }

    private void tick() {
        double perSec = plugin.getConfig().getDouble("afk.points-per-second", 1.0);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!inRoom(p)) continue;
            double now = get(p.getUniqueId()) + perSec;
            points.put(p.getUniqueId(), now);
            if (de.craftsucht.core.video.VideoModule.isActive(p)) continue;
            p.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&5☠ &dAFK-Punkte: &f" + String.format(Locale.ROOT, "%.1f", now) + " &8(+" + perSec + "/s)"));
        }
        if (++saveTicker >= 60) {
            saveTicker = 0;
            save();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        save();
    }

    // ------------------------------------------------------------------ Shop

    private static class ShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private List<Map<?, ?>> items() {
        return plugin.getConfig().getMapList("afk.shop");
    }

    private void openShop(Player p) {
        Inventory inv = Bukkit.createInventory(new ShopHolder(), 27, c("&5☠ &dAFK-Shop"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        List<Map<?, ?>> list = items();
        for (int i = 0; i < Math.min(list.size(), 18); i++) {
            Map<?, ?> m = list.get(i);
            Material mat = Material.matchMaterial(String.valueOf(m.get("icon")));
            if (mat == null) mat = Material.PAPER;
            ItemStack it = new ItemStack(mat);
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(c(String.valueOf(m.get("name"))));
            double cost = Double.parseDouble(String.valueOf(m.get("cost")));
            List<String> lore = new ArrayList<>();
            lore.add(c("&7Preis: &d" + fmtCost(cost) + " AFK-Punkte"));
            lore.add(c(get(p.getUniqueId()) >= cost ? "&aKlicken zum Kaufen" : "&cZu wenig Punkte"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }
        ItemStack info = new ItemStack(Material.CLOCK);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&dDeine AFK-Punkte: &f" + String.format(Locale.ROOT, "%.1f", get(p.getUniqueId()))));
        im.setLore(List.of(c("&7Im AFK-Raum: &d" + plugin.getConfig().getDouble("afk.points-per-second", 1.0) + " Punkte pro Sekunde")));
        info.setItemMeta(im);
        inv.setItem(22, info);
        p.openInventory(inv);
    }

    private static String fmtCost(double d) {
        return d == Math.floor(d) ? String.valueOf((long) d) : String.format(Locale.ROOT, "%.1f", d);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ShopHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        List<Map<?, ?>> list = items();
        if (slot < 0 || slot >= list.size() || slot >= 18) return;
        Map<?, ?> m = list.get(slot);
        double cost = Double.parseDouble(String.valueOf(m.get("cost")));
        if (get(p.getUniqueId()) + 1e-9 < cost) {
            plugin.getMessageUtil().send(p, "&cDu hast zu wenig AFK-Punkte.");
            return;
        }
        String type = String.valueOf(m.get("type")).toLowerCase(Locale.ROOT);
        String value = String.valueOf(m.get("value"));
        boolean ok = false;
        try {
            switch (type) {
                case "crystals" -> {
                    if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
                        cm.getCrystals().add(p.getUniqueId(), Long.parseLong(value));
                        ok = true;
                    }
                }
                case "money" -> {
                    if (plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
                        em.getManager().deposit(p.getUniqueId(), Double.parseDouble(value));
                        ok = true;
                    }
                }
                case "key" -> {
                    // value = "kistenid:anzahl"
                    String[] v = value.split(":");
                    int amount = v.length > 1 ? Integer.parseInt(v[1]) : 1;
                    if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCratePrice(v[0]) >= 0) {
                        cm.addKeys(p.getUniqueId(), v[0], amount);
                        ok = true;
                    }
                }
                case "command" -> {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), value.replace("%player%", p.getName()));
                    ok = true;
                }
                default -> {
                }
            }
        } catch (NumberFormatException ex) {
            ok = false;
        }
        if (!ok) {
            plugin.getMessageUtil().send(p, "&cDieses Angebot ist gerade nicht verfügbar.");
            return;
        }
        points.put(p.getUniqueId(), get(p.getUniqueId()) - cost);
        save();
        p.playSound(p.getLocation(), "entity.experience_orb.pickup", 1f, 1.2f);
        plugin.getMessageUtil().send(p, "&5☠ &dGekauft: &f" + ChatColor.stripColor(c(String.valueOf(m.get("name")))));
        openShop(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (command.getName().equalsIgnoreCase("setafkroom")) {
            if (!(p.isOp() || p.hasPermission("spookycraft.core.admin"))) {
                plugin.getMessageUtil().send(p, "&cKeine Berechtigung.");
                return true;
            }
            double r = 8;
            if (args.length > 0) {
                try {
                    r = Math.max(2, Math.min(100, Double.parseDouble(args[0])));
                } catch (NumberFormatException e) {
                    plugin.getMessageUtil().send(p, "&cUngültige Zahl.");
                    return true;
                }
            }
            Location l = p.getLocation();
            data.set("room.world", l.getWorld().getName());
            data.set("room.x", l.getX());
            data.set("room.y", l.getY());
            data.set("room.z", l.getZ());
            data.set("room.radius", r);
            save();
            plugin.getMessageUtil().send(p, "&aAFK-Raum gesetzt (Radius " + r + " Blöcke um dich).");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("punkte")) {
            plugin.getMessageUtil().send(p, "&7Deine AFK-Punkte: &d" + String.format(Locale.ROOT, "%.1f", get(p.getUniqueId())));
            return true;
        }
        openShop(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "punkte");
        return List.of();
    }
}
