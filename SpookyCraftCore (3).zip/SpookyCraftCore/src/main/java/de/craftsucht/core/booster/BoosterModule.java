package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

/**
 * /citem - Custom-Booster-Items (z.B. Minerpicke mit Job-Geld/XP-Boost).
 * Vorher ein eigenständiges Plugin (BoosterItemsPlugin), jetzt Modul hier -
 * das jobs-Modul liest den Boost jetzt direkt über BoosterAPI statt per
 * Reflection über ein fremdes Plugin.
 */
public class BoosterModule implements Module {

    private final SpookyCraftCore plugin;
    private ItemRegistry itemRegistry;
    private AreaMiningListener areaListener;
    private SpecialItemsListener specialListener;
    private TreeFellerListener treeListener;
    private SwordEffectsListener swordListener;

    public BoosterModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "booster";
    }

    @Override
    public void enable() {
        this.itemRegistry = new ItemRegistry(plugin);
        itemRegistry.load();
        CItemCommand command = new CItemCommand(plugin, this);
        plugin.getCommand("citem").setExecutor(command);
        plugin.getCommand("citem").setTabCompleter(command);
        this.areaListener = new AreaMiningListener(plugin);
        Bukkit.getPluginManager().registerEvents(areaListener, plugin);
        this.specialListener = new SpecialItemsListener(plugin, itemRegistry);
        Bukkit.getPluginManager().registerEvents(specialListener, plugin);
        specialListener.start();
        this.treeListener = new TreeFellerListener(plugin);
        Bukkit.getPluginManager().registerEvents(treeListener, plugin);
        this.swordListener = new SwordEffectsListener(plugin);
        Bukkit.getPluginManager().registerEvents(swordListener, plugin);
    }

    @Override
    public void disable() {
        if (areaListener != null) HandlerList.unregisterAll(areaListener);
        if (treeListener != null) HandlerList.unregisterAll(treeListener);
        if (swordListener != null) HandlerList.unregisterAll(swordListener);
        if (specialListener != null) {
            specialListener.stop();
            HandlerList.unregisterAll(specialListener);
        }
    }

    public ItemRegistry getItemRegistry() {
        return itemRegistry;
    }
}
