package de.craftsucht.core.monitor;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.lang.management.ManagementFactory;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** /monitor - schaltet eine ActionBar mit CPU, RAM und TPS des Servers an/aus (pro Spieler). */
public class MonitorModule implements Module, CommandExecutor, Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    private final SpookyCraftCore plugin;
    private final Set<UUID> viewers = new HashSet<>();
    private BukkitTask task;

    public MonitorModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "monitor";
    }

    @Override
    public void enable() {
        var cmd = plugin.getCommand("monitor");
        if (cmd != null) cmd.setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        stopTask();
        for (UUID id : viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendActionBar(Component.empty());
        }
        viewers.clear();
        HandlerList.unregisterAll(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("§cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (!p.isOp() && !p.hasPermission("spookycraft.monitor.use") && !p.hasPermission("monitor.use")) {
            p.sendMessage("§cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (viewers.remove(p.getUniqueId())) {
            p.sendActionBar(Component.empty());
            p.sendMessage("§c✗ Monitor deaktiviert");
            if (viewers.isEmpty()) stopTask();
        } else {
            viewers.add(p.getUniqueId());
            p.sendMessage("§a✓ Monitor aktiviert (ActionBar)");
            startTask();
        }
        return true;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        viewers.remove(event.getPlayer().getUniqueId());
        if (viewers.isEmpty()) stopTask();
    }

    private void startTask() {
        if (task != null) return;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void stopTask() {
        if (task != null) task.cancel();
        task = null;
    }

    private void tick() {
        if (viewers.isEmpty()) {
            stopTask();
            return;
        }
        String text = build();
        Component bar = LEGACY.deserialize(text);
        for (UUID id : new HashSet<>(viewers)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) viewers.remove(id);
            else p.sendActionBar(bar);
        }
    }

    private String build() {
        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        double cpu = 0;
        if (ManagementFactory.getOperatingSystemMXBean() instanceof com.sun.management.OperatingSystemMXBean os) {
            double load = os.getProcessCpuLoad();
            if (load >= 0) cpu = load * cores * 100.0;
        }
        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long max = rt.maxMemory() / (1024 * 1024);
        double tps = Math.min(20.0, Bukkit.getTPS()[0]);

        String cpuColor = cpu < cores * 60 ? "§a" : cpu < cores * 85 ? "§e" : "§c";
        double ramFrac = (double) used / Math.max(1, max);
        String ramColor = ramFrac < 0.7 ? "§a" : ramFrac < 0.9 ? "§e" : "§c";
        String tpsColor = tps >= 19.0 ? "§a" : tps >= 15.0 ? "§e" : "§c";
        return "§7CPU: " + cpuColor + String.format(Locale.US, "%.0f%%", cpu) + "§7/§f" + (cores * 100) + "%"
                + " §8| §7RAM: " + ramColor + used + " MB§7/§f" + max + " MB"
                + " §8| §7TPS: " + tpsColor + String.format(Locale.US, "%.2f", tps);
    }
}
