package de.craftsucht.core.keepalive;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Hält den Server so weit wie ein Plugin das kann rund um die Uhr am Laufen:
 * 1. Prüft/ändert "pause-when-empty-seconds" in der server.properties (sonst pausiert der Server ohne Spieler nach 60 Sekunden).
 * 2. Optionaler täglicher Neustart mit Vorwarnung (nur wenn das Spigot-Restart-Skript existiert, sonst würde der Server nur ausgehen).
 * 3. /keepalive status zeigt, was noch fehlt (z.B. Restart-Skript für automatischen Neustart nach Abstürzen).
 *
 * Grenzen: Ein Plugin kann einen abgestürzten Server nicht selbst neu starten und keinen Hoster davon abhalten,
 * einen leeren Server abzuschalten - dafür sind Restart-Skript bzw. Hoster-Einstellungen nötig.
 */
public class KeepAliveModule implements Module, CommandExecutor, TabCompleter {

    private static final String PAUSE_KEY = "pause-when-empty-seconds";

    private final SpookyCraftCore plugin;
    private final Set<Integer> warned = new HashSet<>();
    private BukkitTask task;
    private boolean restarting;

    public KeepAliveModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "keepalive";
    }

    @Override
    public void enable() {
        PluginCommand command = plugin.getCommand("keepalive");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
        if (plugin.getConfig().getBoolean("keepalive.auto-fix-server-properties", true)) {
            applyPauseFix(true);
        }
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 600L, 600L); // alle 30 Sekunden
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        task = null;
    }

    // ------------------------------------------------------------------ server.properties

    private File propertiesFile() {
        return new File("server.properties");
    }

    private boolean versionSupportsPause() {
        try {
            String[] p = Bukkit.getMinecraftVersion().split("\\.");
            int major = Integer.parseInt(p[0]);
            int minor = p.length > 1 ? Integer.parseInt(p[1].replaceAll("\\D.*", "")) : 0;
            int patch = p.length > 2 ? Integer.parseInt(p[2].replaceAll("\\D.*", "")) : 0;
            if (major >= 2) return true; // neue Versionsnummern (z.B. 26.x)
            if (major == 1 && minor > 21) return true;
            return major == 1 && minor == 21 && patch >= 2;
        } catch (Exception e) {
            return true;
        }
    }

    /** @return aktueller Wert in der server.properties oder null, wenn die Zeile fehlt/unlesbar ist */
    private Integer readPauseValue() {
        try {
            for (String line : Files.readAllLines(propertiesFile().toPath(), StandardCharsets.UTF_8)) {
                if (line.startsWith(PAUSE_KEY + "=")) {
                    return Integer.parseInt(line.substring(PAUSE_KEY.length() + 1).trim());
                }
            }
        } catch (IOException | NumberFormatException ignored) {
            // fällt auf null zurück
        }
        return null;
    }

    /** Setzt pause-when-empty-seconds=-1. @return true, wenn die Datei geändert wurde (dann ist ein Neustart nötig) */
    private boolean applyPauseFix(boolean log) {
        if (!versionSupportsPause()) {
            if (log) plugin.getLogger().info("KeepAlive: Diese Minecraft-Version pausiert leere Server nicht - nichts zu tun.");
            return false;
        }
        Integer current = readPauseValue();
        if (current != null && current == -1) return false;
        File file = propertiesFile();
        try {
            List<String> lines = new ArrayList<>(Files.readAllLines(file.toPath(), StandardCharsets.UTF_8));
            boolean replaced = false;
            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).startsWith(PAUSE_KEY + "=")) {
                    lines.set(i, PAUSE_KEY + "=-1");
                    replaced = true;
                    break;
                }
            }
            if (!replaced) lines.add(PAUSE_KEY + "=-1");
            Files.write(file.toPath(), lines, StandardCharsets.UTF_8);
            if (log) {
                plugin.getLogger().warning("KeepAlive: server.properties angepasst (" + PAUSE_KEY + "=-1). "
                        + "Damit der Server auch ohne Spieler weiterläuft, einmal NEU STARTEN.");
            }
            return true;
        } catch (IOException e) {
            plugin.getLogger().warning("KeepAlive: server.properties konnte nicht geändert werden: " + e.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------------ Neustart

    private String restartScriptPath() {
        YamlConfiguration spigot = Bukkit.spigot().getSpigotConfig();
        return spigot.getString("settings.restart-script", "./start.sh");
    }

    private boolean restartScriptExists() {
        return new File(restartScriptPath()).isFile();
    }

    private LocalTime restartTime() {
        String text = plugin.getConfig().getString("keepalive.daily-restart-time", "");
        if (text == null || text.isBlank()) return null;
        try {
            return LocalTime.parse(text.trim());
        } catch (Exception e) {
            return null;
        }
    }

    private void tick() {
        if (restarting) return;
        LocalTime time = restartTime();
        if (time == null) return;
        long uptimeMinutes = ManagementFactory.getRuntimeMXBean().getUptime() / 60_000L;
        if (uptimeMinutes < 15) return; // frisch gestartet: nicht gleich wieder neu starten
        if (!restartScriptExists()) return;

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime target = now.toLocalDate().atTime(time);
        if (now.isAfter(target.plusMinutes(5))) target = target.plusDays(1);
        if (!now.isBefore(target)) {
            doRestart();
            return;
        }
        long minutesLeft = Duration.between(now, target).toMinutes();
        for (int m : plugin.getConfig().getIntegerList("keepalive.warn-minutes")) {
            if (minutesLeft == m && warned.add(m)) {
                broadcast("&6&lServer-Neustart in " + m + " Minute" + (m == 1 ? "" : "n") + "! &7Er ist gleich wieder da.");
            }
        }
    }

    private void broadcast(String text) {
        for (Player p : Bukkit.getOnlinePlayers()) plugin.getMessageUtil().send(p, text);
    }

    private void doRestart() {
        restarting = true;
        broadcast("&6&lServer startet jetzt neu. &7Bis gleich!");
        Bukkit.getScheduler().runTaskLater(plugin, () -> Bukkit.spigot().restart(), 40L);
    }

    // ------------------------------------------------------------------ Befehl

    private boolean isAdmin(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin") || s.hasPermission("spookycraft.keepalive.admin");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!isAdmin(sender)) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase() : "status";
        switch (sub) {
            case "fix" -> {
                if (!versionSupportsPause()) {
                    plugin.getMessageUtil().send(sender, "&7Diese Minecraft-Version pausiert leere Server nicht - nichts zu tun.");
                } else if (applyPauseFix(true)) {
                    plugin.getMessageUtil().send(sender, "&aserver.properties angepasst. &eBitte den Server einmal neu starten.");
                } else {
                    plugin.getMessageUtil().send(sender, "&a" + PAUSE_KEY + " steht bereits auf -1.");
                }
            }
            case "restart" -> {
                if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
                    plugin.getMessageUtil().send(sender, "&cDas startet den Server neu. Bestätigen mit &e/keepalive restart confirm");
                } else if (!restartScriptExists()) {
                    plugin.getMessageUtil().send(sender, "&cKein Restart-Skript gefunden (" + restartScriptPath()
                            + "). Der Server würde nur ausgehen. Siehe &e/keepalive status");
                } else {
                    doRestart();
                }
            }
            default -> status(sender);
        }
        return true;
    }

    private void status(CommandSender sender) {
        plugin.getMessageUtil().send(sender, "&7--- &6KeepAlive &7---");
        Integer pause = readPauseValue();
        String pauseText;
        if (!versionSupportsPause()) {
            pauseText = "&7nicht nötig (diese Version pausiert nicht)";
        } else if (pause != null && pause == -1) {
            pauseText = "&aOK (-1, läuft auch ohne Spieler weiter)";
        } else {
            pauseText = "&cAktiv (" + (pause == null ? "Standard 60" : pause) + " s) - &e/keepalive fix &cund neu starten";
        }
        plugin.getMessageUtil().sendRaw(sender, "&8» &7Pausieren ohne Spieler: " + pauseText);

        boolean script = restartScriptExists();
        plugin.getMessageUtil().sendRaw(sender, "&8» &7Restart-Skript (" + restartScriptPath() + "): "
                + (script ? "&agefunden" : "&cfehlt &7- ohne Skript startet der Server nach Absturz/Neustart nicht von selbst wieder"));
        boolean onCrash = Bukkit.spigot().getSpigotConfig().getBoolean("settings.restart-on-crash", true);
        plugin.getMessageUtil().sendRaw(sender, "&8» &7Neustart nach Absturz (spigot.yml): " + (onCrash ? "&aan" : "&caus"));
        LocalTime time = restartTime();
        plugin.getMessageUtil().sendRaw(sender, "&8» &7Täglicher Neustart: " + (time == null ? "&7aus" : "&f" + time
                + (script ? "" : " &c(inaktiv, Restart-Skript fehlt)")));
        plugin.getMessageUtil().sendRaw(sender, "&8» &7Laufzeit: &f" + (ManagementFactory.getRuntimeMXBean().getUptime() / 60_000L) + " Min.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!isAdmin(sender)) return Collections.emptyList();
        if (args.length == 1) return TabCompleteUtil.filter(args[0], "status", "fix", "restart");
        if (args.length == 2 && args[0].equalsIgnoreCase("restart")) return TabCompleteUtil.filter(args[1], "confirm");
        return Collections.emptyList();
    }
}
