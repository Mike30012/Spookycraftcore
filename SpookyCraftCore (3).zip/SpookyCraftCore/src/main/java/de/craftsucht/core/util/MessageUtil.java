package de.craftsucht.core.util;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class MessageUtil {

    private final SpookyCraftCore plugin;
    private String prefix;

    public MessageUtil(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.prefix = "&8[&6☠ SpookyCraft&8] &r";
    }

    public void reloadPrefix() {
        this.prefix = plugin.getConfig().getString("prefix", "&8[&6☠ SpookyCraft&8] &r");
    }

    /** Haeufige Standardtexte werden zentral spooky umformuliert (gilt fuer alle send()/sendRaw()-Meldungen). */
    private static final java.util.LinkedHashMap<String, String> SPOOKY = new java.util.LinkedHashMap<>();

    static {
        String deny = "Die Geister verwehren dir den Zutritt!";
        SPOOKY.put("Dazu hast du keine Berechtigung.", deny);
        SPOOKY.put("Du hast keine Berechtigung dazu.", deny);
        SPOOKY.put("Du hast keine Berechtigung.", deny);
        SPOOKY.put("Du hast keine Rechte für diesen Befehl!", deny);
        SPOOKY.put("Keine Berechtigung.", deny);
        SPOOKY.put("Spieler nicht online.", "Dieser Spieler wandelt nicht in der Geisterwelt.");
        SPOOKY.put("ist nicht online.", "wandelt nicht in der Geisterwelt.");
        SPOOKY.put("Spieler nicht gefunden.", "Die Geister kennen diesen Spieler nicht.");
        SPOOKY.put("Nur als Spieler nutzbar.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Nur Spieler können diesen Befehl nutzen.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Dieser Befehl kann nur von Spielern genutzt werden.", "Nur Seelen aus Fleisch und Blut können das.");
        SPOOKY.put("Dieser Befehl geht nur ingame.", "Dieser Zauber wirkt nur in der Geisterwelt (ingame).");
        SPOOKY.put("Unbekannter Befehl.", "Dieser Zauberspruch ist unbekannt.");
        SPOOKY.put("Du hast nicht genug Geld!", "Deine Taschen sind zu leer – nicht genug Geld!");
        SPOOKY.put("Nicht genug Geld.", "Deine Taschen sind zu leer – nicht genug Geld!");
        SPOOKY.put("Bitte gib eine gültige Zahl ein.", "Das ist keine gültige Zahl, Sterblicher.");
        SPOOKY.put("Ungültige Zahl.", "Das ist keine gültige Zahl, Sterblicher.");
        SPOOKY.put("Ungültiger Betrag.", "Dieser Betrag ist verflucht (ungültig).");
        SPOOKY.put("Halte ein Item in der Hand!", "Halte einen Gegenstand in deiner Hand!");
        SPOOKY.put("Halte ein Item in der Hand.", "Halte einen Gegenstand in deiner Hand.");
        SPOOKY.put("Nutzung:", "Zauberformel:");
        SPOOKY.put("Fehler beim Laden.", "Die Geister haben das Laden verhext.");
    }

    public static String spookify(String text) {
        String r = text;
        for (java.util.Map.Entry<String, String> e : SPOOKY.entrySet()) {
            if (r.contains(e.getKey())) r = r.replace(e.getKey(), e.getValue());
        }
        return r;
    }

    public String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    /** Fehler (&c), Erfolg (&a) und Info bekommen ein eigenes Spooky-Symbol vor dem Text. */
    public void send(CommandSender sender, String message) {
        String m = message;
        if (m.startsWith("&c")) m = "&c✖ " + m;
        else if (m.startsWith("&a")) m = "&a✔ " + m;
        sender.sendMessage(color(prefix + spookify(m)));
    }

    public void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(color(spookify(message)));
    }
}
