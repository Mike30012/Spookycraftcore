package de.craftsucht.core.bank;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.ChatColor;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {

    private final SpookyCraftCore plugin;
    private final BankManager bankManager;
    private final Map<UUID, String> awaitingInput = new HashMap<>();

    public GUIListener(SpookyCraftCore plugin, BankManager bankManager) {
        this.plugin = plugin;
        this.bankManager = bankManager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        HumanEntity humanEntity = e.getWhoClicked();
        if (!(humanEntity instanceof Player player)) return;

        String titel = plugin.getConfig().getString("bank.gui-titel", "&8&lSpookyCraft &6&lBank");
        String plainTitel = ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', titel));
        String invTitel = ChatColor.stripColor(e.getView().getTitle());
        if (!invTitel.equals(plainTitel)) return;

        e.setCancelled(true);
        if (e.getCurrentItem() == null) return;

        int slot = e.getSlot();
        if (slot == 11) {
            player.closeInventory();
            if (e.isShiftClick()) {
                awaitingInput.put(player.getUniqueId(), "einzahlen");
                send(player, "&eGib den Betrag ein, den du einzahlen möchtest: &7(oder &e* &7für alles)");
            } else {
                de.craftsucht.core.economy.EconomyModule economyModule =
                        (de.craftsucht.core.economy.EconomyModule) plugin.getModuleManager().get("economy");
                double balance = economyModule != null ? economyModule.getManager().getBalance(player.getUniqueId()) : 0.0;
                if (balance <= 0.0) {
                    send(player, "&cDeine Taschen sind zu leer – nicht genug Geld!");
                    return;
                }
                bankManager.einzahlen(player, balance);
                send(player, "&aErfolgreich &e" + String.format("%.2f", balance) + "$ &aauf dein Bankkonto eingezahlt.");
                BankGUI.open(plugin, bankManager, player);
            }
        }
        if (slot == 15) {
            player.closeInventory();
            if (e.isShiftClick()) {
                awaitingInput.put(player.getUniqueId(), "auszahlen");
                send(player, "&eGib den Betrag ein, den du auszahlen möchtest: &7(oder &e* &7für alles)");
            } else {
                double guthaben = bankManager.getGuthaben(player.getUniqueId());
                if (guthaben <= 0.0) {
                    send(player, "&cDein Bankkonto hat nicht genug Guthaben!");
                    return;
                }
                bankManager.auszahlen(player, guthaben);
                send(player, "&aErfolgreich &e" + String.format("%.2f", guthaben) + "$ &avon deinem Bankkonto abgehoben.");
                BankGUI.open(plugin, bankManager, player);
            }
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        Player player = e.getPlayer();
        UUID uuid = player.getUniqueId();
        if (!awaitingInput.containsKey(uuid)) return;

        e.setCancelled(true);
        String input = e.getMessage().trim();
        String aktion = awaitingInput.remove(uuid);

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            double betrag;
            if (input.equals("*")) {
                de.craftsucht.core.economy.EconomyModule economyModule =
                        (de.craftsucht.core.economy.EconomyModule) plugin.getModuleManager().get("economy");
                betrag = aktion.equals("einzahlen")
                        ? (economyModule != null ? economyModule.getManager().getBalance(uuid) : 0.0)
                        : bankManager.getGuthaben(uuid);
            } else {
                try {
                    betrag = Double.parseDouble(input.replace(",", "."));
                } catch (NumberFormatException ex) {
                    send(player, "&cDas ist keine gültige Zahl, Sterblicher.");
                    return;
                }
            }
            if (betrag <= 0.0) {
                send(player, "&cDas ist keine gültige Zahl, Sterblicher.");
                return;
            }
            if (aktion.equals("einzahlen")) {
                if (!bankManager.einzahlen(player, betrag)) {
                    send(player, "&cDeine Taschen sind zu leer – nicht genug Geld!");
                    return;
                }
                send(player, "&aErfolgreich &e" + String.format("%.2f", betrag) + "$ &aauf dein Bankkonto eingezahlt.");
            } else {
                if (!bankManager.auszahlen(player, betrag)) {
                    send(player, "&cDein Bankkonto hat nicht genug Guthaben!");
                    return;
                }
                send(player, "&aErfolgreich &e" + String.format("%.2f", betrag) + "$ &avon deinem Bankkonto abgehoben.");
            }
            BankGUI.open(plugin, bankManager, player);
        });
    }

    private void send(Player player, String msg) {
        player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8[&6Bank&8] " + msg));
    }
}
