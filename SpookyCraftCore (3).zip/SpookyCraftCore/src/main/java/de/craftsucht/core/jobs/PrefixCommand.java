package de.craftsucht.core.jobs;

import de.craftsucht.core.rank.RankModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

/**
 * /prefix ändert die FARBE des Rangs, dem der Spieler gerade zugewiesen ist
 * (z.B. "Owner") - betrifft also ALLE mit diesem Rang, nicht nur den
 * ausführenden Spieler selbst. Farbe kommt entweder aus einem per Job-Level
 * freigeschalteten Titel (GUI) oder frei per /prefix hex <RRGGBB>.
 */
public class PrefixCommand implements CommandExecutor, TabCompleter {

    private final JobsModule jobs;
    private final PrefixGuiListener gui;

    public PrefixCommand(JobsModule jobs, PrefixGuiListener gui) {
        this.jobs = jobs;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        if (args.length == 0) {
            gui.open(player);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reset" -> applyRankColor(player, "&f", "zurückgesetzt");
            case "hex" -> {
                if (args.length < 2) {
                    player.sendMessage(ChatColor.RED + "Nutzung: /prefix hex <RRGGBB>, z.B. /prefix hex FF00AA");
                    return true;
                }
                String hex = args[1].replace("#", "");
                if (!PrefixColorManager.isValidHex(hex)) {
                    player.sendMessage(ChatColor.RED + "Ungültiger Hex-Code. Format: RRGGBB (z.B. FF00AA)");
                    return true;
                }
                applyRankColor(player, PrefixColorManager.toColorCode(hex), "gesetzt: #" + hex.toUpperCase());
            }
            default -> gui.open(player);
        }
        return true;
    }

    /** Setzt die Farbe des aktuellen Rangs des Spielers und refresht Chat/Tab/Nametag/Scoreboard sofort. */
    void applyRankColor(Player player, String colorCode, String feedbackSuffix) {
        RankModule rankModule = (RankModule) jobs.plugin.getModuleManager().get("rank");
        if (rankModule == null || rankModule.getManager() == null) {
            player.sendMessage(ChatColor.RED + "Rang-Farben gibt es nur, wenn das Rang-System aktiv ist.");
            return;
        }
        boolean reset = colorCode.equals("&f") && feedbackSuffix.contains("zurückgesetzt");
        boolean ok = reset
                ? rankModule.getManager().clearPlayerColor(player.getUniqueId())
                : rankModule.getManager().setPlayerColor(player.getUniqueId(), colorCode);
        if (!ok) {
            player.sendMessage(ChatColor.RED + "Konnte Prefix-Farbe nicht ändern.");
            return;
        }
        player.sendMessage((reset ? "" : ChatColor.translateAlternateColorCodes('&', colorCode)) + "Prefix-Farbe "
                + (reset ? "auf die Farbe deines Rangs zurückgesetzt" : feedbackSuffix) + " §7(gilt nur für dich)");

        de.craftsucht.core.module.Module m = jobs.plugin.getModuleManager().get("scoreboard");
        if (m instanceof de.craftsucht.core.scoreboard.ScoreboardModule sm) {
            sm.refreshNow();
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("hex", "reset");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("hex")) {
            return List.of("FF0000", "00FF00", "0000FF", "FFAA00", "FF00AA", "00FFFF");
        }
        return Collections.emptyList();
    }
}
