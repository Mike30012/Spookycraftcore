package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CItemCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final BoosterModule booster;

    public CItemCommand(SpookyCraftCore plugin, BoosterModule booster) {
        this.plugin = plugin;
        this.booster = booster;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("boosteritems.admin") && !sender.hasPermission("spookycraft.core.admin")) {
            sender.sendMessage(ChatColor.RED + "Die Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give" -> handleGive(sender, args);
            case "list" -> handleList(sender);
            case "reload" -> {
                booster.getItemRegistry().load();
                sender.sendMessage(ChatColor.GREEN + "items.yml neu geladen (" + booster.getItemRegistry().getTemplates().size() + " Items).");
            }
            default -> sendUsage(sender);
        }
        return true;
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Nutzung: /citem give <spieler> <item-id> [prozent 10-1000]");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Spieler '" + args[1] + "' wandelt nicht in der Geisterwelt.");
            return;
        }
        ItemTemplate template = booster.getItemRegistry().getTemplate(args[2]);
        if (template == null) {
            sender.sendMessage(ChatColor.RED + "Unbekannte Item-ID '" + args[2] + "'. Siehe /citem list.");
            return;
        }

        Double percent = null;
        if (args.length >= 4) {
            try {
                percent = Double.parseDouble(args[3]);
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "Ungültiger Prozentwert. Zahl zwischen " + (int) ItemRegistry.MIN_PERCENT + " und " + (int) ItemRegistry.MAX_PERCENT + " erwartet.");
                return;
            }
            if (percent < ItemRegistry.MIN_PERCENT || percent > ItemRegistry.MAX_PERCENT) {
                sender.sendMessage(ChatColor.RED + "Prozentwert muss zwischen " + (int) ItemRegistry.MIN_PERCENT + "% und " + (int) ItemRegistry.MAX_PERCENT + "% liegen.");
                return;
            }
        }

        ItemStack item = booster.getItemRegistry().build(template, percent);
        target.getInventory().addItem(item);
        String percentInfo = percent != null ? " (" + formatPercent(percent) + "%)" : "";
        sender.sendMessage(ChatColor.GREEN + "Item '" + template.getId() + "'" + percentInfo + " an " + target.getName() + " gegeben.");
        if (!target.equals(sender)) {
            target.sendMessage(ChatColor.GREEN + "Du hast ein Item erhalten: " + ChatColor.stripColor(template.getDisplayName()));
        }
    }

    private String formatPercent(double value) {
        return value == Math.floor(value) ? String.valueOf((int) value) : String.valueOf(value);
    }

    private void handleList(CommandSender sender) {
        if (booster.getItemRegistry().getTemplates().isEmpty()) {
            sender.sendMessage(ChatColor.YELLOW + "Keine Custom-Items in items.yml definiert.");
            return;
        }
        sender.sendMessage(ChatColor.GOLD + "Verfügbare Custom-Items:");
        for (ItemTemplate t : booster.getItemRegistry().getTemplates().values()) {
            sender.sendMessage(ChatColor.GRAY + " - " + ChatColor.WHITE + t.getId() + ChatColor.GRAY + " (" + ChatColor.stripColor(t.getDisplayName()) + ChatColor.GRAY + ")");
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "/citem give <spieler> <item-id> [prozent 10-1000]");
        sender.sendMessage(ChatColor.GOLD + "/citem list");
        sender.sendMessage(ChatColor.GOLD + "/citem reload");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            return filter(List.of("give", "list", "reload"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return filter(new ArrayList<>(booster.getItemRegistry().getTemplates().keySet()), args[2]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("give")) {
            return filter(List.of("10", "50", "100", "250", "500", "1000"), args[3]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
