package de.craftsucht.core.blocklog;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.StaffCheck;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Geister-Chronik (/co): protokolliert Bloecke (abbauen, setzen, Explosionen, Feuer) in einer eigenen
 * SQLite-Datei (blocklog.db) und kann sie ansehen, zurueckrollen und wiederherstellen - wie CoreProtect.
 * Rollback stellt nur Bloecke wieder her, keinen Kisten-Inhalt.
 */
public class BlockLogModule implements Module, Listener, CommandExecutor, TabCompleter {

    private static final int BREAK = 0;
    private static final int PLACE = 1;
    private static final int EXPLODE = 2;

    private record Entry(long t, String who, String world, int x, int y, int z, int action, String oldData, String newData) {
    }

    private record Row(long id, long t, String who, String world, int x, int y, int z, int action, String oldData, String newData) {
    }

    private static final class Query {
        String user;
        Long since;
        Integer radius;
        Location center;
        Integer action;
        int page = 1;
    }

    private final SpookyCraftCore plugin;
    private final ConcurrentLinkedQueue<Entry> queue = new ConcurrentLinkedQueue<>();
    private final Set<UUID> inspecting = new HashSet<>();
    private ExecutorService exec;
    private Connection conn;
    private BukkitTask flushTask;
    private volatile boolean working;

    public BlockLogModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "blocklog";
    }

    // ------------------------------------------------------------------ Start / Stop

    @Override
    public void enable() {
        exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "SpookyCraft-BlockLog");
            t.setDaemon(true);
            return t;
        });
        exec.execute(this::openDb);
        flushTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> exec.execute(this::drain), 40L, 40L);
        plugin.getCommand("co").setExecutor(this);
        plugin.getCommand("co").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        int keep = plugin.getConfig().getInt("blocklog.keep-days", 30);
        if (keep > 0) {
            exec.execute(() -> {
                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM log_blocks WHERE t < ?")) {
                    ps.setLong(1, System.currentTimeMillis() - keep * 86_400_000L);
                    ps.executeUpdate();
                } catch (SQLException | RuntimeException e) {
                    plugin.getLogger().warning("Chronik: Aufräumen fehlgeschlagen: " + e.getMessage());
                }
            });
        }
    }

    @Override
    public void disable() {
        if (flushTask != null) flushTask.cancel();
        if (exec != null) {
            exec.execute(() -> {
                drain();
                try {
                    if (conn != null) conn.close();
                } catch (SQLException ignored) {
                    // egal beim Beenden
                }
            });
            exec.shutdown();
            try {
                exec.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void openDb() {
        try {
            Class.forName("org.sqlite.JDBC");
            File f = new File(plugin.getDataFolder(), "blocklog.db");
            plugin.getDataFolder().mkdirs();
            conn = DriverManager.getConnection("jdbc:sqlite:" + f.getAbsolutePath());
            try (Statement st = conn.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL");
                st.execute("PRAGMA synchronous=NORMAL");
                st.execute("CREATE TABLE IF NOT EXISTS log_blocks (id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, who TEXT, "
                        + "world TEXT, x INTEGER, y INTEGER, z INTEGER, action INTEGER, old TEXT, new TEXT, rolled INTEGER DEFAULT 0)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_log_pos ON log_blocks (world, x, z, y)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_log_t ON log_blocks (t)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_log_who ON log_blocks (who)");
            }
        } catch (ClassNotFoundException | SQLException e) {
            plugin.getLogger().severe("Chronik: Datenbank konnte nicht geöffnet werden: " + e.getMessage());
            conn = null;
        }
    }

    /** Schreibt alle wartenden Einträge (nur im Datenbank-Thread aufrufen). */
    private void drain() {
        if (conn == null || queue.isEmpty()) return;
        try {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO log_blocks (t, who, world, x, y, z, action, old, new) VALUES (?,?,?,?,?,?,?,?,?)")) {
                Entry e;
                int n = 0;
                while ((e = queue.poll()) != null && n < 20000) {
                    ps.setLong(1, e.t);
                    ps.setString(2, e.who);
                    ps.setString(3, e.world);
                    ps.setInt(4, e.x);
                    ps.setInt(5, e.y);
                    ps.setInt(6, e.z);
                    ps.setInt(7, e.action);
                    ps.setString(8, e.oldData);
                    ps.setString(9, e.newData);
                    ps.addBatch();
                    n++;
                }
                ps.executeBatch();
            }
            conn.commit();
        } catch (SQLException e) {
            plugin.getLogger().warning("Chronik: Schreiben fehlgeschlagen: " + e.getMessage());
            try {
                conn.rollback();
            } catch (SQLException ignored) {
                // nichts zu tun
            }
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException ignored) {
                // nichts zu tun
            }
        }
    }

    // ------------------------------------------------------------------ Protokoll

    private void log(String who, Block b, int action, String oldData, String newData) {
        if (oldData.equals(newData)) return;
        queue.add(new Entry(System.currentTimeMillis(), who, b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), action, oldData, newData));
    }

    private static final String AIR = "minecraft:air";

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        log(e.getPlayer().getName(), e.getBlock(), BREAK, e.getBlock().getBlockData().getAsString(), AIR);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        String old = e.getBlockReplacedState().getBlockData().getAsString();
        log(e.getPlayer().getName(), e.getBlockPlaced(), PLACE, old, e.getBlockPlaced().getBlockData().getAsString());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        String who = "#" + e.getEntityType().name().toLowerCase(Locale.ROOT);
        for (Block b : e.blockList()) log(who, b, EXPLODE, b.getBlockData().getAsString(), AIR);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        for (Block b : e.blockList()) log("#explosion", b, EXPLODE, b.getBlockData().getAsString(), AIR);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        log("#feuer", e.getBlock(), EXPLODE, e.getBlock().getBlockData().getAsString(), AIR);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        inspecting.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Inspektor

    @EventHandler(priority = EventPriority.HIGH)
    public void onInspect(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        Player p = e.getPlayer();
        if (!inspecting.contains(p.getUniqueId())) return;
        if (e.getAction() != Action.LEFT_CLICK_BLOCK && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        e.setCancelled(true);
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(Event.Result.DENY);
        Block b = e.getAction() == Action.RIGHT_CLICK_BLOCK ? e.getClickedBlock().getRelative(e.getBlockFace()) : e.getClickedBlock();
        final String world = b.getWorld().getName();
        final int x = b.getX(), y = b.getY(), z = b.getZ();
        exec.execute(() -> {
            drain();
            List<Row> rows = select("WHERE world=? AND x=? AND y=? AND z=?", List.of(world, x, y, z), 0, 8);
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getMessageUtil().sendRaw(p, "&8&l☠ &7Chronik bei &f" + x + " " + y + " " + z);
                if (rows.isEmpty()) plugin.getMessageUtil().sendRaw(p, "&7Hier haben die Geister nichts gesehen.");
                for (Row r : rows) plugin.getMessageUtil().sendRaw(p, describe(r));
            });
        });
    }

    // ------------------------------------------------------------------ Befehl

    private boolean canView(CommandSender s) {
        return s.isOp() || StaffCheck.isStaff(plugin, s) || s.hasPermission("spookycraft.blocklog.use");
    }

    private boolean canRollback(CommandSender s) {
        return s.isOp() || StaffCheck.isStaff(plugin, s) || s.hasPermission("spookycraft.blocklog.rollback");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!canView(sender)) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (conn == null) {
            plugin.getMessageUtil().send(sender, "&cDie Chronik schläft gerade (Datenbank nicht bereit). Siehe Konsole.");
            return true;
        }
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "inspect", "i" -> inspect(sender);
            case "lookup", "l" -> lookup(sender, args);
            case "rollback", "rb" -> change(sender, args, true);
            case "restore", "rs" -> change(sender, args, false);
            case "purge" -> purge(sender, args);
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender s) {
        plugin.getMessageUtil().sendRaw(s, "&8&l☠ &7Geister-Chronik &8(Blöcke)");
        plugin.getMessageUtil().sendRaw(s, "&f/co inspect &7- Block anklicken: wer hat hier was getan");
        plugin.getMessageUtil().sendRaw(s, "&f/co lookup u:<Name> t:<Zeit> r:<Radius> a:<break|place|explode> p:<Seite>");
        plugin.getMessageUtil().sendRaw(s, "&f/co rollback u:<Name> t:<Zeit> r:<Radius> &7- zurückrollen");
        plugin.getMessageUtil().sendRaw(s, "&f/co restore u:<Name> t:<Zeit> r:<Radius> &7- Rollback rückgängig");
        plugin.getMessageUtil().sendRaw(s, "&f/co purge t:<Zeit> &7- alte Einträge löschen");
        plugin.getMessageUtil().sendRaw(s, "&7Zeit: &f1w2d3h4m5s &7(z.B. &f3d&7, &f12h&7, &f30m&7)");
    }

    private void inspect(CommandSender s) {
        if (!(s instanceof Player p)) {
            plugin.getMessageUtil().send(s, "&cNur Seelen aus Fleisch und Blut können das.");
            return;
        }
        if (inspecting.remove(p.getUniqueId())) {
            plugin.getMessageUtil().send(p, "&7Der Geisterblick schließt sich.");
        } else {
            inspecting.add(p.getUniqueId());
            plugin.getMessageUtil().send(p, "&aGeisterblick offen: &fLinksklick &aauf einen Block, &fRechtsklick &afür den Platz davor.");
        }
    }

    /** Liest u: t: r: a: p: aus den Argumenten. Gibt null zurueck (mit Fehlermeldung) bei Fehlern. */
    private Query parse(CommandSender s, String[] args) {
        Query q = new Query();
        for (int i = 1; i < args.length; i++) {
            String a = args[i];
            int c = a.indexOf(':');
            if (c < 1) {
                plugin.getMessageUtil().send(s, "&cUnbekannte Angabe: &f" + a);
                return null;
            }
            String key = a.substring(0, c).toLowerCase(Locale.ROOT);
            String val = a.substring(c + 1);
            switch (key) {
                case "u" -> q.user = val;
                case "t" -> {
                    long ms = parseTime(val);
                    if (ms <= 0) {
                        plugin.getMessageUtil().send(s, "&cZeit nicht lesbar: &f" + val + " &7(Beispiel: 3d, 12h, 30m)");
                        return null;
                    }
                    q.since = System.currentTimeMillis() - ms;
                }
                case "r" -> {
                    try {
                        q.radius = Math.max(1, Math.min(500, Integer.parseInt(val)));
                    } catch (NumberFormatException e) {
                        plugin.getMessageUtil().send(s, "&cRadius muss eine Zahl sein.");
                        return null;
                    }
                    if (!(s instanceof Player p)) {
                        plugin.getMessageUtil().send(s, "&cr: geht nur im Spiel.");
                        return null;
                    }
                    q.center = p.getLocation();
                }
                case "a" -> {
                    switch (val.toLowerCase(Locale.ROOT)) {
                        case "break" -> q.action = BREAK;
                        case "place" -> q.action = PLACE;
                        case "explode" -> q.action = EXPLODE;
                        default -> {
                            plugin.getMessageUtil().send(s, "&ca: break, place oder explode.");
                            return null;
                        }
                    }
                }
                case "p" -> {
                    try {
                        q.page = Math.max(1, Integer.parseInt(val));
                    } catch (NumberFormatException e) {
                        q.page = 1;
                    }
                }
                default -> {
                    plugin.getMessageUtil().send(s, "&cUnbekannte Angabe: &f" + key + ":");
                    return null;
                }
            }
        }
        return q;
    }

    private static long parseTime(String s) {
        long total = 0;
        StringBuilder num = new StringBuilder();
        for (char ch : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (Character.isDigit(ch)) {
                num.append(ch);
                continue;
            }
            if (num.length() == 0) return -1;
            long n;
            try {
                n = Long.parseLong(num.toString());
            } catch (NumberFormatException e) {
                return -1;
            }
            num.setLength(0);
            switch (ch) {
                case 'w' -> total += n * 604_800_000L;
                case 'd' -> total += n * 86_400_000L;
                case 'h' -> total += n * 3_600_000L;
                case 'm' -> total += n * 60_000L;
                case 's' -> total += n * 1_000L;
                default -> {
                    return -1;
                }
            }
        }
        return num.length() == 0 ? total : -1;
    }

    /** Baut WHERE + Parameter (ohne "rolled"-Filter). */
    private String where(Query q, List<Object> params) {
        StringBuilder sb = new StringBuilder("WHERE 1=1");
        if (q.user != null) {
            sb.append(" AND who = ? COLLATE NOCASE");
            params.add(q.user);
        }
        if (q.since != null) {
            sb.append(" AND t >= ?");
            params.add(q.since);
        }
        if (q.action != null) {
            sb.append(" AND action = ?");
            params.add(q.action);
        }
        if (q.radius != null && q.center != null && q.center.getWorld() != null) {
            sb.append(" AND world = ? AND x BETWEEN ? AND ? AND y BETWEEN ? AND ? AND z BETWEEN ? AND ?");
            params.add(q.center.getWorld().getName());
            params.add(q.center.getBlockX() - q.radius);
            params.add(q.center.getBlockX() + q.radius);
            params.add(q.center.getBlockY() - q.radius);
            params.add(q.center.getBlockY() + q.radius);
            params.add(q.center.getBlockZ() - q.radius);
            params.add(q.center.getBlockZ() + q.radius);
        }
        return sb.toString();
    }

    private void lookup(CommandSender s, String[] args) {
        Query q = parse(s, args);
        if (q == null) return;
        if (q.user == null && q.since == null && q.radius == null) {
            plugin.getMessageUtil().send(s, "&cGib mindestens u:, t: oder r: an.");
            return;
        }
        List<Object> params = new ArrayList<>();
        String w = where(q, params);
        int per = 8;
        int page = q.page;
        exec.execute(() -> {
            drain();
            int total = count(w, params);
            List<Row> rows = select(w, params, (page - 1) * per, per);
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getMessageUtil().sendRaw(s, "&8&l☠ &7Chronik &8- &f" + total + " &7Einträge, Seite &f" + page + "&7/&f" + Math.max(1, (total + per - 1) / per));
                if (rows.isEmpty()) plugin.getMessageUtil().sendRaw(s, "&7Die Geister haben nichts gesehen.");
                for (Row r : rows) plugin.getMessageUtil().sendRaw(s, describe(r));
            });
        });
    }

    private void change(CommandSender s, String[] args, boolean rollback) {
        if (!canRollback(s)) {
            plugin.getMessageUtil().send(s, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        Query q = parse(s, args);
        if (q == null) return;
        if (q.since == null || (q.user == null && q.radius == null)) {
            plugin.getMessageUtil().send(s, "&cFür " + (rollback ? "Rollback" : "Restore") + " brauchst du &ft:&c und &fu:&c oder &fr:&c.");
            return;
        }
        List<Object> params = new ArrayList<>();
        String w = where(q, params) + " AND rolled = " + (rollback ? 0 : 1);
        int max = Math.max(1000, plugin.getConfig().getInt("blocklog.max-rollback", 200000));
        plugin.getMessageUtil().send(s, "&7Die Geister durchstöbern die Vergangenheit …");
        exec.execute(() -> {
            drain();
            List<Row> rows = select(w, params, 0, max + 1, rollback ? "DESC" : "ASC");
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (rows.size() > max) {
                    plugin.getMessageUtil().send(s, "&cZu viele Einträge (über " + max + "). Grenze mit t: oder r: enger ein.");
                    return;
                }
                if (rows.isEmpty()) {
                    plugin.getMessageUtil().send(s, "&7Nichts zu tun.");
                    return;
                }
                apply(s, rows, rollback);
            });
        });
    }

    /** Setzt Bloecke in Paketen pro Tick, damit der Server nicht ruckelt. */
    private void apply(CommandSender s, List<Row> rows, boolean rollback) {
        final int perTick = Math.max(50, plugin.getConfig().getInt("blocklog.blocks-per-tick", 400));
        final List<Long> done = new ArrayList<>(rows.size());
        final int[] idx = {0};
        final int[] failed = {0};
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                int n = 0;
                while (idx[0] < rows.size() && n < perTick) {
                    Row r = rows.get(idx[0]++);
                    n++;
                    World world = Bukkit.getWorld(r.world);
                    if (world == null) {
                        failed[0]++;
                        continue;
                    }
                    try {
                        BlockData data = Bukkit.createBlockData(rollback ? r.oldData : r.newData);
                        world.getBlockAt(r.x, r.y, r.z).setBlockData(data, false);
                        done.add(r.id);
                    } catch (IllegalArgumentException | IllegalStateException e) {
                        failed[0]++;
                    }
                }
                if (idx[0] >= rows.size()) {
                    cancel();
                    markRolled(done, rollback);
                    plugin.getMessageUtil().send(s, "&a" + done.size() + " Blöcke " + (rollback ? "zurückgerollt" : "wiederhergestellt")
                            + (failed[0] > 0 ? " &7(" + failed[0] + " übersprungen)" : "") + "&a.");
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void markRolled(List<Long> ids, boolean rolledBack) {
        exec.execute(() -> {
            if (conn == null) return;
            try {
                conn.setAutoCommit(false);
                try (PreparedStatement ps = conn.prepareStatement("UPDATE log_blocks SET rolled=? WHERE id=?")) {
                    for (long id : ids) {
                        ps.setInt(1, rolledBack ? 1 : 0);
                        ps.setLong(2, id);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                conn.commit();
            } catch (SQLException e) {
                plugin.getLogger().warning("Chronik: Markieren fehlgeschlagen: " + e.getMessage());
            } finally {
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException ignored) {
                    // nichts zu tun
                }
            }
        });
    }

    private void purge(CommandSender s, String[] args) {
        if (!canRollback(s)) {
            plugin.getMessageUtil().send(s, "&cDie Geister verwehren dir den Zutritt!");
            return;
        }
        Query q = parse(s, args);
        if (q == null || q.since == null) {
            plugin.getMessageUtil().send(s, "&cNutzung: /co purge t:<Zeit> &7(löscht Einträge, die älter sind)");
            return;
        }
        final long limit = q.since;
        exec.execute(() -> {
            drain();
            int n = 0;
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM log_blocks WHERE t < ?")) {
                ps.setLong(1, limit);
                n = ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().warning("Chronik: Löschen fehlgeschlagen: " + e.getMessage());
            }
            final int deleted = n;
            Bukkit.getScheduler().runTask(plugin, () -> plugin.getMessageUtil().send(s, "&a" + deleted + " alte Einträge vergessen."));
        });
    }

    // ------------------------------------------------------------------ Datenbank-Abfragen (nur im Datenbank-Thread)

    private int count(String where, List<Object> params) {
        try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM log_blocks " + where)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Chronik: Zählen fehlgeschlagen: " + e.getMessage());
            return 0;
        }
    }

    private List<Row> select(String where, List<Object> params, int offset, int limit) {
        return select(where, params, offset, limit, "DESC");
    }

    private List<Row> select(String where, List<Object> params, int offset, int limit, String order) {
        List<Row> out = new ArrayList<>();
        String sql = "SELECT id, t, who, world, x, y, z, action, old, new FROM log_blocks " + where
                + " ORDER BY id " + order + " LIMIT ? OFFSET ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            List<Object> all = new ArrayList<>(params);
            all.add(limit);
            all.add(offset);
            bind(ps, all);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new Row(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6),
                            rs.getInt(7), rs.getInt(8), rs.getString(9), rs.getString(10)));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Chronik: Abfrage fehlgeschlagen: " + e.getMessage());
        }
        return out;
    }

    private static void bind(PreparedStatement ps, List<Object> params) throws SQLException {
        for (int i = 0; i < params.size(); i++) {
            Object o = params.get(i);
            if (o instanceof Long l) ps.setLong(i + 1, l);
            else if (o instanceof Integer n) ps.setInt(i + 1, n);
            else ps.setString(i + 1, String.valueOf(o));
        }
    }

    // ------------------------------------------------------------------ Anzeige

    private static String material(String blockData) {
        String s = blockData.startsWith("minecraft:") ? blockData.substring(10) : blockData;
        int b = s.indexOf('[');
        return b >= 0 ? s.substring(0, b) : s;
    }

    private static String ago(long t) {
        long sec = Math.max(0, (System.currentTimeMillis() - t) / 1000);
        if (sec < 60) return sec + "s";
        if (sec < 3600) return (sec / 60) + "m";
        if (sec < 86400) return String.format(Locale.ROOT, "%.1fh", sec / 3600.0);
        return String.format(Locale.ROOT, "%.1fd", sec / 86400.0);
    }

    private String describe(Row r) {
        String what;
        String block;
        if (r.action == PLACE) {
            what = "setzte";
            block = material(r.newData);
        } else if (r.action == EXPLODE) {
            what = "zerstörte";
            block = material(r.oldData);
        } else {
            what = "baute ab";
            block = material(r.oldData);
        }
        return "&8" + ago(r.t) + " &7her &f" + r.who + " &7" + what + " &e" + block
                + " &8(" + r.x + " " + r.y + " " + r.z + ")";
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!canView(s)) return List.of();
        if (a.length == 1) {
            List<String> out = new ArrayList<>(List.of("inspect", "lookup", "rollback", "restore", "purge", "help"));
            out.removeIf(x -> !x.startsWith(a[0].toLowerCase(Locale.ROOT)));
            return out;
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String k : new String[]{"u:", "t:", "r:", "a:", "p:"}) {
            if (k.startsWith(last)) out.add(k);
        }
        if (last.startsWith("a:")) {
            for (String v : new String[]{"a:break", "a:place", "a:explode"}) {
                if (v.startsWith(last)) out.add(v);
            }
        }
        return out;
    }
}
