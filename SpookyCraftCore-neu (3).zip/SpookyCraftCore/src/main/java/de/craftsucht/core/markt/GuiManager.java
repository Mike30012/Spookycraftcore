package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Alle Menüs des Spielermarkts: Hauptmenü, Kategorie, Item-Handelsmenü, Meine Aufträge, Abholung. */
public class GuiManager {

    public static final int SLOT_MAIN_ORDERS = 29;
    public static final int SLOT_MAIN_PICKUP = 31;

    // Bottom-Row der 54er Menüs
    public static final int SLOT_BACK = 45;
    public static final int SLOT_PREV = 45;
    public static final int SLOT_BUY_ORDER = 47;
    public static final int SLOT_ALL = 47;
    public static final int SLOT_QUICKSELL = 49;
    public static final int SLOT_CENTER = 49;
    public static final int SLOT_INSTANT = 48;
    public static final int SLOT_SELL_OFFER = 51;
    public static final int SLOT_NEXT = 53;
    public static final int SLOT_PICKUP = 53;

    private static final int PAGE_SIZE = 45;

    private final SpookyCraftCore plugin;
    private final ShopManager shop;
    private final MarketRepository repo;
    private final MarketService service;
    private final BookMarket books;

    public GuiManager(SpookyCraftCore plugin, ShopManager shop, MarketRepository repo, MarketService service) {
        this.plugin = plugin;
        this.shop = shop;
        this.repo = repo;
        this.service = service;
        this.books = new BookMarket(plugin);
    }

    public BookMarket books() {
        return books;
    }

    // ------------------------------------------------------------------ Bausteine

    private static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private static ItemStack icon(Material material, int amount, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            if (lore != null && !lore.isEmpty()) {
                List<String> colored = new ArrayList<>();
                for (String line : lore) colored.add(color(line));
                meta.setLore(colored);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static ItemStack icon(Material material, String name, String... lore) {
        return icon(material, 1, name, List.of(lore));
    }

    private static void fill(Inventory inv) {
        ItemStack pane = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
    }

    private static String price(double value) {
        return "$" + MarketService.fmt(value);
    }

    private static List<String> statLines(MarketRepository.Stat stat) {
        List<String> lore = new ArrayList<>();
        if (stat != null && stat.bestOffer() >= 0) {
            lore.add("&aKaufen ab: &f" + price(stat.bestOffer()) + " &8(" + stat.offerAmount() + " Stück im Angebot)");
        } else {
            lore.add("&aKaufen: &7keine Angebote");
        }
        if (stat != null && stat.bestBuy() >= 0) {
            lore.add("&6Verkaufen für: &f" + price(stat.bestBuy()) + " &8(" + stat.buyAmount() + " Stück gesucht)");
        } else {
            lore.add("&6Verkaufen: &7keine Kaufaufträge");
        }
        return lore;
    }

    private static int[] categorySlots(int count) {
        if (count <= 7) {
            int start = 9 + (9 - count) / 2;
            int[] slots = new int[count];
            for (int i = 0; i < count; i++) slots[i] = start + i;
            return slots;
        }
        return new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    }

    // ------------------------------------------------------------------ Hauptmenü

    public void openMain(Player player) {
        MarktHolder holder = new MarktHolder(MarktHolder.Type.MAIN, null, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 36, color("&8&lMarkt"));
        fill(inv);

        List<ShopCategory> categories = new ArrayList<>(shop.getCategories().values());
        int[] slots = categorySlots(categories.size() + 1);
        for (int i = 0; i < categories.size() && i < slots.length - 1; i++) {
            ShopCategory category = categories.get(i);
            inv.setItem(slots[i], icon(category.getIcon(), 1, category.getDisplayName(),
                    List.of("&7" + category.getItems().size() + " Items", "", "&eKlicken zum Stöbern")));
            holder.categoryBySlot().put(slots[i], category.getKey());
        }
        int bookSlot = slots[Math.min(categories.size(), slots.length - 1)];
        inv.setItem(bookSlot, icon(Material.ENCHANTED_BOOK, 1, "&dVerzauberte Bücher",
                List.of("&7" + books.all().size() + " Bücher", "", "&eKlicken zum Stöbern")));
        holder.categoryBySlot().put(bookSlot, BookMarket.KEY);

        UUID uuid = player.getUniqueId();
        int ownOrders = repo.countOrdersOf(uuid);
        int pickup = repo.countPickupItems(uuid);
        if (ownOrders > 0 || !service.serverOnly()) inv.setItem(SLOT_MAIN_ORDERS, icon(Material.BOOK, "&eMeine Aufträge",
                "&7Aktive Aufträge: &f" + ownOrders, "", "&eKlicken zum Verwalten"));
        inv.setItem(SLOT_MAIN_PICKUP, icon(pickup > 0 ? Material.ENDER_CHEST : Material.CHEST, "&aAbholen",
                pickup > 0 ? "&f" + pickup + " &7Item(s) warten auf dich" : "&7Nichts zum Abholen", "",
                "&eKlicken zum Abholen"));
        if (service.serverOnly()) {
            inv.setItem(33, icon(Material.PAPER, "&bSo funktioniert der Markt",
                    "&7Wähle eine Kategorie und ein Item.",
                    "&aKaufen: &7Linksklick - der Server verkauft alles.",
                    "&6Verkaufen: &7Rechtsklick - der Server kauft alles an.",
                    "&7Schnell verkaufen: &f/sell &7und &f/sellall"));
        } else {
            inv.setItem(33, icon(Material.PAPER, "&bSo funktioniert der Markt",
                    "&7Wähle eine Kategorie und ein Item.",
                    "&aKaufen: &7aus einem Verkaufsangebot oder per Kaufauftrag.",
                    "&6Verkaufen: &7in einen Kaufauftrag oder als Angebot.",
                    "&7Gekaufte Items holst du hier ab.",
                    "&7Schnell verkaufen: &f/sell",
                    "&bDirekt kaufen: &7Linksklick auf ein Item."));
        }
        player.openInventory(inv);
    }

    // ------------------------------------------------------------------ Kategorie

    /** Kategorie "Verzauberte Bücher": jedes Buch sofort vom Server kaufen oder an ihn verkaufen. */
    public void openBooks(Player player, int page) {
        List<BookMarket.Book> all = books.all();
        int pages = Math.max(1, (int) Math.ceil(all.size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, pages - 1));

        MarktHolder holder = new MarktHolder(MarktHolder.Type.CATEGORY, BookMarket.KEY, null, page);
        Inventory inv = Bukkit.createInventory(holder, 54, color("&8&lMarkt: &r&dVerzauberte Bücher"));
        fill(inv);

        int from = page * PAGE_SIZE;
        for (int i = from; i < Math.min(all.size(), from + PAGE_SIZE); i++) {
            BookMarket.Book book = all.get(i);
            List<String> lore = new ArrayList<>();
            lore.add("&aKaufen: &f" + price(books.buyPrice(book)) + " &7pro Buch");
            lore.add("&6Verkaufen: &f" + price(books.sellPrice(book)) + " &7pro Buch");
            lore.add("&7In deinem Inventar: &f" + books.count(player, book));
            lore.add("");
            lore.add("&eLinksklick: &f1 kaufen");
            lore.add("&eShift-Linksklick: &f5 kaufen");
            lore.add("&eRechtsklick: &f1 verkaufen");
            lore.add("&eShift-Rechtsklick: &falle verkaufen");
            int slot = i - from;
            ItemStack stack = books.create(book, 1);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(color("&d" + BookMarket.title(book)));
                List<String> colored = new ArrayList<>();
                for (String line : lore) colored.add(color(line));
                meta.setLore(colored);
                stack.setItemMeta(meta);
            }
            inv.setItem(slot, stack);
            holder.bookBySlot().put(slot, book.id());
        }

        inv.setItem(SLOT_CENTER, icon(Material.ARROW, "&eZurück zum Markt"));
        if (page > 0) inv.setItem(SLOT_PREV, icon(Material.SPECTRAL_ARROW, "&7Vorherige Seite", "&8Seite " + page + "/" + pages));
        if (page < pages - 1) inv.setItem(SLOT_NEXT, icon(Material.SPECTRAL_ARROW, "&7Nächste Seite", "&8Seite " + (page + 2) + "/" + pages));
        player.openInventory(inv);
    }

    public void openCategory(Player player, String categoryKey, int page) {
        if (BookMarket.KEY.equals(categoryKey)) {
            openBooks(player, page);
            return;
        }
        ShopCategory category = shop.getCategories().get(categoryKey);
        if (category == null) {
            openMain(player);
            return;
        }
        List<ShopItem> items = category.getItems();
        int pages = Math.max(1, (int) Math.ceil(items.size() / (double) PAGE_SIZE));
        page = Math.max(0, Math.min(page, pages - 1));

        MarktHolder holder = new MarktHolder(MarktHolder.Type.CATEGORY, categoryKey, null, page);
        Inventory inv = Bukkit.createInventory(holder, 54, color("&8&lMarkt: &r" + category.getDisplayName()));
        fill(inv);

        Map<Material, MarketRepository.Stat> stats = repo.getStats();
        int from = page * PAGE_SIZE;
        for (int i = from; i < Math.min(items.size(), from + PAGE_SIZE); i++) {
            Material material = items.get(i).getMaterial();
            List<String> lore;
            if (service.serverOnly()) {
                lore = new ArrayList<>();
                double buyPrice = service.serverPriceOf(material);
                double sellPrice = service.serverBuyPriceOf(material);
                lore.add(buyPrice > 0 ? "&aKaufen: &f" + price(buyPrice) + " &7pro Stück" : "&aKaufen: &7nicht verfügbar");
                lore.add(sellPrice > 0 ? "&6Verkaufen: &f" + price(sellPrice) + " &7pro Stück" : "&6Verkaufen: &7wird nicht angekauft");
                lore.add("&7In deinem Inventar: &f" + service.countPlain(player, material));
                lore.add("");
                lore.add("&eLinksklick: &f1 kaufen");
                lore.add("&eShift-Linksklick: &f64 kaufen");
                lore.add("&eRechtsklick: &f1 verkaufen");
                lore.add("&eShift-Rechtsklick: &falle verkaufen");
            } else {
                lore = statLines(stats.get(material));
                double serverPrice = service.serverPriceOf(material);
                if (serverPrice > 0) lore.add("&bServer-Sofortkauf: &f" + price(serverPrice) + " &7pro Stück");
                lore.add("");
                lore.add("&eLinksklick: &f1 direkt kaufen");
                lore.add("&eShift-Linksklick: &f64 direkt kaufen");
                lore.add("&eRechtsklick: &fHandelsmenü");
            }
            int slot = i - from;
            inv.setItem(slot, icon(material, 1, "&f" + MarketService.name(material), lore));
            holder.materialBySlot().put(slot, material);
        }

        inv.setItem(SLOT_CENTER, icon(Material.ARROW, "&eZurück zum Markt"));
        if (page > 0) inv.setItem(SLOT_PREV, icon(Material.SPECTRAL_ARROW, "&7Vorherige Seite", "&8Seite " + page + "/" + pages));
        if (page < pages - 1) inv.setItem(SLOT_NEXT, icon(Material.SPECTRAL_ARROW, "&7Nächste Seite", "&8Seite " + (page + 2) + "/" + pages));
        player.openInventory(inv);
    }

    // ------------------------------------------------------------------ Item-Handelsmenü

    public void openItem(Player player, Material material, String categoryKey) {
        MarktHolder holder = new MarktHolder(MarktHolder.Type.ITEM, categoryKey, material, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, color("&8&lMarkt: &r" + MarketService.name(material)));
        fill(inv);

        List<MarketOrder> offers = repo.getOrders(material, false);
        List<MarketOrder> buys = repo.getOrders(material, true);
        UUID uuid = player.getUniqueId();

        // Kopfzeile
        inv.setItem(1, icon(Material.LIME_STAINED_GLASS_PANE, "&aVerkaufsangebote", "&7Hier kaufst du (günstigste zuerst)."));
        inv.setItem(7, icon(Material.ORANGE_STAINED_GLASS_PANE, "&6Kaufaufträge", "&7Hier verkaufst du (höchster Preis zuerst)."));
        MarketRepository.Stat stat = new MarketRepository.Stat(
                offers.isEmpty() ? -1 : offers.get(0).price(), offers.stream().mapToInt(MarketOrder::remaining).sum(),
                buys.isEmpty() ? -1 : buys.get(0).price(), buys.stream().mapToInt(MarketOrder::remaining).sum());
        List<String> centerLore = statLines(stat);
        centerLore.add("");
        if (service.serverPriceOf(material) > 0) {
            centerLore.add("&bServer-Sofortkauf: &f" + price(service.serverPriceOf(material)) + " &7pro Stück");
        }
        if (service.minPriceOf(material) > 0) {
            centerLore.add("&7Mindestpreis: &f" + price(service.minPriceOf(material)) + " &7pro Stück");
        }
        centerLore.add("&7In deinem Inventar: &f" + service.countPlain(player, material));
        inv.setItem(4, icon(material, 1, "&f" + MarketService.name(material), centerLore));

        // Trennlinie
        ItemStack separator = icon(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int row = 1; row <= 4; row++) inv.setItem(row * 9 + 4, separator);

        // 4x4 Angebote links, 4x4 Aufträge rechts
        for (int i = 0; i < 16; i++) {
            int row = i / 4 + 1;
            int col = i % 4;
            if (i < offers.size()) {
                int slot = row * 9 + col;
                inv.setItem(slot, orderIcon(offers.get(i), uuid));
                holder.orderBySlot().put(slot, offers.get(i).id());
            }
            if (i < buys.size()) {
                int slot = row * 9 + 5 + col;
                inv.setItem(slot, orderIcon(buys.get(i), uuid));
                holder.orderBySlot().put(slot, buys.get(i).id());
            }
        }

        int plain = service.countPlain(player, material);
        inv.setItem(SLOT_BACK, icon(Material.ARROW, "&eZurück"));
        inv.setItem(SLOT_BUY_ORDER, icon(Material.GOLD_INGOT, "&6Kaufauftrag erstellen",
                "&7Du legst Menge und Preis pro Stück fest.", "&7Das Geld wird sofort reserviert.", "&8Gebühr: 1 % beim Erstellen, 2 % beim Kauf", "", "&eKlicken, dann im Chat eingeben"));
        double cheapest = service.cheapestBuyPrice(uuid, material);
        inv.setItem(SLOT_INSTANT, icon(Material.LIME_CONCRETE, "&aSofort kaufen",
                cheapest > 0 ? "&7Günstigster Preis: &f" + price(cheapest) + " &7pro Stück" : "&7Gerade kein Angebot verfügbar",
                "&7Kauft automatisch zum günstigsten Preis", "", "&eLinksklick: &f1 kaufen", "&eRechtsklick: &f16 kaufen",
                "&eShift-Linksklick: &f64 kaufen"));
        inv.setItem(SLOT_QUICKSELL, icon(Material.HOPPER, "&bSchnellverkauf",
                "&7Verkauft &f" + plain + "x &7aus deinem Inventar", "&7sofort an die höchsten Kaufaufträge.", "", "&eKlicken zum Verkaufen"));
        inv.setItem(SLOT_SELL_OFFER, icon(Material.EMERALD, "&aVerkaufsangebot erstellen",
                "&7Du legst Menge und Preis pro Stück fest.", "&7Die Items werden sofort reserviert.", "&8Gebühr: 1 % beim Erstellen", "", "&eKlicken, dann im Chat eingeben"));
        int pickup = repo.countPickupItems(uuid);
        inv.setItem(SLOT_PICKUP, icon(pickup > 0 ? Material.ENDER_CHEST : Material.CHEST, "&aAbholen",
                pickup > 0 ? "&f" + pickup + " &7Item(s) warten auf dich" : "&7Nichts zum Abholen"));
        player.openInventory(inv);
    }

    private ItemStack orderIcon(MarketOrder order, UUID viewer) {
        boolean own = order.owner().equals(viewer);
        List<String> lore = new ArrayList<>();
        lore.add("&7" + (order.buy() ? "Käufer: " : "Anbieter: ") + "&f" + (order.ownerName() == null ? "?" : order.ownerName()));
        lore.add("&7Preis: &a" + price(order.price()) + " &7pro Stück");
        lore.add("&7" + (order.buy() ? "Gesucht: " : "Angeboten: ") + "&f" + order.remaining() + " Stück");
        lore.add("");
        if (own) {
            lore.add("&6Das ist dein Auftrag.");
            lore.add("&cShift-Rechtsklick: abbrechen");
        } else if (order.buy()) {
            lore.add("&eLinksklick: &f1 verkaufen");
            lore.add("&eShift-Linksklick: &f64 verkaufen");
            lore.add("&eRechtsklick: &falle verkaufen");
        } else {
            lore.add("&8Beim Kauf kommen 2 % Gebühr dazu.");
            lore.add("&eLinksklick: &f1 kaufen");
            lore.add("&eShift-Linksklick: &f64 kaufen");
            lore.add("&eRechtsklick: &falle kaufen");
        }
        return icon(order.material(), order.remaining(), (own ? "&6" : "&f") + MarketService.name(order.material()), lore);
    }

    // ------------------------------------------------------------------ Meine Aufträge

    public void openOrders(Player player) {
        MarktHolder holder = new MarktHolder(MarktHolder.Type.ORDERS, null, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, color("&8&lMarkt: &rMeine Aufträge"));
        fill(inv);
        List<MarketOrder> orders = repo.getOrdersOf(player.getUniqueId());
        for (int i = 0; i < orders.size() && i < PAGE_SIZE; i++) {
            MarketOrder order = orders.get(i);
            List<String> lore = new ArrayList<>();
            lore.add(order.buy() ? "&6Kaufauftrag" : "&aVerkaufsangebot");
            lore.add("&7Preis: &a" + price(order.price()) + " &7pro Stück");
            lore.add("&7Offen: &f" + order.remaining() + " Stück");
            lore.add("");
            lore.add("&cShift-Rechtsklick: abbrechen");
            inv.setItem(i, icon(order.material(), order.remaining(), "&f" + MarketService.name(order.material()), lore));
            holder.orderBySlot().put(i, order.id());
        }
        if (orders.isEmpty()) {
            inv.setItem(22, icon(Material.BARRIER, "&7Du hast keine aktiven Aufträge."));
        }
        inv.setItem(SLOT_CENTER, icon(Material.ARROW, "&eZurück zum Markt"));
        inv.setItem(SLOT_PICKUP, icon(Material.CHEST, "&aAbholen"));
        player.openInventory(inv);
    }

    // ------------------------------------------------------------------ Abholung

    public void openPickup(Player player) {
        MarktHolder holder = new MarktHolder(MarktHolder.Type.PICKUP, null, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, color("&8&lMarkt: &rAbholen"));
        fill(inv);
        Map<Material, Integer> pickups = repo.getPickups(player.getUniqueId());
        int slot = 0;
        for (Map.Entry<Material, Integer> entry : pickups.entrySet()) {
            if (slot >= PAGE_SIZE) break;
            inv.setItem(slot, icon(entry.getKey(), entry.getValue(), "&f" + MarketService.name(entry.getKey()),
                    List.of("&7Wartet: &f" + entry.getValue() + " Stück", "", "&eKlicken zum Abholen")));
            holder.materialBySlot().put(slot, entry.getKey());
            slot++;
        }
        if (pickups.isEmpty()) {
            inv.setItem(22, icon(Material.BARRIER, "&7Es liegt nichts zur Abholung bereit."));
        } else {
            inv.setItem(SLOT_ALL, icon(Material.EMERALD_BLOCK, "&aAlles abholen", "&7Holt alles ab, was ins Inventar passt."));
        }
        inv.setItem(SLOT_CENTER, icon(Material.ARROW, "&eZurück zum Markt"));
        player.openInventory(inv);
    }
}
