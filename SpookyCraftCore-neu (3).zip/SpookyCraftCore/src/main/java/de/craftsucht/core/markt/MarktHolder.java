package de.craftsucht.core.markt;

import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

/** Merkt sich, welche Ansicht offen ist und was hinter den einzelnen Slots steckt. */
public class MarktHolder implements InventoryHolder {

    public enum Type {
        MAIN,
        CATEGORY,
        ITEM,
        ORDERS,
        PICKUP
    }

    private final Type type;
    private final String categoryKey;
    private final Material material;
    private final int page;

    private final Map<Integer, String> categoryBySlot = new HashMap<>();
    private final Map<Integer, Material> materialBySlot = new HashMap<>();
    private final Map<Integer, Integer> orderBySlot = new HashMap<>();
    private final Map<Integer, String> bookBySlot = new HashMap<>();

    public MarktHolder(Type type, String categoryKey, Material material, int page) {
        this.type = type;
        this.categoryKey = categoryKey;
        this.material = material;
        this.page = page;
    }

    public Type getType() {
        return type;
    }

    public String getCategoryKey() {
        return categoryKey;
    }

    public Material getMaterial() {
        return material;
    }

    public int getPage() {
        return page;
    }

    public Map<Integer, String> categoryBySlot() {
        return categoryBySlot;
    }

    public Map<Integer, Material> materialBySlot() {
        return materialBySlot;
    }

    public Map<Integer, Integer> orderBySlot() {
        return orderBySlot;
    }

    /** Slot -> Buch-ID (Kategorie "Verzauberte Bücher"). */
    public Map<Integer, String> bookBySlot() {
        return bookBySlot;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }
}
