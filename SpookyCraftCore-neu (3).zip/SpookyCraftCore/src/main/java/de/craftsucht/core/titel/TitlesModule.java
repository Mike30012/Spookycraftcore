package de.craftsucht.core.titel;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.erfolge.AchievementsModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.prestige.PrestigeModule;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /titel - Titel, die im Chat vor dem Namen stehen. Freischalten per Erfolg, Prestige, Kauf oder Recht.
 * Eigene Liste in der config.yml unter titel.list, sonst gilt die eingebaute. Stände in titles.yml.
 */
public class TitlesModule implements Module, CommandExecutor, Listener {

    private record Def(String id, String name, String unlock) {
    }

    private static final class TitleHolder implements InventoryHolder {
        final List<Def> shown = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static TitlesModule INSTANCE;

    /** Titel fuer den Chat, z.B. "§8[§r§5Geisterjäger§8] §r" - leer, wenn keiner gewählt ist. */
    public static String chatPart(Player p) {
        TitlesModule m = INSTANCE;
        if (m == null) return "";
        try {
            String sel = m.data.getString("players." + p.getUniqueId() + ".selected");
            if (sel == null) return "";
            for (Def d : m.defs()) {
                if (d.id.equals(sel) && m.owned(p, d)) {
                    return "§8[§r" + GuiUtil.c(d.name).replace("%", "") + "§8] §r";
                }
            }
        } catch (RuntimeException ignored) {
            // nie den Chat gefährden
        }
        return "";
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public TitlesModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "titel";
    }

    @Override
    public void enable() {
        INSTANCE = this;
        file = new File(plugin.getDataFolder(), "titles.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("titel").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        INSTANCE = null;
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("titles.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private List<Def> defs() {
        List<Def> out = new ArrayList<>();
        List<Map<?, ?>> cfg = plugin.getConfig().getMapList("titel.list");
        if (!cfg.isEmpty()) {
            for (Map<?, ?> m : cfg) {
                out.add(new Def(String.valueOf(m.get("id")), String.valueOf(m.get("name")),
                        m.get("unlock") == null ? "free" : String.valueOf(m.get("unlock"))));
            }
            return out;
        }
        out.add(new Def("neuling", "&7Neuling", "free"));
        out.add(new Def("geisterjaeger", "&5Geisterjäger", "achievement:kills_100"));
        out.add(new Def("seelenjaeger", "&dSeelenjäger", "achievement:kills_1000"));
        out.add(new Def("minenarbeiter", "&6Minenarbeiter", "achievement:blocks_10000"));
        out.add(new Def("grabegeist", "&8Grabegeist", "achievement:blocks_100000"));
        out.add(new Def("stammgast", "&aStammgast", "achievement:playtime_10"));
        out.add(new Def("veteran", "&bVeteran", "achievement:playtime_50"));
        out.add(new Def("urgestein", "&3Urgestein", "achievement:playtime_200"));
        out.add(new Def("wohlhabend", "&eWohlhabend", "achievement:money_100k"));
        out.add(new Def("millionaer", "&6&lMillionär", "achievement:money_1m"));
        out.add(new Def("fachmann", "&aFachmann", "achievement:job_max"));
        out.add(new Def("prestige1", "&d★ Wiedergeboren", "prestige:1"));
        out.add(new Def("prestige5", "&c★★★ Legende", "prestige:5"));
        out.add(new Def("pfandleiher", "&2Pfandleiher", "price:50000"));
        out.add(new Def("geisterfreund", "&fGeisterfreund", "price:100000"));
        return out;
    }

    private boolean bought(UUID id, String title) {
        return data.getStringList("players." + id + ".bought").contains(title);
    }

    private boolean owned(Player p, Def d) {
        String u = d.unlock;
        if (u.equalsIgnoreCase("free")) return true;
        if (bought(p.getUniqueId(), d.id)) return true;
        int c = u.indexOf(':');
        if (c < 0) return false;
        String kind = u.substring(0, c).toLowerCase();
        String val = u.substring(c + 1);
        switch (kind) {
            case "achievement":
                return AchievementsModule.isDone(p.getUniqueId(), val);
            case "prestige":
                try {
                    return PrestigeModule.total(p.getUniqueId()) >= Integer.parseInt(val);
                } catch (NumberFormatException e) {
                    return false;
                }
            case "permission":
                return p.hasPermission(val);
            default:
                return false;
        }
    }

    private long price(Def d) {
        if (!d.unlock.toLowerCase().startsWith("price:")) return -1;
        try {
            return Long.parseLong(d.unlock.substring(6));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private String requirement(Def d) {
        String u = d.unlock;
        int c = u.indexOf(':');
        if (c < 0) return "&7Nicht freigeschaltet";
        String val = u.substring(c + 1);
        return switch (u.substring(0, c).toLowerCase()) {
            case "achievement" -> "&7Erfolg: " + AchievementsModule.nameOf(val);
            case "prestige" -> "&7Prestige-Stufen gesamt: &f" + val;
            case "price" -> "&7Preis: &e" + GuiUtil.money(price(d));
            case "permission" -> "&7Nur für bestimmte Ränge";
            default -> "&7Nicht freigeschaltet";
        };
    }

    // ------------------------------------------------------------------ Menue

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        open(p);
        return true;
    }

    private void open(Player p) {
        TitleHolder h = new TitleHolder();
        List<Def> defs = defs();
        int rows = Math.max(2, Math.min(6, (defs.size() + 8) / 9 + 1));
        Inventory inv = Bukkit.createInventory(h, rows * 9, GuiUtil.c("&e&l☠ &6Titel"));
        ItemStack pane = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        String sel = data.getString("players." + p.getUniqueId() + ".selected");
        for (int i = 0; i < defs.size() && i < inv.getSize() - 9; i++) {
            Def d = defs.get(i);
            h.shown.add(d);
            boolean own = owned(p, d);
            List<String> lore = new ArrayList<>();
            lore.add("&7So sieht es aus: " + d.name);
            ItemStack it;
            if (own) {
                boolean on = d.id.equals(sel);
                lore.add(on ? "&a✔ Ausgewählt &7(Klick: ablegen)" : "&eKlick: &7auswählen");
                it = GuiUtil.item(Material.NAME_TAG, d.name, lore);
                if (on) it = GuiUtil.glow(it);
            } else {
                lore.add(requirement(d));
                if (price(d) > 0) lore.add("&eKlick: &7kaufen");
                it = GuiUtil.item(Material.GRAY_DYE, d.name, lore);
            }
            inv.setItem(i, it);
        }
        inv.setItem(inv.getSize() - 5, GuiUtil.item(Material.BARRIER, "&cTitel ablegen"));
        p.openInventory(inv);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof TitleHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof TitleHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        p.playSound(p.getLocation(), "ui.button.click", 0.6f, 1.0f);
        if (slot == e.getView().getTopInventory().getSize() - 5) {
            data.set("players." + p.getUniqueId() + ".selected", null);
            save();
            open(p);
            return;
        }
        if (slot < 0 || slot >= h.shown.size()) return;
        Def d = h.shown.get(slot);
        if (owned(p, d)) {
            String key = "players." + p.getUniqueId() + ".selected";
            data.set(key, d.id.equals(data.getString(key)) ? null : d.id);
            save();
            open(p);
            return;
        }
        long price = price(d);
        if (price <= 0) {
            plugin.getMessageUtil().send(p, "&cDen Titel hast du noch nicht freigeschaltet.");
            return;
        }
        if (!(plugin.getModuleManager().get("economy") instanceof EconomyModule em) || em.getManager() == null
                || !em.getManager().withdraw(p.getUniqueId(), price)) {
            plugin.getMessageUtil().send(p, "&cDafür fehlt dir das Geld (&f" + GuiUtil.money(price) + "&c).");
            return;
        }
        List<String> list = new ArrayList<>(data.getStringList("players." + p.getUniqueId() + ".bought"));
        list.add(d.id);
        data.set("players." + p.getUniqueId() + ".bought", list);
        data.set("players." + p.getUniqueId() + ".selected", d.id);
        save();
        plugin.getMessageUtil().send(p, "&aTitel gekauft und ausgewählt: " + d.name);
        open(p);
    }
}
