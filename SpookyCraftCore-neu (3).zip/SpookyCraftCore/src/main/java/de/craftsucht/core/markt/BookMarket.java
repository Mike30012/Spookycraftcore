package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Kategorie "Verzauberte Bücher": jedes Buch (jede Verzauberung in jeder Stufe) kann sofort vom Server gekauft
 * und an den Server verkauft werden. Preise: Grundpreis je Verzauberung (config markt.book-prices.&lt;name&gt;,
 * sonst eingebaute Werte), pro Stufe verdoppelt. Ankauf = markt.book-sell-percent % (Standard 25) des Kaufpreises.
 */
public class BookMarket {

    public static final String KEY = "buecher";

    /** Ein handelbares Buch: eine Verzauberung in einer Stufe. */
    public record Book(Enchantment enchantment, int level) {
        public String enchantKey() {
            return enchantment.getKey().getKey();
        }

        public String id() {
            return enchantKey() + ":" + level;
        }
    }

    private static final Map<String, String> NAMES = new HashMap<>();
    private static final Map<String, Double> BASE = new HashMap<>();

    static {
        String[][] names = {
                {"sharpness", "Schärfe"}, {"smite", "Bann"}, {"bane_of_arthropods", "Nemesis der Gliederfüßer"},
                {"knockback", "Rückstoß"}, {"fire_aspect", "Verbrennung"}, {"looting", "Plünderung"},
                {"sweeping_edge", "Schwungkraft"}, {"efficiency", "Effizienz"}, {"silk_touch", "Behutsamkeit"},
                {"unbreaking", "Haltbarkeit"}, {"fortune", "Glück"}, {"power", "Stärke"}, {"punch", "Schlag"},
                {"flame", "Flamme"}, {"infinity", "Unendlichkeit"}, {"luck_of_the_sea", "Glück des Meeres"},
                {"lure", "Köder"}, {"loyalty", "Treue"}, {"impaling", "Aufspießen"}, {"riptide", "Sog"},
                {"channeling", "Entladung"}, {"multishot", "Mehrfachschuss"}, {"piercing", "Durchschuss"},
                {"quick_charge", "Schnellladen"}, {"mending", "Reparatur"}, {"vanishing_curse", "Fluch des Verschwindens"},
                {"binding_curse", "Fluch der Bindung"}, {"protection", "Schutz"}, {"fire_protection", "Feuerschutz"},
                {"feather_falling", "Federfall"}, {"blast_protection", "Explosionsschutz"},
                {"projectile_protection", "Schussschutz"}, {"respiration", "Atmung"}, {"aqua_affinity", "Wasseraffinität"},
                {"thorns", "Dornen"}, {"depth_strider", "Wassergänger"}, {"frost_walker", "Eisläufer"},
                {"soul_speed", "Seelenläufer"}, {"swift_sneaking", "Flinke Schleiche"}, {"density", "Dichte"},
                {"breach", "Durchbruch"}, {"wind_burst", "Windstoß"}, {"lunge", "Ausfallschritt"}};
        for (String[] n : names) NAMES.put(n[0], n[1]);

        Object[][] base = {
                {"mending", 30000.0}, {"silk_touch", 12000.0}, {"infinity", 10000.0}, {"swift_sneaking", 5000.0},
                {"wind_burst", 5000.0}, {"fortune", 4000.0}, {"looting", 3500.0}, {"frost_walker", 3000.0},
                {"soul_speed", 3000.0}, {"density", 3000.0}, {"breach", 3000.0}, {"riptide", 3000.0},
                {"channeling", 3000.0}, {"multishot", 3000.0}, {"sharpness", 2500.0}, {"efficiency", 2500.0},
                {"protection", 2500.0}, {"power", 2500.0}, {"luck_of_the_sea", 2500.0}, {"unbreaking", 2000.0},
                {"loyalty", 2000.0}, {"impaling", 2000.0}, {"quick_charge", 2000.0}, {"sweeping_edge", 2000.0},
                {"fire_aspect", 2000.0}, {"flame", 2000.0}, {"lure", 2000.0}, {"aqua_affinity", 2000.0},
                {"depth_strider", 1800.0}, {"binding_curse", 300.0}, {"vanishing_curse", 300.0}};
        for (Object[] b : base) BASE.put((String) b[0], (Double) b[1]);
    }

    private final SpookyCraftCore plugin;
    private List<Book> cache;

    public BookMarket(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ Katalog

    /** Alle Bücher, nach deutschem Namen und Stufe sortiert. */
    public synchronized List<Book> all() {
        if (cache == null) {
            List<Book> list = new ArrayList<>();
            for (Enchantment enchantment : Registry.ENCHANTMENT) {
                int max = Math.max(1, enchantment.getMaxLevel());
                for (int level = 1; level <= max; level++) list.add(new Book(enchantment, level));
            }
            list.sort(Comparator.comparing((Book b) -> displayName(b.enchantment())).thenComparingInt(Book::level));
            cache = list;
        }
        return cache;
    }

    public Book find(String id) {
        if (id == null) return null;
        for (Book book : all()) if (book.id().equals(id)) return book;
        return null;
    }

    public static String displayName(Enchantment enchantment) {
        String key = enchantment.getKey().getKey();
        String name = NAMES.get(key);
        if (name != null) return name;
        StringBuilder sb = new StringBuilder();
        for (String part : key.split("_")) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    public static String roman(int level) {
        String[] numerals = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return level >= 1 && level <= numerals.length ? numerals[level - 1] : String.valueOf(level);
    }

    public static String title(Book book) {
        String name = displayName(book.enchantment());
        return book.enchantment().getMaxLevel() <= 1 ? name : name + " " + roman(book.level());
    }

    // ------------------------------------------------------------------ Preise

    public double buyPrice(Book book) {
        var cfg = plugin.getConfig();
        double base = cfg.getDouble("markt.book-prices." + book.enchantKey(),
                BASE.getOrDefault(book.enchantKey(), cfg.getDouble("markt.book-default-price", 1500.0)));
        return MarketService.round2(base * Math.pow(2, book.level() - 1));
    }

    public double sellPrice(Book book) {
        double percent = plugin.getConfig().getDouble("markt.book-sell-percent", 25.0);
        return MarketService.round2(buyPrice(book) * percent / 100.0);
    }

    // ------------------------------------------------------------------ Items

    public ItemStack create(Book book, int amount) {
        ItemStack stack = new ItemStack(Material.ENCHANTED_BOOK, Math.max(1, amount));
        EnchantmentStorageMeta meta = (EnchantmentStorageMeta) stack.getItemMeta();
        if (meta != null) {
            meta.addStoredEnchant(book.enchantment(), book.level(), true);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /** Genau dieses Buch: nur diese eine Verzauberung, kein eigener Name. */
    public boolean matches(ItemStack stack, Book book) {
        if (stack == null || stack.getType() != Material.ENCHANTED_BOOK || !stack.hasItemMeta()) return false;
        if (!(stack.getItemMeta() instanceof EnchantmentStorageMeta meta)) return false;
        if (meta.hasDisplayName() || meta.hasEnchants()) return false;
        Map<Enchantment, Integer> stored = meta.getStoredEnchants();
        return stored.size() == 1 && stored.getOrDefault(book.enchantment(), 0) == book.level();
    }

    public int count(Player p, Book book) {
        int count = 0;
        for (ItemStack stack : p.getInventory().getStorageContents()) {
            if (matches(stack, book)) count += stack.getAmount();
        }
        return count;
    }

    private boolean remove(Player p, Book book, int amount) {
        if (count(p, book) < amount) return false;
        ItemStack[] contents = p.getInventory().getStorageContents();
        int left = amount;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack stack = contents[i];
            if (!matches(stack, book)) continue;
            int take = Math.min(left, stack.getAmount());
            if (take == stack.getAmount()) contents[i] = null;
            else stack.setAmount(stack.getAmount() - take);
            left -= take;
        }
        p.getInventory().setStorageContents(contents);
        return true;
    }

    // ------------------------------------------------------------------ Kaufen / Verkaufen

    private EconomyManager eco() {
        return plugin.getModuleManager().get("economy") instanceof EconomyModule module ? module.getManager() : null;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    /** Kauft Bücher vom Server. Was nicht ins Inventar passt, wird nicht berechnet. */
    public boolean buy(Player p, Book book, int amount) {
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        double unit = buyPrice(book);
        int bought = 0;
        for (int i = 0; i < amount; i++) {
            if (!eco.withdraw(p.getUniqueId(), unit)) {
                msg(p, "&cDir fehlt Geld für &f" + (amount - i) + "x " + title(book) + "&c (je $" + MarketService.fmt(unit) + ").");
                break;
            }
            if (!p.getInventory().addItem(create(book, 1)).isEmpty()) {
                eco.deposit(p.getUniqueId(), unit);
                msg(p, "&cDein Inventar ist voll.");
                break;
            }
            bought++;
        }
        if (bought > 0) {
            msg(p, "&a" + bought + "x &dBuch: " + title(book) + " &agekauft für &f$" + MarketService.fmt(bought * unit));
        }
        return bought > 0;
    }

    /** Verkauft Bücher an den Server. amount &lt;= 0 = alle dieses Buchs. */
    public boolean sell(Player p, Book book, int amount) {
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        int have = count(p, book);
        int take = amount <= 0 ? have : Math.min(amount, have);
        if (take <= 0) {
            msg(p, "&cDu hast kein &f" + title(book).toLowerCase(Locale.ROOT) + " &c(als Buch ohne Namen) im Inventar.");
            return false;
        }
        if (!remove(p, book, take)) return false;
        double gain = MarketService.round2(take * sellPrice(book));
        eco.deposit(p.getUniqueId(), gain);
        msg(p, "&a" + take + "x &dBuch: " + title(book) + " &averkauft für &f$" + MarketService.fmt(gain));
        return true;
    }
}
