package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Klicks im Markt-GUI + Chat-Eingabe für "Kaufauftrag/Verkaufsangebot erstellen". */
public class GuiListener implements Listener {

    private static final long INPUT_TIMEOUT_MILLIS = 90_000L;

    private record Pending(Material material, boolean buy, String categoryKey, long expiresAt) {
    }

    private final SpookyCraftCore plugin;
    private final MarketRepository repo;
    private final MarketService service;
    private final GuiManager gui;
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public GuiListener(SpookyCraftCore plugin, MarketRepository repo, MarketService service, GuiManager gui) {
        this.plugin = plugin;
        this.repo = repo;
        this.service = service;
        this.gui = gui;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MarktHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        pending.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MarktHolder holder)) return;
        event.setCancelled(true); // im Markt-GUI darf nie etwas verschoben werden
        if (!(event.getWhoClicked() instanceof Player player)) return;

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getView().getTopInventory().getSize()) return;
        ClickType click = event.getClick();

        String bookId = holder.getType() == MarktHolder.Type.CATEGORY ? holder.bookBySlot().get(slot) : null;
        if (bookId != null) {
            BookMarket.Book book = gui.books().find(bookId);
            if (book != null) {
                switch (click) {
                    case LEFT -> gui.books().buy(player, book, 1);
                    case SHIFT_LEFT -> gui.books().buy(player, book, 5);
                    case RIGHT -> gui.books().sell(player, book, 1);
                    case SHIFT_RIGHT -> gui.books().sell(player, book, 0);
                    default -> { }
                }
                gui.openBooks(player, holder.getPage());
            }
            return;
        }

        switch (holder.getType()) {
            case MAIN -> {
                String category = holder.categoryBySlot().get(slot);
                if (category != null) {
                    gui.openCategory(player, category, 0);
                } else if (slot == GuiManager.SLOT_MAIN_ORDERS) {
                    gui.openOrders(player);
                } else if (slot == GuiManager.SLOT_MAIN_PICKUP) {
                    gui.openPickup(player);
                }
            }
            case CATEGORY -> {
                Material material = holder.materialBySlot().get(slot);
                if (material != null) {
                    if (click == ClickType.LEFT || click == ClickType.SHIFT_LEFT) {
                        service.buyInstant(player, material, click == ClickType.SHIFT_LEFT ? 64 : 1);
                        gui.openCategory(player, holder.getCategoryKey(), holder.getPage());
                    } else if (service.serverOnly()) {
                        if (click == ClickType.RIGHT) service.quickSell(player, material, 1);
                        else if (click == ClickType.SHIFT_RIGHT) service.quickSell(player, material, 2304);
                        gui.openCategory(player, holder.getCategoryKey(), holder.getPage());
                    } else {
                        gui.openItem(player, material, holder.getCategoryKey());
                    }
                } else if (slot == GuiManager.SLOT_CENTER) {
                    gui.openMain(player);
                } else if (slot == GuiManager.SLOT_PREV && holder.getPage() > 0) {
                    gui.openCategory(player, holder.getCategoryKey(), holder.getPage() - 1);
                } else if (slot == GuiManager.SLOT_NEXT) {
                    gui.openCategory(player, holder.getCategoryKey(), holder.getPage() + 1);
                }
            }
            case ITEM -> handleItemClick(player, holder, slot, click);
            case ORDERS -> {
                Integer orderId = holder.orderBySlot().get(slot);
                if (orderId != null) {
                    if (click == ClickType.SHIFT_RIGHT) {
                        service.cancelOrder(player, orderId);
                        gui.openOrders(player);
                    } else {
                        msg(player, "&7Zum Abbrechen: &eShift-Rechtsklick &7auf den Auftrag.");
                    }
                } else if (slot == GuiManager.SLOT_CENTER) {
                    gui.openMain(player);
                } else if (slot == GuiManager.SLOT_PICKUP) {
                    gui.openPickup(player);
                }
            }
            case PICKUP -> {
                Material material = holder.materialBySlot().get(slot);
                if (material != null) {
                    service.claim(player, material);
                    gui.openPickup(player);
                } else if (slot == GuiManager.SLOT_ALL) {
                    service.claim(player, null);
                    gui.openPickup(player);
                } else if (slot == GuiManager.SLOT_CENTER) {
                    gui.openMain(player);
                }
            }
        }
    }

    private void handleItemClick(Player player, MarktHolder holder, int slot, ClickType click) {
        Material material = holder.getMaterial();

        if (slot == GuiManager.SLOT_BACK) {
            if (holder.getCategoryKey() != null) {
                gui.openCategory(player, holder.getCategoryKey(), 0);
            } else {
                gui.openMain(player);
            }
            return;
        }
        if (slot == GuiManager.SLOT_BUY_ORDER || slot == GuiManager.SLOT_SELL_OFFER) {
            boolean buy = slot == GuiManager.SLOT_BUY_ORDER;
            pending.put(player.getUniqueId(), new Pending(material, buy, holder.getCategoryKey(),
                    System.currentTimeMillis() + INPUT_TIMEOUT_MILLIS));
            player.closeInventory();
            msg(player, (buy ? "&6Kaufauftrag" : "&aVerkaufsangebot") + " für &f" + MarketService.name(material) + "&7:");
            msg(player, "&7Schreibe &fMenge Preis-pro-Stück &7in den Chat, z.B. &f64 3.50 &7(oder &fabbrechen&7).");
            return;
        }
        if (slot == GuiManager.SLOT_INSTANT) {
            int amount = switch (click) {
                case LEFT -> 1;
                case RIGHT -> 16;
                case SHIFT_LEFT -> 64;
                default -> 0;
            };
            if (amount > 0) service.buyInstant(player, material, amount);
            gui.openItem(player, material, holder.getCategoryKey());
            return;
        }
        if (slot == GuiManager.SLOT_QUICKSELL) {
            service.quickSell(player, material, service.countPlain(player, material));
            gui.openItem(player, material, holder.getCategoryKey());
            return;
        }
        if (slot == GuiManager.SLOT_PICKUP) {
            gui.openPickup(player);
            return;
        }

        Integer orderId = holder.orderBySlot().get(slot);
        if (orderId == null) return;
        MarketOrder order = repo.getOrder(orderId);
        if (order != null && order.owner().equals(player.getUniqueId())) {
            if (click == ClickType.SHIFT_RIGHT) {
                service.cancelOrder(player, orderId);
            } else {
                msg(player, "&7Das ist dein Auftrag. Abbrechen mit &eShift-Rechtsklick&7.");
            }
        } else if (order != null) {
            int amount = switch (click) {
                case LEFT -> 1;
                case SHIFT_LEFT -> 64;
                case RIGHT -> order.remaining();
                default -> 0;
            };
            if (amount > 0) {
                if (order.buy()) {
                    service.sellToBuyOrder(player, orderId, amount);
                } else {
                    service.buyFromOffer(player, orderId, amount);
                }
            }
        } else {
            msg(player, "&cDieser Auftrag existiert nicht mehr.");
        }
        gui.openItem(player, material, holder.getCategoryKey());
    }

    // ------------------------------------------------------------------ Chat-Eingabe: "<menge> <preis>"

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Pending pend = pending.get(event.getPlayer().getUniqueId());
        if (pend == null) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        String text = event.getMessage().trim();
        Bukkit.getScheduler().runTask(plugin, () -> handleInput(player, pend, text));
    }

    private void handleInput(Player player, Pending pend, String text) {
        pending.remove(player.getUniqueId());
        if (System.currentTimeMillis() > pend.expiresAt()) {
            msg(player, "&cDie Eingabe ist abgelaufen. Öffne das Handelsmenü erneut.");
            return;
        }
        if (text.equalsIgnoreCase("abbrechen") || text.equalsIgnoreCase("cancel")) {
            msg(player, "&7Abgebrochen.");
            gui.openItem(player, pend.material(), pend.categoryKey());
            return;
        }
        String[] parts = text.split("\\s+");
        int amount;
        double price;
        try {
            if (parts.length != 2) throw new NumberFormatException();
            amount = Integer.parseInt(parts[0]);
            price = Double.parseDouble(parts[1].replace(',', '.'));
        } catch (NumberFormatException e) {
            msg(player, "&cUngültige Eingabe. Format: &fMenge Preis-pro-Stück &c(z.B. &f64 3.50&c). Bitte erneut im Menü starten.");
            gui.openItem(player, pend.material(), pend.categoryKey());
            return;
        }
        if (pend.buy()) {
            service.createBuyOrder(player, pend.material(), amount, price);
        } else {
            service.createSellOffer(player, pend.material(), amount, price);
        }
        gui.openItem(player, pend.material(), pend.categoryKey());
    }
}
