package de.craftsucht.core.gehalt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.rank.RankModule;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Gehalt für Ränge: Wer online ist und länger als "minutes" nichts bekommen hat, erhält das Gehalt seines Rangs.
 * Kein Nachzahlen für Offline-Zeit. Einstellungen: config gehalt.ranks.<rang>: {amount, minutes}. /gehalt zeigt das eigene.
 */
public class GehaltModule implements Module, Listener, CommandExecutor {

    private final SpookyCraftCore plugin;
    private final Map<UUID, Long> lastPaid = new HashMap<>();
    private File file;
    private BukkitTask task;

    public GehaltModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "gehalt";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "gehalt.yml");
        lastPaid.clear();
        if (file.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
            ConfigurationSection sec = y.getConfigurationSection("lastpaid");
            if (sec != null) {
                for (String k : sec.getKeys(false)) {
                    try {
                        lastPaid.put(UUID.fromString(k), sec.getLong(k));
                    } catch (IllegalArgumentException ignored) {
                    }
                }
            }
        }
        plugin.getCommand("gehalt").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        long period = Math.max(10, plugin.getConfig().getInt("gehalt.check-seconds", 60)) * 20L;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 200L, period);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        save();
    }

    private void save() {
        if (file == null) return;
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : lastPaid.entrySet()) y.set("lastpaid." + e.getKey(), e.getValue());
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("gehalt.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        save();
    }

    private record Pay(double amount, long minutes, String rank) {
    }

    /** Gehalt des Spielers laut Rang (null = keins). */
    private Pay payOf(UUID id) {
        if (!(plugin.getModuleManager().get("rank") instanceof RankModule rm) || rm.getManager() == null) return null;
        String rank = rm.getManager().getUserRank(id);
        if (rank == null) return null;
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("gehalt.ranks");
        if (sec == null) return null;
        for (String key : sec.getKeys(false)) {
            if (key.equalsIgnoreCase(rank)) {
                double amount = sec.getDouble(key + ".amount", 0);
                long minutes = Math.max(1, sec.getLong(key + ".minutes", 60));
                return amount > 0 ? new Pay(amount, minutes, rank) : null;
            }
        }
        return null;
    }

    private long shortestInterval() {
        long best = 60;
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("gehalt.ranks");
        if (sec == null) return best;
        best = Long.MAX_VALUE;
        for (String key : sec.getKeys(false)) best = Math.min(best, Math.max(1, sec.getLong(key + ".minutes", 60)));
        return best == Long.MAX_VALUE ? 60 : best;
    }

    private void tick() {
        if (!(plugin.getModuleManager().get("economy") instanceof EconomyModule eco) || eco.getManager() == null) return;
        long now = System.currentTimeMillis();
        long cheapest = shortestInterval() * 60_000L;
        boolean dirty = false;
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            Long last = lastPaid.get(id);
            if (last == null) {                       // neu: Uhr starten, erst nach Ablauf zahlen
                lastPaid.put(id, now);
                dirty = true;
                continue;
            }
            if (now - last < cheapest) continue;      // nichts kann schon fällig sein (spart die Rang-Abfrage)
            Pay pay = payOf(id);
            if (pay == null || now - last < pay.minutes() * 60_000L) continue;
            eco.getManager().deposit(id, pay.amount());
            lastPaid.put(id, now);
            dirty = true;
            plugin.getMessageUtil().send(p, "&a[Gehalt] &7Du hast &a$" + String.format(Locale.GERMANY, "%,.0f", pay.amount())
                    + " &7Gehalt als &f" + pay.rank() + " &7erhalten.");
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        }
        if (dirty) save();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) {
            plugin.getMessageUtil().send(s, "&cNur für Spieler.");
            return true;
        }
        Pay pay = payOf(p.getUniqueId());
        if (pay == null) {
            plugin.getMessageUtil().send(p, "&a[Gehalt] &7Dein Rang bekommt kein Gehalt.");
            return true;
        }
        long last = lastPaid.getOrDefault(p.getUniqueId(), System.currentTimeMillis());
        long left = Math.max(0, pay.minutes() * 60_000L - (System.currentTimeMillis() - last)) / 60_000L;
        plugin.getMessageUtil().send(p, "&a[Gehalt] &7Rang &f" + pay.rank() + "&7: &a$" + String.format(Locale.GERMANY, "%,.0f", pay.amount())
                + " &7alle &f" + pay.minutes() + " &7Minuten &8(nächste Auszahlung in ca. &f" + left + " &8Min., nur wenn du online bist)");
        return true;
    }
}
