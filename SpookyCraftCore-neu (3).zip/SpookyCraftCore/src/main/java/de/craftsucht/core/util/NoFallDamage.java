package de.craftsucht.core.util;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.List;

/** Kein Fallschaden in der Plotwelt (jede Welt, deren Name "plot" enthält, plus nofall.worlds aus der config.yml). */
public class NoFallDamage implements Listener {

    private final SpookyCraftCore plugin;

    public NoFallDamage(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        String w = p.getWorld().getName();
        List<String> list = plugin.getConfig().getStringList("nofall.worlds");
        boolean match = w.toLowerCase().contains("plot");
        for (String s : list) if (s.equalsIgnoreCase(w)) match = true;
        if (match) e.setCancelled(true);
    }
}
