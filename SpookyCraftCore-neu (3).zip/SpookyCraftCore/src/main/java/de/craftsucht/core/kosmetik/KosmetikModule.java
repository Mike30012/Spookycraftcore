package de.craftsucht.core.kosmetik;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Kosmetik am Spieler (Hüte, Flügel, Rucksack, Haustier). /kosmetik öffnet den Shop.
 * Die Modelle sind kleine Block-Modelle im Resource-Pack (custom_model_data 2001-2008 auf PHANTOM_MEMBRANE),
 * sie laufen als Item-Display-Entity mit dem Spieler mit. Ein Teil pro Platz: kopf, ruecken, haustier.
 */
public class KosmetikModule implements Module, Listener, CommandExecutor, TabCompleter {

    private record Def(String id, String name, String slot, double price, Material icon, int model) {
    }

    private static final List<Def> DEFS = List.of(
            new Def("heiligenschein", "&e&lHeiligenschein", "kopf", 150000, Material.GLOWSTONE_DUST, 2001),
            new Def("teufelshoerner", "&c&lTeufelshörner", "kopf", 120000, Material.BLAZE_POWDER, 2002),
            new Def("krone", "&6&lKrone", "kopf", 300000, Material.GOLDEN_HELMET, 2003),
            new Def("zauberhut", "&5&lZauberhut", "kopf", 100000, Material.ENCHANTED_BOOK, 2004),
            new Def("fledermausfluegel", "&5&lFledermaus-Flügel", "ruecken", 250000, Material.BAT_SPAWN_EGG, 2005),
            new Def("engelsfluegel", "&f&lEngelsflügel", "ruecken", 250000, Material.FEATHER, 2006),
            new Def("rucksack", "&6&lRucksack", "ruecken", 90000, Material.BUNDLE, 2007),
            new Def("geist", "&f&lHaustier Geist", "haustier", 200000, Material.GHAST_TEAR, 2008));

    private static final int[] SLOTS = {10, 11, 12, 13, 15, 16, 17, 22};
    private static final int SLOT_CLEAR = 26;

    private static final class ShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private record Shown(Def def, ItemDisplay entity) {
    }

    private final SpookyCraftCore plugin;
    private final Map<UUID, Set<String>> owned = new HashMap<>();
    private final Map<UUID, Map<String, String>> active = new HashMap<>();   // Platz -> ID
    private final Map<UUID, List<Shown>> shown = new HashMap<>();
    private File file;
    private BukkitTask task;
    private long ticks;

    public KosmetikModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "kosmetik";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "kosmetik.yml");
        load();
        plugin.getCommand("kosmetik").setExecutor(this);
        plugin.getCommand("kosmetik").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 1L);
        for (Player p : Bukkit.getOnlinePlayers()) show(p);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        for (UUID id : new ArrayList<>(shown.keySet())) hide(id);
        save();
    }

    // ------------------------------------------------------------------ Daten

    private void load() {
        owned.clear();
        active.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection o = y.getConfigurationSection("owned");
        if (o != null) for (String k : o.getKeys(false)) {
            try {
                owned.put(UUID.fromString(k), new HashSet<>(o.getStringList(k)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        ConfigurationSection a = y.getConfigurationSection("active");
        if (a != null) for (String k : a.getKeys(false)) {
            try {
                Map<String, String> m = new HashMap<>();
                ConfigurationSection s = a.getConfigurationSection(k);
                if (s != null) for (String slot : s.getKeys(false)) m.put(slot, s.getString(slot));
                active.put(UUID.fromString(k), m);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void save() {
        if (file == null) return;
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Set<String>> e : owned.entrySet()) y.set("owned." + e.getKey(), new ArrayList<>(e.getValue()));
        for (Map.Entry<UUID, Map<String, String>> e : active.entrySet()) {
            for (Map.Entry<String, String> s : e.getValue().entrySet()) y.set("active." + e.getKey() + "." + s.getKey(), s.getValue());
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("kosmetik.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    private Def def(String id) {
        for (Def d : DEFS) if (d.id().equalsIgnoreCase(id)) return d;
        return null;
    }

    private double price(Def d) {
        return plugin.getConfig().getDouble("kosmetik.preise." + d.id(), d.price());
    }

    // ------------------------------------------------------------------ Anzeige am Spieler

    private ItemStack modelItem(Def d) {
        ItemStack it = new ItemStack(Material.PHANTOM_MEMBRANE);
        ItemMeta m = it.getItemMeta();
        m.setCustomModelData(d.model());
        it.setItemMeta(m);
        return it;
    }

    private Location target(Player p, Def d) {
        Location base = p.getLocation();
        double yaw = Math.toRadians(base.getYaw());
        Location l = base.clone();
        l.setPitch(0f);
        if (d.slot().equals("haustier")) {
            double rx = -Math.cos(yaw), rz = -Math.sin(yaw);        // rechts vom Spieler
            double bob = Math.sin(ticks / 8.0) * 0.12;
            l.add(rx * 1.0, 1.15 + bob, rz * 1.0);
        } else {
            l.add(0, 0.5, 0);                                         // Modell-Ursprung (Modellmitte) auf Fußhöhe + 0,5
        }
        return l;
    }

    private void spawn(Player p, Def d, List<Shown> list) {
        Location l = target(p, d);
        ItemDisplay e = l.getWorld().spawn(l, ItemDisplay.class, disp -> {
            disp.setItemStack(modelItem(d));
            disp.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            disp.setTeleportDuration(2);
            disp.setPersistent(false);
        });
        list.add(new Shown(d, e));
    }

    private void show(Player p) {
        hide(p.getUniqueId());
        Map<String, String> act = active.get(p.getUniqueId());
        if (act == null || act.isEmpty()) return;
        List<Shown> list = new ArrayList<>();
        for (String id : act.values()) {
            Def d = def(id);
            if (d != null) spawn(p, d, list);
        }
        if (!list.isEmpty()) shown.put(p.getUniqueId(), list);
    }

    private void hide(UUID id) {
        List<Shown> list = shown.remove(id);
        if (list == null) return;
        for (Shown s : list) if (s.entity().isValid()) s.entity().remove();
    }

    private void tick() {
        ticks++;
        if (shown.isEmpty()) return;
        for (UUID id : new ArrayList<>(shown.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline()) {
                hide(id);
                continue;
            }
            List<Shown> list = shown.get(id);
            boolean hidden = p.isDead() || p.getGameMode() == org.bukkit.GameMode.SPECTATOR
                    || p.hasPotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY);
            for (int i = 0; i < list.size(); i++) {
                Shown s = list.get(i);
                ItemDisplay e = s.entity();
                if (hidden) {
                    if (e.isValid()) e.remove();
                    continue;
                }
                Location t = target(p, s.def());
                if (!e.isValid() || !e.getWorld().equals(t.getWorld())) {
                    if (e.isValid()) e.remove();
                    List<Shown> tmp = new ArrayList<>();
                    spawn(p, s.def(), tmp);
                    list.set(i, tmp.get(0));
                } else {
                    e.teleport(t);
                }
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) show(p);
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        hide(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Menü

    private Component txt(String legacy) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(legacy).decoration(TextDecoration.ITALIC, false);
    }

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(new ShopHolder(), 36, txt("&5&lKosmetik"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.displayName(Component.text(" "));
        filler.setItemMeta(fm);
        for (int i = 0; i < 36; i++) inv.setItem(i, filler);
        Set<String> mine = owned.getOrDefault(p.getUniqueId(), Set.of());
        Map<String, String> act = active.getOrDefault(p.getUniqueId(), Map.of());
        for (int i = 0; i < DEFS.size(); i++) {
            Def d = DEFS.get(i);
            ItemStack it = new ItemStack(d.icon());
            ItemMeta m = it.getItemMeta();
            m.displayName(txt(d.name()));
            boolean has = mine.contains(d.id()) || p.hasPermission("spookycraft.kosmetik.free");
            boolean on = d.id().equals(act.get(d.slot()));
            List<Component> lore = new ArrayList<>();
            lore.add(txt("&8Platz: " + d.slot()));
            if (on) lore.add(txt("&a✔ Aktiv &7- Klick: ausziehen"));
            else if (has) lore.add(txt("&e● Gekauft &7- Klick: anziehen"));
            else {
                lore.add(txt("&7Preis: &a$" + String.format(Locale.GERMANY, "%,.0f", price(d))));
                lore.add(txt("&7Klick: kaufen"));
            }
            m.lore(lore);
            if (on) m.setEnchantmentGlintOverride(true);
            it.setItemMeta(m);
            inv.setItem(SLOTS[i], it);
        }
        ItemStack clear = new ItemStack(Material.BARRIER);
        ItemMeta cm = clear.getItemMeta();
        cm.displayName(txt("&c&lAlles ausziehen"));
        clear.setItemMeta(cm);
        inv.setItem(SLOT_CLEAR, clear);
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof ShopHolder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player p)) return;
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        int slot = event.getSlot();
        if (slot == SLOT_CLEAR) {
            active.remove(p.getUniqueId());
            hide(p.getUniqueId());
            save();
            open(p);
            return;
        }
        for (int i = 0; i < SLOTS.length; i++) {
            if (SLOTS[i] != slot) continue;
            Def d = DEFS.get(i);
            Set<String> mine = owned.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());
            boolean has = mine.contains(d.id()) || p.hasPermission("spookycraft.kosmetik.free");
            if (!has) {
                if (!buy(p, d)) return;
                mine.add(d.id());
            }
            Map<String, String> act = active.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
            if (d.id().equals(act.get(d.slot()))) act.remove(d.slot());
            else act.put(d.slot(), d.id());
            save();
            show(p);
            open(p);
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.6f);
            return;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ShopHolder) event.setCancelled(true);
    }

    private boolean buy(Player p, Def d) {
        if (!(plugin.getModuleManager().get("economy") instanceof EconomyModule eco) || eco.getManager() == null) {
            plugin.getMessageUtil().send(p, "&cWirtschaft nicht verfügbar.");
            return false;
        }
        double price = price(d);
        if (!eco.getManager().withdraw(p.getUniqueId(), price)) {
            plugin.getMessageUtil().send(p, "&c[Kosmetik] &7Dafür fehlen dir &c$" + String.format(Locale.GERMANY, "%,.0f", price) + "&7.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return false;
        }
        plugin.getMessageUtil().send(p, "&a[Kosmetik] &7Gekauft: " + d.name() + " &7für &a$" + String.format(Locale.GERMANY, "%,.0f", price));
        return true;
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length >= 3 && a[0].equalsIgnoreCase("give")) {
            if (!s.isOp() && !s.hasPermission("spookycraft.kosmetik.admin")) {
                plugin.getMessageUtil().send(s, "&cKeine Rechte.");
                return true;
            }
            Player t = Bukkit.getPlayerExact(a[1]);
            Def d = def(a[2]);
            if (t == null || d == null) {
                plugin.getMessageUtil().send(s, "&cSpieler oder Kosmetik nicht gefunden. IDs: heiligenschein, teufelshoerner, krone, zauberhut, fledermausfluegel, engelsfluegel, rucksack, geist");
                return true;
            }
            owned.computeIfAbsent(t.getUniqueId(), k -> new HashSet<>()).add(d.id());
            save();
            plugin.getMessageUtil().send(s, "&a[Kosmetik] &7" + t.getName() + " hat jetzt " + d.name());
            plugin.getMessageUtil().send(t, "&a[Kosmetik] &7Du hast " + d.name() + " &7bekommen! &8(/kosmetik)");
            return true;
        }
        if (!(s instanceof Player p)) {
            plugin.getMessageUtil().send(s, "&cNur für Spieler.");
            return true;
        }
        open(p);
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.isOp() && !s.hasPermission("spookycraft.kosmetik.admin")) return out;
        if (a.length == 1) out.add("give");
        else if (a.length == 2) for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        else if (a.length == 3) for (Def d : DEFS) out.add(d.id());
        return out;
    }
}
