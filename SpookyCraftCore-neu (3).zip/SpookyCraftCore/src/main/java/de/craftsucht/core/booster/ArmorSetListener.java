package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Set-Boni (alle 4 Teile): Lava (Feuerresistenz + Schwimmen in Lava), Wasser (Wasseratmung, schnelles Schwimmen,
 * kein Fallschaden), Enderman (kein Enderperlen-Schaden + Nachtsicht).
 */
public class ArmorSetListener implements Listener {

    private final SpookyCraftCore plugin;
    private final NamespacedKey key;
    private BukkitTask scanTask;
    private BukkitTask lavaTask;
    private final Map<UUID, String> current = new HashMap<>();
    private final Set<UUID> lavaWearers = new HashSet<>();
    private final Map<UUID, Long> pearlTime = new HashMap<>();

    public ArmorSetListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.key = SpecialItemsListener.keySpecial(plugin);
    }

    public void start() {
        scanTask = Bukkit.getScheduler().runTaskTimer(plugin, this::scan, 20L, 10L);
        lavaTask = Bukkit.getScheduler().runTaskTimer(plugin, this::lavaMove, 20L, 2L);
    }

    public void stop() {
        if (scanTask != null) scanTask.cancel();
        if (lavaTask != null) lavaTask.cancel();
        for (Player p : Bukkit.getOnlinePlayers()) clearEffects(p, current.get(p.getUniqueId()));
        current.clear();
        lavaWearers.clear();
    }

    private String special(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    /** "lava", "wasser", "ender" wenn alle 4 Teile eines Sets getragen werden, sonst null. */
    private String setOf(Player p) {
        ItemStack[] armor = p.getInventory().getArmorContents();   // Stiefel, Hose, Brust, Helm
        if (armor.length < 4) return null;
        String boots = special(armor[0]);
        String legs = special(armor[1]);
        String chest = special(armor[2]);
        String helm = special(armor[3]);
        if (boots == null || legs == null || chest == null || helm == null) return null;
        for (String set : new String[]{"lava", "wasser", "ender", "emerald"}) {
            if (boots.equals(set + "_boots") && legs.equals(set + "_legs")
                    && chest.equals(set + "_chest") && helm.equals(set + "_helm")) return set;
        }
        return null;
    }

    private void scan() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            String set = setOf(p);
            String before = current.get(id);
            if (before != null && !before.equals(set)) {
                clearEffects(p, before);
                current.remove(id);
                lavaWearers.remove(id);
            }
            if (set == null) continue;
            current.put(id, set);
            switch (set) {
                case "lava" -> {
                    lavaWearers.add(id);
                    effect(p, PotionEffectType.FIRE_RESISTANCE, 80, 0);
                }
                case "wasser" -> {
                    effect(p, PotionEffectType.WATER_BREATHING, 80, 0);
                    effect(p, PotionEffectType.DOLPHINS_GRACE, 80, 1);
                }
                case "ender" -> effect(p, PotionEffectType.NIGHT_VISION, 400, 0);
                case "emerald" -> {
                    effect(p, PotionEffectType.HASTE, 80, 1);
                    effect(p, PotionEffectType.LUCK, 80, 1);
                }
                default -> { }
            }
        }
        current.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
    }

    private void effect(Player p, PotionEffectType type, int ticks, int amplifier) {
        p.addPotionEffect(new PotionEffect(type, ticks, amplifier, false, false, false));
    }

    private void clearEffects(Player p, String set) {
        if (set == null) return;
        switch (set) {
            case "lava" -> p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
            case "wasser" -> {
                p.removePotionEffect(PotionEffectType.WATER_BREATHING);
                p.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
            }
            case "ender" -> p.removePotionEffect(PotionEffectType.NIGHT_VISION);
            case "emerald" -> {
                p.removePotionEffect(PotionEffectType.HASTE);
                p.removePotionEffect(PotionEffectType.LUCK);
            }
            default -> { }
        }
    }

    /** Schwimmen in Lava: schneller vorwärts, Aufschwimmen, Sneaken = sinken. */
    private void lavaMove() {
        for (UUID id : new HashSet<>(lavaWearers)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline()) {
                lavaWearers.remove(id);
                continue;
            }
            Material at = p.getLocation().getBlock().getType();
            if (at != Material.LAVA) continue;
            Vector v = p.getVelocity();
            double hs = Math.hypot(v.getX(), v.getZ());
            if (hs > 0.01) {
                double factor = Math.min(1.8, 0.45 / hs);
                v.setX(v.getX() * factor);
                v.setZ(v.getZ() * factor);
            }
            if (p.isSneaking()) v.setY(Math.min(v.getY(), -0.2));
            else v.setY(Math.max(v.getY(), 0.03));
            p.setVelocity(v);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (event.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) return;
        if ("ender".equals(setOf(event.getPlayer()))) {
            pearlTime.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(event.getEntity() instanceof Player p)) return;
        String set = setOf(p);
        if ("wasser".equals(set)) {
            event.setCancelled(true);
            return;
        }
        if ("ender".equals(set)) {
            Long t = pearlTime.get(p.getUniqueId());
            if (t != null && System.currentTimeMillis() - t < 1500L) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        current.remove(id);
        lavaWearers.remove(id);
        pearlTime.remove(id);
    }
}
