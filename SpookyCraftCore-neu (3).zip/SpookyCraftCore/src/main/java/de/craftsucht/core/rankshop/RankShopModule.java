package de.craftsucht.core.rankshop;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.perks.PerksModule;
import de.craftsucht.core.rank.RankManager;
import de.craftsucht.core.rank.RankModule;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * /rangshop: kaufbare Ränge (VIP-Leiter) mit Geld. Team-Raenge sind nie kaufbar.
 * Ränge, Preise, Rechte und Perks stehen in config.yml unter rankshop.ranks.
 * Die Ränge werden beim ersten Start im Rang-System angelegt (nur wenn es sie noch nicht gibt).
 * Mit LuckPerms: Gruppen selbst in LuckPerms anlegen, der Kauf setzt dann "lp user <name> parent set <id>".
 */
public class RankShopModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;

    public RankShopModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "rankshop";
    }

    @Override
    public void enable() {
        plugin.getCommand("rangshop").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskLater(plugin, this::ensureRanks, 60L);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private static String str(Map<?, ?> m, String k, String def) {
        Object o = m.get(k);
        return o == null ? def : String.valueOf(o);
    }

    private static int num(Map<?, ?> m, String k, int def) {
        try {
            return Integer.parseInt(str(m, k, String.valueOf(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static List<String> strList(Map<?, ?> m, String k) {
        List<String> out = new ArrayList<>();
        Object o = m.get(k);
        if (o instanceof List<?> l) for (Object x : l) out.add(String.valueOf(x));
        return out;
    }

    private List<Map<?, ?>> ladder() {
        return plugin.getConfig().getMapList("rankshop.ranks");
    }

    private RankManager rankManager() {
        return plugin.getModuleManager().get("rank") instanceof RankModule rm ? rm.getManager() : null;
    }

    private int indexOf(String rankId) {
        List<Map<?, ?>> l = ladder();
        for (int i = 0; i < l.size(); i++) if (str(l.get(i), "id", "").equalsIgnoreCase(rankId)) return i;
        return -1;
    }

    // ------------------------------------------------------------------ Ränge anlegen

    /** Legt die Shop-Raenge im eigenen Rang-System an (nur wenn es sie noch nicht gibt - spätere /rank-Aenderungen bleiben). */
    private void ensureRanks() {
        RankManager rm = rankManager();
        if (rm == null || rm.usesLuckPerms()) return;
        String previous = null;
        for (Map<?, ?> r : ladder()) {
            String id = str(r, "id", "").toLowerCase(Locale.ROOT);
            if (id.isEmpty()) continue;
            if (rm.getRank(id) == null) {
                rm.createRank(id, str(r, "prefix", "&7" + id), num(r, "weight", 10), previous);
                for (String perm : strList(r, "permissions")) rm.setPermission(id, perm, true);
                plugin.getLogger().info("Rangshop: Rang '" + id + "' angelegt.");
            }
            previous = id;
        }
    }

    // ------------------------------------------------------------------ Kauf-Logik

    private String currentRank(Player p) {
        RankManager rm = rankManager();
        return rm == null ? "" : rm.getUserRank(p.getUniqueId());
    }

    /** true, wenn der Spieler Standard-Spieler oder auf der VIP-Leiter ist (also kaufen darf). */
    private boolean canBuyAtAll(Player p) {
        RankManager rm = rankManager();
        if (rm == null) return false;
        String cur = currentRank(p);
        if (cur == null) return true;
        return indexOf(cur) >= 0 || cur.equalsIgnoreCase(rm.getDefaultRankName()) || cur.equalsIgnoreCase("default");
    }

    /** Preis fuer den Aufstieg auf Stufe idx (abzueglich des Preises des aktuellen Rangs, wenn upgrade-discount an ist). */
    private int priceFor(Player p, int idx) {
        List<Map<?, ?>> l = ladder();
        int price = num(l.get(idx), "cost", 0);
        if (plugin.getConfig().getBoolean("rankshop.upgrade-discount", true)) {
            int cur = indexOf(currentRank(p));
            if (cur >= 0) price -= num(l.get(cur), "cost", 0);
        }
        return Math.max(0, price);
    }

    private void buy(Player p, int idx) {
        List<Map<?, ?>> l = ladder();
        if (idx < 0 || idx >= l.size()) return;
        if (!canBuyAtAll(p)) {
            plugin.getMessageUtil().send(p, "&cTeam-Ränge können nicht gekauft werden – und du bist bereits ein Wächter der Geisterwelt.");
            return;
        }
        int cur = indexOf(currentRank(p));
        if (cur >= idx) {
            plugin.getMessageUtil().send(p, "&cDiesen Rang (oder einen höheren) besitzt du bereits.");
            return;
        }
        Map<?, ?> target = l.get(idx);
        int price = priceFor(p, idx);
        EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
        if (eco == null) return;
        if (price > 0 && !eco.withdraw(p.getUniqueId(), price)) {
            plugin.getMessageUtil().send(p, "&cDeine Taschen sind zu leer – dir fehlen &e" + String.format(Locale.GERMANY, "%,d", price) + "$&c.");
            return;
        }
        String id = str(target, "id", "").toLowerCase(Locale.ROOT);
        RankManager rm = rankManager();
        if (rm.usesLuckPerms()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + p.getName() + " parent set " + id);
        } else {
            ensureRanks();
            rm.setUserRank(p.getUniqueId(), id);
            rm.apply(p);
        }
        if (plugin.getModuleManager().get("perks") instanceof PerksModule pm) {
            for (String perk : strList(target, "perks")) pm.grantPerk(p, perk);
        }
        if (plugin.getModuleManager().get("scoreboard") instanceof ScoreboardModule sm) sm.refreshNow();
        p.playSound(p.getLocation(), "entity.witch.celebrate", 0.9f, 1.0f);
        Bukkit.broadcastMessage(c("&5☠ &f" + p.getName() + " &dist den Geistern beigetreten als " + str(target, "prefix", id) + "&d!"));
    }

    // ------------------------------------------------------------------ GUI

    private static class ShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private void open(Player p) {
        ensureRanks();
        List<Map<?, ?>> l = ladder();
        Inventory inv = Bukkit.createInventory(new ShopHolder(), 27, c("&5☠ &dRang-Shop"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        int cur = indexOf(currentRank(p));
        boolean can = canBuyAtAll(p);
        int n = Math.min(l.size(), 7);
        int start = 13 - (n / 2);
        for (int i = 0; i < n; i++) {
            Map<?, ?> r = l.get(i);
            Material mat = Material.matchMaterial(str(r, "icon", "PAPER"));
            ItemStack it = new ItemStack(mat == null ? Material.PAPER : mat);
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(c(str(r, "prefix", str(r, "id", "?"))));
            List<String> lore = new ArrayList<>();
            for (String line : strList(r, "lore")) lore.add(c(line));
            lore.add("");
            if (!can) {
                lore.add(c("&cTeam-Ränge können keine Ränge kaufen"));
            } else if (cur >= i) {
                lore.add(c("&a✔ Bereits freigeschaltet"));
            } else {
                lore.add(c("&7Preis: &e" + String.format(Locale.GERMANY, "%,d", priceFor(p, i)) + "$"
                        + (cur >= 0 && plugin.getConfig().getBoolean("rankshop.upgrade-discount", true) ? " &8(Aufstieg, dein Rang wird angerechnet)" : "")));
                lore.add(c("&eKlicken zum Kaufen"));
            }
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(start + i, it);
        }
        EconomyManager eco = plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
        ItemStack info = new ItemStack(Material.GOLD_INGOT);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&eDein Geld: &f" + String.format(Locale.GERMANY, "%,.0f", eco == null ? 0 : eco.getBalance(p.getUniqueId())) + "$"));
        info.setItemMeta(im);
        inv.setItem(22, info);
        p.openInventory(inv);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        open(p);
        return true;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ShopHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int n = Math.min(ladder().size(), 7);
        int start = 13 - (n / 2);
        int idx = e.getSlot() - start;
        if (idx < 0 || idx >= n) return;
        buy(p, idx);
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }
}
