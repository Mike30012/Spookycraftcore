package de.craftsucht.core.komfort;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Komfort: /homes als Menue (Klick = hin, Rechtsklick = loeschen), /rangliste (Bestenlisten), @Name im Chat pingt den Spieler.
 */
public class ComfortModule implements Module, CommandExecutor, Listener {

    private static final class HomesHolder implements InventoryHolder {
        final List<String> names = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;

    public ComfortModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "komfort";
    }

    @Override
    public void enable() {
        plugin.getCommand("rangliste").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        // nichts offen
    }

    // ------------------------------------------------------------------ /homes Menue

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHomesCommand(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("komfort.homes-gui", true)) return;
        String msg = e.getMessage().trim().toLowerCase(Locale.ROOT);
        if (msg.equals("/homes") || msg.equals("/essentials:homes")) {
            e.setCancelled(true);
            openHomes(e.getPlayer());
        }
    }

    private void openHomes(Player p) {
        HomesHolder h = new HomesHolder();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT name, world FROM homes WHERE uuid=? ORDER BY name")) {
            ps.setString(1, p.getUniqueId().toString());
            List<String> worlds = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() && h.names.size() < 45) {
                    h.names.add(rs.getString(1));
                    worlds.add(rs.getString(2));
                }
            }
            int rows = Math.max(1, Math.min(6, (h.names.size() + 8) / 9));
            Inventory inv = Bukkit.createInventory(h, rows * 9, GuiUtil.c("&2&l☠ &aDeine Homes"));
            for (int i = 0; i < h.names.size(); i++) {
                inv.setItem(i, GuiUtil.item(Material.RED_BED, "&a" + h.names.get(i),
                        "&7Welt: &f" + worlds.get(i), "&eLinksklick: &7hinteleportieren", "&cRechtsklick: &7löschen"));
            }
            if (h.names.isEmpty()) {
                plugin.getMessageUtil().send(p, "&7Du hast keine Homes. Setze eins mit &e/sethome [name]&7.");
                return;
            }
            p.openInventory(inv);
        } catch (SQLException ex) {
            plugin.getMessageUtil().send(p, "&cFehler beim Laden der Homes.");
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof HomesHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot < 0 || slot >= h.names.size()) return;
        String name = h.names.get(slot);
        p.closeInventory();
        if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) {
            p.performCommand("delhome " + name);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline()) openHomes(p);
            }, 2L);
        } else {
            p.performCommand("home " + name);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof HomesHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ /rangliste

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String kind = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        final String table;
        final String col;
        final String title;
        switch (kind) {
            case "reich", "geld", "money" -> {
                table = "economy";
                col = "balance";
                title = "Die Reichsten";
            }
            case "zeit", "spielzeit", "playtime" -> {
                table = "stats";
                col = "playtime_seconds";
                title = "Meiste Spielzeit";
            }
            case "kills" -> {
                table = "stats";
                col = "kills";
                title = "Meiste Kills";
            }
            case "tode", "deaths" -> {
                table = "stats";
                col = "deaths";
                title = "Meiste Tode";
            }
            case "blocks", "bloecke", "blöcke" -> {
                table = "stats";
                col = "blocks_broken";
                title = "Meiste Blöcke abgebaut";
            }
            default -> {
                plugin.getMessageUtil().send(sender, "&7Bestenlisten: &e/rangliste reich&7, &ezeit&7, &ekills&7, &etode&7, &eblocks");
                return true;
            }
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<String> lines = new ArrayList<>();
            try (Connection c = plugin.getDatabase().getConnection();
                 PreparedStatement ps = c.prepareStatement("SELECT uuid, " + col + " FROM " + table + " ORDER BY " + col + " DESC LIMIT 10");
                 ResultSet rs = ps.executeQuery()) {
                int i = 1;
                while (rs.next()) {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(UUID.fromString(rs.getString(1)));
                    String name = op.getName() != null ? op.getName() : "?";
                    double v = rs.getDouble(2);
                    String val = col.equals("balance") ? GuiUtil.money(v)
                            : col.equals("playtime_seconds") ? (long) (v / 3600) + " Std."
                            : String.valueOf((long) v);
                    lines.add("&e" + i++ + ". &f" + name + " &8- &7" + val);
                }
            } catch (SQLException | IllegalArgumentException ex) {
                Bukkit.getScheduler().runTask(plugin, () -> plugin.getMessageUtil().send(sender, "&cDie Liste konnte nicht geladen werden."));
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getMessageUtil().send(sender, "&6☠ &e" + title);
                for (String l : lines) plugin.getMessageUtil().send(sender, l);
                if (lines.isEmpty()) plugin.getMessageUtil().send(sender, "&7Noch keine Einträge.");
            });
        });
        return true;
    }

    // ------------------------------------------------------------------ @Name

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        if (!plugin.getConfig().getBoolean("komfort.mentions", true)) return;
        String lower = e.getMessage().toLowerCase(Locale.ROOT);
        if (!lower.contains("@")) return;
        final String from = e.getPlayer().getName();
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().equals(from)) continue;
                if (lower.contains("@" + p.getName().toLowerCase(Locale.ROOT))) {
                    p.playSound(p.getLocation(), "block.note_block.pling", 1f, 1.5f);
                    p.sendActionBar(Component.text(GuiUtil.c("&6☠ &e" + from + " &7hat dich erwähnt")));
                }
            }
        });
    }
}
