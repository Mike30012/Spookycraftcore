package de.craftsucht.core.video;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.rank.RankModule;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * /video - Video-Modus zum Filmen: Scoreboard, Chat und Actionbar-Anzeigen sind fuer dich aus
 * (andere Spieler merken nichts). Nochmal /video schaltet alles wieder ein.
 */
public class VideoModule implements Module, CommandExecutor, Listener {

    private static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();

    public static boolean isActive(Player p) {
        return ACTIVE.contains(p.getUniqueId());
    }

    private final SpookyCraftCore plugin;

    public VideoModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "video";
    }

    @Override
    public void enable() {
        plugin.getCommand("video").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        org.bukkit.event.HandlerList.unregisterAll(this);
        ACTIVE.clear();
    }

    private boolean allowed(Player p) {
        if (p.isOp() || p.hasPermission("spookycraft.video") || p.hasPermission("spookycraft.core.admin")) return true;
        if (plugin.getModuleManager().get("rank") instanceof RankModule rm && rm.getManager() != null) {
            String r = rm.getManager().getUserRank(p.getUniqueId());
            return r != null && (r.equalsIgnoreCase("owner") || r.equalsIgnoreCase("admin")
                    || plugin.getConfig().getStringList("video.ranks").stream().anyMatch(r::equalsIgnoreCase));
        }
        return false;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!allowed(p)) {
            plugin.getMessageUtil().send(p, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (ACTIVE.remove(p.getUniqueId())) {
            plugin.getMessageUtil().send(p, "&5☠ &dVideo-Modus &causgeschaltet&d. Scoreboard und Chat sind wieder da.");
        } else {
            ACTIVE.add(p.getUniqueId());
            // Scoreboard sofort leeren (das Scoreboard-Modul lässt ihn ab jetzt in Ruhe)
            p.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
            p.sendActionBar(net.kyori.adventure.text.Component.empty());
            plugin.getMessageUtil().send(p, "&5☠ &dVideo-Modus &aeingeschaltet&d: Scoreboard, Chat und Anzeigen sind für dich aus. &7(/video zum Beenden)");
        }
        return true;
    }

    /** Chat-Nachrichten gar nicht erst an Video-Spieler zustellen. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent e) {
        if (ACTIVE.isEmpty()) return;
        e.getRecipients().removeIf(p -> ACTIVE.contains(p.getUniqueId()) && !p.getUniqueId().equals(e.getPlayer().getUniqueId()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        ACTIVE.remove(e.getPlayer().getUniqueId());
    }
}
