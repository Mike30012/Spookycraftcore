package de.craftsucht.core.sortieren;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Container;
import org.bukkit.block.DoubleChest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Automatisches Sortieren: Kisten, Fässer, Shulker und Endertruhen werden beim Schließen sortiert,
 * dazu das Inventar (ohne Hotbar und Rüstung). /sort sortiert sofort, /sort auto schaltet es pro Spieler an/aus.
 * Einstellungen: config sort.*
 */
public class SortModule implements Module, Listener, CommandExecutor {

    private final SpookyCraftCore plugin;
    private NamespacedKey autoKey;

    public SortModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "sortieren";
    }

    @Override
    public void enable() {
        autoKey = new NamespacedKey(plugin, "sort_auto");
        plugin.getCommand("sort").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
    }

    private boolean autoOn(Player p) {
        Byte b = p.getPersistentDataContainer().get(autoKey, PersistentDataType.BYTE);
        if (b != null) return b == 1;
        return plugin.getConfig().getBoolean("sort.auto-default", true);
    }

    private boolean sortable(Inventory inv) {
        InventoryType t = inv.getType();
        if (t == InventoryType.ENDER_CHEST) return true;
        if (t != InventoryType.CHEST && t != InventoryType.BARREL && t != InventoryType.SHULKER_BOX) return false;
        InventoryHolder h = inv.getHolder();
        return h instanceof Container || h instanceof DoubleChest;   // eigene Menüs (Markt, Tresor ...) bleiben unberührt
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player p)) return;
        if (!autoOn(p)) return;
        Inventory top = event.getView().getTopInventory();
        if (plugin.getConfig().getBoolean("sort.chests", true) && sortable(top)) {
            sort(top, 0, top.getSize());
        }
        if (plugin.getConfig().getBoolean("sort.inventory", true)) {
            sortPlayer(p);
        }
    }

    private void sortPlayer(Player p) {
        sort(p.getInventory(), 9, 36);   // Hauptinventar; Hotbar (0-8) und Rüstung bleiben unberührt
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) {
            plugin.getMessageUtil().send(s, "&cNur für Spieler.");
            return true;
        }
        if (a.length > 0 && a[0].equalsIgnoreCase("auto")) {
            boolean now = !autoOn(p);
            p.getPersistentDataContainer().set(autoKey, PersistentDataType.BYTE, (byte) (now ? 1 : 0));
            plugin.getMessageUtil().send(p, now ? "&a[Sortieren] &7Automatisches Sortieren &aan&7." : "&a[Sortieren] &7Automatisches Sortieren &caus&7.");
            return true;
        }
        sortPlayer(p);
        plugin.getMessageUtil().send(p, "&a[Sortieren] &7Inventar sortiert. &8(/sort auto = automatisch an/aus)");
        return true;
    }

    /** Stapel zusammenführen, dann nach Material und Name sortieren (Slots von bis, bis exklusiv). */
    static void sort(Inventory inv, int from, int to) {
        List<ItemStack> merged = new ArrayList<>();
        for (int i = from; i < to; i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.getType().isAir()) continue;
            ItemStack rest = it.clone();
            for (ItemStack m : merged) {
                if (rest.getAmount() <= 0) break;
                if (m.getAmount() < m.getMaxStackSize() && m.isSimilar(rest)) {
                    int move = Math.min(m.getMaxStackSize() - m.getAmount(), rest.getAmount());
                    m.setAmount(m.getAmount() + move);
                    rest.setAmount(rest.getAmount() - move);
                }
            }
            if (rest.getAmount() > 0) merged.add(rest);
        }
        merged.sort(Comparator
                .comparing((ItemStack i) -> i.getType().name())
                .thenComparing(i -> String.valueOf(i.getItemMeta()))
                .thenComparing(Comparator.comparingInt(ItemStack::getAmount).reversed()));
        for (int i = from; i < to; i++) {
            int idx = i - from;
            inv.setItem(i, idx < merged.size() ? merged.get(idx) : null);
        }
    }
}
