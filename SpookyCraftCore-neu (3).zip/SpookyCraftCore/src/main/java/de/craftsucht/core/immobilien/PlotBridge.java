package de.craftsucht.core.immobilien;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Duenne Bruecke zu PlotSquared (Version 6/7) per Reflection - so kompiliert das Plugin auch ohne PlotSquared
 * und eine andere API-Version lässt nur den Immobilienmarkt ausfallen, nicht das ganze Plugin.
 */
final class PlotBridge {

    /** Ein Plot, wie PlotSquared ihn kennt (Plot-Objekt unverändert durchreichen). */
    record PlotRef(Object plot, String key, UUID owner) {
    }

    private Class<?> bukkitUtil;
    private Class<?> psLocation;
    private Class<?> plotClass;
    private Method toPs;
    private Method toBukkit;
    private Method getPlot;
    private Method getOwnerAbs;
    private Method setOwner;
    private Method getCenter;
    private Method getBase;
    private Method getId;
    private String error;
    private boolean ready;

    boolean init() {
        if (ready) return true;
        Plugin ps = Bukkit.getPluginManager().getPlugin("PlotSquared");
        if (ps == null || !ps.isEnabled()) {
            error = "PlotSquared ist nicht installiert oder nicht gestartet.";
            return false;
        }
        try {
            ClassLoader cl = ps.getClass().getClassLoader();
            bukkitUtil = Class.forName("com.plotsquared.bukkit.util.BukkitUtil", true, cl);
            psLocation = Class.forName("com.plotsquared.core.location.Location", true, cl);
            plotClass = Class.forName("com.plotsquared.core.plot.Plot", true, cl);
            toPs = bukkitUtil.getMethod("adapt", Location.class);
            toBukkit = bukkitUtil.getMethod("adapt", psLocation);
            getPlot = psLocation.getMethod("getPlot");
            getOwnerAbs = plotClass.getMethod("getOwnerAbs");
            setOwner = plotClass.getMethod("setOwner", UUID.class);
            getCenter = plotClass.getMethod("getCenter", Consumer.class);
            getId = plotClass.getMethod("getId");
            try {
                getBase = plotClass.getMethod("getBasePlot", boolean.class);
            } catch (NoSuchMethodException e) {
                getBase = null;
            }
            ready = true;
            return true;
        } catch (ReflectiveOperationException | RuntimeException e) {
            error = "PlotSquared-Schnittstelle nicht kompatibel (" + e.getClass().getSimpleName() + ": " + e.getMessage() + ").";
            return false;
        }
    }

    String error() {
        return error == null ? "PlotSquared nicht bereit." : error;
    }

    /** Plot an dieser Stelle (Hauptplot bei verbundenen Plots) oder null. */
    PlotRef plotAt(Location loc) {
        if (!init() || loc == null || loc.getWorld() == null) return null;
        try {
            Object psLoc = toPs.invoke(null, loc);
            Object plot = getPlot.invoke(psLoc);
            if (plot == null) return null;
            if (getBase != null) {
                Object base = getBase.invoke(plot, false);
                if (base != null) plot = base;
            }
            UUID owner = (UUID) getOwnerAbs.invoke(plot);
            String key = loc.getWorld().getName() + "|" + getId.invoke(plot);
            return new PlotRef(plot, key, owner);
        } catch (ReflectiveOperationException | RuntimeException e) {
            error = "PlotSquared-Abfrage fehlgeschlagen (" + e.getClass().getSimpleName() + ").";
            return null;
        }
    }

    /** Mitte des Plots (Bukkit-Location). Der Rueckruf kommt moeglicherweise asynchron. */
    void center(PlotRef ref, Consumer<Location> result) {
        try {
            Consumer<Object> cb = o -> {
                try {
                    result.accept(o == null ? null : (Location) toBukkit.invoke(null, o));
                } catch (ReflectiveOperationException | RuntimeException e) {
                    result.accept(null);
                }
            };
            getCenter.invoke(ref.plot(), cb);
        } catch (ReflectiveOperationException | RuntimeException e) {
            result.accept(null);
        }
    }

    boolean transfer(PlotRef ref, UUID newOwner) {
        try {
            Object r = setOwner.invoke(ref.plot(), newOwner);
            return !(r instanceof Boolean b) || b;
        } catch (ReflectiveOperationException | RuntimeException e) {
            error = "Plot konnte nicht uebertragen werden (" + e.getClass().getSimpleName() + ").";
            return false;
        }
    }
}
