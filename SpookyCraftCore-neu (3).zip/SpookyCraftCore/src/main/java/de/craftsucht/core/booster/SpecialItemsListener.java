package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import com.destroystokyo.paper.event.player.PlayerArmorChangeEvent;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Verhalten der Spezial-Items aus ItemRegistry (früher Skripte): Flug-Schuhe, Speed-Schuhe, Mining-Pistole,
 * Erz-Wandler, Bedrock-Brecher, Ban-Hammer und die Bedrock-Rüstung (Rezepte + Resistenz).
 * Items per /citem give <spieler> <id>. Einstellungen: "special-items:" in der config.yml.
 */
public class SpecialItemsListener implements Listener {

    public static NamespacedKey keySpecial(SpookyCraftCore plugin) {
        return new NamespacedKey(plugin, "special_item");
    }

    private static final Set<String> PROTECTED = Set.of(
            "SPAWNER", "TRIAL_SPAWNER", "VAULT", "ENDER_CHEST", "BEACON", "FURNACE", "BLAST_FURNACE", "SMOKER", "HOPPER",
            "DISPENSER", "DROPPER", "CHEST", "TRAPPED_CHEST", "BARREL", "BREWING_STAND", "ENCHANTING_TABLE", "LECTERN",
            "JUKEBOX", "CRAFTER", "END_PORTAL_FRAME", "END_PORTAL", "NETHER_PORTAL", "REINFORCED_DEEPSLATE");

    private static final Set<String> BEDROCK_ARMOR = Set.of("bedrock_helm", "bedrock_chest", "bedrock_legs", "bedrock_boots");
    private static final Material[] ORES = {Material.DIAMOND_BLOCK, Material.COAL_BLOCK, Material.GOLD_BLOCK,
            Material.NETHERITE_BLOCK, Material.EMERALD_BLOCK, Material.COPPER_BLOCK, Material.IRON_BLOCK};
    private static final int[] PISTOL_RADII = {3, 5, 7};
    private static final long RESISTANCE_PERIOD_TICKS = 12000L; // 10 Minuten
    private static final int RESISTANCE_DURATION_TICKS = 600 * 20;

    private final SpookyCraftCore plugin;
    private final ItemRegistry registry;
    private final NamespacedKey key;
    private final Random random = new Random();
    private final Set<UUID> flyers = new HashSet<>();
    private final Set<UUID> speeders = new HashSet<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final List<NamespacedKey> recipeKeys = new ArrayList<>();
    private BukkitTask resistanceTask;
    private BukkitTask magnetTask;
    private final Set<UUID> nightVisioners = new HashSet<>();
    private final Map<UUID, Long> noFallUntil = new HashMap<>();
    private final Map<UUID, Long> hookCooldowns = new HashMap<>();
    private final Set<UUID> magnetOn = new HashSet<>();
    private final Map<UUID, Long> tpCooldowns = new HashMap<>();
    private Map<Material, ItemStack> smeltMap;

    public SpecialItemsListener(SpookyCraftCore plugin, ItemRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
        this.key = keySpecial(plugin);
    }

    // ------------------------------------------------------------------ Start / Stop

    public void start() {
        registerRecipes();
        resistanceTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (wearsBedrockArmor(p)) giveResistance(p);
            }
        }, RESISTANCE_PERIOD_TICKS, RESISTANCE_PERIOD_TICKS);
        magnetTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickMagnets, 5L, 3L);
        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
    }

    public void stop() {
        if (resistanceTask != null) resistanceTask.cancel();
        if (magnetTask != null) magnetTask.cancel();
        for (NamespacedKey k : recipeKeys) Bukkit.removeRecipe(k);
        recipeKeys.clear();
        for (UUID id : new ArrayList<>(speeders)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.removePotionEffect(PotionEffectType.SPEED);
        }
        for (UUID id : new ArrayList<>(nightVisioners)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }
        nightVisioners.clear();
        for (UUID id : new ArrayList<>(flyers)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE)) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
        }
        speeders.clear();
        flyers.clear();
    }

    private void registerRecipes() {
        addRecipe("bedrock_schwert", "B", "B", "S");
        addRecipe("bedrock_helm", "BBB", "B B");
        addRecipe("bedrock_brustplatte", "B B", "BBB", "BBB");
        addRecipe("bedrock_beinschutz", "BBB", "B B", "B B");
        addRecipe("bedrock_stiefel", "B B", "B B");
    }

    private void addRecipe(String id, String... shape) {
        ItemTemplate template = registry.getTemplate(id);
        if (template == null) return;
        NamespacedKey recipeKey = new NamespacedKey(plugin, "craft_" + id);
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, registry.build(template));
        recipe.shape(shape);
        recipe.setIngredient('B', Material.BEDROCK);
        if (id.equals("bedrock_schwert")) recipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(recipe);
        recipeKeys.add(recipeKey);
    }

    // ------------------------------------------------------------------ Hilfen

    private String special(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    private boolean onCooldown(Player p) {
        long seconds = Math.max(0, plugin.getConfig().getInt("special-items.cooldown-seconds", 1));
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(p.getUniqueId());
        if (last != null && now - last < seconds * 1000L) return true;
        cooldowns.put(p.getUniqueId(), now);
        return false;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    private boolean breakable(Block block) {
        Material type = block.getType();
        if (type.isAir() || block.isLiquid()) return false;
        if (type.getHardness() < 0) return false; // Bedrock & Co.
        String name = type.name();
        return !PROTECTED.contains(name) && !name.endsWith("_SHULKER_BOX");
    }

    private List<Block> sphere(Block center, int radius) {
        List<Block> blocks = new ArrayList<>();
        int r2 = radius * radius;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x * x + y * y + z * z <= r2) blocks.add(center.getRelative(x, y, z));
                }
            }
        }
        return blocks;
    }

    /** Fragt Schutz-Plugins (Grundstücke etc.) per BlockBreakEvent; true = erlaubt. */
    private boolean allowed(Player player, Block block) {
        BlockBreakEvent event = new BlockBreakEvent(block, player);
        AreaMiningListener.setExtraBreak(true);
        try {
            Bukkit.getPluginManager().callEvent(event);
        } finally {
            AreaMiningListener.setExtraBreak(false);
        }
        return !event.isCancelled();
    }

    // ------------------------------------------------------------------ Flug-Schuhe / Speed-Schuhe / Bedrock-Rüstung

    @EventHandler
    public void onArmorChange(PlayerArmorChangeEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            if (event.getSlotType() == PlayerArmorChangeEvent.SlotType.FEET) {
                updateFlight(p);
                updateSpeed(p);
            }
            if (event.getSlotType() == PlayerArmorChangeEvent.SlotType.HEAD) updateNightVision(p);
            if (wearsBedrockArmor(p) && !p.hasPotionEffect(PotionEffectType.RESISTANCE)) giveResistance(p);
        });
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) refresh(p);
        }, 5L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) refresh(p);
        }, 5L);
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) updateFlight(p);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        flyers.remove(id);
        speeders.remove(id);
        cooldowns.remove(id);
        magnetOn.remove(id);
        tpCooldowns.remove(id);
        nightVisioners.remove(id);
        noFallUntil.remove(id);
        hookCooldowns.remove(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        flyers.remove(event.getEntity().getUniqueId());
        speeders.remove(event.getEntity().getUniqueId());
        nightVisioners.remove(event.getEntity().getUniqueId());
    }

    private void refresh(Player p) {
        updateFlight(p);
        updateSpeed(p);
        updateNightVision(p);
        if (wearsBedrockArmor(p) && !p.hasPotionEffect(PotionEffectType.RESISTANCE)) giveResistance(p);
    }

    private void updateFlight(Player p) {
        String bootId = special(p.getInventory().getBoots());
        boolean wears = "flugschuhe".equals(bootId) || "flug_speed_schuhe".equals(bootId);
        GameMode gm = p.getGameMode();
        boolean survivalLike = gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE;
        if (wears && survivalLike) {
            if (flyers.add(p.getUniqueId())) {
                p.setAllowFlight(true);
                if (!p.isOnGround()) p.setFlying(true);
                msg(p, "&b[Flugschuhe] &eFlugmodus aktiviert!");
            }
        } else if (flyers.remove(p.getUniqueId())) {
            if (survivalLike) {
                p.setFlying(false);
                p.setAllowFlight(false);
                msg(p, "&b[Flugschuhe] &cFlugmodus deaktiviert!");
            }
        }
    }

    private void updateSpeed(Player p) {
        String bootId = special(p.getInventory().getBoots());
        boolean wears = "speedschuhe".equals(bootId) || "flug_speed_schuhe".equals(bootId);
        if (wears) {
            speeders.add(p.getUniqueId());
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 10, false, false, false));
        } else {
            boolean ours = speeders.remove(p.getUniqueId());
            PotionEffect effect = p.getPotionEffect(PotionEffectType.SPEED);
            // auch Reste vom alten Skript (Speed 11, sehr lang) entfernen
            boolean leftover = effect != null && effect.getAmplifier() == 10 && (effect.isInfinite() || effect.getDuration() > 20 * 3600);
            if (ours || leftover) p.removePotionEffect(PotionEffectType.SPEED);
        }
    }

    private void updateNightVision(Player p) {
        boolean wears = "nachtsicht_helm".equals(special(p.getInventory().getHelmet()));
        if (wears) {
            nightVisioners.add(p.getUniqueId());
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        } else {
            boolean ours = nightVisioners.remove(p.getUniqueId());
            PotionEffect effect = p.getPotionEffect(PotionEffectType.NIGHT_VISION);
            // Rest nach Neustart/Absturz: unendliche Nachtsicht ohne Brille entfernen
            boolean leftover = effect != null && effect.getAmplifier() == 0 && effect.isInfinite();
            if (ours || leftover) p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }
    }

    private boolean wearsBedrockArmor(Player p) {
        for (ItemStack piece : p.getInventory().getArmorContents()) {
            String s = special(piece);
            if (s != null && BEDROCK_ARMOR.contains(s)) return true;
        }
        return false;
    }

    private void giveResistance(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, RESISTANCE_DURATION_TICKS, 0, false, false, true));
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(event.getEntity() instanceof Player p)) return;
        String boots = special(p.getInventory().getBoots());
        if ("flugschuhe".equals(boots) || "flug_speed_schuhe".equals(boots)) event.setCancelled(true);
        else if (noFallUntil.getOrDefault(p.getUniqueId(), 0L) > System.currentTimeMillis()) event.setCancelled(true);
    }

    // ------------------------------------------------------------------ Mining-Pistole / Erz-Wandler / Bedrock-Brecher

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        ItemStack item = event.getItem();
        String special = special(item);
        if (special == null) return;
        Player player = event.getPlayer();
        Action action = event.getAction();

        switch (special) {
            case "mining_pistole" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                if (onCooldown(player)) return;
                Block target = player.getTargetBlockExact(64);
                if (target == null || !breakable(target)) return;
                player.getWorld().playSound(player.getLocation(), "entity.generic.explode", 0.5f, 2.0f);
                int radius = PISTOL_RADII[random.nextInt(PISTOL_RADII.length)];
                startPistole(player, item, target, radius);
            }
            case "erz_wandler" -> {
                if (action != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
                event.setCancelled(true);
                if (onCooldown(player)) return;
                convertOres(player, event.getClickedBlock());
            }
            case "bedrock_brecher" -> {
                if (action != Action.LEFT_CLICK_BLOCK && action != Action.RIGHT_CLICK_BLOCK) return;
                Block block = event.getClickedBlock();
                if (block == null || block.getType() != Material.BEDROCK) return;
                event.setCancelled(true);
                if (!allowed(player, block)) return;
                Location loc = block.getLocation().add(0.5, 0.5, 0.5);
                block.setType(Material.AIR);
                block.getWorld().dropItemNaturally(loc, new ItemStack(Material.BEDROCK));
                block.getWorld().playSound(loc, "block.stone.break", 1.0f, 1.0f);
            }
            case "magnet" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                if (magnetOn.remove(player.getUniqueId())) {
                    msg(player, "&c[Magnet] &cAusgeschaltet.");
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.7f);
                } else {
                    magnetOn.add(player.getUniqueId());
                    msg(player, "&a[Magnet] &aEingeschaltet!");
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.8f, 1.4f);
                }
            }
            case "teleport_stab" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                teleport(player);
            }
            case "verkleinerung_stab" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                if (onCooldown(player)) return;
                toggleScale(player, player, false);
            }
            case "vergroesserung_stab" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                if (onCooldown(player)) return;
                toggleScale(player, player, true);
            }
            case "enterhaken" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                grapple(player);
            }
            case "handy" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                openPhone(player);
            }
            case "mob_faenger" -> {
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
                event.setCancelled(true);
                releaseMob(player, item, event.getClickedBlock(), event.getBlockFace());
            }
            default -> { }
        }
    }

    /** Baut die Kugel in Stücken pro Tick ab (verhindert einen Lag-Spike bei Radius 7 = ~1400 Blöcke). */
    private void startPistole(Player player, ItemStack tool, Block center, int radius) {
        List<Block> blocks = new ArrayList<>();
        for (Block b : sphere(center, radius)) if (breakable(b)) blocks.add(b);
        if (blocks.isEmpty()) return;
        Location origin = center.getLocation();
        blocks.sort(Comparator.comparingDouble(b -> b.getLocation().distanceSquared(origin)));

        final int perTick = Math.max(20, plugin.getConfig().getInt("special-items.pistol-blocks-per-tick", 200));
        final boolean toInventory = plugin.getConfig().getBoolean("special-items.pistol-drops-to-inventory", true);
        final ItemStack toolCopy = tool.clone();

        new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                int done = 0;
                int end = Math.min(blocks.size(), index + perTick);
                for (; index < end; index++) {
                    Block block = blocks.get(index);
                    if (!breakable(block)) continue;
                    BlockBreakEvent event = new BlockBreakEvent(block, player);
                    AreaMiningListener.setExtraBreak(true);
                    try {
                        Bukkit.getPluginManager().callEvent(event);
                    } finally {
                        AreaMiningListener.setExtraBreak(false);
                    }
                    if (event.isCancelled()) continue;
                    done++;
                    if (event.isDropItems() && toInventory) {
                        Collection<ItemStack> drops = block.getDrops(toolCopy, player);
                        block.setType(Material.AIR);
                        for (ItemStack drop : drops) {
                            for (ItemStack left : player.getInventory().addItem(drop).values()) {
                                block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), left);
                            }
                        }
                    } else if (event.isDropItems()) {
                        block.breakNaturally(toolCopy);
                    } else {
                        block.setType(Material.AIR);
                    }
                }
                if (index >= blocks.size()) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void convertOres(Player player, Block center) {
        for (Block block : sphere(center, 3)) {
            if (!breakable(block)) continue;
            if (!allowed(player, block)) continue;
            block.setType(ORES[random.nextInt(ORES.length)]);
        }
        player.getWorld().playSound(center.getLocation(), "block.amethyst_block.chime", 1.0f, 1.0f);
    }

    // ------------------------------------------------------------------ Schwamm / unendliche Eimer

    private static final BlockFace[] FACES = {BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    /** Schwamm platzieren: saugt Wasser auf (wie Vanille), wird aber nicht gesetzt und bleibt im Inventar. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpongePlace(BlockPlaceEvent event) {
        if (!"unendlich_schwamm".equals(special(event.getItemInHand()))) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        Block start = event.getBlockPlaced();
        if (soak(player, start) > 0) {
            player.getWorld().playSound(start.getLocation(), "block.pointed_dripstone.drip_water", 1.0f, 1.0f);
        }
    }

    /** Wie der Vanille-Schwamm: breitet sich nur durch aufgesaugtes Wasser aus (Radius 6, höchstens 65 Blöcke). */
    private int soak(Player player, Block start) {
        int maxDepth = Math.max(1, plugin.getConfig().getInt("special-items.sponge-radius", 6));
        int maxBlocks = Math.max(1, plugin.getConfig().getInt("special-items.sponge-max-blocks", 65));
        Set<Block> seen = new HashSet<>();
        Deque<Block> queue = new ArrayDeque<>();
        Deque<Integer> depths = new ArrayDeque<>();
        seen.add(start);
        queue.add(start);
        depths.add(0);
        int removed = 0;
        if (absorb(player, start)) removed++;
        while (!queue.isEmpty() && removed < maxBlocks) {
            Block current = queue.poll();
            int depth = depths.poll();
            if (depth >= maxDepth) continue;
            for (BlockFace face : FACES) {
                Block next = current.getRelative(face);
                if (!seen.add(next)) continue;
                if (!absorb(player, next)) continue;
                removed++;
                queue.add(next);
                depths.add(depth + 1);
                if (removed >= maxBlocks) break;
            }
        }
        return removed;
    }

    private boolean absorb(Player player, Block block) {
        Material type = block.getType();
        boolean liquid = type == Material.WATER;
        boolean logged = false;
        boolean plant = false;
        if (!liquid) {
            if (block.getBlockData() instanceof Waterlogged wlog && wlog.isWaterlogged()) {
                logged = true;
            } else if (type == Material.SEAGRASS || type == Material.TALL_SEAGRASS || type == Material.KELP
                    || type == Material.KELP_PLANT || type == Material.BUBBLE_COLUMN) {
                plant = true;
            }
        }
        if (!liquid && !logged && !plant) return false;
        if (!allowed(player, block)) return false;
        if (logged) {
            Waterlogged data = (Waterlogged) block.getBlockData();
            data.setWaterlogged(false);
            block.setBlockData(data, false);
        } else {
            block.setType(Material.AIR, false);
        }
        return true;
    }

    /** Unendliche Eimer: nach dem Ausleeren bekommt der Spieler wieder genau denselben vollen Eimer. */
    @EventHandler(ignoreCancelled = true)
    public void onInfiniteBucket(PlayerBucketEmptyEvent event) {
        ItemStack inHand = event.getPlayer().getInventory().getItem(event.getHand());
        String special = special(inHand);
        if (!"unendlich_wassereimer".equals(special) && !"unendlich_lavaeimer".equals(special)) return;
        event.setItemStack(inHand.clone());
    }

    /** Unendlicher Leer-Eimer: nimmt Wasser/Lava/Pulverschnee auf, bleibt aber immer leer. */
    @EventHandler(ignoreCancelled = true)
    public void onInfiniteEmptyBucket(org.bukkit.event.player.PlayerBucketFillEvent event) {
        ItemStack inHand = event.getPlayer().getInventory().getItem(event.getHand());
        if (!"unendlich_leereimer".equals(special(inHand))) return;
        event.setItemStack(inHand.clone());
    }

    // ------------------------------------------------------------------ Ban-Hammer

    @EventHandler
    public void onHammer(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker) || !(event.getEntity() instanceof Player victim)) return;
        if (!"banhammer".equals(special(attacker.getInventory().getItemInMainHand()))) return;
        event.setCancelled(true);
        if (!attacker.isOp() && !attacker.hasPermission("spookycraft.core.admin") && !attacker.hasPermission("spookycraft.punish.ban")) {
            msg(attacker, "&cDu darfst den Ban-Hammer nicht benutzen.");
            return;
        }
        if (victim.isOp()) {
            msg(attacker, "&cOperatoren kannst du nicht mit dem Ban-Hammer bannen.");
            return;
        }
        final String name = victim.getName();
        victim.getWorld().strikeLightningEffect(victim.getLocation());
        Bukkit.getScheduler().runTaskLater(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + name + " Du wurdest vom Ban-Hammer getroffen!"), 1L);
        msg(attacker, "&c&l[Ban-Hammer] &e" + name + " &cwurde permanent verbannt!");
    }

    // ------------------------------------------------------------------ Magnet / Auto-Schmelz-Picke / Teleport-Stab / Verkleinerungs-Stab

    private void tickMagnets() {
        if (magnetOn.isEmpty()) return;
        double radius = Math.max(1.0, plugin.getConfig().getDouble("special-items.magnet-radius", 7.0));
        for (UUID id : new ArrayList<>(magnetOn)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || p.isDead()) continue;
            if (!hasSpecial(p, "magnet")) {
                magnetOn.remove(id);
                continue;
            }
            Location target = p.getLocation().add(0, 0.6, 0);
            for (org.bukkit.entity.Entity e : p.getNearbyEntities(radius, radius, radius)) {
                boolean item = e instanceof org.bukkit.entity.Item;
                if (!item && !(e instanceof org.bukkit.entity.ExperienceOrb)) continue;
                if (item) {
                    org.bukkit.entity.Item drop = (org.bukkit.entity.Item) e;
                    if (drop.getPickupDelay() > 10) continue; // gerade erst fallen gelassen / geworfen
                }
                org.bukkit.util.Vector v = target.toVector().subtract(e.getLocation().toVector());
                double len = v.length();
                if (len < 0.3) continue;
                e.setVelocity(v.normalize().multiply(Math.min(0.6, 0.15 + len * 0.08)));
            }
        }
    }

    private boolean hasSpecial(Player p, String id) {
        for (ItemStack it : p.getInventory().getContents()) {
            if (id.equals(special(it))) return true;
        }
        return false;
    }

    private Map<Material, ItemStack> smeltMap() {
        if (smeltMap == null) {
            Map<Material, ItemStack> m = new HashMap<>();
            java.util.Iterator<org.bukkit.inventory.Recipe> it = Bukkit.recipeIterator();
            while (it.hasNext()) {
                org.bukkit.inventory.Recipe r = it.next();
                if (!(r instanceof org.bukkit.inventory.FurnaceRecipe f)) continue;
                Material in = f.getInput().getType();
                String n = in.name();
                if (n.startsWith("RAW_") || n.equals("ANCIENT_DEBRIS") || n.endsWith("_ORE")) m.putIfAbsent(in, f.getResult());
            }
            smeltMap = m;
        }
        return smeltMap;
    }

    /** Auto-Schmelz-Picke: Erze droppen direkt geschmolzen ins Inventar. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSmeltBreak(BlockBreakEvent event) {
        Player p = event.getPlayer();
        if (!"autosmelt_picke".equals(special(p.getInventory().getItemInMainHand()))) return;
        if (p.getGameMode() == GameMode.CREATIVE) return;
        Block block = event.getBlock();
        String n = block.getType().name();
        if (!(n.endsWith("_ORE") || n.equals("ANCIENT_DEBRIS"))) return;
        Collection<ItemStack> drops = block.getDrops(p.getInventory().getItemInMainHand(), p);
        if (drops.isEmpty()) return;
        event.setDropItems(false);
        Location loc = block.getLocation().add(0.5, 0.5, 0.5);
        for (ItemStack drop : drops) {
            ItemStack out = drop.clone();
            ItemStack smelted = smeltMap().get(drop.getType());
            if (smelted != null) {
                out = smelted.clone();
                out.setAmount(drop.getAmount() * Math.max(1, smelted.getAmount()));
            }
            for (ItemStack left : p.getInventory().addItem(out).values()) {
                block.getWorld().dropItemNaturally(loc, left);
            }
        }
        block.getWorld().spawnParticle(org.bukkit.Particle.FLAME, loc, 8, 0.25, 0.25, 0.25, 0.01);
    }

    private void teleport(Player p) {
        long seconds = Math.max(0, plugin.getConfig().getInt("special-items.teleport-cooldown-seconds", 3));
        long now = System.currentTimeMillis();
        Long last = tpCooldowns.get(p.getUniqueId());
        if (last != null && now - last < seconds * 1000L) return;
        double range = Math.max(3.0, plugin.getConfig().getDouble("special-items.teleport-range", 30.0));
        org.bukkit.util.RayTraceResult hit = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(),
                range, org.bukkit.FluidCollisionMode.NEVER, true);
        Location dest;
        if (hit != null && hit.getHitBlock() != null) {
            BlockFace face = hit.getHitBlockFace() == null ? BlockFace.UP : hit.getHitBlockFace();
            dest = hit.getHitBlock().getRelative(face).getLocation().add(0.5, 0, 0.5);
        } else {
            dest = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(range)).getBlock().getLocation().add(0.5, -1, 0.5);
        }
        dest = safeSpot(dest);
        if (dest == null) {
            msg(p, "&c[Teleport-Stab] &cDort ist kein sicherer Platz.");
            return;
        }
        tpCooldowns.put(p.getUniqueId(), now);
        dest.setYaw(p.getLocation().getYaw());
        dest.setPitch(p.getLocation().getPitch());
        Location from = p.getLocation();
        from.getWorld().spawnParticle(org.bukkit.Particle.PORTAL, from.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.5);
        p.teleport(dest);
        p.setFallDistance(0f);
        dest.getWorld().spawnParticle(org.bukkit.Particle.PORTAL, dest.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.5);
        dest.getWorld().playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
    }

    /** Sucht (bis 3 Blöcke nach oben) einen Platz mit freien Füßen/Kopf und festem/ungefährlichem Boden. */
    private Location safeSpot(Location base) {
        for (int up = 0; up <= 3; up++) {
            Block feet = base.clone().add(0, up, 0).getBlock();
            Block head = feet.getRelative(BlockFace.UP);
            Block ground = feet.getRelative(BlockFace.DOWN);
            if (!feet.isPassable() || !head.isPassable()) continue;
            if (feet.isLiquid() || head.isLiquid()) continue;
            if (ground.getType() == Material.LAVA || ground.getType() == Material.FIRE || ground.getType() == Material.MAGMA_BLOCK) continue;
            return feet.getLocation().add(0.5, 0, 0.5);
        }
        return null;
    }

    private void toggleScale(Player actor, org.bukkit.entity.LivingEntity target, boolean grow) {
        org.bukkit.attribute.AttributeInstance attr = target.getAttribute(org.bukkit.attribute.Attribute.GENERIC_SCALE);
        if (attr == null) return;
        double goal = grow ? Math.min(16.0, Math.max(1.1, plugin.getConfig().getDouble("special-items.grow-scale", 2.0)))
                : Math.max(0.0625, plugin.getConfig().getDouble("special-items.shrink-scale", 0.4));
        boolean active = grow ? attr.getBaseValue() > 1.01 : attr.getBaseValue() < 0.99;
        attr.setBaseValue(active ? 1.0 : goal);
        String tag = grow ? "&6[Vergrößerung] " : "&b[Verkleinerung] ";
        actor.playSound(actor.getLocation(), Sound.ENTITY_ILLUSIONER_CAST_SPELL, 0.8f, active ? 0.8f : (grow ? 0.6f : 1.6f));
        if (target instanceof Player tp && tp != actor) {
            msg(tp, tag + (active ? "&7Du bist wieder normal groß." : (grow ? "&7Du wurdest vergrößert!" : "&7Du wurdest verkleinert!")));
        }
        msg(actor, tag + (active ? "&7Wieder normal groß." : (grow ? "&7Riesig!" : "&7Klein!")));
    }

    @EventHandler
    public void onShrinkEntity(org.bukkit.event.player.PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player p = event.getPlayer();
        String sp = special(p.getInventory().getItemInMainHand());
        if (sp == null) return;
        if (sp.equals("mob_faenger")) {
            event.setCancelled(true);
            if (event.getRightClicked() instanceof org.bukkit.entity.LivingEntity le) catchMob(p, le);
            return;
        }
        boolean grow = sp.equals("vergroesserung_stab");
        if (!grow && !sp.equals("verkleinerung_stab")) return;
        if (!(event.getRightClicked() instanceof org.bukkit.entity.LivingEntity target)) return;
        event.setCancelled(true);
        if (!p.isSneaking()) return; // ohne Sneak: nur Selbst-Toggle über Luft/Block
        if (target instanceof Player other && other != p) {
            String perm = plugin.getConfig().getString("special-items.shrink-others-permission", "spookycraft.items.shrink.others");
            if (!p.isOp() && !p.hasPermission(perm)) {
                msg(p, "&c[Größe] &cDu darfst keine Spieler verändern.");
                return;
            }
        }
        if (onCooldown(p)) return;
        toggleScale(p, target, grow);
    }

    // ------------------------------------------------------------------ Mob-Fänger (Ball)

    private NamespacedKey mobKey() {
        return new NamespacedKey(plugin, "mob_data");
    }

    private void catchMob(Player p, org.bukkit.entity.LivingEntity target) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        org.bukkit.inventory.meta.ItemMeta meta = hand.getItemMeta();
        if (meta == null) return;
        if (meta.getPersistentDataContainer().has(mobKey(), PersistentDataType.STRING)) {
            msg(p, "&c[Mob-Fänger] &cDer Ball ist schon voll. Lass das Mob erst frei.");
            return;
        }
        if (target instanceof Player || target instanceof org.bukkit.entity.ArmorStand) {
            msg(p, "&c[Mob-Fänger] &cDas kann man nicht fangen.");
            return;
        }
        if (plugin.getConfig().getStringList("special-items.catch-blacklist").contains(target.getType().name())) {
            msg(p, "&c[Mob-Fänger] &cDieses Mob ist zu stark für den Ball.");
            return;
        }
        if (target.getPassengers().size() > 0 || target.isInsideVehicle()) {
            msg(p, "&c[Mob-Fänger] &cDas Mob sitzt/trägt gerade etwas.");
            return;
        }
        if (onCooldown(p)) return;
        // Schutz: darf der Spieler dem Mob etwas antun? (Claims/Plots reagieren auf den Schadens-Event)
        EntityDamageByEntityEvent test = new EntityDamageByEntityEvent(p, target, EntityDamageEvent.DamageCause.ENTITY_ATTACK, 0.0);
        Bukkit.getPluginManager().callEvent(test);
        if (test.isCancelled()) {
            msg(p, "&c[Mob-Fänger] &cHier darfst du nichts fangen.");
            return;
        }
        byte[] data;
        try {
            data = Bukkit.getUnsafe().serializeEntity(target);
        } catch (Throwable t) {
            msg(p, "&c[Mob-Fänger] &cDieses Mob konnte nicht gefangen werden.");
            return;
        }
        String name = target.customName() != null
                ? net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(target.customName())
                : target.getType().name().toLowerCase().replace('_', ' ');
        ItemStack ball = hand.clone();
        ball.setAmount(1);
        org.bukkit.inventory.meta.ItemMeta bm = ball.getItemMeta();
        bm.getPersistentDataContainer().set(mobKey(), PersistentDataType.STRING, java.util.Base64.getEncoder().encodeToString(data));
        bm.setCustomModelData(907);
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(net.kyori.adventure.text.Component.text("Rechtsklick auf einen Block: freilassen", net.kyori.adventure.text.format.NamedTextColor.GRAY)
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        lore.add(net.kyori.adventure.text.Component.text("Gefangen: " + name, net.kyori.adventure.text.format.NamedTextColor.GREEN)
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        bm.lore(lore);
        ball.setItemMeta(bm);
        Location loc = target.getLocation();
        target.remove();
        if (hand.getAmount() > 1) {
            hand.setAmount(hand.getAmount() - 1);
            for (ItemStack left : p.getInventory().addItem(ball).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
        } else {
            p.getInventory().setItemInMainHand(ball);
        }
        loc.getWorld().spawnParticle(org.bukkit.Particle.CLOUD, loc.clone().add(0, 0.5, 0), 20, 0.3, 0.4, 0.3, 0.02);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.8f);
        msg(p, "&a[Mob-Fänger] &7Gefangen: &f" + name);
    }

    private void releaseMob(Player p, ItemStack ball, Block clicked, BlockFace face) {
        org.bukkit.inventory.meta.ItemMeta meta = ball.getItemMeta();
        if (meta == null) return;
        String enc = meta.getPersistentDataContainer().get(mobKey(), PersistentDataType.STRING);
        if (enc == null) {
            msg(p, "&7[Mob-Fänger] &7Der Ball ist leer. Rechtsklick auf ein Mob, um es zu fangen.");
            return;
        }
        Block base = clicked != null ? clicked : p.getTargetBlockExact(6);
        if (base == null) return;
        Block spot = base.getRelative(face == null ? BlockFace.UP : face);
        if (onCooldown(p)) return;
        if (!spot.isPassable()) {
            msg(p, "&c[Mob-Fänger] &cDort ist kein Platz.");
            return;
        }
        Location at = spot.getLocation().add(0.5, 0, 0.5);
        try {
            org.bukkit.entity.Entity e = Bukkit.getUnsafe().deserializeEntity(java.util.Base64.getDecoder().decode(enc), at.getWorld());
            e.spawnAt(at);
        } catch (Throwable t) {
            msg(p, "&c[Mob-Fänger] &cDas Mob konnte nicht freigelassen werden.");
            return;
        }
        org.bukkit.inventory.meta.ItemMeta bm = ball.getItemMeta();
        bm.getPersistentDataContainer().remove(mobKey());
        bm.setCustomModelData(906);
        bm.lore(List.of(net.kyori.adventure.text.Component.text("Rechtsklick auf ein Mob: einfangen", net.kyori.adventure.text.format.NamedTextColor.GRAY)
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false),
                net.kyori.adventure.text.Component.text("(Leer)", net.kyori.adventure.text.format.NamedTextColor.DARK_GRAY)
                        .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)));
        ball.setItemMeta(bm);
        at.getWorld().spawnParticle(org.bukkit.Particle.CLOUD, at.clone().add(0, 0.5, 0), 20, 0.3, 0.4, 0.3, 0.02);
        at.getWorld().playSound(at, Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.2f);
        msg(p, "&a[Mob-Fänger] &7Freigelassen!");
    }

    // ------------------------------------------------------------------ Enterhaken / Handy

    private void grapple(Player p) {
        long now = System.currentTimeMillis();
        Long last = hookCooldowns.get(p.getUniqueId());
        long cd = Math.max(0, plugin.getConfig().getInt("special-items.hook-cooldown-seconds", 2)) * 1000L;
        if (last != null && now - last < cd) return;
        double range = Math.max(5.0, plugin.getConfig().getDouble("special-items.hook-range", 40.0));
        org.bukkit.util.RayTraceResult hit = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(),
                range, org.bukkit.FluidCollisionMode.NEVER, true);
        if (hit == null || hit.getHitBlock() == null) {
            msg(p, "&c[Enterhaken] &cKein Block in Reichweite.");
            return;
        }
        hookCooldowns.put(p.getUniqueId(), now);
        final Location target = hit.getHitPosition().toLocation(p.getWorld());
        // Seil aus Partikeln
        Location from = p.getEyeLocation().add(0, -0.4, 0);
        org.bukkit.util.Vector line = target.toVector().subtract(from.toVector());
        double len = line.length();
        line.normalize();
        for (double d = 0; d < len; d += 0.7) {
            p.getWorld().spawnParticle(org.bukkit.Particle.CRIT, from.clone().add(line.clone().multiply(d)), 1, 0, 0, 0, 0);
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_FISHING_BOBBER_THROW, 1.0f, 0.8f);
        noFallUntil.put(p.getUniqueId(), now + 8000L);
        final int[] ticks = {0};
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!p.isOnline() || p.isDead() || ++ticks[0] > 40) {
                    cancel();
                    return;
                }
                org.bukkit.util.Vector to = target.toVector().subtract(p.getLocation().add(0, 1, 0).toVector());
                double dist = to.length();
                if (dist < 2.0) {
                    cancel();
                    return;
                }
                p.setVelocity(to.normalize().multiply(Math.min(1.8, 0.7 + dist * 0.05)).add(new org.bukkit.util.Vector(0, 0.08, 0)));
                p.setFallDistance(0f);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Menü-Eintrag: {Slot, Material, Name, Befehl}. */
    private static final Object[][] PHONE = {
            {10, Material.ENDER_PEARL, "&b&lSpawn", "spawn"},
            {11, Material.EMERALD, "&a&lMarkt", "markt"},
            {12, Material.GOLD_INGOT, "&6&lBank", "bank"},
            {13, Material.RED_BED, "&c&lHomes", "homes"},
            {14, Material.IRON_PICKAXE, "&e&lJobs", "jobs"},
            {15, Material.CLOCK, "&f&lTägliche Belohnung", "daily"},
            {16, Material.COMPASS, "&9&lRandom-Teleport", "rtp"},
            {19, Material.MAP, "&b&lWarps", "warps"},
            {20, Material.ENDER_CHEST, "&5&lTresor", "tresor"},
            {21, Material.BUNDLE, "&6&lRucksack", "rucksack"},
            {22, Material.SHIELD, "&c&lClan", "clan"},
            {23, Material.NETHER_STAR, "&d&lPerks", "perks"},
            {24, Material.BOOK, "&e&lQuests", "quests"},
            {25, Material.NAME_TAG, "&a&lTitel", "titel"}
    };

    private static final class PhoneHolder implements org.bukkit.inventory.InventoryHolder {
        @Override
        public org.bukkit.inventory.Inventory getInventory() {
            return null;
        }
    }

    private void openPhone(Player p) {
        org.bukkit.inventory.Inventory inv = Bukkit.createInventory(new PhoneHolder(), 27,
                net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand().deserialize("&5&lHandy"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        org.bukkit.inventory.meta.ItemMeta fm = filler.getItemMeta();
        fm.displayName(net.kyori.adventure.text.Component.text(" "));
        filler.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        for (Object[] e : PHONE) {
            ItemStack it = new ItemStack((Material) e[1]);
            org.bukkit.inventory.meta.ItemMeta m = it.getItemMeta();
            m.displayName(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacyAmpersand()
                    .deserialize((String) e[2]).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            m.lore(List.of(net.kyori.adventure.text.Component.text("Klicken: /" + e[3], net.kyori.adventure.text.format.NamedTextColor.GRAY)
                    .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)));
            it.setItemMeta(m);
            inv.setItem((Integer) e[0], it);
        }
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.7f, 1.6f);
    }

    @EventHandler
    public void onPhoneClick(org.bukkit.event.inventory.InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof PhoneHolder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player p)) return;
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;
        for (Object[] e : PHONE) {
            if ((Integer) e[0] == event.getSlot()) {
                String cmd = (String) e[3];
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> p.performCommand(cmd));
                return;
            }
        }
    }

    @EventHandler
    public void onPhoneDrag(org.bukkit.event.inventory.InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof PhoneHolder) event.setCancelled(true);
    }
}
