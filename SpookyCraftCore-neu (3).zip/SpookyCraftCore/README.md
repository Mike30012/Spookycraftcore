# SpookyCraftCore

All-in-One-Plugin für SpookyCraft. Vereint Economy, Punish, Essentials, Nickname,
Friends, Clans, Vanish, Stats, Scoreboard, TabList, Kits, Shop, Auction,
Report, Discord-Webhook, Party, AntiCheat (light) und Maintenance-Mode in
einem Plugin mit gemeinsamer SQLite-Datenbank.

## Build

Voraussetzung: JDK 17, Maven, Internetzugriff auf repo.papermc.io.

```
mvn clean package
```

Das fertige Jar liegt danach in `target/SpookyCraftCore.jar` — einfach in den
`plugins`-Ordner des Servers legen.

## Module an/ausschalten

In `config.yml` unter `modules:` lässt sich jedes Feature einzeln
deaktivieren, ohne den Rest des Plugins anzufassen. `/bccore reload` lädt
die Config neu, `/bccore modules` zeigt den aktuellen Status.

## Struktur

Jedes Feature ist ein eigenständiges Modul unter
`de.craftsucht.core.<modulname>` und implementiert das `Module`-Interface
(`enable()`/`disable()`/`reload()`). Der `ModuleManager` registriert und
verwaltet alle Module zentral. Alle Daten liegen in einer gemeinsamen
SQLite-Datenbank (`blockcity.db` — Dateiname bewusst unverändert, damit bestehende Daten nicht verloren gehen) statt in vielen einzelnen YAML-Dateien —
siehe `database/Database.java` für das Schema.

## Neu: eigenes Rang-/Berechtigungssystem (statt LuckPerms)

Modul `rank` (`de.craftsucht.core.rank`) baut ein eigenes, LuckPerms-ähnliches
System: Ränge mit Prefix, Gewicht und einem Elternrang (Vererbung), sowie
pro Rang gesetzte Permissions. Beim Login bekommt jeder Spieler ein
`PermissionAttachment`, das aus der Vererbungskette seines Rangs berechnet
wird — LuckPerms wird dafür nicht mehr gebraucht (bleibt aber als optionale
softdepend erhalten, falls du parallel weiter damit arbeiten willst).

Befehle: `/rank create|delete|setprefix|setweight|setparent|setpermission|
unsetpermission|info|list|user` (Alias: `/rg`, `/group`).

## Neu: Eigenes Rang-System jetzt All-in-One (Farbe + Name in einem Befehl)

`/rank create <&farbe&lName> [gewicht]` – z.B. `/rank create &4&lOwner` legt
einen Rang an, dessen sichtbarer Name direkt der eingefärbte Text ist (die
Farbcodes werden für die interne ID automatisch entfernt: `&4&lOwner` →
ID `owner`). Der Prefix wird jetzt **live überall** angezeigt, sobald er
gesetzt/geändert wird (kein Neustart, kein Rejoin nötig):

- **Scoreboard** (Sidebar, Rang-Zeile)
- **Tabliste** (`/tab`, Spielerliste)
- **Nametag über dem Kopf** (per Scoreboard-Team pro Betrachter synchronisiert)
- **Chat** (`<Prefix> Spielername §8» Nachricht`)

`/rank setprefix`, `/rank user <spieler> set <rang>` und `/rank delete`
stoßen ebenfalls sofort ein Sichtbarkeits-Update an. Anzeige läuft **immer**
über das eigene Rank-System, auch wenn LuckPerms zusätzlich installiert ist
(siehe weiter unten, warum).

### Echtes `*`-Wildcard bei Permissions

`/rank setpermission <rang> * true` schaltet jetzt wirklich **alle**
bekannten Permission-Nodes frei (von jedem Plugin auf dem Server, siehe
`KnownPermissions.java`) – nicht nur eine bedeutungslose Permission namens
`"*"`, wie es vorher (und bei reinem Bukkit ohne Zusatzlogik) der Fall
gewesen wäre. Gezielte Einzel-Einträge (z.B. `craftsucht.core.admin=false`)
überschreiben den Wildcard trotzdem, falls du mal etwas explizit sperren
willst. Wichtig: Nodes, die irgendwo im Code nur per `hasPermission()`
geprüft, aber nirgends deklariert werden (z.B. eigene, undokumentierte
Checks in Fremd-Plugins), kann grundsätzlich niemand automatisch erfassen –
das ist eine technische Grenze, keine Einschränkung unseres Systems.

## Neu: Scoreboard im Opsucht-artigen Bullet-Stil

Kein Screenshot von Opsucht lag vor, daher an den bekannten "»"-Bullet-Stil
von deutschen Citybuild/Prison-Servern angelehnt: Titel, Trennlinie, dann
`§8» §7Rang/Geld/Server`, Trennlinie. Die Kristalle-Zeile gibt's nicht mehr,
an ihrer Stelle steht jetzt der Rang. Sag Bescheid bzw. schick ein Bild,
falls es noch näher ans Original ran soll.

## Neu: TabCompleter für alle Commands

Jeder Command hat jetzt eigene Tab-Completion (Spielernamen, Unterbefehle,
Enum-Werte wie Gamemodes/true-false/Rang-Namen) statt der Standard-Bukkit-
Vorschläge.

## Neu: Punish-Modul erweitert (Mute, Unban-Log, Historie)

Zusätzlich zu `/ban`, `/tempban`, `/unban`, `/warn`, `/kick` gibt es jetzt:

- **`/mute <spieler> [dauer z.B. 1h] [grund]`** – Chat-Stummschaltung, mit oder
  ohne Ablaufzeit. Blockt normalen Chat **und** Clan-Chat komplett (Clan-Chat
  respektiert jetzt den Cancel-Status des Chat-Events).
- **`/unmute <spieler>`**
- **`/history <spieler>`** – zeigt die letzten 10 Einträge (Typ, Grund, Staff,
  Zeitpunkt, aktiv/erledigt) für einen Spieler, inkl. `UNBAN`/`UNMUTE`
  als eigene Log-Einträge (vorher wurde ein Unban nirgends protokolliert).

## Neu: /alert (server-weite bunte Ankündigung)

`/alert <nachricht>` sendet eine Nachricht an alle Online-Spieler, egal in
welcher Multiverse-Welt sie gerade sind (läuft alles auf demselben
Server-Prozess). Beliebige `&`-Farbcodes im Text werden übersetzt, z.B.
`/alert &6Hallo &laller &6auf SpookyCraft!`. Tab-Completion schlägt beim
Tippen von `&` passende Farbcodes vor. Standardmäßig nur für OP/Admins
(`craftsucht.core.alert`, fällt auch unter `craftsucht.core.admin`).

## Neu: Utility-Modul (ein paar zusätzliche Komfort-Befehle)

`/rtp` (Random Teleport), `/ec` (Enderchest ohne Block), `/craft`
(Werkbank überall), `/repair` (Item in der Hand reparieren), `/hat`
(Item in der Hand aufsetzen).

## Neu: ItemDB direkt eingebaut (vorher eigenes ItemDBPlugin)

Das bisher separate ItemDBPlugin ist jetzt Modul `itemdb`
(`de.craftsucht.core.itemdb`) im Core-Plugin, kein eigenes Jar mehr nötig:

- **`/db add`** – Item aus der Hand (amount=1, inkl. NBT/Enchants/Lore via
  Base64) in die Datenbank
- **`/db search <name>`** / **`/db see`** – Nur-Ansicht-GUI (54 Slots,
  45 Items/Seite + Vor/Zurück), Items sind nicht entnehmbar
- Läuft jetzt über die **gemeinsame** SQLite-Datenbank (`blockcity.db`,
  Tabelle `itemdb_items`) statt einer eigenen `itemdb.db` — falls schon
  Items im alten ItemDBPlugin gesammelt wurden, müssten die manuell aus der
  alten `itemdb.db` in die neue Tabelle übertragen werden (altes Plugin
  bitte vom Server entfernen, sonst laufen zwei `/db`-Commands gegeneinander).
- Permissions unverändert: `itemdb.use` (default: alle), `itemdb.add`
  (default: false — gezielt vergeben, z.B. via `/rank setpermission`)

## Neu: /nav und /server (Welten-Wechsel, vorher eigenes Plugin)

Modul `nav` (`de.craftsucht.core.nav`) - beide Befehle machen dasselbe
(zwei Namen für denselben Command, wie ursprünglich gewünscht):

- **`/nav <welt>`** / **`/server <welt>`** – teleportiert zum Spawn der
  angegebenen Welt (case-insensitiv), listet bei falschem/fehlendem
  Namen die verfügbaren Welten auf
- Tab-Completer schlägt die tatsächlich geladenen Weltnamen vor
- Keine Permission-Einschränkung, frei für alle Spieler nutzbar
- Läuft rein über Bukkits eigene Welten-API (`Bukkit.getWorlds()`), braucht
  also keine Multiverse-Core-Abhängigkeit beim Kompilieren - Multiverse
  erstellt die Welten ja nur, verwaltet sie aber als ganz normale Bukkit-Welten

## Neu: /markt (vorher eigenständiges MarktPlugin, jetzt eingebaut)

Modul `markt` (`de.craftsucht.core.markt`) - das alte, separate MarktPlugin.jar
wurde aus dem hochgeladenen kompilierten Jar dekompiliert (Quellcode lag nicht
mehr vor) und als sauberes Modul portiert:

- **`/markt`** – öffnet das Kauf-/Verkaufs-GUI mit 5 Kategorien (Erze &
  Blöcke, Mob Drops, Essen, Einrichtung, Rüstung & Waffen), Preise/Items in
  `shop.yml` konfigurierbar (liegt jetzt neben `config.yml` im Plugin-Ordner)
- **`/markt reload`** – lädt `shop.yml` neu, jetzt über `craftsucht.core.admin`
  abgesichert (vorher eigene `marktplugin.reload`-Permission)
- Kauf per Linksklick (1 Stück) / Shift-Linksklick (64 Stück) oben im GUI,
  Verkauf per Klick auf ein Item im eigenen Inventar unten

**Wichtige bewusste Änderung:** Das Original nutzte Vault (`net.milkbowl.
vault.economy.Economy`) für die Bezahlung. Das ist jetzt komplett raus –
Kauf/Verkauf läuft direkt über unser eigenes `EconomyManager` (`economy`-
Modul), damit der Kontostand beim Markt garantiert exakt mit dem übereinstimmt,
was Scoreboard, `/eco` und `/pay` anzeigen. Es gibt also keine zwei
möglicherweise auseinanderlaufenden Geld-Quellen mehr.

## Neu: /jobs (vorher eigenständiges MinecraftJobs-Plugin, jetzt eingebaut)

Modul `jobs` (`de.craftsucht.core.jobs`) - wie beim Markt aus einem
hochgeladenen kompilierten Jar dekompiliert (kein Quellcode vorhanden) und
sauber portiert. 5 Jobs (miner/woodcutter/hunter/fisher/digger) mit
Level-System bis 230, **alle Spieler sind automatisch in jedem Job**, jeder Job
hat einen unabhängigen Level/XP-Fortschritt, und alle 10 Level gibt's
Item-Belohnungen + Server-Broadcast.

- **`/jobs`**, **`/jobs info [job]`**
- **`/jobs reload`** (admin-only) - lädt `jobs.yml` neu
- **`/jobs join` und `/jobs leave` wurden entfernt**
- Actionbar-Jobs-Bar zeigt den Fortschritt der Jobs abwechselnd
- Gehalt wird **jede Minute für jeden Job** ausgezahlt
- Neue Jobs starten automatisch auf **Level 1 / 0 XP**
- Job-Definitionen/Preise in eigener `jobs.yml`
- Spielerdaten pro Job in der gemeinsamen SQLite-Datenbank (`jobs_player_jobs`)

**Bewusste Änderungen gegenüber dem Original:**
- **Vault raus, eigene Economy rein** - exakt wie beim Markt, gleicher Grund
  (ein gemeinsamer Kontostand statt zwei potenziell unterschiedlichen). Das
  war vermutlich auch der Grund, warum sich das Plugin bei dir deaktiviert
  hat: `depend: [Vault]` in der `plugin.yml` ist eine harte Abhängigkeit -
  ohne aktives Vault-Plugin lädt Bukkit das Jobs-Plugin gar nicht erst.
- **LuckPerms-Prefix raus, Namensfarbe rein**: Das Original setzte bei
  Job-Titeln (alle 10 Level) einen kompletten LuckPerms-Prefix. Das hätte bei
  uns nichts bewirkt (unser Rang-System ignoriert LuckPerms-Prefixe
  grundsätzlich). Stattdessen wird **nur die Farbe** des höchsten erreichten
  Titels übernommen und auf den Spielernamen in Chat/Tabliste/Nametag
  angewendet - der eigentliche Rang-Prefix (aus `/rank`) bleibt unangetastet,
  nur die Namensfarbe wechselt mit dem Job-Fortschritt.
- **BoosterItemsPlugin-Kopplung per Reflection statt Compile-Dependency**:
  `BoosterHook` ruft `de.spookycraft.boosteritems.BoosterAPI` jetzt über
  Reflection auf (Klasse/Methoden zur Laufzeit per Namen gesucht), nicht per
  echtem Java-Import. Grund: BoosterItemsPlugin ist noch ein separates
  Plugin, dessen Quellcode/API uns hier nicht vorliegt. Sobald es auch mal in
  SpookyCraftCore integriert wird, funktioniert die Kopplung automatisch
  weiter, ohne Codeänderung hier.
- **Bug aus dem Original gefixt**: Beim Fischen wurde nie ausgezahlt, weil
  eine nie zugewiesene Variable statt des tatsächlichen Auszahlungsbetrags
  geprüft wurde (`JobListener.onFish`). Jetzt korrekt.

**Zu erledigen bei dir:** altes `MinecraftJobs-1.jar` vom Server entfernen
(sonst Command-Konflikt bei `/jobs`).

## Neu: /prefix ändert jetzt die RANG-Farbe (nicht mehr nur persönliche Namensfarbe)

**Update (19.09.):** `/prefix` färbt jetzt den **Rang-Prefix** um (z.B.
`Owner:`), nicht mehr nur den Namen des ausführenden Spielers - betrifft
also **alle** mit demselben Rang, weil der Rang-Prefix serverweit geteilt
ist. War vorher eine rein persönliche Namensfarbe, wurde auf Wunsch
umgestellt.

- **`/prefix`** – öffnet ein GUI mit allen Meilensteinen (Level 10-230) des
  aktuell aktiven Jobs. Erreichte Level sind als farbige Glasscheibe anklickbar
  (setzt die Rang-Farbe auf die jeweilige Titel-Farbe), noch nicht erreichte
  sind grau gesperrt mit Level-Angabe.
- **`/prefix hex <RRGGBB>`** – setzt die Rang-Farbe auf eine **komplett
  freie** Farbe, z.B. `/prefix hex FF00AA`. Volle Hex-Unterstützung, nicht
  nur die 16 klassischen Minecraft-Farben.
- **`/prefix reset`** – Rang-Farbe zurück auf Weiß.
- Nur die Farbe ändert sich, Text/Fettdruck des Rang-Prefixes bleiben
  gleich (`&4&lOwner` → `&b&lOwner` bei Blau z.B.).

**Bugfix nebenbei gefunden:** `/rank setprefix` hat bisher **nie** wirklich
etwas geändert - `createRank()` nutzt intern `INSERT OR IGNORE`, das
ignoriert bei einem bereits existierenden Rang den kompletten Aufruf
stillschweigend. Jetzt gibt's eine echte `RankManager#updatePrefix()`
(UPDATE-Statement), die auch `/rank setprefix` selbst jetzt nutzt.

**Technische Einschränkung:** Das Nametag über dem Kopf läuft über
Minecrafts Scoreboard-Team-System, und das kennt bei der Farbe nur die 16
klassischen Farben, keine beliebigen Hex-Werte (Protokoll-Limitierung, nicht
unsere). Bei einer per `/prefix hex` gesetzten Hex-Farbe zeigen **Chat und
Tabliste** sie trotzdem korrekt an, nur das Nametag über dem Kopf bleibt in
dem Fall auf der Standardfarbe.


**Bugfix nebenbei gefunden:** Die Farb-Erkennung aus den Job-Titeln
(`RewardManager.extractColor`) hat vorher praktisch immer nur Grau
zurückgegeben, weil sie den ersten Farbcode im Titel-String genommen hat -
das ist aber immer die graue Klammer (`&7[`), nicht die eigentliche
Titelfarbe. Jetzt wird korrekt der zweite Farbcode (die tatsächliche
Tier-Farbe) verwendet.

## Neu: /citem (vorher eigenständiges BoosterItemsPlugin, jetzt eingebaut)

Modul `booster` (`de.craftsucht.core.booster`) - wie Markt/Jobs aus einem
hochgeladenen kompilierten Jar dekompiliert und sauber portiert. Custom-Items
mit echten Enchantments (Unsafe-Level, normale Tooltip-Farbe) und Job-Geld/
XP-Boost, den das jobs-Modul beim Auszahlen automatisch berücksichtigt.

- **`/citem give <spieler> <item-id> [prozent]`**, **`/citem list`**,
  **`/citem reload`**
- Items in eigener `items.yml` definiert (Material, Name, Enchants, Lore,
  Booster-Job + Prozentsätze)
- **Neu gegenüber dem Original:** beim Ausgeben optional einen Prozentsatz
  direkt mitgeben, `/citem give Mike spookycraft_minerpicke 250` gibt z.B.
  eine Picke mit +250% statt dem `items.yml`-Standardwert - klemmt auf
  10-1000%, wie gewünscht
- Minerpicke umbenannt zu `&6&lSpookycraft_Minerpicke` (vorher "OPSUCHT
  Minerpicke")

**Keine Reflection mehr nötig:** Weil Jobs und Booster-Items jetzt im
selben Plugin laufen, ruft `JobListener` `BoosterAPI.getBoost(...)` direkt
auf statt über den Reflection-Umweg (`BoosterHook`, der ist raus). Simpler
und robuster - kompiliert normal mit, statt zur Laufzeit Klassen per Namen
zu suchen.

**Zu erledigen bei dir:** altes `BoosterItemsPlugin.jar` vom Server entfernen
(sonst Command-Konflikt bei `/citem`).

## Neu: /bank (vorher eigenständiges BankSystem, jetzt eingebaut)

Modul `bank` (`de.craftsucht.core.bank`) - wie Markt/Jobs/Booster aus einem
hochgeladenen kompilierten Jar dekompiliert und portiert. Genau derselbe
Vault-Disconnect-Bug wie bei den anderen: `depend: [Vault]`, Ein-/Auszahlen
lief über Vault statt unserer eigenen Economy - deswegen "reagiert nicht auf
unsere Economy".

- **`/bank`** – öffnet GUI (Kontostand-Übersicht, Einzahlen/Auszahlen-Buttons,
  Klick = alles, Shift-Klick = Betrag im Chat eingeben)
- **`/bank einzahlen [betrag|*]`**, **`/bank auszahlen [betrag|*]`**,
  **`/bank reload`**
- Zinsen automatisch alle X Minuten (Standard: 10 Minuten, 10% - Werte in
  `config.yml` unter `bank:` einstellbar), gilt für **alle** Konten mit
  Guthaben, auch Offline-Spieler (nicht nur die gerade online sind)
- Bankguthaben in der gemeinsamen SQLite-Datenbank (Tabelle `bank_accounts`)
  statt eigener YAML-Datei pro Spieler
- Ein-/Auszahlen bucht jetzt direkt auf unsere eigene Economy um - der
  Kontostand, den Scoreboard/`/eco`/`/pay` zeigen, ändert sich also
  garantiert mit

**Achtung, kein Bug, aber ein Hinweis:** 10% Zinsen alle 10 Minuten war schon
im Original so konfiguriert - das ist ziemlich viel (Zinseszins-Effekt).
Falls das nicht Absicht ist, in `config.yml` unter `bank.zinsen-prozent`
bzw. `bank.zinsen-intervall-minuten` anpassen.

**Zu erledigen bei dir:** altes `BankSystem.jar` vom Server entfernen (sonst
Command-Konflikt bei `/bank`).

## Neu: /sc (Staffchat)

Modul `staffchat` (`de.craftsucht.core.staffchat`):

- **`/sc <nachricht>`** – Nachricht nur für Staff sichtbar (OP, `craftsucht.core.staffchat` oder `craftsucht.core.admin`), auch in der Konsole
- **`/sc`** ohne Text – togglet einen Dauer-Modus: alles, was der Spieler danach schreibt, geht automatisch in den Staffchat statt in den normalen Chat, bis er `/sc` erneut eingibt
- Format: `[Staff] Name: Nachricht`

## Bekannte Einschränkungen / nächste Schritte

- Die Rang-Anzeige (Scoreboard/Tab/Nametag/Chat) nutzt bewusst **immer** das
  eigene interne Rang-System (`/rank`), auch wenn LuckPerms zusätzlich läuft —
  siehe Abschnitt weiter oben, warum. Das TabList-Modul zeigt zusätzlich noch
  eine statische Kopfzeile.
- Kit-Inhalte sind aktuell hardcoded (siehe `KitsModule`) — bei Bedarf nach
  `config.yml` auslagern.
- AntiCheat ist bewusst minimal (nur Bewegungs-Sanity-Check) und standardmäßig
  deaktiviert — kein Ersatz für ein echtes AntiCheat-Plugin.
- Der Code wurde in dieser Umgebung ohne Netzwerkzugriff auf das PaperMC-Repo
  geschrieben und konnte daher nicht kompiliert/getestet werden. Bitte lokal
  mit `mvn clean package` bauen und kurz durchtesten, bevor es live geht.

## LuckPerms
Eigenes Rank-System ist optional (`modules.rank`, Standard aus). Mit `modules.luckperms: true` kommen die LuckPerms-Prefixe in Chat, Scoreboard und Tabliste.
Prefix setzen: `/lp group <gruppe> meta setprefix 100 "&4&lOwner"`.
Wichtige Nodes: craftsucht.core.admin, craftsucht.punish.*, craftsucht.anticheat.*, craftsucht.shopkiste.admin, craftsucht.markt.npc, craftsucht.farmreset.admin, craftsucht.keepalive.admin, craftsucht.jobs.allprefixes, craftsucht.chat.color

## Lokal bauen
Java 21 installieren, dann im Projektordner:
- Windows: `gradlew.bat shadowJar`
- Linux/Mac: `./gradlew shadowJar`

Die JAR liegt danach in `build/libs/`. Der Wrapper lädt Gradle 8.10.2 automatisch.
