package de.craftsucht.core.plotrate;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.immobilien.PlotBridge;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Plot-Bewertung (/plotrate): Auf einem fremden Plot werden fünf Bereiche mit 1-5 Punkten bewertet
 * (Keller, Außenansicht, Garten, Inneneinrichtung, Kreativität). Je nach Gesamtpunkten (5-25) setzt das Plugin
 * eine Trophäe aus Block-Anzeigen auf den Plot: Erde, Eisen, Gold, Diamant, Drachenei mit Leuchtfeuern,
 * dazu ein Text "Bewertet von ... am ... N/25 Punkte". Gespeichert wird in plotrate.yml.
 */
public class PlotRateModule implements Module, CommandExecutor, TabCompleter, Listener {

    private record Category(String name, Material icon) {
    }

    private static final List<Category> CATS = List.of(
            new Category("Keller", Material.IRON_DOOR),
            new Category("Außenansicht", Material.NETHER_STAR),
            new Category("Garten", Material.DANDELION),
            new Category("Inneneinrichtung", Material.CRAFTING_TABLE),
            new Category("Kreativität", Material.CHAIN_COMMAND_BLOCK));

    /** Offene Bewertung eines Spielers. */
    private static class Session implements InventoryHolder {
        final String plotKey;
        final UUID owner;
        final Location where;
        final int[] score = new int[CATS.size()];
        int page;
        boolean finished;

        Session(String plotKey, UUID owner, Location where) {
            this.plotKey = plotKey;
            this.owner = owner;
            this.where = where;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final int SIZE = 54;
    private final SpookyCraftCore plugin;
    private final PlotBridge bridge = new PlotBridge();
    private File file;
    private YamlConfiguration data;

    public PlotRateModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "plotrate";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "plotrate.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("plotrate").setExecutor(this);
        plugin.getCommand("plotrate").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("plotrate.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Befehl

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur im Spiel.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("clear")) return clear(p);
        if (args.length >= 1 && args[0].equalsIgnoreCase("info")) return info(p);

        if (plugin.getConfig().getBoolean("plotrate.team-only", true)
                && !p.isOp() && !p.hasPermission("spookycraft.plotrate.use")) {
            plugin.getMessageUtil().send(p, "&cDie Plot-Bewertung ist dem Team vorbehalten.");
            return true;
        }
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            plugin.getMessageUtil().send(p, bridge.init() ? "&cDu stehst auf keinem Plot." : "&c" + bridge.error());
            return true;
        }
        if (ref.owner() == null) {
            plugin.getMessageUtil().send(p, "&cDieser Plot hat keinen Besitzer.");
            return true;
        }
        if (ref.owner().equals(p.getUniqueId()) && !plugin.getConfig().getBoolean("plotrate.allow-own-plot", false)) {
            plugin.getMessageUtil().send(p, "&cDu kannst deinen eigenen Plot nicht bewerten.");
            return true;
        }
        open(p, new Session(ref.key(), ref.owner(), p.getLocation().clone()));
        return true;
    }

    private boolean info(Player p) {
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            plugin.getMessageUtil().send(p, "&cDu stehst auf keinem Plot.");
            return true;
        }
        ConfigurationSection sec = data.getConfigurationSection("trophies");
        int n = 0, sum = 0;
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                if (!ref.key().equals(sec.getString(k + ".plot"))) continue;
                n++;
                sum += sec.getInt(k + ".total");
            }
        }
        if (n == 0) plugin.getMessageUtil().send(p, "&7Dieser Plot wurde noch nicht bewertet.");
        else plugin.getMessageUtil().send(p, "&7Bewertungen: &f" + n + " &8| &7Durchschnitt: &a"
                + String.format(Locale.GERMANY, "%.1f", sum / (double) n) + "&7/" + (CATS.size() * 5) + " Punkte");
        return true;
    }

    private boolean clear(Player p) {
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null) {
            plugin.getMessageUtil().send(p, "&cDu stehst auf keinem Plot.");
            return true;
        }
        boolean admin = p.isOp() || p.hasPermission("spookycraft.plotrate.admin");
        if (!admin && !p.getUniqueId().equals(ref.owner())) {
            plugin.getMessageUtil().send(p, "&cNur der Besitzer oder das Team kann Bewertungen entfernen.");
            return true;
        }
        int n = 0;
        ConfigurationSection sec = data.getConfigurationSection("trophies");
        if (sec != null) {
            for (String k : new ArrayList<>(sec.getKeys(false))) {
                if (!ref.key().equals(sec.getString(k + ".plot"))) continue;
                removeTrophy(k);
                n++;
            }
        }
        save();
        plugin.getMessageUtil().send(p, "&a" + n + " Bewertungs-Trophäen entfernt.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            List<String> out = new ArrayList<>();
            for (String s : List.of("info", "clear")) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            return out;
        }
        return List.of();
    }

    // ------------------------------------------------------------------ Menü

    private void open(Player p, Session s) {
        Inventory inv = Bukkit.createInventory(s, SIZE, GuiUtil.c("&5&l☠ &d&lSpookyCraft &8» &fPlot-Bewertung"));
        render(inv, s);
        p.openInventory(inv);
    }

    private void render(Inventory inv, Session s) {
        var black = GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < SIZE; i++) inv.setItem(i, black);
        Category c = CATS.get(s.page);
        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("&7Bereich &f" + (s.page + 1) + "&7/&f" + CATS.size());
        lore.add(s.score[s.page] > 0 ? "&7Deine Punkte: &a" + s.score[s.page] : "&7Noch nicht bewertet");
        inv.setItem(13, GuiUtil.item(c.icon(), "&d&l" + c.name(), lore));
        for (int i = 1; i <= 5; i++) {
            boolean on = s.score[s.page] >= i;
            ItemStack it = GuiUtil.item(on ? Material.LIME_STAINED_GLASS_PANE : Material.LIGHT_GRAY_STAINED_GLASS_PANE,
                    (on ? "&a" : "&7") + i + (i == 1 ? " Punkt" : " Punkte"), "", "&8Klicke, um " + i + " Punkt" + (i == 1 ? "" : "e") + " zu geben");
            it.setAmount(i);
            inv.setItem(27 + 1 + i, it);   // Slots 29-33
        }
        // Fortschritt: kleine Punkte oben links, pro Bereich ein Feld
        for (int i = 0; i < CATS.size(); i++) {
            boolean done = s.score[i] > 0;
            inv.setItem(1 + i, GuiUtil.item(done ? Material.LIME_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE,
                    (i == s.page ? "&d&l" : "&7") + CATS.get(i).name(), done ? "&7Punkte: &a" + s.score[i] : "&8offen"));
        }
        int total = 0;
        for (int v : s.score) total += v;
        inv.setItem(45 + 2, s.page > 0
                ? GuiUtil.item(Material.OAK_DOOR, "&7« Zurück", "&8Voriger Bereich")
                : GuiUtil.item(Material.BLACK_STAINED_GLASS_PANE, " "));
        inv.setItem(45 + 4, GuiUtil.item(Material.RED_STAINED_GLASS_PANE, "&c&lAbbrechen", "&8Bewertung verwerfen"));
        boolean last = s.page == CATS.size() - 1;
        boolean ok = s.score[s.page] > 0;
        inv.setItem(45 + 6, ok
                ? GuiUtil.item(last ? Material.EMERALD : Material.ARROW, last ? "&a&lFertig" : "&aWeiter »",
                last ? "&7Gesamt: &a" + total + "&7/" + (CATS.size() * 5) : "&8Nächster Bereich")
                : GuiUtil.item(Material.BARRIER, "&cErst Punkte vergeben", "&8Wähle 1 bis 5 Punkte"));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Session s)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getRawSlot();
        if (slot >= 29 && slot <= 33) {
            s.score[s.page] = slot - 28;
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 0.8f + 0.1f * (slot - 28));
            render(e.getInventory(), s);
        } else if (slot == 47 && s.page > 0) {
            s.page--;
            render(e.getInventory(), s);
        } else if (slot == 49) {
            s.finished = true;
            p.closeInventory();
            plugin.getMessageUtil().send(p, "&7Bewertung abgebrochen.");
        } else if (slot == 51 && s.score[s.page] > 0) {
            if (s.page < CATS.size() - 1) {
                s.page++;
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
                render(e.getInventory(), s);
            } else {
                s.finished = true;
                p.closeInventory();
                finish(p, s);
            }
        } else if (slot >= 1 && slot <= 5) {
            s.page = slot - 1;
            render(e.getInventory(), s);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Session) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        // Schließen ohne "Fertig" verwirft die Bewertung einfach
    }

    // ------------------------------------------------------------------ Ergebnis / Trophäe

    private int tier(int total) {
        List<Integer> t = plugin.getConfig().getIntegerList("plotrate.tiers");
        if (t.size() != 5) t = List.of(5, 9, 12, 15, 18);
        int tier = 1;
        for (int i = 0; i < 5; i++) if (total >= t.get(i)) tier = i + 1;
        return tier;
    }

    private void finish(Player p, Session s) {
        // Plot-Besitzer darf sich nicht verändert haben
        PlotBridge.PlotRef ref = bridge.plotAt(p.getLocation());
        if (ref == null || !ref.key().equals(s.plotKey)) {
            plugin.getMessageUtil().send(p, "&cDu hast den Plot verlassen, die Bewertung wurde nicht gespeichert.");
            return;
        }
        int total = 0;
        for (int v : s.score) total += v;
        int tier = tier(total);

        // Alte Bewertung desselben Spielers auf diesem Plot ersetzen
        ConfigurationSection sec = data.getConfigurationSection("trophies");
        if (sec != null) {
            for (String k : new ArrayList<>(sec.getKeys(false))) {
                if (s.plotKey.equals(sec.getString(k + ".plot")) && p.getUniqueId().toString().equals(sec.getString(k + ".rater"))) {
                    removeTrophy(k);
                }
            }
        }

        // Trophäe: 2 Blöcke vor dem Spieler, auf Fußhöhe
        Location base = p.getLocation().getBlock().getLocation();
        org.bukkit.util.Vector dir = p.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.01) dir = new org.bukkit.util.Vector(0, 0, 1);
        dir.normalize();
        int dx = Math.abs(dir.getX()) >= Math.abs(dir.getZ()) ? (int) Math.signum(dir.getX()) : 0;
        int dz = dx == 0 ? (int) Math.signum(dir.getZ()) : 0;
        Location spot = base.clone().add(dx * 2, 0, dz * 2);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz)) + 180f;   // Text schaut zum Spieler

        List<UUID> ids = new ArrayList<>();
        String date = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
        Material block = switch (tier) {
            case 1 -> Material.DIRT;
            case 2 -> Material.IRON_BLOCK;
            case 3 -> Material.GOLD_BLOCK;
            case 4 -> Material.DIAMOND_BLOCK;
            default -> Material.DRAGON_EGG;
        };
        ids.add(spawnBlock(spot, block.createBlockData()));
        if (tier == 5) {
            // Zwei Leuchtfeuer links und rechts vom Drachenei
            ids.add(spawnBlock(spot.clone().add(dz * 2, 0, -dx * 2), Material.BEACON.createBlockData()));
            ids.add(spawnBlock(spot.clone().add(-dz * 2, 0, dx * 2), Material.BEACON.createBlockData()));
        }
        TextDisplay txt = spot.getWorld().spawn(spot.clone().add(0.5, 1.55, 0.5), TextDisplay.class, t -> {
            t.text(plugin.getMessageUtil().styled("&eBewertet von &f" + p.getName() + "\n&7am &f" + date + "\n&a" + total + "&7/" + (CATS.size() * 5) + " Punkte"));
            t.setBillboard(Display.Billboard.CENTER);
            t.setPersistent(true);
            t.setBackgroundColor(org.bukkit.Color.fromARGB(160, 0, 0, 0));
        });
        ids.add(txt.getUniqueId());

        String id = Long.toString(System.currentTimeMillis(), 36) + p.getUniqueId().toString().substring(0, 4);
        String path = "trophies." + id;
        data.set(path + ".plot", s.plotKey);
        data.set(path + ".rater", p.getUniqueId().toString());
        data.set(path + ".rater-name", p.getName());
        data.set(path + ".owner", s.owner.toString());
        data.set(path + ".total", total);
        data.set(path + ".date", date);
        data.set(path + ".scores", java.util.Arrays.stream(s.score).boxed().toList());
        List<String> idStr = new ArrayList<>();
        for (UUID u : ids) idStr.add(u.toString());
        data.set(path + ".entities", idStr);
        data.set(path + ".world", spot.getWorld().getName());
        data.set(path + ".x", spot.getBlockX());
        data.set(path + ".z", spot.getBlockZ());
        save();

        String[] names = {"Erde", "Eisen", "Gold", "Diamant", "Drachenei"};
        plugin.getMessageUtil().send(p, "&aBewertung gespeichert: &f" + total + "&7/" + (CATS.size() * 5) + " &7Punkte &8(&f" + names[tier - 1] + "&8)");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1f);
        Player owner = Bukkit.getPlayer(s.owner);
        if (owner != null && owner.isOnline()) {
            plugin.getMessageUtil().send(owner, "&d" + p.getName() + " &7hat deinen Plot bewertet: &a" + total + "&7/" + (CATS.size() * 5) + " Punkte.");
        }
    }

    private UUID spawnBlock(Location corner, BlockData data) {
        BlockDisplay d = corner.getWorld().spawn(corner, BlockDisplay.class, bd -> {
            bd.setBlock(data);
            bd.setPersistent(true);
            bd.setTransformation(new Transformation(new Vector3f(0, 0, 0), new AxisAngle4f(), new Vector3f(1f, 1f, 1f), new AxisAngle4f()));
        });
        return d.getUniqueId();
    }

    private void removeTrophy(String id) {
        List<String> ids = data.getStringList("trophies." + id + ".entities");
        for (String s : ids) {
            try {
                Entity e = Bukkit.getEntity(UUID.fromString(s));
                if (e != null) e.remove();
            } catch (IllegalArgumentException ignored) {
                // kaputte ID
            }
        }
        data.set("trophies." + id, null);
    }
}
