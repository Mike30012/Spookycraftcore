package de.craftsucht.core.rank;

import java.util.List;

/**
 * Fest eingebaute Team-/Ehren-Raenge mit Rechten. Sie werden beim Start angelegt, wenn es sie noch nicht gibt
 * (bestehende Raenge und ihre Rechte bleiben unveraendert). Reihenfolge = Eltern vor Kindern.
 * Gewichte 64-100 liegen ueber allen Shop-Raengen (Geist bis Legende: 10-60).
 */
final class TeamRanks {

    record Def(String id, String prefix, int weight, String parent, List<String> perms) {
    }

    private TeamRanks() {
    }

    private static final List<String> CHAT = List.of("spookycraft.chat.color", "spookycraft.chat.emoji", "spookycraft.chat.ping");

    private static final List<String> COMFORT = List.of("spookycraft.vip.craft", "spookycraft.vip.ec", "spookycraft.vip.hat",
            "spookycraft.essentials.feed", "essentials.anvil", "essentials.grindstone", "essentials.loom", "essentials.trash",
            "essentials.stonecutter", "essentials.cartographytable", "essentials.smithingtable",
            "spookycraft.tresor.pages.3", "spookycraft.rtp.bypass", "spookycraft.pwarp.max.3");

    static final List<Def> ALL = List.of(
            // ---- unten (ohne Eltern) ----
            new Def("test-sup", "&3&lTest-Sup", 75, null, List.of("spookycraft.core.staffchat", "spookycraft.punish.warn",
                    "spookycraft.punish.kick", "spookycraft.punish.history", "essentials.tp", "essentials.vanish.see",
                    "spookycraft.chat.color", "spookycraft.chat.emoji")),
            new Def("sup", "&9&lSup", 78, "test-sup", List.of("spookycraft.plotrate.use", "spookycraft.punish.mute", "spookycraft.punish.unmute",
                    "essentials.tphere", "essentials.invsee", "essentials.top", "spookycraft.blocklog.use",
                    "spookycraft.anticheat.alerts", "spookycraft.core.alert", "spookycraft.core.vanish", "spookycraft.chat.ping")),
            new Def("test-mod", "&a&lTest-Mod", 82, "sup", List.of("spookycraft.punish.tempban", "spookycraft.punish.unban",
                    "essentials.tpo", "essentials.clear", "spookycraft.essentials.heal", "spookycraft.monitor.use", "monitor.use")),
            new Def("mod", "&2&lMod", 85, "test-mod", List.of("spookycraft.punish.ban", "essentials.tpo", "essentials.tpohere", "essentials.clear",
                    "spookycraft.essentials.heal", "spookycraft.essentials.feed", "spookycraft.essentials.fly",
                    "spookycraft.blocklog.rollback", "spookycraft.anticheat.use", "spookycraft.monitor.use", "monitor.use",
                    "freeze.use", "chatclear.use")),
            new Def("builder", "&a&lBuilder", 70, null, List.of("spookycraft.plotrate.use", "essentials.tp", "essentials.tppos", "essentials.top",
                    "essentials.time", "essentials.weather", "essentials.vanish.see", "spookycraft.essentials.gamemode",
                    "minecraft.command.gamemode", "spookycraft.essentials.fly", "spookycraft.essentials.speed",
                    "spookycraft.blocklog.use", "spookycraft.chat.color", "spookycraft.chat.emoji")),
            new Def("test-builder", "&2&lTest-Builder", 69, null, List.of("essentials.tp", "essentials.top", "essentials.time",
                    "essentials.vanish.see", "spookycraft.essentials.fly", "spookycraft.chat.color", "spookycraft.chat.emoji")),
            new Def("head-builder", "&6&lHead-Builder", 73, "builder", List.of("essentials.setspawn", "essentials.delwarp",
                    "essentials.tphere", "spookycraft.blocklog.rollback", "spookycraft.core.staffchat", "spookycraft.core.vanish")),
            new Def("content", "&d&lContent", 68, null, join(CHAT, COMFORT, List.of("spookycraft.video", "spookycraft.morph",
                    "spookycraft.kosmetik.free"))),
            // ---- Dev: wie Mod plus Entwickler-Werkzeuge, aber KEINE Admin-Rechte ----
            new Def("creator", "&5&lCreator", 66, null, join(CHAT, COMFORT, List.of("spookycraft.video"))),
            new Def("creator+", "&d&lCreator&5&l+", 67, "creator", List.of("spookycraft.morph", "spookycraft.kosmetik.free",
                    "spookycraft.essentials.fly", "spookycraft.essentials.speed", "spookycraft.essentials.heal",
                    "spookycraft.tresor.pages.4", "spookycraft.pwarp.max.5")),
            new Def("test-dev", "&3&lTest-Dev", 88, null, List.of("itemdb.use", "itemdb.add", "perks.perkview", "essentials.tp",
                    "essentials.top", "essentials.time", "essentials.weather", "essentials.vanish.see",
                    "spookycraft.essentials.gamemode", "minecraft.command.gamemode", "spookycraft.core.staffchat",
                    "spookycraft.chat.color", "spookycraft.chat.emoji")),
            new Def("dev", "&b&lDev", 90, "mod", List.of("boosteritems.admin", "itemdb.add", "itemdb.take", "itemdb.use",
                    "spookycraft.kosmetik.admin", "spookycraft.crates.admin", "spookycraft.pets.admin", "perks.admin",
                    "perks.giveitem", "perks.perkview", "spookycraft.shopkiste.admin", "spookycraft.farmreset.admin",
                    "essentials.god", "essentials.item", "essentials.invsee", "essentials.time", "essentials.weather",
                    "essentials.tp", "essentials.tphere", "essentials.top", "essentials.vanish.see", "vd.use",
                    "spookycraft.essentials.gamemode", "minecraft.command.gamemode", "spookycraft.essentials.speed")),
            // ---- Admin: wie Mod plus alles ausser Owner-"*" ----
            new Def("head-dev", "&b&lHead-Dev", 91, "dev", List.of("spookycraft.core.admin", "spookycraft.backup.admin",
                    "spookycraft.keepalive.admin", "spookycraft.tresor.admin", "spookycraft.markt.npc", "banksystem.admin",
                    "spookycraft.multiacc.bypass", "essentials.enchant", "essentials.more", "essentials.createkit",
                    "essentials.tpall", "essentials.tppos", "fake.use", "playersize.use", "code.create")),
            // ---- Test-Admin: wie Mod plus Server-Werkzeuge, aber ohne gefaehrliche Admin-Rechte ----
            new Def("test-admin", "&e&lTest-Admin", 92, "mod", List.of("spookycraft.core.admin", "spookycraft.crates.admin",
                    "spookycraft.kosmetik.admin", "spookycraft.pets.admin", "perks.giveitem", "perks.perkview", "itemdb.use",
                    "itemdb.add", "essentials.tp", "essentials.tphere", "essentials.tppos", "essentials.top", "essentials.time",
                    "essentials.weather", "essentials.invsee", "essentials.vanish.see", "spookycraft.essentials.gamemode",
                    "minecraft.command.gamemode", "spookycraft.essentials.speed", "vd.use", "spookycraft.multiacc.bypass")),
            new Def("admin", "&c&lAdmin", 95, "mod", List.of("spookycraft.plotrate.admin", "spookycraft.core.admin", "spookycraft.backup.admin",
                    "spookycraft.keepalive.admin", "spookycraft.tresor.admin", "banksystem.admin", "spookycraft.markt.npc",
                    "boosteritems.admin", "itemdb.add", "itemdb.take", "itemdb.use", "spookycraft.kosmetik.admin",
                    "spookycraft.crates.admin", "spookycraft.pets.admin", "perks.admin", "perks.giveitem", "perks.perkview",
                    "spookycraft.shopkiste.admin", "spookycraft.farmreset.admin", "spookycraft.multiacc.bypass",
                    "spookycraft.essentials.gamemode", "minecraft.command.gamemode", "spookycraft.essentials.speed",
                    "essentials.god", "essentials.item", "essentials.invsee", "essentials.time", "essentials.weather",
                    "essentials.tp", "essentials.tphere", "essentials.tpall", "essentials.tppos", "essentials.top",
                    "essentials.enchant", "essentials.more", "essentials.sudo", "essentials.kickall", "essentials.setspawn",
                    "essentials.delwarp", "essentials.createkit", "essentials.vanish.see", "essentials.smite",
                    "essentials.lightning", "essentials.burn", "essentials.ext", "vd.use", "fake.use", "playersize.use",
                    "code.create", "rang.set", "skript.adminpanel")),
            new Def("owner", "&4&lOwner", 100, "admin", List.of("*"))
    );

    @SafeVarargs
    private static List<String> join(List<String>... lists) {
        java.util.LinkedHashSet<String> s = new java.util.LinkedHashSet<>();
        for (List<String> l : lists) s.addAll(l);
        return List.copyOf(s);
    }

    /** Legt fehlende Team-Raenge samt Rechten an. */
    static int seed(RankManager manager) {
        int created = 0;
        for (Def d : ALL) {
            if (manager.getRank(d.id()) != null) continue;
            if (manager.createRank(d.id(), d.prefix(), d.weight(), d.parent())) {
                for (String p : d.perms()) manager.setPermission(d.id(), p, true);
                created++;
            }
        }
        return created;
    }
}
