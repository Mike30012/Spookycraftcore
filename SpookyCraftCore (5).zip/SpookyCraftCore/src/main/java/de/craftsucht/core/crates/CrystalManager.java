package de.craftsucht.core.crates;

import de.craftsucht.core.SpookyCraftCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Kristalle: die Zweitwährung zum Öffnen von Kisten (Tabelle "crystals"). */
public class CrystalManager {

    private final SpookyCraftCore plugin;
    private final Map<UUID, Long> cache = new ConcurrentHashMap<>();

    public CrystalManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public long get(UUID id) {
        Long cached = cache.get(id);
        if (cached != null) return cached;
        long value = load(id);
        cache.put(id, value);
        return value;
    }

    private long load(UUID id) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT amount FROM crystals WHERE uuid=?")) {
            ps.setString(1, id.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getLong(1);
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Kristalle laden fehlgeschlagen: " + e.getMessage());
        }
        return 0L;
    }

    public void set(UUID id, long amount) {
        long value = Math.max(0L, amount);
        cache.put(id, value);
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO crystals (uuid, amount) VALUES (?,?) ON CONFLICT(uuid) DO UPDATE SET amount = excluded.amount")) {
            ps.setString(1, id.toString());
            ps.setLong(2, value);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Kristalle speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    public void add(UUID id, long amount) {
        set(id, get(id) + amount);
    }

    /** @return false, wenn nicht genug Kristalle vorhanden sind (dann wird nichts abgezogen). */
    public boolean take(UUID id, long amount) {
        if (get(id) < amount) return false;
        set(id, get(id) - amount);
        return true;
    }

    public void forget(UUID id) {
        cache.remove(id);
    }
}
