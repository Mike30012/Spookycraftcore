package de.craftsucht.core.perks;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * /perks - dauerhafte Geister-Kräfte, die man mit Kristallen kauft und per Klick an/aus schaltet.
 * Liste in config.yml (perks.list), Besitz in perks.yml.
 */
public class PerksModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private BukkitTask task;

    public PerksModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "perks";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "perks.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("perks").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 100L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        org.bukkit.event.HandlerList.unregisterAll(this);
        for (Player p : Bukkit.getOnlinePlayers()) clearAll(p);
        save();
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("perks.yml speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private List<Map<?, ?>> perks() {
        return plugin.getConfig().getMapList("perks.list");
    }

    private static String str(Map<?, ?> m, String k, String def) {
        Object o = m.get(k);
        return o == null ? def : String.valueOf(o);
    }

    private static int num(Map<?, ?> m, String k, int def) {
        try {
            return Integer.parseInt(str(m, k, String.valueOf(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private boolean owns(Player p, String id) {
        return data.getStringList(p.getUniqueId() + ".owned").contains(id);
    }

    private boolean enabled(Player p, String id) {
        return !data.getStringList(p.getUniqueId() + ".off").contains(id);
    }

    private void toggle(Player p, String id) {
        List<String> off = new ArrayList<>(data.getStringList(p.getUniqueId() + ".off"));
        if (!off.remove(id)) off.add(id);
        data.set(p.getUniqueId() + ".off", off);
        save();
    }

    private void grant(Player p, String id) {
        List<String> owned = new ArrayList<>(data.getStringList(p.getUniqueId() + ".owned"));
        if (!owned.contains(id)) owned.add(id);
        data.set(p.getUniqueId() + ".owned", owned);
        save();
    }

    // ------------------------------------------------------------------ Effekte

    private PotionEffectType type(Map<?, ?> m) {
        return PotionEffectType.getByKey(NamespacedKey.minecraft(str(m, "effect", "speed").toLowerCase(Locale.ROOT)));
    }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
    }

    private void apply(Player p) {
        for (Map<?, ?> m : perks()) {
            String id = str(m, "id", "");
            PotionEffectType t = type(m);
            if (t == null || !owns(p, id) || !enabled(p, id)) continue;
            p.addPotionEffect(new PotionEffect(t, 260, Math.max(0, num(m, "amplifier", 0)), true, false, false));
        }
    }

    private void clearAll(Player p) {
        for (Map<?, ?> m : perks()) {
            PotionEffectType t = type(m);
            if (t != null && owns(p, str(m, "id", ""))) p.removePotionEffect(t);
        }
    }

    // ------------------------------------------------------------------ Befehl + GUI

    private static class PerkHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 3 && args[0].equalsIgnoreCase("give")) {
            if (!(sender.isOp() || sender.hasPermission("spookycraft.core.admin") || !(sender instanceof Player))) {
                plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
                return true;
            }
            Player t = Bukkit.getPlayerExact(args[1]);
            if (t == null) {
                plugin.getMessageUtil().send(sender, "&cDieser Spieler wandelt nicht in der Geisterwelt.");
                return true;
            }
            grant(t, args[2]);
            plugin.getMessageUtil().send(sender, "&aDie Geister haben " + t.getName() + " die Kraft &e" + args[2] + " &averliehen.");
            return true;
        }
        if (!(sender instanceof Player p)) {
            plugin.getMessageUtil().send(sender, "&cNur Seelen aus Fleisch und Blut können das.");
            return true;
        }
        open(p);
        return true;
    }

    private void open(Player p) {
        List<Map<?, ?>> list = perks();
        int size = Math.max(27, ((list.size() + 8) / 9) * 9 + 9);
        size = Math.min(size, 54);
        Inventory inv = Bukkit.createInventory(new PerkHolder(), size, c("&5☠ &dGeister-Kräfte"));
        ItemStack filler = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < size; i++) inv.setItem(i, filler);
        for (int i = 0; i < Math.min(list.size(), size - 9); i++) {
            Map<?, ?> m = list.get(i);
            String id = str(m, "id", "");
            Material mat = Material.matchMaterial(str(m, "icon", "PAPER"));
            ItemStack it = new ItemStack(mat == null ? Material.PAPER : mat);
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(c(str(m, "name", id)));
            List<String> lore = new ArrayList<>();
            lore.add(c("&7" + str(m, "desc", "Eine Kraft der Geister")));
            lore.add("");
            if (owns(p, id)) {
                lore.add(c(enabled(p, id) ? "&a✔ Aktiv &8- &7Klicken zum Ausschalten" : "&c✖ Aus &8- &7Klicken zum Einschalten"));
            } else {
                lore.add(c("&7Preis: &b" + num(m, "cost", 100) + " Kristalle"));
                lore.add(c("&eKlicken zum Kaufen"));
            }
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }
        long cr = crystalsOf(p);
        ItemStack info = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&bDeine Kristalle: &f" + cr));
        info.setItemMeta(im);
        inv.setItem(size - 5, info);
        p.openInventory(inv);
    }

    private long crystalsOf(Player p) {
        if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
            return cm.getCrystals().get(p.getUniqueId());
        }
        return 0;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof PerkHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        List<Map<?, ?>> list = perks();
        int slot = e.getSlot();
        if (slot < 0 || slot >= list.size()) return;
        Map<?, ?> m = list.get(slot);
        String id = str(m, "id", "");
        if (owns(p, id)) {
            toggle(p, id);
            PotionEffectType t = type(m);
            if (t != null && !enabled(p, id)) p.removePotionEffect(t);
            else apply(p);
            p.playSound(p.getLocation(), "block.note_block.bell", 0.7f, 1.2f);
        } else {
            int cost = num(m, "cost", 100);
            if (plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null
                    && cm.getCrystals().take(p.getUniqueId(), cost)) {
                grant(p, id);
                apply(p);
                p.playSound(p.getLocation(), "entity.witch.celebrate", 0.8f, 1.0f);
                plugin.getMessageUtil().send(p, "&5☠ &dDie Geister haben dir die Kraft " + c(str(m, "name", id)) + " &dverliehen!");
            } else {
                plugin.getMessageUtil().send(p, "&cDir fehlen Kristalle für diese Kraft.");
                return;
            }
        }
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof PerkHolder) e.setCancelled(true);
    }
}
