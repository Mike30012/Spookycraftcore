package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ItemRegistry {

    /** Erlaubter Bereich für den Booster-Prozentsatz, siehe build() mit Override. */
    public static final double MIN_PERCENT = 10.0;
    public static final double MAX_PERCENT = 1000.0;

    private final SpookyCraftCore plugin;
    private final Map<String, ItemTemplate> templates = new LinkedHashMap<>();

    public ItemRegistry(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        templates.clear();
        File file = new File(plugin.getDataFolder(), "items.yml");
        if (!file.exists()) {
            plugin.saveResource("items.yml", false);
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection itemsSection = yaml.getConfigurationSection("items");
        if (itemsSection == null) {
            plugin.getLogger().warning("items.yml enthält keinen 'items:' Abschnitt.");
            addAreaPickaxes();
            addSpecialItems();
            return;
        }
        for (String id : itemsSection.getKeys(false)) {
            ConfigurationSection section = itemsSection.getConfigurationSection(id);
            if (section == null) continue;
            try {
                ItemTemplate template = parseTemplate(id, section);
                templates.put(id.toLowerCase(), template);
            } catch (Exception e) {
                plugin.getLogger().warning("Konnte Item '" + id + "' nicht laden: " + e.getMessage());
            }
        }
        addAreaPickaxes();
        addSpecialItems();
    }

    /**
     * Spezial-Items (früher als Skript): Flug-Schuhe, Speed-Schuhe, Mining-Pistole, Erz-Wandler, Bedrock-Brecher,
     * Ban-Hammer und die Bedrock-Rüstung. Das Verhalten steckt in {@link SpecialItemsListener}.
     * Eigene Einträge mit derselben ID in items.yml haben Vorrang.
     */
    private void addSpecialItems() {
        special("flugschuhe", Material.DIAMOND_BOOTS, "&b&l✈ FLUG-SCHUHE ✈",
                List.of("&7Ziehe diese Schuhe an, um", "&7wie im Creative zu fliegen!"), "flugschuhe");
        special("speedschuhe", Material.DIAMOND_BOOTS, "&bSpeed Schuhe",
                List.of("&7Verleiht Speed 11"), "speedschuhe");
        special("mining_pistole", Material.NETHERITE_PICKAXE, "&b&lMining-Pistole",
                List.of("&7Rechtsklick, um Blöcke", "&7aus der Ferne massenhaft abzubauen!"), "mining_pistole");
        special("erz_wandler", Material.NETHERITE_PICKAXE, "&6&lErz-Wandler Spitzhacke",
                List.of("&7Rechtsklick auf JEDEN Block,", "&7um Erze im Radius zu erschaffen!"), "erz_wandler");
        special("bedrock_brecher", Material.NETHERITE_PICKAXE, "&0&lBedrock-Brecher",
                List.of("&7Kann unzerstörbaren Bedrock", "&7abbauen und als Item droppen!"), "bedrock_brecher");
        special("banhammer", Material.MACE, "&4&l⚡ DER BAN-HAMMER ⚡",
                List.of("&7Schlage einen echten Spieler zum Bannen!"), "banhammer");

        ItemTemplate sword = special("bedrock_schwert", Material.NETHERITE_SWORD, "&7Bedrock-Schwert",
                List.of("&8Aus Bedrock geschmiedet"), "bedrock_sword");
        if (sword != null) sword.modelData(1001);
        for (String[] gear : new String[][]{
                {"bedrock_helm", "LEATHER_HELMET", "Bedrock-Helm", "bedrock_helm"},
                {"bedrock_brustplatte", "LEATHER_CHESTPLATE", "Bedrock-Brustplatte", "bedrock_chest"},
                {"bedrock_beinschutz", "LEATHER_LEGGINGS", "Bedrock-Beinschutz", "bedrock_legs"},
                {"bedrock_stiefel", "LEATHER_BOOTS", "Bedrock-Stiefel", "bedrock_boots"}}) {
            ItemTemplate t = special(gear[0], Material.valueOf(gear[1]), "&7" + gear[2],
                    List.of("&8Aus Bedrock geschmiedet", "&7Resistenz alle 10 Minuten"), gear[3]);
            if (t != null) {
                t.dye(0x2D2D2D);
                t.getEnchants().put("UNBREAKING", 10);
            }
        }
        String[][] swords = {
                {"geisterklinge", "&b&lGeisterklinge", "sword_geist", "&7Schläge verlangsamen & lassen Gegner &bleuchten"},
                {"inferno_klinge", "&6&lInferno-Klinge", "sword_inferno", "&7Setzt Gegner in &6Flammen"},
                {"frost_klinge", "&9&lFrost-Klinge", "sword_frost", "&7Friert Gegner ein &8(&fStarke Verlangsamung&8)"},
                {"schatten_klinge", "&5&lSchatten-Klinge", "sword_schatten", "&7Blendet & schwächt Gegner"},
                {"koenigsklinge", "&e&lKönigsklinge", "sword_koenig", "&7Heilt dich bei jedem Treffer"},
                {"one_hit_wonder", "&d&lMini One Hit Wonder", "sword_onehit", "&7Tötet Mobs &7& Spieler mit &c&lEINEM &7Schlag"}};
        for (String[] s : swords) {
            ItemTemplate t = special(s[0], Material.NETHERITE_SWORD, s[1],
                    List.of("", "&a✪ &lOP-Schwert", s[3], "&8↳ &7Sehr hoher Schaden & Beute"), s[2]);
            if (t != null) {
                t.getEnchants().put("SHARPNESS", 12);
                t.getEnchants().put("LOOTING", 5);
                t.getEnchants().put("SWEEPING_EDGE", 3);
                t.getEnchants().put("UNBREAKING", 10);
                t.getEnchants().put("MENDING", 1);
                if (s[0].equals("inferno_klinge")) t.getEnchants().put("FIRE_ASPECT", 2);
            }
        }
        String[][] axes = {
                {"holzfaeller_axt_1", "&a&lHolzfäller-Axt I", "fell_64", "&7Fällt Bäume mit bis zu &f64 &7Stämmen"},
                {"holzfaeller_axt_2", "&6&lHolzfäller-Axt II", "fell_256", "&7Fällt Bäume mit bis zu &f256 &7Stämmen"},
                {"holzfaeller_axt_3", "&5&lHolzfäller-Axt III", "fell_1024", "&7Fällt auch riesige Bäume &8(bis &f1024 &8Stämme)"}};
        for (String[] a : axes) {
            ItemTemplate t = special(a[0], Material.NETHERITE_AXE, a[1],
                    List.of("", "&a✪ &lHolzfäller-Axt", a[3], "&8↳ &7Sneaken = nur 1 Stamm"), a[2]);
            if (t != null) {
                t.getEnchants().put("EFFICIENCY", 10);
                t.getEnchants().put("UNBREAKING", 10);
                t.getEnchants().put("MENDING", 1);
            }
        }
        ItemTemplate owner = special("owner_hacke", Material.NETHERITE_PICKAXE, "&4&lOwner Hacke v1",
                List.of("", "&cNur für den Server Owner!", "&8Einzigartig. Stark. Unaufhaltbar."), "owner_hacke");
        if (owner != null) {
            owner.getEnchants().put("EFFICIENCY", 10);
            owner.getEnchants().put("UNBREAKING", 10);
            owner.getEnchants().put("FORTUNE", 10);
            owner.getEnchants().put("MENDING", 1);
        }
        ItemTemplate adminH = special("admin_hacke", Material.NETHERITE_PICKAXE, "&a&lKians Admin Spitzhacke v1",
                List.of("", "&aNur für Admins!", "&8Grün. Schnell. Gefährlich."), "admin_hacke");
        if (adminH != null) {
            adminH.getEnchants().put("EFFICIENCY", 10);
            adminH.getEnchants().put("UNBREAKING", 10);
            adminH.getEnchants().put("FORTUNE", 5);
            adminH.getEnchants().put("MENDING", 1);
        }
        String[] godIds = {"gods_picke", "gods_picke_fortune"};
        for (String gid : godIds) {
            boolean silk = gid.equals("gods_picke");
            ItemTemplate god = special(gid, Material.NETHERITE_PICKAXE,
                    silk ? "&6&lGod's Picke &e(Silk Touch)" : "&6&lGod's Picke &e(Fortune V)",
                    List.of("", "&eLegendary Artifact of the Server Creator",
                            "&8↳ &7Modus: &e1x1",
                            "&8↳ &7Rechtsklick im Inventar wechselt 1x1 - 5x5",
                            "&8↳ &7Sneaken + Rechtsklick geht auch in der Hand"), "gods_picke");
            if (god != null) {
                god.getEnchants().put("EFFICIENCY", 25);
                god.getEnchants().put("UNBREAKING", 15);
                god.getEnchants().put("MENDING", 3);
                god.getEnchants().put(silk ? "SILK_TOUCH" : "FORTUNE", silk ? 1 : 5);
            }
        }
        String[][] setDefs = {
                {"lava", "&6&lLava", "0xC84A10", "&c✦ Feuerresistenz", "&c✦ Schwimmen in Lava"},
                {"wasser", "&9&lWasser", "0x1E6EDC", "&b✦ Wasseratmung & schnelles Schwimmen", "&b✦ Kein Fallschaden"},
                {"ender", "&5&lEnderman", "0x1A0F26", "&d✦ Kein Enderperlen-Schaden", "&d✦ Nachtsicht"},
                {"emerald", "&a&lEmerald", "0x17DD62", "&a✦ Eile II (schneller abbauen)", "&a✦ Glück"}};
        String[][] pieces = {
                {"helm", "HELMET", "Helm", "helm"}, {"brustplatte", "CHESTPLATE", "Brustplatte", "chest"},
                {"beinschutz", "LEGGINGS", "Beinschutz", "legs"}, {"stiefel", "BOOTS", "Stiefel", "boots"}};
        for (String[] set : setDefs) {
            for (String[] piece : pieces) {
                ItemTemplate t = special(set[0] + "_" + piece[0], Material.valueOf("LEATHER_" + piece[1]),
                        set[1] + "-" + piece[2],
                        List.of("", "&a✪ &lSet-Bonus &7(alle 4 Teile)", set[3], set[4], "&8↳ &7Schutz wie Netherite"),
                        set[0] + "_" + piece[3]);
                if (t != null) {
                    t.dye(Integer.decode(set[2]));
                    t.getEnchants().put("PROTECTION", 6);
                    t.getEnchants().put("UNBREAKING", 10);
                    t.getEnchants().put("MENDING", 1);
                }
            }
        }
        String[][] toolSets = {{"wasser", "&9", "Wasser"}, {"emerald", "&a", "Emerald"}, {"ender", "&5", "Enderman"}};
        Object[][] tools = {
                {"spitzhacke", Material.NETHERITE_PICKAXE, "Spitzhacke"}, {"axt", Material.NETHERITE_AXE, "Axt"},
                {"schwert", Material.NETHERITE_SWORD, "Schwert"}, {"hacke", Material.NETHERITE_HOE, "Hacke"},
                {"schaufel", Material.NETHERITE_SHOVEL, "Schaufel"}};
        for (String[] ts : toolSets) {
            for (Object[] tool : tools) {
                String tid = ts[0] + "_" + tool[0];
                ItemTemplate tt = special(tid, (Material) tool[1], ts[1] + "&l" + ts[2] + "-" + tool[2],
                        List.of("", "&7Teil der " + ts[1] + ts[2] + "&7-Serie", "&8Rüstung, Spitzhacke, Axt, Schwert, Hacke, Schaufel"),
                        "tool_" + tid);
                if (tt != null) {
                    boolean isSword = tool[0].equals("schwert");
                    tt.getEnchants().put(isSword ? "SHARPNESS" : "EFFICIENCY", 10);
                    tt.getEnchants().put("UNBREAKING", 10);
                    tt.getEnchants().put(isSword ? "LOOTING" : "FORTUNE", isSword ? 5 : 3);
                    tt.getEnchants().put("MENDING", 1);
                }
            }
        }
        ItemTemplate wings = special("elytra_brustplatte", Material.ELYTRA, "&d&lElytra-Brustplatte",
                List.of("", "&7Brustplatte und Elytra in &dEINEM &7Item", "&8↳ &7Gleiten + Schutz wie Netherite"), "elytra_chest");
        if (wings != null) {
            wings.getEnchants().put("PROTECTION", 6);
            wings.getEnchants().put("UNBREAKING", 10);
            wings.getEnchants().put("MENDING", 1);
        }
        applyModelIds();
    }

    /** Modell-Nummern (custom_model_data) für die Texturen im SpookyCraft-Resource-Pack. Ohne Pack sieht man das normale Vanilla-Item. */
    private static final Map<String, Integer> MODEL_IDS = new LinkedHashMap<>();
    static {
        for (int n = 1; n <= 10; n++) MODEL_IDS.put("bohrer_" + n + "x" + n, 100 + n);
        MODEL_IDS.put("mining_pistole", 201);
        MODEL_IDS.put("erz_wandler", 202);
        MODEL_IDS.put("bedrock_brecher", 203);
        MODEL_IDS.put("spookycraft_minerpicke", 301);
        MODEL_IDS.put("flugschuhe", 401);
        MODEL_IDS.put("speedschuhe", 402);
        MODEL_IDS.put("banhammer", 501);
        MODEL_IDS.put("bedrock_helm", 601);
        MODEL_IDS.put("bedrock_brustplatte", 602);
        MODEL_IDS.put("bedrock_beinschutz", 603);
        MODEL_IDS.put("bedrock_stiefel", 604);
        MODEL_IDS.put("bedrock_schwert", 1001);
        MODEL_IDS.put("geisterklinge", 1101);
        MODEL_IDS.put("inferno_klinge", 1102);
        MODEL_IDS.put("frost_klinge", 1103);
        MODEL_IDS.put("schatten_klinge", 1104);
        MODEL_IDS.put("koenigsklinge", 1105);
        MODEL_IDS.put("one_hit_wonder", 1106);
        MODEL_IDS.put("holzfaeller_axt_1", 701);
        MODEL_IDS.put("holzfaeller_axt_2", 702);
        MODEL_IDS.put("holzfaeller_axt_3", 703);
        MODEL_IDS.put("owner_hacke", 205);
        MODEL_IDS.put("admin_hacke", 206);
        MODEL_IDS.put("gods_picke", 207);
        MODEL_IDS.put("gods_picke_fortune", 207);
        MODEL_IDS.put("elytra_brustplatte", 801);
        String[] toolIds = {"spitzhacke", "axt", "schwert", "hacke", "schaufel"};
        String[] toolSetIds = {"wasser", "emerald", "ender"};
        for (int ti = 0; ti < 3; ti++) {
            for (int tj = 0; tj < 5; tj++) MODEL_IDS.put(toolSetIds[ti] + "_" + toolIds[tj], 851 + ti * 10 + tj);
        }
        String[] setNames = {"lava", "wasser", "ender", "emerald"};
        String[] pieceIds = {"helm", "brustplatte", "beinschutz", "stiefel"};
        for (int si = 0; si < 4; si++) {
            for (int pi = 0; pi < 4; pi++) MODEL_IDS.put(setNames[si] + "_" + pieceIds[pi], 811 + si * 10 + pi);
        }
    }

    private void applyModelIds() {
        for (Map.Entry<String, Integer> e : MODEL_IDS.entrySet()) {
            ItemTemplate t = templates.get(e.getKey());
            if (t != null && t.getModelData() == null) t.modelData(e.getValue());
        }
    }

    private ItemTemplate special(String id, Material material, String name, List<String> lore, String special) {
        if (templates.containsKey(id)) return null;
        ItemTemplate t = new ItemTemplate(id, material, name, false, false, new LinkedHashMap<>(),
                new ArrayList<>(lore), null, 0.0, 0.0, 0).special(special);
        templates.put(id, t);
        return t;
    }

    /**
     * Area-Spitzhacken 1x1 bis 10x10 (bohrer_NxN). Sie werden immer eingebaut, damit sie auch mit einer bereits
     * vorhandenen items.yml funktionieren. Eigene Einträge mit derselben ID in items.yml haben Vorrang.
     */
    private void addAreaPickaxes() {
        String[] colors = {"&f", "&a", "&2", "&b", "&3", "&9", "&d", "&5", "&6", "&c"};
        for (int n = 1; n <= 10; n++) {
            String id = "bohrer_" + n + "x" + n;
            if (templates.containsKey(id)) continue;
            Map<String, Integer> enchants = new LinkedHashMap<>();
            enchants.put("EFFICIENCY", n >= 7 ? 14 : n >= 4 ? 13 : 12);
            enchants.put("FORTUNE", 3);
            enchants.put("UNBREAKING", 10);
            enchants.put("MENDING", 1);
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add("&a✪ &lBohrer &7⚒");
            lore.add(n > 1 ? "&8↳ &7Baut &f{area}x{area} &7Blöcke auf einmal ab" : "&8↳ &7Normaler Bohrer &8(&f1x1&8)");
            lore.add(n > 1 ? "&8↳ &7Nur Steine & Erze &8· &7Sneaken = 1 Block" : "&8↳ &7Unzerstörbar");
            templates.put(id, new ItemTemplate(id, Material.NETHERITE_PICKAXE, colors[n - 1] + "&lBohrer &f" + n + "x" + n,
                    true, true, enchants, lore, null, 0.0, 0.0, n));
        }
    }

    private ItemTemplate parseTemplate(String id, ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "STONE"));
        if (material == null) material = Material.STONE;
        String displayName = section.getString("display-name", "&fCustom Item");
        boolean unbreakable = section.getBoolean("unbreakable", false);
        boolean glow = section.getBoolean("glow", false);
        Map<String, Integer> enchants = new LinkedHashMap<>();
        ConfigurationSection enchSection = section.getConfigurationSection("enchants");
        if (enchSection != null) {
            for (String key : enchSection.getKeys(false)) {
                enchants.put(key.toUpperCase(), enchSection.getInt(key));
            }
        }
        List<String> lore = section.getStringList("lore");
        String boosterJob = null;
        double moneyPercent = 0.0;
        double xpPercent = 0.0;
        ConfigurationSection boosterSection = section.getConfigurationSection("booster");
        if (boosterSection != null) {
            boosterJob = boosterSection.getString("job");
            moneyPercent = boosterSection.getDouble("money-percent", 0.0);
            xpPercent = boosterSection.getDouble("xp-percent", 0.0);
        }
        return new ItemTemplate(id, material, displayName, unbreakable, glow, enchants, lore, boosterJob, moneyPercent, xpPercent,
                section.getInt("area", 0));
    }

    public ItemStack build(ItemTemplate template) {
        return build(template, null);
    }

    /**
     * Baut das Item wie im Original, aber mit optionalem Prozent-Override
     * für Geld/XP (z.B. per /citem give <spieler> <id> <prozent>) - geklemmt
     * auf MIN_PERCENT-MAX_PERCENT (10-1000%). null = Standardwert aus items.yml.
     */
    public ItemStack build(ItemTemplate template, Double percentOverride) {
        double money = template.getBoosterMoneyPercent();
        double xp = template.getBoosterXpPercent();
        if (percentOverride != null) {
            double clamped = Math.max(MIN_PERCENT, Math.min(MAX_PERCENT, percentOverride));
            money = clamped;
            xp = clamped;
        }

        ItemStack item = new ItemStack(template.getMaterial());
        item = withBedrockLook(item, template);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(template.getDisplayName()));
        meta.setUnbreakable(template.isUnbreakable());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);

        for (Map.Entry<String, Integer> entry : template.getEnchants().entrySet()) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(entry.getKey().toLowerCase()));
            if (enchantment == null) {
                plugin.getLogger().warning("Unbekanntes Enchantment: " + entry.getKey());
                continue;
            }
            meta.addEnchant(enchantment, entry.getValue(), true);
        }
        if (template.isGlow() && template.getEnchants().isEmpty()) {
            Enchantment glowEnchant = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("unbreaking"));
            if (glowEnchant != null) {
                meta.addEnchant(glowEnchant, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
        }

        List<String> coloredLore = new ArrayList<>();
        for (String line : template.getLore()) {
            String replaced = line.replace("{money}", trimPercent(money)).replace("{xp}", trimPercent(xp))
                    .replace("{area}", String.valueOf(template.getAreaSize()));
            coloredLore.add(color(replaced));
        }
        meta.setLore(coloredLore);

        if (template.getBoosterJob() != null) {
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            pdc.set(BoosterAPI.keyJob(plugin), PersistentDataType.STRING, template.getBoosterJob());
            pdc.set(BoosterAPI.keyMoney(plugin), PersistentDataType.DOUBLE, money);
            pdc.set(BoosterAPI.keyXp(plugin), PersistentDataType.DOUBLE, xp);
        }
        if (template.getSpecial() != null) {
            meta.getPersistentDataContainer().set(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING, template.getSpecial());
        }
        if (template.getDyeRgb() != null && meta instanceof org.bukkit.inventory.meta.LeatherArmorMeta leather) {
            leather.setColor(org.bukkit.Color.fromRGB(template.getDyeRgb()));
            meta.addItemFlags(ItemFlag.HIDE_DYE);
        }
        applyWornLookMeta(meta, template);
        applyArmorStats(meta, template);
        if (template.getModelData() != null) {
            meta.setCustomModelData(template.getModelData());
        }
        String sp = template.getSpecial();
        if ("owner_hacke".equals(sp) || "admin_hacke".equals(sp) || "gods_picke".equals(sp) || (sp != null && sp.startsWith("tool_"))) {
            meta.setEnchantmentGlintOverride(false);   // kein lila Glint ueber den eigenen Item-Bildern
        }
        if (template.getAreaSize() > 1) {
            meta.getPersistentDataContainer().set(AreaMiningListener.keyArea(plugin), PersistentDataType.INTEGER, template.getAreaSize());
        }
        item.setItemMeta(meta);
        return item;
    }

    /** Welche Ausrüstungs-Textur (Resource-Pack) das Item am Körper trägt: {Slot, Asset} oder null. */
    private String[] wornLook(ItemTemplate template) {
        String special = template.getSpecial();
        if (special == null) return null;
        return switch (special) {
            case "bedrock_helm" -> new String[]{"head", "bedrock"};
            case "bedrock_chest" -> new String[]{"chest", "bedrock"};
            case "bedrock_legs" -> new String[]{"legs", "bedrock"};
            case "bedrock_boots" -> new String[]{"feet", "bedrock"};
            case "flugschuhe" -> new String[]{"feet", "flug"};
            case "speedschuhe" -> new String[]{"feet", "speed"};
            case "elytra_chest" -> new String[]{"chest", "elytra_chest"};
            case "lava_helm" -> new String[]{"head", "lava"};
            case "lava_chest" -> new String[]{"chest", "lava"};
            case "lava_legs" -> new String[]{"legs", "lava"};
            case "lava_boots" -> new String[]{"feet", "lava"};
            case "water_helm", "wasser_helm" -> new String[]{"head", "wasser"};
            case "wasser_chest" -> new String[]{"chest", "wasser"};
            case "wasser_legs" -> new String[]{"legs", "wasser"};
            case "wasser_boots" -> new String[]{"feet", "wasser"};
            case "ender_helm" -> new String[]{"head", "ender"};
            case "ender_chest" -> new String[]{"chest", "ender"};
            case "ender_legs" -> new String[]{"legs", "ender"};
            case "ender_boots" -> new String[]{"feet", "ender"};
            case "emerald_helm" -> new String[]{"head", "emerald"};
            case "emerald_chest" -> new String[]{"chest", "emerald"};
            case "emerald_legs" -> new String[]{"legs", "emerald"};
            case "emerald_boots" -> new String[]{"feet", "emerald"};
            default -> null;
        };
    }

    /** Erster Versuch: per Komponenten-String (funktioniert ohne neue API). */
    private ItemStack withBedrockLook(ItemStack item, ItemTemplate template) {
        String[] look = wornLook(template);
        if (look == null) return item;
        try {
            return Bukkit.getUnsafe().modifyItemStack(item,
                    "[minecraft:equippable={slot:\"" + look[0] + "\",asset_id:\"spookycraft:" + look[1] + "\"}]");
        } catch (Throwable t) {
            plugin.getLogger().warning("Ausrüstungs-Optik (Komponente) konnte nicht gesetzt werden: " + t);
            return item;
        }
    }

    /** Zweiter, sicherer Weg: über die ItemMeta-API (Paper 1.21.3+) per Reflection, damit es auch mit älterer API kompiliert. */
    private void applyWornLookMeta(ItemMeta meta, ItemTemplate template) {
        String[] look = wornLook(template);
        if (look == null) return;
        try {
            Class<?> ec = Class.forName("org.bukkit.inventory.meta.components.EquippableComponent");
            Object comp = ItemMeta.class.getMethod("getEquippable").invoke(meta);
            org.bukkit.inventory.EquipmentSlot slot = switch (look[0]) {
                case "head" -> org.bukkit.inventory.EquipmentSlot.HEAD;
                case "chest" -> org.bukkit.inventory.EquipmentSlot.CHEST;
                case "legs" -> org.bukkit.inventory.EquipmentSlot.LEGS;
                default -> org.bukkit.inventory.EquipmentSlot.FEET;
            };
            ec.getMethod("setSlot", org.bukkit.inventory.EquipmentSlot.class).invoke(comp, slot);
            ec.getMethod("setModel", NamespacedKey.class).invoke(comp, new NamespacedKey("spookycraft", look[1]));
            ItemMeta.class.getMethod("setEquippable", ec).invoke(meta, comp);
        } catch (Throwable t) {
            if (!wornWarned) {
                wornWarned = true;
                plugin.getLogger().warning("Ausrüstungs-Optik (ItemMeta) nicht möglich: " + t);
            }
        }
    }

    private boolean wornWarned;

    /** Ruestungswerte wie Netherite fuer die neuen Sets und die Elytra-Brustplatte (ersetzt die Leder-Standardwerte). */
    private void applyArmorStats(ItemMeta meta, ItemTemplate template) {
        String sp = template.getSpecial();
        if (sp == null) return;
        boolean setItem = sp.startsWith("lava_") || sp.startsWith("wasser_") || sp.startsWith("ender_") || sp.startsWith("emerald_");
        boolean wings = sp.equals("elytra_chest");
        if (!setItem && !wings) return;
        String piece = wings ? "chest" : sp.substring(sp.indexOf('_') + 1);
        double armor;
        org.bukkit.inventory.EquipmentSlotGroup group;
        switch (piece) {
            case "helm" -> { armor = 3; group = org.bukkit.inventory.EquipmentSlotGroup.HEAD; }
            case "chest" -> { armor = 8; group = org.bukkit.inventory.EquipmentSlotGroup.CHEST; }
            case "legs" -> { armor = 6; group = org.bukkit.inventory.EquipmentSlotGroup.LEGS; }
            default -> { armor = 3; group = org.bukkit.inventory.EquipmentSlotGroup.FEET; }
        }
        try {
            meta.addAttributeModifier(org.bukkit.attribute.Attribute.GENERIC_ARMOR, new org.bukkit.attribute.AttributeModifier(
                    new NamespacedKey(plugin, "armor_" + sp), armor, org.bukkit.attribute.AttributeModifier.Operation.ADD_NUMBER, group));
            meta.addAttributeModifier(org.bukkit.attribute.Attribute.GENERIC_ARMOR_TOUGHNESS, new org.bukkit.attribute.AttributeModifier(
                    new NamespacedKey(plugin, "tough_" + sp), 3.0, org.bukkit.attribute.AttributeModifier.Operation.ADD_NUMBER, group));
            if (!wings) {
                meta.addAttributeModifier(org.bukkit.attribute.Attribute.GENERIC_KNOCKBACK_RESISTANCE, new org.bukkit.attribute.AttributeModifier(
                        new NamespacedKey(plugin, "kb_" + sp), 0.1, org.bukkit.attribute.AttributeModifier.Operation.ADD_NUMBER, group));
            }
        } catch (Throwable t) {
            plugin.getLogger().warning("Ruestungswerte konnten nicht gesetzt werden: " + t);
        }
    }

    private String trimPercent(double value) {
        if (value == Math.floor(value)) {
            return String.valueOf((int) value);
        }
        return String.valueOf(value);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public Map<String, ItemTemplate> getTemplates() {
        return templates;
    }

    public ItemTemplate getTemplate(String id) {
        String key = id.toLowerCase();
        if (key.startsWith("spitzhacke_")) key = "bohrer_" + key.substring(11);   // alte IDs (crates.yml, items.yml) gehen weiter
        return templates.get(key);
    }
}
