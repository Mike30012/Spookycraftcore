package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Holzfäller-Äxte: Beim Abbauen eines Baumstamms fällt der ganze Baum (alle zusammenhängenden Stämme).
 * Die Axt-Items haben das Spezial-Tag "fell_<max Stämme>" (z.B. fell_128). Einstellungen: "tree-feller:" in der config.yml.
 */
public class TreeFellerListener implements Listener {

    private final SpookyCraftCore plugin;

    public TreeFellerListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    private int maxLogs(ItemStack tool) {
        if (tool == null || !tool.hasItemMeta()) return 0;
        String special = tool.getItemMeta().getPersistentDataContainer()
                .get(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING);
        if (special == null || !special.startsWith("fell_")) return 0;
        try {
            return Integer.parseInt(special.substring(5));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static boolean isLog(Block b) {
        return Tag.LOGS.isTagged(b.getType());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (AreaMiningListener.isExtraBreak()) return;
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        int limit = maxLogs(tool);
        if (limit <= 0) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        FileConfiguration cfg = plugin.getConfig();
        if (player.isSneaking() && cfg.getBoolean("tree-feller.sneak-disables", true)) return;
        List<String> worlds = cfg.getStringList("tree-feller.worlds");
        if (!worlds.isEmpty() && !worlds.contains(player.getWorld().getName())) return;

        Block start = event.getBlock();
        if (!isLog(start)) return;
        limit = Math.min(limit, Math.max(1, cfg.getInt("tree-feller.max-logs", 1024)));

        // Alle zusammenhängenden Stämme suchen (inkl. Diagonalen, damit Äste/Dark-Oak-Stämme mitkommen)
        Set<Block> found = new HashSet<>();
        ArrayDeque<Block> queue = new ArrayDeque<>();
        found.add(start);
        queue.add(start);
        boolean leaves = false;
        while (!queue.isEmpty() && found.size() < limit + 1) {
            Block b = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block n = b.getRelative(dx, dy, dz);
                        if (isLog(n)) {
                            if (found.size() < limit + 1 && found.add(n)) queue.add(n);
                        } else if (!leaves && Tag.LEAVES.isTagged(n.getType())
                                && n.getBlockData() instanceof org.bukkit.block.data.type.Leaves l && !l.isPersistent()) {
                            leaves = true;   // natürliche Blätter = echter Baum, kein Holzhaus
                        }
                    }
                }
            }
        }
        if (cfg.getBoolean("tree-feller.require-leaves", true) && !leaves) return;
        found.remove(start);   // der angeklickte Stamm wird ganz normal abgebaut
        if (found.isEmpty()) return;

        List<Block> logs = new ArrayList<>(found);
        logs.sort(Comparator.comparingInt(Block::getY).reversed());
        final int perTick = Math.max(5, cfg.getInt("tree-feller.blocks-per-tick", 40));
        final boolean toInventory = cfg.getBoolean("tree-feller.drops-to-inventory", true);
        final ItemStack toolCopy = tool.clone();
        final Block center = start;

        new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                AreaMiningListener.setExtraBreak(true);
                try {
                    int done = 0;
                    while (index < logs.size() && done < perTick) {
                        Block block = logs.get(index++);
                        done++;
                        if (!isLog(block)) continue;
                        BlockBreakEvent extra = new BlockBreakEvent(block, player);
                        Bukkit.getPluginManager().callEvent(extra);
                        if (extra.isCancelled()) continue;
                        if (extra.isDropItems()) {
                            Collection<ItemStack> drops = block.getDrops(toolCopy, player);
                            block.setType(Material.AIR, false);
                            for (ItemStack drop : drops) {
                                if (toInventory) {
                                    for (ItemStack left : player.getInventory().addItem(drop).values()) {
                                        center.getWorld().dropItemNaturally(center.getLocation().add(0.5, 0.5, 0.5), left);
                                    }
                                } else {
                                    block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), drop);
                                }
                            }
                        } else {
                            block.setType(Material.AIR, false);
                        }
                    }
                } finally {
                    AreaMiningListener.setExtraBreak(false);
                }
                if (index >= logs.size()) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
