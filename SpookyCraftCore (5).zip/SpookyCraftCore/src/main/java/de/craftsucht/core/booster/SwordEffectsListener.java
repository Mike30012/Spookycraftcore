package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Kleine Spezialeffekte der OP-Schwerter (Geister-, Inferno-, Frost-, Schatten-, Königsklinge). */
public class SwordEffectsListener implements Listener {

    private final SpookyCraftCore plugin;

    public SwordEffectsListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    /** Henkerklinge: ein Schlag tötet (Schaden wird riesig, Rüstung/Resistenz helfen nicht). Bosse und Spieler abschaltbar. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOneHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!plugin.getConfig().getBoolean("sword-effects.enabled", true)) return;
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || !item.hasItemMeta()) return;
        String special = item.getItemMeta().getPersistentDataContainer()
                .get(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING);
        if (!"sword_onehit".equals(special)) return;
        if (victim instanceof Player && !plugin.getConfig().getBoolean("sword-effects.onehit.players", true)) return;
        boolean boss = victim instanceof org.bukkit.entity.EnderDragon || victim instanceof org.bukkit.entity.Wither
                || victim instanceof org.bukkit.entity.Warden;
        if (boss && !plugin.getConfig().getBoolean("sword-effects.onehit.bosses", false)) return;
        event.setDamage(1_000_000.0);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;
        if (!plugin.getConfig().getBoolean("sword-effects.enabled", true)) return;
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || !item.hasItemMeta()) return;
        String special = item.getItemMeta().getPersistentDataContainer()
                .get(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING);
        if (special == null || !special.startsWith("sword_")) return;
        switch (special) {
            case "sword_geist" -> {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 0));
                victim.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0));
            }
            case "sword_inferno" -> victim.setFireTicks(100);
            case "sword_frost" -> {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
                victim.setFreezeTicks(Math.max(victim.getFreezeTicks(), 140));
            }
            case "sword_schatten" -> {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0));
                victim.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0));
            }
            case "sword_koenig" -> {
                double max = player.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null
                        ? player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() : 20.0;
                player.setHealth(Math.min(max, player.getHealth() + 2.0));
            }
            default -> { }
        }
    }
}
