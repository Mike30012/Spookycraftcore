package de.craftsucht.core.basics;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.vanish.VanishModule;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Statistic;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.OfflinePlayer;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Fehlende Essentials-Befehle: /spawn /setspawn /back /tp /tphere /tpo /tpohere /tpall /tppos /tptoggle /top /homes /delhome
 * /warps /delwarp /god /invsee /clear /seen /ignore /playtime /suicide /ext /burn /smite /lightning /more /near /getpos
 * /ping /motd /gmc /gms /gma /gmsp /day /night /sun /rain /storm /anvil /grindstone /loom /cartographytable /smithingtable
 * /stonecutter /trash /enchant /item /sudo /kickall. (/tpahere und /tpcancel stecken im essentials-Modul.)
 * Spieler-Befehle (Rechte "essentials.<befehl>") wie /anvil sind als Rang-Vorteile gedacht; Team-Befehle brauchen
 * OP, spookycraft.core.admin oder das jeweilige essentials.<befehl>-Recht.
 */
public class BasicsModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static final Set<UUID> TP_BLOCKED = new HashSet<>();

    public static boolean isTpBlocked(UUID uuid) {
        return TP_BLOCKED.contains(uuid);
    }

    private static final String[] COMMANDS = {
            "spawn", "setspawn", "back", "tp", "tphere", "tpo", "tpohere", "tpall", "tppos", "tptoggle", "top", "homes", "delhome",
            "warps", "delwarp", "god", "invsee", "clear", "seen", "ignore", "playtime", "suicide", "ext", "burn", "smite",
            "lightning", "more", "near", "getpos", "ping", "motd", "gmc", "gms", "gma", "gmsp", "day", "night", "sun", "rain",
            "storm", "anvil", "grindstone", "loom", "cartographytable", "smithingtable", "stonecutter", "trash", "enchant",
            "item", "sudo", "kickall"};

    /** Befehle, bei denen das erste Argument ein Spielername ist. */
    private static final Set<String> PLAYER_ARG = Set.of("tp", "tphere", "tpo", "tpohere", "god", "invsee", "clear", "seen",
            "ignore", "playtime", "ext", "burn", "smite", "lightning", "ping", "gmc", "gms", "gma", "gmsp", "sudo");

    private final SpookyCraftCore plugin;
    private final Map<UUID, Location> lastLocation = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;

    public BasicsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "basics";
    }

    @Override
    public void enable() {
        dataFile = new File(plugin.getDataFolder(), "basics.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        for (String name : COMMANDS) {
            if (plugin.getCommand(name) != null) {
                plugin.getCommand(name).setExecutor(this);
                plugin.getCommand(name).setTabCompleter(this);
            }
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        TP_BLOCKED.clear();
        lastLocation.clear();
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("basics.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Hilfen

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    /** OP, spookycraft.core.admin oder das genannte Recht. */
    private boolean can(CommandSender s, String perm) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin") || s.hasPermission(perm);
    }

    private boolean deny(CommandSender s, String cmd) {
        if (can(s, "essentials." + cmd)) return false;
        msg(s, "&cDazu hast du keine Berechtigung.");
        return true;
    }

    private Player onlinePlayer(CommandSender s, String name) {
        Player target = Bukkit.getPlayerExact(name);
        if (target == null) msg(s, "&cSpieler '" + name + "' ist nicht online.");
        return target;
    }

    private boolean isVanished(Player p) {
        return plugin.getModuleManager().get("vanish") instanceof VanishModule vm && vm.isVanished(p.getUniqueId());
    }

    private Location spawnLocation() {
        Location loc = data.getLocation("spawn");
        if (loc != null && loc.getWorld() != null) return loc;
        String worldName = plugin.getConfig().getString("extras.spawn-world", "");
        World world = worldName.isEmpty() ? null : Bukkit.getWorld(worldName);
        if (world == null) world = Bukkit.getWorlds().get(0);
        return world.getSpawnLocation();
    }

    private double coord(String text, double base) {
        if (text.startsWith("~")) {
            return base + (text.length() > 1 ? Double.parseDouble(text.substring(1).replace(',', '.')) : 0);
        }
        return Double.parseDouble(text.replace(',', '.'));
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase();
        Player p = sender instanceof Player pl ? pl : null;
        try {
            switch (cmd) {
                case "tp", "tpo" -> tp(sender, cmd, args);
                case "kickall" -> kickAll(sender, args);
                case "sudo" -> sudo(sender, args);
                case "tphere", "tpohere" -> {
                    if (needPlayer(sender, p) || deny(sender, cmd)) return true;
                    if (args.length < 1) {
                        msg(p, "&cNutzung: /" + cmd + " <spieler>");
                        return true;
                    }
                    Player target = onlinePlayer(p, args[0]);
                    if (target != null) {
                        target.teleport(p.getLocation());
                        msg(p, "&a" + target.getName() + " wurde zu dir teleportiert.");
                    }
                }
                case "seen" -> seen(sender, args);
                case "motd" -> motd(sender);
                default -> {
                    if (p == null) {
                        msg(sender, "&cDieser Befehl geht nur ingame.");
                        return true;
                    }
                    playerCommand(p, cmd, args);
                }
            }
        } catch (NumberFormatException e) {
            msg(sender, "&cUngültige Zahl.");
        }
        return true;
    }

    private boolean needPlayer(CommandSender sender, Player p) {
        if (p != null) return false;
        msg(sender, "&cDieser Befehl geht nur ingame.");
        return true;
    }

    private void playerCommand(Player p, String cmd, String[] args) {
        switch (cmd) {
            case "spawn" -> {
                p.teleport(spawnLocation());
                msg(p, "&aDu wurdest zum Spawn teleportiert.");
            }
            case "setspawn" -> {
                if (deny(p, cmd)) return;
                data.set("spawn", p.getLocation());
                save();
                p.getWorld().setSpawnLocation(p.getLocation());
                msg(p, "&aSpawn gesetzt.");
            }
            case "back" -> {
                Location last = lastLocation.get(p.getUniqueId());
                if (last == null || last.getWorld() == null) {
                    msg(p, "&cDu hast keine Position, zu der du zurück kannst.");
                    return;
                }
                p.teleport(last);
                msg(p, "&aDu wurdest zurück teleportiert.");
            }
            case "tpall" -> {
                if (deny(p, cmd)) return;
                int n = 0;
                for (Player other : Bukkit.getOnlinePlayers()) {
                    if (other != p) {
                        other.teleport(p.getLocation());
                        n++;
                    }
                }
                msg(p, "&a" + n + " Spieler zu dir teleportiert.");
            }
            case "tppos" -> {
                if (deny(p, cmd)) return;
                if (args.length < 3) {
                    msg(p, "&cNutzung: /tppos <x> <y> <z> [welt]");
                    return;
                }
                World world = args.length > 3 ? Bukkit.getWorld(args[3]) : p.getWorld();
                if (world == null) {
                    msg(p, "&cUnbekannte Welt.");
                    return;
                }
                Location loc = p.getLocation();
                p.teleport(new Location(world, coord(args[0], loc.getX()), coord(args[1], loc.getY()), coord(args[2], loc.getZ()),
                        loc.getYaw(), loc.getPitch()));
            }
            case "tptoggle" -> {
                if (TP_BLOCKED.remove(p.getUniqueId())) {
                    msg(p, "&aTeleport-Anfragen sind wieder &aerlaubt&a.");
                } else {
                    TP_BLOCKED.add(p.getUniqueId());
                    msg(p, "&7Teleport-Anfragen sind jetzt &cgesperrt&7.");
                }
            }
            case "top" -> {
                if (deny(p, cmd)) return;
                Location loc = p.getLocation();
                int y = p.getWorld().getHighestBlockYAt(loc) + 1;
                loc.setY(y);
                p.teleport(loc);
            }
            case "homes" -> homes(p);
            case "delhome" -> delHome(p, args);
            case "warps" -> warps(p);
            case "delwarp" -> delWarp(p, args);
            case "god" -> god(p, args);
            case "invsee" -> {
                if (deny(p, cmd)) return;
                if (args.length < 1) {
                    msg(p, "&cNutzung: /invsee <spieler>");
                    return;
                }
                Player target = onlinePlayer(p, args[0]);
                if (target != null) p.openInventory(target.getInventory());
            }
            case "clear" -> {
                Player target = args.length > 0 ? onlinePlayer(p, args[0]) : p;
                if (target == null || deny(p, cmd)) return;
                target.getInventory().clear();
                msg(p, "&aInventar von " + target.getName() + " geleert.");
            }
            case "ignore" -> ignore(p, args);
            case "playtime" -> playtime(p, args);
            case "suicide" -> {
                if (deny(p, cmd)) return;
                p.setHealth(0);
            }
            case "ext" -> {
                Player target = args.length > 0 ? onlinePlayer(p, args[0]) : p;
                if (target == null || (target != p && deny(p, cmd))) return;
                target.setFireTicks(0);
                msg(p, "&aFeuer gelöscht.");
            }
            case "burn" -> {
                if (deny(p, cmd)) return;
                if (args.length < 2) {
                    msg(p, "&cNutzung: /burn <spieler> <sekunden>");
                    return;
                }
                Player target = onlinePlayer(p, args[0]);
                if (target == null) return;
                target.setFireTicks(Integer.parseInt(args[1]) * 20);
                msg(p, "&a" + target.getName() + " brennt.");
            }
            case "smite", "lightning" -> {
                if (deny(p, cmd)) return;
                Location loc;
                if (args.length > 0) {
                    Player target = onlinePlayer(p, args[0]);
                    if (target == null) return;
                    loc = target.getLocation();
                } else {
                    var block = p.getTargetBlockExact(100);
                    loc = block != null ? block.getLocation() : p.getLocation();
                }
                loc.getWorld().strikeLightning(loc);
            }
            case "more" -> {
                if (deny(p, cmd)) return;
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) {
                    msg(p, "&cHalte ein Item in der Hand.");
                    return;
                }
                hand.setAmount(hand.getMaxStackSize());
            }
            case "near" -> near(p, args);
            case "getpos" -> {
                Location l = p.getLocation();
                msg(p, String.format(Locale.US, "&7Position: &e%.1f %.1f %.1f &7in &e%s &7(Blick: %s)", l.getX(), l.getY(), l.getZ(),
                        l.getWorld().getName(), p.getFacing().name()));
            }
            case "ping" -> {
                Player target = args.length > 0 ? onlinePlayer(p, args[0]) : p;
                if (target != null) msg(p, "&7Ping von &e" + target.getName() + "&7: &a" + target.getPing() + " ms");
            }
            case "gmc" -> gamemode(p, args, GameMode.CREATIVE);
            case "gms" -> gamemode(p, args, GameMode.SURVIVAL);
            case "gma" -> gamemode(p, args, GameMode.ADVENTURE);
            case "gmsp" -> gamemode(p, args, GameMode.SPECTATOR);
            case "day" -> {
                if (deny(p, "time")) return;
                p.getWorld().setTime(1000);
                msg(p, "&aZeit auf Tag gestellt.");
            }
            case "night" -> {
                if (deny(p, "time")) return;
                p.getWorld().setTime(13000);
                msg(p, "&aZeit auf Nacht gestellt.");
            }
            case "sun" -> weather(p, false, false);
            case "rain" -> weather(p, true, false);
            case "storm" -> weather(p, true, true);
            case "anvil" -> station(p, cmd, "openAnvil", InventoryType.ANVIL);
            case "grindstone" -> station(p, cmd, "openGrindstone", InventoryType.GRINDSTONE);
            case "loom" -> station(p, cmd, "openLoom", InventoryType.LOOM);
            case "cartographytable" -> station(p, cmd, "openCartographyTable", InventoryType.CARTOGRAPHY);
            case "smithingtable" -> station(p, cmd, "openSmithingTable", InventoryType.SMITHING);
            case "stonecutter" -> station(p, cmd, "openStonecutter", InventoryType.STONECUTTER);
            case "trash" -> {
                if (deny(p, cmd)) return;
                p.openInventory(Bukkit.createInventory(null, 36, "§8Mülleimer"));
            }
            case "enchant" -> enchant(p, args);
            case "item" -> giveItem(p, args);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ Teleport

    private void tp(CommandSender sender, String cmd, String[] args) {
        if (deny(sender, cmd)) return;
        Player self = sender instanceof Player pl ? pl : null;
        if (args.length == 1 && self != null) {
            Player target = onlinePlayer(sender, args[0]);
            if (target != null) {
                self.teleport(target.getLocation());
                msg(self, "&aTeleportiert zu " + target.getName() + ".");
            }
        } else if (args.length == 2) {
            Player a = onlinePlayer(sender, args[0]);
            Player b = onlinePlayer(sender, args[1]);
            if (a != null && b != null) {
                a.teleport(b.getLocation());
                msg(sender, "&a" + a.getName() + " zu " + b.getName() + " teleportiert.");
            }
        } else if (args.length == 3 && self != null) {
            Location l = self.getLocation();
            self.teleport(new Location(l.getWorld(), coord(args[0], l.getX()), coord(args[1], l.getY()), coord(args[2], l.getZ()), l.getYaw(), l.getPitch()));
        } else if (args.length == 4) {
            Player a = onlinePlayer(sender, args[0]);
            if (a == null) return;
            Location l = a.getLocation();
            a.teleport(new Location(l.getWorld(), coord(args[1], l.getX()), coord(args[2], l.getY()), coord(args[3], l.getZ()), l.getYaw(), l.getPitch()));
        } else {
            msg(sender, "&cNutzung: /" + cmd + " <spieler> | <spieler> <ziel> | <x> <y> <z> | <spieler> <x> <y> <z>");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.COMMAND || cause == PlayerTeleportEvent.TeleportCause.PLUGIN
                || cause == PlayerTeleportEvent.TeleportCause.UNKNOWN) {
            lastLocation.put(event.getPlayer().getUniqueId(), event.getFrom());
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        lastLocation.put(event.getEntity().getUniqueId(), event.getEntity().getLocation());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastLocation.remove(event.getPlayer().getUniqueId());
        TP_BLOCKED.remove(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Homes / Warps

    private void homes(Player p) {
        List<String> names = new ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT name FROM homes WHERE uuid=? ORDER BY name")) {
            ps.setString(1, p.getUniqueId().toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) names.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            msg(p, "&cFehler beim Laden der Homes.");
            return;
        }
        msg(p, names.isEmpty() ? "&7Du hast keine Homes. Setze eins mit &e/sethome [name]&7." : "&7Deine Homes: &e" + String.join("&7, &e", names));
    }

    private void delHome(Player p, String[] args) {
        String name = args.length > 0 ? args[0] : "home";
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM homes WHERE uuid=? AND name=?")) {
            ps.setString(1, p.getUniqueId().toString());
            ps.setString(2, name);
            msg(p, ps.executeUpdate() > 0 ? "&aHome '" + name + "' gelöscht." : "&cKein Home mit diesem Namen.");
        } catch (SQLException e) {
            msg(p, "&cFehler beim Löschen des Homes.");
        }
    }

    private void warps(Player p) {
        List<String> names = new ArrayList<>();
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT name FROM warps ORDER BY name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) names.add(rs.getString("name"));
        } catch (SQLException e) {
            msg(p, "&cFehler beim Laden der Warps.");
            return;
        }
        msg(p, names.isEmpty() ? "&7Es gibt keine Warps." : "&7Warps: &e" + String.join("&7, &e", names));
    }

    private void delWarp(Player p, String[] args) {
        if (deny(p, "delwarp")) return;
        if (args.length < 1) {
            msg(p, "&cNutzung: /delwarp <name>");
            return;
        }
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM warps WHERE name=?")) {
            ps.setString(1, args[0]);
            msg(p, ps.executeUpdate() > 0 ? "&aWarp '" + args[0] + "' gelöscht." : "&cWarp existiert nicht.");
        } catch (SQLException e) {
            msg(p, "&cFehler beim Löschen des Warps.");
        }
    }

    // ------------------------------------------------------------------ Team- und Spieler-Befehle

    private void god(Player p, String[] args) {
        Player target = args.length > 0 ? onlinePlayer(p, args[0]) : p;
        if (target == null || deny(p, "god")) return;
        target.setInvulnerable(!target.isInvulnerable());
        msg(p, "&7Gottmodus für &e" + target.getName() + "&7: " + (target.isInvulnerable() ? "&aAN" : "&cAUS"));
    }

    private void gamemode(Player p, String[] args, GameMode mode) {
        if (!can(p, "spookycraft.essentials.gamemode")) {
            msg(p, "&cDazu hast du keine Berechtigung.");
            return;
        }
        Player target = args.length > 0 ? onlinePlayer(p, args[0]) : p;
        if (target == null) return;
        target.setGameMode(mode);
        msg(p, "&7Spielmodus von &e" + target.getName() + "&7: &a" + mode.name().toLowerCase());
    }

    private void weather(Player p, boolean storm, boolean thunder) {
        if (deny(p, "weather")) return;
        p.getWorld().setStorm(storm);
        p.getWorld().setThundering(thunder);
        msg(p, "&aWetter gesetzt.");
    }

    private void station(Player p, String cmd, String methodName, InventoryType fallback) {
        if (deny(p, cmd)) return;
        try {
            // Paper: echte Werkstation (Rezepte/Umbenennen funktionieren)
            Player.class.getMethod(methodName, Location.class, boolean.class).invoke(p, null, true);
        } catch (ReflectiveOperationException | RuntimeException e) {
            p.openInventory(Bukkit.createInventory(p, fallback));
        }
    }

    private void enchant(Player p, String[] args) {
        if (deny(p, "enchant")) return;
        if (args.length < 1) {
            msg(p, "&cNutzung: /enchant <verzauberung> [stufe]");
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            msg(p, "&cHalte ein Item in der Hand.");
            return;
        }
        Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(args[0].toLowerCase()));
        if (enchantment == null) {
            msg(p, "&cUnbekannte Verzauberung.");
            return;
        }
        int level = args.length > 1 ? Integer.parseInt(args[1]) : enchantment.getMaxLevel();
        if (level <= 0) {
            hand.removeEnchantment(enchantment);
        } else {
            hand.addUnsafeEnchantment(enchantment, Math.min(level, 255));
        }
        msg(p, "&aVerzauberung gesetzt.");
    }

    private void giveItem(Player p, String[] args) {
        if (deny(p, "item")) return;
        if (args.length < 1) {
            msg(p, "&cNutzung: /item <item> [anzahl]");
            return;
        }
        Material material = Material.matchMaterial(args[0]);
        if (material == null || !material.isItem()) {
            msg(p, "&cUnbekanntes Item.");
            return;
        }
        int amount = args.length > 1 ? Math.max(1, Math.min(2304, parseIntSafe(args[1], 64))) : material.getMaxStackSize();
        ItemStack stack = new ItemStack(material, amount);
        for (ItemStack left : p.getInventory().addItem(stack).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
        msg(p, "&aDu hast &e" + amount + "x " + material.name().toLowerCase() + " &aerhalten.");
    }

    private static int parseIntSafe(String s, int def) {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return def; }
    }

    private void sudo(CommandSender sender, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.core.admin")) {
            msg(sender, "&cDazu hast du keine Berechtigung.");
            return;
        }
        if (args.length < 2) {
            msg(sender, "&cNutzung: /sudo <spieler> <befehl>");
            return;
        }
        Player target = onlinePlayer(sender, args[0]);
        if (target == null) return;
        target.performCommand(String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
        msg(sender, "&aBefehl als " + target.getName() + " ausgeführt.");
    }

    private void kickAll(CommandSender sender, String[] args) {
        if (deny(sender, "kickall")) return;
        String reason = args.length > 0 ? String.join(" ", args) : "Wartungsarbeiten";
        for (Player online : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (!can(online, "essentials.kickall.exempt")) online.kickPlayer(reason);
        }
    }

    private void near(Player p, String[] args) {
        int radius = args.length > 0 ? Math.max(1, Math.min(1000, Integer.parseInt(args[0]))) : 200;
        List<String> list = new ArrayList<>();
        for (Player other : p.getWorld().getPlayers()) {
            if (other == p || (isVanished(other) && !can(p, "essentials.vanish.see"))) continue;
            double dist = other.getLocation().distance(p.getLocation());
            if (dist <= radius) list.add(other.getName() + " &8(&7" + (int) dist + "m&8)");
        }
        msg(p, list.isEmpty() ? "&7Keine Spieler im Umkreis von &e" + radius + "m&7." : "&7In der Nähe: &e" + String.join("&7, &e", list));
    }

    private void playtime(Player p, String[] args) {
        Player target = args.length > 0 && can(p, "essentials.playtime.others") ? onlinePlayer(p, args[0]) : p;
        if (target == null) return;
        long minutes = target.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20L / 60L;
        msg(p, "&7Spielzeit von &e" + target.getName() + "&7: &a" + (minutes / 60) + " Std. " + (minutes % 60) + " Min.");
    }

    private void seen(CommandSender sender, String[] args) {
        if (args.length < 1) {
            msg(sender, "&cNutzung: /seen <spieler>");
            return;
        }
        Player online = Bukkit.getPlayerExact(args[0]);
        boolean viewerStaff = can(sender, "essentials.vanish.see");
        if (online != null && (!isVanished(online) || viewerStaff)) {
            msg(sender, "&e" + online.getName() + " &7ist gerade &aonline&7.");
            return;
        }
        OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(args[0]);
        if (off == null || !off.hasPlayedBefore()) {
            msg(sender, "&cDen Spieler kenne ich nicht.");
            return;
        }
        long last = off.getLastSeen();
        msg(sender, "&e" + off.getName() + " &7war zuletzt online am &e" + new SimpleDateFormat("dd.MM.yyyy HH:mm").format(new Date(last)) + "&7.");
    }

    private void motd(CommandSender s) {
        List<String> lines = plugin.getConfig().getStringList("basics.motd");
        for (String line : lines) plugin.getMessageUtil().sendRaw(s, line);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.getConfig().getBoolean("basics.motd-on-join", true)) return;
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) motd(p);
        }, 10L);
    }

    // ------------------------------------------------------------------ Ignore

    private void ignore(Player p, String[] args) {
        if (args.length < 1) {
            msg(p, "&cNutzung: /ignore <spieler>");
            return;
        }
        OfflinePlayer target = Bukkit.getPlayerExact(args[0]) != null ? Bukkit.getPlayerExact(args[0]) : Bukkit.getOfflinePlayerIfCached(args[0]);
        if (target == null) {
            msg(p, "&cDen Spieler kenne ich nicht.");
            return;
        }
        if (target.getUniqueId().equals(p.getUniqueId())) {
            msg(p, "&cDich selbst kannst du nicht ignorieren.");
            return;
        }
        if (target.isOnline() && target.getPlayer() != null && can(target.getPlayer(), "essentials.ignore.exempt")) {
            msg(p, "&cDieser Spieler kann nicht ignoriert werden.");
            return;
        }
        String path = "ignore." + p.getUniqueId();
        List<String> list = new ArrayList<>(data.getStringList(path));
        String id = target.getUniqueId().toString();
        if (list.remove(id)) {
            msg(p, "&7Du ignorierst &e" + target.getName() + " &7nicht mehr.");
        } else {
            list.add(id);
            msg(p, "&7Du ignorierst jetzt &e" + target.getName() + "&7. Seine Chat-Nachrichten siehst du nicht mehr.");
        }
        data.set(path, list);
        save();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        String sender = event.getPlayer().getUniqueId().toString();
        event.getRecipients().removeIf(r -> r != event.getPlayer() && data.getStringList("ignore." + r.getUniqueId()).contains(sender));
    }

    // ------------------------------------------------------------------ Tab-Completion

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase();
        if ((args.length == 1 && PLAYER_ARG.contains(cmd)) || (args.length == 2 && cmd.equals("tp"))) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[args.length - 1].toLowerCase())).collect(Collectors.toList());
        }
        if (cmd.equals("item")) {
            if (args.length == 1) {
                String pre = args[0].toLowerCase().replace("minecraft:", "");
                List<String> out = new java.util.ArrayList<>();
                for (org.bukkit.Material m : org.bukkit.Material.values()) {
                    if (m.isLegacy() || !m.isItem()) continue;
                    String n = m.name().toLowerCase();
                    if (n.startsWith(pre) || n.contains("_" + pre)) out.add(n);
                }
                java.util.Collections.sort(out);
                return out;
            }
            if (args.length == 2) return List.of("1", "16", "32", "64");
        }
        return Collections.emptyList();
    }
}
