package de.craftsucht.core.vanish;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Vanish: Spieler wird für normale Spieler komplett versteckt (Welt, Tab-Liste, Scoreboard-Online-Zahl).
 * Team (OP / spookycraft.core.vanish / spookycraft.core.admin) sieht Vanish-Spieler weiterhin.
 */
public class VanishModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;
    private final Set<UUID> vanished = new HashSet<>();

    public VanishModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "vanish";
    }

    @Override
    public void enable() {
        plugin.getCommand("vanish").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        for (UUID id : vanished) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) for (Player other : Bukkit.getOnlinePlayers()) other.showPlayer(plugin, p);
        }
        vanished.clear();
    }

    /** Darf dieser Spieler Vanish-Spieler sehen? (Team ja - außer vanish.hide-from-staff: true in der config.yml) */
    private boolean mayStaffSee(Player viewer) {
        return isStaff(viewer) && !plugin.getConfig().getBoolean("vanish.hide-from-staff", false);
    }

    /** Darf Vanish-Spieler sehen / selbst vanishen. */
    public static boolean isStaff(Player p) {
        return p.isOp() || p.hasPermission("spookycraft.core.vanish") || p.hasPermission("spookycraft.core.admin");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!isStaff(p)) {
            plugin.getMessageUtil().send(p, "&cKeine Berechtigung.");
            return true;
        }
        if (vanished.remove(p.getUniqueId())) {
            for (Player other : Bukkit.getOnlinePlayers()) other.showPlayer(plugin, p);
            plugin.getMessageUtil().send(p, "&aDu bist wieder sichtbar.");
        } else {
            vanished.add(p.getUniqueId());
            for (Player other : Bukkit.getOnlinePlayers()) {
                if (other != p && !mayStaffSee(other)) other.hidePlayer(plugin, p);
            }
            plugin.getMessageUtil().send(p, "&aDu bist jetzt unsichtbar (auch in Tab und Scoreboard).");
        }
        refreshScoreboards();
        return true;
    }

    /** Neue Spieler dürfen aktuell vanishte Spieler nicht sehen (weder in der Welt noch in Tab). */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player joined = event.getPlayer();
        if (!mayStaffSee(joined)) {
            for (UUID id : vanished) {
                Player v = Bukkit.getPlayer(id);
                if (v != null) joined.hidePlayer(plugin, v);
            }
        }
        refreshScoreboards();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent event) {
        Player p = event.getPlayer();
        if (vanished.remove(p.getUniqueId())) {
            event.quitMessage(null); // kein "hat den Server verlassen" für Vanish-Spieler
        }
        Bukkit.getScheduler().runTask(plugin, this::refreshScoreboards);
    }

    private void refreshScoreboards() {
        if (plugin.getModuleManager().get("scoreboard") instanceof ScoreboardModule sb) {
            sb.refreshNow();
        }
    }

    public boolean isVanished(UUID uuid) {
        return vanished.contains(uuid);
    }

    /** Anzahl sichtbarer Spieler - Vanish-Spieler zählen für niemanden mit (auch nicht für sich selbst). */
    public int visibleCount(Player viewer) {
        int n = 0;
        for (Player p : Bukkit.getOnlinePlayers()) if (!vanished.contains(p.getUniqueId())) n++;
        return n;
    }

    /** Anzahl vanishter Spieler online (fürs Team als Zusatzinfo). */
    public int vanishedCount() {
        int n = 0;
        for (Player p : Bukkit.getOnlinePlayers()) if (vanished.contains(p.getUniqueId())) n++;
        return n;
    }
}
