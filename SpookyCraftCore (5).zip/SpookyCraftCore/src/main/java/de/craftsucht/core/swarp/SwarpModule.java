package de.craftsucht.core.swarp;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import java.util.UUID;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * /swarp - Spieler-Shop-Warps: /swarp create &lt;name&gt; setzt einen Warp an deiner Position,
 * /swarp &lt;name&gt; teleportiert dorthin. Weitere: /swarp delete &lt;name&gt;, /swarp list, /swarp mine.
 */
public class SwarpModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter, org.bukkit.event.Listener {

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final List<String> SUBS = List.of("create", "delete", "list", "mine", "menu");

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;

    public SwarpModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "swarp";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "swarps.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("swarp").setExecutor(this);
        plugin.getCommand("swarp").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("swarps.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private ConfigurationSection root() {
        ConfigurationSection s = data.getConfigurationSection("swarps");
        return s != null ? s : data.createSection("swarps");
    }

    private boolean isAdmin(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin");
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur für Spieler!");
            return true;
        }
        if (args.length == 0) {
            openMenu(p, 0);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create", "set" -> create(p, args);
            case "delete", "del", "remove" -> delete(p, args);
            case "list" -> list(p);
            case "menu", "gui" -> openMenu(p, 0);
            case "mine", "meine" -> mine(p);
            default -> teleport(p, args[0]);
        }
        return true;
    }

    private static final long DAY_MS = 24L * 60 * 60 * 1000;

    private List<String> categories() {
        List<String> l = plugin.getConfig().getStringList("swarp.categories");
        return l.isEmpty() ? List.of("Shops", "Farmen", "Bauwerke", "Sonstiges") : l;
    }

    /** Gueltige Kategorie (Gross/Kleinschreibung egal) oder null; ohne Angabe die erste Kategorie. */
    private String categoryOf(String input) {
        List<String> all = categories();
        if (input == null) return all.get(0);
        for (String c : all) if (c.equalsIgnoreCase(input)) return c;
        return null;
    }

    /** Besuche der letzten 24 Stunden (alte werden verworfen). */
    private List<Long> recentVisits(ConfigurationSection s) {
        long limit = System.currentTimeMillis() - DAY_MS;
        List<Long> out = new ArrayList<>();
        for (Long t : s.getLongList("visits")) if (t != null && t >= limit) out.add(t);
        return out;
    }

    private static String formatDate(long millis) {
        return new java.text.SimpleDateFormat("dd.MM.yy, HH:mm").format(new java.util.Date(millis));
    }

    private void create(Player p, String[] args) {
        if (args.length < 2) {
            msg(p, "&cNutzung: &e/swarp create <name> [kategorie]");
            return;
        }
        String name = args[1];
        String category = categoryOf(args.length > 2 ? args[2] : null);
        if (category == null) {
            msg(p, "&cUnbekannte Kategorie. Mögliche: &e" + String.join("&7, &e", categories()));
            return;
        }
        if (!NAME.matcher(name).matches()) {
            msg(p, "&cDer Name darf nur Buchstaben, Zahlen und _ enthalten (max. 16 Zeichen).");
            return;
        }
        String key = name.toLowerCase(Locale.ROOT);
        if (SUBS.contains(key)) {
            msg(p, "&cDieser Name ist reserviert.");
            return;
        }
        ConfigurationSection root = root();
        if (root.isConfigurationSection(key)) {
            msg(p, "&cEinen Shop-Warp namens &e" + name + " &cgibt es schon.");
            return;
        }
        int max = plugin.getConfig().getInt("swarp.max-per-player", 3);
        if (!isAdmin(p) && countOf(p.getUniqueId().toString()) >= max) {
            msg(p, "&cDu hast schon &e" + max + " &cShop-Warps. Lösche einen mit &e/swarp delete <name>&c.");
            return;
        }
        Location l = p.getLocation();
        ConfigurationSection s = root.createSection(key);
        s.set("name", name);
        s.set("owner", p.getUniqueId().toString());
        s.set("owner-name", p.getName());
        s.set("category", category);
        s.set("created", System.currentTimeMillis());
        s.set("world", l.getWorld().getName());
        s.set("x", l.getX());
        s.set("y", l.getY());
        s.set("z", l.getZ());
        s.set("yaw", (double) l.getYaw());
        s.set("pitch", (double) l.getPitch());
        save();
        msg(p, "&aShop-Warp &e" + name + " &aerstellt. Andere kommen mit &e/swarp " + name + " &ahierher.");
    }

    private void delete(Player p, String[] args) {
        if (args.length < 2) {
            msg(p, "&cNutzung: &e/swarp delete <name>");
            return;
        }
        String key = args[1].toLowerCase(Locale.ROOT);
        ConfigurationSection s = root().getConfigurationSection(key);
        if (s == null) {
            msg(p, "&cDen Shop-Warp gibt es nicht.");
            return;
        }
        if (!s.getString("owner", "").equals(p.getUniqueId().toString()) && !isAdmin(p)) {
            msg(p, "&cDas ist nicht dein Shop-Warp.");
            return;
        }
        root().set(key, null);
        save();
        msg(p, "&aShop-Warp gelöscht.");
    }

    private void teleport(Player p, String name) {
        ConfigurationSection s = root().getConfigurationSection(name.toLowerCase(Locale.ROOT));
        if (s == null) {
            msg(p, "&cDen Shop-Warp &e" + name + " &cgibt es nicht. Alle: &e/swarp list");
            return;
        }
        World w = Bukkit.getWorld(s.getString("world", ""));
        if (w == null) {
            msg(p, "&cDie Welt dieses Warps ist nicht geladen.");
            return;
        }
        Location l = new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
        p.teleport(l);
        if (!p.getUniqueId().toString().equals(s.getString("owner", ""))) {
            List<Long> v = recentVisits(s);
            v.add(System.currentTimeMillis());
            s.set("visits", v);
            save();
        }
        msg(p, "&aTeleportiert zu &e" + s.getString("name", name) + " &7(von " + s.getString("owner-name", "?") + ")");
    }

    private void mine(Player p) {
        String id = p.getUniqueId().toString();
        List<String> names = new ArrayList<>();
        for (String k : root().getKeys(false)) {
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s != null && id.equals(s.getString("owner"))) names.add(s.getString("name", k));
        }
        if (names.isEmpty()) {
            msg(p, "&7Du hast noch keinen Shop-Warp. Erstelle einen mit &e/swarp create <name>");
            return;
        }
        msg(p, "&7Deine Shop-Warps: &e" + String.join("&7, &e", names));
    }

    private int countOf(String ownerId) {
        int n = 0;
        for (String k : root().getKeys(false)) {
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s != null && ownerId.equals(s.getString("owner"))) n++;
        }
        return n;
    }

    private void list(Player p) {
        List<ConfigurationSection> all = new ArrayList<>();
        for (String k : root().getKeys(false)) {
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s != null) all.add(s);
        }
        if (all.isEmpty()) {
            msg(p, "&7Es gibt noch keine Shop-Warps. Erstelle einen mit &e/swarp create <name>");
            return;
        }
        all.sort(Comparator.comparing(s -> s.getString("name", "").toLowerCase(Locale.ROOT)));
        p.sendMessage(Component.text("--- Shop-Warps (klicken zum Teleportieren) ---", NamedTextColor.GOLD));
        int shown = 0;
        for (ConfigurationSection s : all) {
            if (shown++ >= 40) {
                p.sendMessage(Component.text("... und weitere. Nutze /swarp <name>", NamedTextColor.GRAY));
                break;
            }
            String name = s.getString("name", "?");
            p.sendMessage(Component.text("» ", NamedTextColor.DARK_GRAY)
                    .append(Component.text(name, NamedTextColor.YELLOW))
                    .append(Component.text(" von " + s.getString("owner-name", "?"), NamedTextColor.GRAY))
                    .clickEvent(ClickEvent.runCommand("/swarp " + name))
                    .hoverEvent(HoverEvent.showText(Component.text("Klick: /swarp " + name, NamedTextColor.GREEN))));
        }
    }

    // ------------------------------------------------------------------ Menue (/swarp)

    private static final int PAGE_SIZE = 45;

    private static class MenuHolder implements InventoryHolder {
        int page;
        List<String> keys = new ArrayList<>();
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(c(name));
        List<String> l = new ArrayList<>();
        for (String x : lore) l.add(c(x));
        meta.setLore(l);
        it.setItemMeta(meta);
        return it;
    }

    private void openMenu(Player p, int page) {
        List<String> keys = new ArrayList<>();
        for (String k : root().getKeys(false)) {
            if (root().isConfigurationSection(k)) keys.add(k);
        }
        // Shops von Spielern, die online sind, zuerst; danach alphabetisch
        keys.sort(Comparator.<String, Boolean>comparing(k -> {
            String o = root().getString(k + ".owner", "");
            try {
                return Bukkit.getPlayer(UUID.fromString(o)) == null;
            } catch (IllegalArgumentException e) {
                return true;
            }
        }).thenComparing(k -> root().getString(k + ".name", k).toLowerCase(Locale.ROOT)));

        int pages = Math.max(1, (keys.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, pages - 1));
        MenuHolder holder = new MenuHolder();
        holder.page = page;
        Inventory inv = Bukkit.createInventory(holder, 54, c("&8Shop-Warps &7(" + (page + 1) + "/" + pages + ")"));
        holder.inv = inv;

        int from = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && from + i < keys.size(); i++) {
            String k = keys.get(from + i);
            ConfigurationSection s = root().getConfigurationSection(k);
            if (s == null) continue;
            holder.keys.add(k);
            String ownerId = s.getString("owner", "");
            OfflinePlayer owner = null;
            try {
                owner = Bukkit.getOfflinePlayer(UUID.fromString(ownerId));
            } catch (IllegalArgumentException ignored) {
            }
            boolean online = owner != null && owner.isOnline();
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            if (owner != null) sm.setOwningPlayer(owner);
            sm.setDisplayName(c("&b" + s.getString("name", k)));
            List<String> lore = new ArrayList<>();
            lore.add("");
            lore.add(c("&7Inhaber: &b" + s.getString("owner-name", "?") + (online ? " &a●" : "")));
            lore.add(c("&7Kategorie: &c" + s.getString("category", categories().get(0))));
            lore.add(c("&7Besuche letzte 24h: &b" + recentVisits(s).size()));
            long created = s.getLong("created", 0L);
            lore.add(c("&7Erstelldatum: &b" + (created > 0 ? formatDate(created) : "unbekannt")));
            lore.add("");
            lore.add(c("&aKlick: &7zum Shop teleportieren"));
            boolean own = ownerId.equals(p.getUniqueId().toString());
            if (own || isAdmin(p)) lore.add(c("&cShift + Rechtsklick: &7Warp löschen"));
            sm.setLore(lore);
            head.setItemMeta(sm);
            inv.setItem(i, head);
        }

        ItemStack filler = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, filler);
        if (page > 0) inv.setItem(45, icon(Material.ARROW, "&e« Vorherige Seite", "&7Seite " + page));
        if (page < pages - 1) inv.setItem(53, icon(Material.ARROW, "&eNächste Seite »", "&7Seite " + (page + 2)));
        int mineCount = countOf(p.getUniqueId().toString());
        int max = plugin.getConfig().getInt("swarp.max-per-player", 3);
        inv.setItem(49, icon(Material.NETHER_STAR, "&6Deine Shop-Warps",
                "&7Du hast &e" + mineCount + (isAdmin(p) ? "" : "&7/&e" + max) + " &7Shop-Warps.",
                "",
                "&7Neuen Warp setzen:",
                "&e/swarp create <name>",
                "&7an deiner aktuellen Position.",
                "&8Optional mit Kategorie: &7" + String.join(", ", categories())));
        if (keys.isEmpty()) {
            inv.setItem(22, icon(Material.BARRIER, "&cNoch keine Shop-Warps", "&7Erstelle den ersten mit", "&e/swarp create <name>"));
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getRawSlot();
        if (slot == 45 && holder.page > 0) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1f);
            openMenu(p, holder.page - 1);
            return;
        }
        if (slot == 53) {
            ItemStack it = e.getCurrentItem();
            if (it != null && it.getType() == Material.ARROW) {
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1f);
                openMenu(p, holder.page + 1);
            }
            return;
        }
        if (slot < 0 || slot >= PAGE_SIZE || slot >= holder.keys.size()) return;
        String key = holder.keys.get(slot);
        ConfigurationSection s = root().getConfigurationSection(key);
        if (s == null) {
            openMenu(p, holder.page);
            return;
        }
        if (e.getClick() == ClickType.SHIFT_RIGHT) {
            boolean own = s.getString("owner", "").equals(p.getUniqueId().toString());
            if (own || isAdmin(p)) {
                root().set(key, null);
                save();
                msg(p, "&aShop-Warp gelöscht.");
                openMenu(p, holder.page);
            }
            return;
        }
        p.closeInventory();
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1.2f);
        teleport(p, key);
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String pre = args[0].toLowerCase(Locale.ROOT);
            for (String sub : SUBS) if (sub.startsWith(pre)) out.add(sub);
            for (String k : root().getKeys(false)) {
                ConfigurationSection s = root().getConfigurationSection(k);
                String n = s != null ? s.getString("name", k) : k;
                if (n.toLowerCase(Locale.ROOT).startsWith(pre)) out.add(n);
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("del"))) {
            String pre = args[1].toLowerCase(Locale.ROOT);
            for (String k : root().getKeys(false)) {
                ConfigurationSection s = root().getConfigurationSection(k);
                if (s == null) continue;
                boolean own = sender instanceof Player pl && pl.getUniqueId().toString().equals(s.getString("owner"));
                if ((own || isAdmin(sender)) && k.startsWith(pre)) out.add(s.getString("name", k));
            }
        }
        return out;
    }
}
