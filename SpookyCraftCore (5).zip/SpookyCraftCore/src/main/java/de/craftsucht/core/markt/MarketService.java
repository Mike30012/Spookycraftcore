package de.craftsucht.core.markt;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Spielermarkt-Logik nach OPSUCHT-Vorbild:
 * - Kaufaufträge: Geld wird sofort in Treuhand genommen, andere Spieler verkaufen hinein.
 * - Verkaufsangebote: Items werden sofort in Treuhand genommen, andere Spieler kaufen daraus.
 * - Gekaufte/zurückgegebene Items landen im Abholungs-Lager (/markt abholen) und gehen bei vollem Inventar nicht verloren.
 * - Passende Gegenangebote werden beim Erstellen sofort ausgeführt (zum Preis des älteren Auftrags).
 * Es sind nur Items ohne Zusatzdaten handelbar (keine verzauberten/benannten Custom-Items).
 */
public class MarketService {

    private final SpookyCraftCore plugin;
    private final MarketRepository repo;
    private final ShopManager shop;

    public MarketService(SpookyCraftCore plugin, MarketRepository repo, ShopManager shop) {
        this.plugin = plugin;
        this.repo = repo;
        this.shop = shop;
    }

    // ------------------------------------------------------------------ Hilfen

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private EconomyManager eco() {
        EconomyModule module = (EconomyModule) plugin.getModuleManager().get("economy");
        return module != null ? module.getManager() : null;
    }

    private void msg(Player p, String text) {
        plugin.getMessageUtil().send(p, text);
    }

    public static double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    public static String fmt(double value) {
        return String.format(Locale.GERMANY, "%,.2f", value);
    }

    public static String name(Material material) {
        StringBuilder sb = new StringBuilder();
        for (String part : material.name().toLowerCase().split("_")) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    /** Mindestpreis pro Stück laut config (markt.min-prices), 0 = keiner. Gilt für Kaufaufträge UND Verkaufsangebote. */
    public double minPriceOf(Material material) {
        String n = material.name();
        double floor = cfg().getDouble("markt.min-prices." + n); // ohne Default-Parameter: nutzt auch die Jar-Defaults
        if (floor <= 0 && n.endsWith("_SPAWN_EGG")) floor = cfg().getDouble("markt.min-prices.SPAWN_EGG_DEFAULT");
        return Math.max(0.0, floor);
    }

    /**
     * Preis pro Stück, zu dem der SERVER das Item sofort verkauft (0 = kein Server-Angebot).
     * Reihenfolge: config markt.server-prices -> buy-price aus shop.yml -> Mindestpreis (z.B. Besonderes).
     */
    public double serverPriceOf(Material material) {
        if (!cfg().getBoolean("markt.server-sofortkauf", true)) return 0.0;
        if (!shop.isTradable(material)) return 0.0;
        double price = explicitPrice(material);
        // Kein eigener Preis: aus verwandten Items ableiten (Blöcke, Tiefenschiefer-Erze, Werkzeuge/Rüstung).
        if (price <= 0) price = derivedPrice(material, 0);
        // Alles andere ist trotzdem sofort kaufbar (Standard-Serverpreis aus der config).
        if (price <= 0) price = cfg().getDouble("markt.default-server-price", 25.0);
        return Math.max(0.0, price);
    }

    /** Preis aus config (server-prices) -> shop.yml (buy-price) -> Mindestpreis, 0 = keiner. */
    private double explicitPrice(Material material) {
        double price = cfg().getDouble("markt.server-prices." + material.name());
        if (price <= 0) price = shop.getServerBuyPrice(material);
        if (price <= 0) price = minPriceOf(material);
        return Math.max(0.0, price);
    }

    private double priceOrDerived(Material material, int depth) {
        double p = explicitPrice(material);
        return p > 0 ? p : derivedPrice(material, depth + 1);
    }

    private static Material mat(String name) {
        return Material.matchMaterial(name);
    }

    /** Leitet einen Preis aus bekannten Items ab, 0 = nicht möglich. */
    private double derivedPrice(Material material, int depth) {
        if (depth > 2) return 0.0;
        String n = material.name();

        // Blöcke: 9x das Grundmaterial (DIAMOND_BLOCK = 9 Diamanten, RAW_IRON_BLOCK = 9 Roheisen ...)
        if (n.endsWith("_BLOCK")) {
            String base = n.substring(0, n.length() - "_BLOCK".length());
            for (String candidate : new String[]{base, base + "_INGOT"}) {
                Material m = mat(candidate);
                if (m != null && m != material) {
                    double p = priceOrDerived(m, depth);
                    if (p > 0) return p * 9;
                }
            }
            if (base.equals("GOLD")) {
                Material m = mat("GOLD_INGOT");
                if (m != null) {
                    double p = priceOrDerived(m, depth);
                    if (p > 0) return p * 9;
                }
            }
        }

        // Tiefenschiefer-Erze kosten wie das normale Erz
        if (n.startsWith("DEEPSLATE_")) {
            Material m = mat(n.substring("DEEPSLATE_".length()));
            if (m != null) {
                double p = priceOrDerived(m, depth);
                if (p > 0) return p;
            }
        }

        // Werkzeuge und Rüstung: Materialmenge x Preis des Barrens/Edelsteins
        int us = n.indexOf('_');
        if (us > 0) {
            String tier = n.substring(0, us);
            String piece = n.substring(us + 1);
            int count = switch (piece) {
                case "PICKAXE", "AXE" -> 3;
                case "SWORD", "HOE" -> 2;
                case "SHOVEL" -> 1;
                case "HELMET" -> 5;
                case "CHESTPLATE" -> 8;
                case "LEGGINGS" -> 7;
                case "BOOTS" -> 4;
                default -> 0;
            };
            if (count > 0) {
                String materialName = switch (tier) {
                    case "DIAMOND" -> "DIAMOND";
                    case "IRON" -> "IRON_INGOT";
                    case "GOLDEN" -> "GOLD_INGOT";
                    case "STONE" -> "COBBLESTONE";
                    default -> null;
                };
                if (materialName != null) {
                    Material m = mat(materialName);
                    if (m != null) {
                        double p = priceOrDerived(m, depth);
                        if (p > 0) return p * count;
                    }
                }
                if (tier.equals("NETHERITE")) {
                    // Netherite = Diamant-Variante + 1 Netherite-Barren
                    Material diamondPiece = mat("DIAMOND_" + piece);
                    Material ingot = mat("NETHERITE_INGOT");
                    if (diamondPiece != null && ingot != null) {
                        double d = priceOrDerived(diamondPiece, depth);
                        double i = priceOrDerived(ingot, depth);
                        if (d > 0 && i > 0) return d + i;
                    }
                }
            }
        }
        return 0.0;
    }

    /** Günstigster Kaufpreis für den Spieler: Server-Preis oder günstigstes fremdes Angebot (0 = nichts verfügbar). */
    public double cheapestBuyPrice(UUID viewer, Material material) {
        double best = serverPriceOf(material);
        for (MarketOrder offer : repo.getOrders(material, false)) {
            if (offer.owner().equals(viewer)) continue;
            if (best <= 0 || offer.price() < best) best = offer.price();
            break; // Liste ist nach Preis sortiert
        }
        return best;
    }

    public boolean isTradable(Material material) {
        return shop.isTradable(material);
    }

    public static boolean isPlain(ItemStack stack, Material material) {
        return stack != null && stack.getType() == material && !stack.hasItemMeta();
    }

    public int countPlain(Player p, Material material) {
        int count = 0;
        for (ItemStack stack : p.getInventory().getStorageContents()) {
            if (isPlain(stack, material)) count += stack.getAmount();
        }
        return count;
    }

    private boolean removePlain(Player p, Material material, int amount) {
        if (countPlain(p, material) < amount) return false;
        ItemStack[] contents = p.getInventory().getStorageContents();
        int left = amount;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack stack = contents[i];
            if (!isPlain(stack, material)) continue;
            int take = Math.min(left, stack.getAmount());
            if (take == stack.getAmount()) {
                contents[i] = null;
            } else {
                stack.setAmount(stack.getAmount() - take);
            }
            left -= take;
        }
        p.getInventory().setStorageContents(contents);
        return true;
    }

    /** @return wie viele Items tatsächlich ins Inventar gepasst haben */
    private int giveToInventory(Player p, Material material, int amount) {
        int given = 0;
        int maxStack = Math.max(1, material.getMaxStackSize());
        while (given < amount) {
            int n = Math.min(maxStack, amount - given);
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(material, n));
            if (!left.isEmpty()) {
                int notAdded = 0;
                for (ItemStack stack : left.values()) notAdded += stack.getAmount();
                given += n - notAdded;
                break;
            }
            given += n;
        }
        return given;
    }

    private void notifyOwner(UUID owner, String text) {
        Player online = Bukkit.getPlayer(owner);
        if (online != null) msg(online, text);
    }

    private boolean validate(Player p, Material material, int amount, double price) {
        if (!shop.isTradable(material)) {
            msg(p, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return false;
        }
        // Wie bei OPSUCHT: kein Auftragslimit und keine Preisgrenzen (0 = unbegrenzt). Nur technische Mindestwerte.
        int maxAmount = cfg().getInt("markt.max-amount-per-order", 0);
        int cap = maxAmount > 0 ? maxAmount : 10_000_000;
        if (amount < 1 || amount > cap) {
            msg(p, "&cDie Menge muss zwischen 1 und " + cap + " liegen.");
            return false;
        }
        double minPrice = cfg().getDouble("markt.min-price", 0.01);
        double maxPrice = cfg().getDouble("markt.max-price", 0.0);
        if (price < minPrice || (maxPrice > 0 && price > maxPrice)) {
            msg(p, "&cUngültiger Preis pro Stück (mindestens $" + fmt(minPrice) + ").");
            return false;
        }
        double floor = minPriceOf(material);
        if (floor > 0 && price + 1e-9 < floor) {
            msg(p, "&cDer Mindestpreis für &f" + name(material) + " &cist &f$" + fmt(floor) + " &cpro Stück.");
            return false;
        }
        int maxOrders = cfg().getInt("markt.max-orders-per-player", 0);
        if (maxOrders > 0 && repo.countOrdersOf(p.getUniqueId()) >= maxOrders) {
            msg(p, "&cDu hast bereits die maximale Anzahl an Aufträgen (" + maxOrders + ").");
            return false;
        }
        return true;
    }

    /** 1 % (Standard) des Auftragswerts beim Erstellen eines Angebots. */
    private double creationFeeRate() {
        return Math.max(0.0, cfg().getDouble("markt.creation-fee-percent", 1.0)) / 100.0;
    }

    /** 2 % (Standard) beim Durchführen eines Kaufs - zahlt der Käufer zusätzlich, der Verkäufer bekommt den vollen Preis. */
    private double purchaseFeeRate() {
        return Math.max(0.0, cfg().getDouble("markt.purchase-fee-percent", 2.0)) / 100.0;
    }

    // ------------------------------------------------------------------ Aufträge erstellen

    public boolean createBuyOrder(Player p, Material material, int amount, double price) {
        price = round2(price);
        if (!validate(p, material, amount, price)) return false;
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        UUID uuid = p.getUniqueId();
        double pf = purchaseFeeRate();
        double cf = creationFeeRate();
        // Treuhand: Preis + 2 % Kaufgebühr werden sofort reserviert (wie bei OPSUCHT wird das Geld bei Erstellung abgebucht).
        double escrow = round2(amount * price * (1.0 + pf));
        double creationFeeMax = round2(amount * price * cf);
        if (eco.getBalance(uuid) + 1e-9 < escrow + creationFeeMax) {
            msg(p, "&cDir fehlen &f$" + fmt(escrow + creationFeeMax - eco.getBalance(uuid)) + "&c (Auftrag $" + fmt(escrow)
                    + " inkl. Kaufgebühr + max. $" + fmt(creationFeeMax) + " Erstellungsgebühr).");
            return false;
        }
        if (!eco.withdraw(uuid, escrow)) {
            msg(p, "&cDie Zahlung ist fehlgeschlagen.");
            return false;
        }

        int remaining = amount;
        double spent = 0;
        for (MarketOrder offer : repo.getOrders(material, false)) { // günstigste zuerst
            if (remaining <= 0 || offer.price() > price + 1e-9) break;
            if (offer.owner().equals(uuid)) continue;
            int take = Math.min(remaining, offer.remaining());
            double cost = round2(take * offer.price());
            double fee = round2(cost * pf);
            eco.deposit(offer.owner(), cost); // Verkäufer bekommt den vollen Preis
            double refund = round2(round2(take * price * (1.0 + pf)) - cost - fee); // Differenz zum Gebotspreis zurück
            if (refund > 0) eco.deposit(uuid, refund);
            repo.addPickup(uuid, material, take);
            repo.setRemaining(offer.id(), offer.remaining() - take);
            notifyOwner(offer.owner(), "&aDein Verkaufsangebot: &f" + take + "x " + name(material) + " &averkauft für &f$" + fmt(cost));
            spent += cost + fee;
            remaining -= take;
        }

        int bought = amount - remaining;
        if (bought > 0) {
            msg(p, "&a" + bought + "x " + name(material) + " sofort gekauft für &f$" + fmt(spent) + " &7(inkl. Gebühr, Abholen im Markt-Menü)");
        }
        if (remaining > 0) {
            double creationFee = round2(remaining * price * cf);
            if (creationFee > 0) eco.withdraw(uuid, creationFee);
            if (!repo.insert(uuid, p.getName(), material, true, price, remaining)) {
                eco.deposit(uuid, round2(remaining * price * (1.0 + pf)) + creationFee);
                msg(p, "&cDer Auftrag konnte nicht gespeichert werden. Dein Geld wurde zurückgegeben.");
                return bought > 0;
            }
            msg(p, "&aKaufauftrag erstellt: &f" + remaining + "x " + name(material) + " &afür &f$" + fmt(price) + " &apro Stück"
                    + " &7(Erstellungsgebühr $" + fmt(creationFee) + ")");
        }
        return true;
    }

    public boolean createSellOffer(Player p, Material material, int amount, double price) {
        price = round2(price);
        if (!validate(p, material, amount, price)) return false;
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        UUID uuid = p.getUniqueId();
        double cf = creationFeeRate();
        double creationFeeMax = round2(amount * price * cf);
        if (eco.getBalance(uuid) + 1e-9 < creationFeeMax) {
            msg(p, "&cFür die Erstellungsgebühr fehlen dir &f$" + fmt(creationFeeMax - eco.getBalance(uuid)) + "&c (1 % des Angebotswerts).");
            return false;
        }
        if (!removePlain(p, material, amount)) {
            msg(p, "&cDu hast nicht genug &f" + name(material) + " &c(ohne Verzauberung/Namen) im Inventar. Du brauchst " + amount + ".");
            return false;
        }

        int remaining = amount;
        double earned = 0;
        for (MarketOrder order : repo.getOrders(material, true)) { // höchster Preis zuerst
            if (remaining <= 0 || order.price() < price - 1e-9) break;
            if (order.owner().equals(uuid)) continue;
            int take = Math.min(remaining, order.remaining());
            double gain = round2(take * order.price());
            eco.deposit(uuid, gain);
            repo.addPickup(order.owner(), material, take);
            repo.setRemaining(order.id(), order.remaining() - take);
            notifyOwner(order.owner(), "&aDein Kaufauftrag: &f" + take + "x " + name(material) + " &agekauft für &f$" + fmt(gain)
                    + " &7(Abholen im Markt-Menü)");
            earned += gain;
            remaining -= take;
        }

        int sold = amount - remaining;
        if (sold > 0) {
            msg(p, "&a" + sold + "x " + name(material) + " sofort verkauft für &f$" + fmt(earned));
        }
        if (remaining > 0) {
            double creationFee = round2(remaining * price * cf);
            if (creationFee > 0 && !eco.withdraw(uuid, creationFee)) {
                repo.addPickup(uuid, material, remaining);
                msg(p, "&cDie Erstellungsgebühr konnte nicht bezahlt werden. Deine Items liegen im Abholungs-Lager.");
                return sold > 0;
            }
            if (!repo.insert(uuid, p.getName(), material, false, price, remaining)) {
                repo.addPickup(uuid, material, remaining);
                if (creationFee > 0) eco.deposit(uuid, creationFee);
                msg(p, "&cDas Angebot konnte nicht gespeichert werden. Deine Items liegen im Abholungs-Lager.");
                return sold > 0;
            }
            msg(p, "&aVerkaufsangebot erstellt: &f" + remaining + "x " + name(material) + " &afür &f$" + fmt(price) + " &apro Stück"
                    + " &7(Erstellungsgebühr $" + fmt(creationFee) + ")");
        }
        return true;
    }

    // ------------------------------------------------------------------ Direkt aus der Liste handeln

    /**
     * Sofortkauf: kauft immer zum günstigsten Preis - aus Spieler-Angeboten oder direkt vom Server (unbegrenzter Vorrat).
     * Server-Käufe landen direkt im Inventar (was nicht passt, im Abholen-Menü), Spieler-Angebote im Abholen-Menü.
     */
    public boolean buyInstant(Player p, Material material, int amount) {
        if (!shop.isTradable(material)) {
            msg(p, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return false;
        }
        EconomyManager eco = eco();
        if (eco == null) {
            msg(p, "&cDie Wirtschaft ist gerade nicht verfügbar.");
            return false;
        }
        amount = Math.max(1, Math.min(amount, 2304));
        UUID uuid = p.getUniqueId();
        double serverPrice = serverPriceOf(material);
        List<MarketOrder> offers = repo.getOrders(material, false);

        int remaining = amount;
        int fromPlayers = 0;
        int fromServer = 0;
        double spent = 0;
        boolean noMoney = false;
        int index = 0;
        while (remaining > 0) {
            while (index < offers.size() && offers.get(index).owner().equals(uuid)) index++;
            MarketOrder offer = index < offers.size() ? offers.get(index) : null;
            boolean useOffer = offer != null && (serverPrice <= 0 || offer.price() <= serverPrice);
            if (useOffer) {
                int take = Math.min(remaining, offer.remaining());
                double cost = round2(take * offer.price());
                double fee = round2(cost * purchaseFeeRate());
                if (!eco.withdraw(uuid, cost + fee)) {
                    noMoney = true;
                    break;
                }
                eco.deposit(offer.owner(), cost);
                repo.addPickup(uuid, material, take);
                repo.setRemaining(offer.id(), offer.remaining() - take);
                notifyOwner(offer.owner(), "&aDein Verkaufsangebot: &f" + take + "x " + name(material) + " &averkauft für &f$" + fmt(cost));
                spent += cost + fee;
                remaining -= take;
                fromPlayers += take;
                index++;
            } else if (serverPrice > 0) {
                int affordable = (int) Math.floor((eco.getBalance(uuid) + 1e-9) / serverPrice);
                int take = Math.min(remaining, affordable);
                if (take <= 0) {
                    noMoney = true;
                    break;
                }
                double cost = round2(take * serverPrice);
                if (!eco.withdraw(uuid, cost)) {
                    noMoney = true;
                    break;
                }
                int given = giveToInventory(p, material, take);
                if (given < take) repo.addPickup(uuid, material, take - given);
                spent += cost;
                remaining -= take;
                fromServer += take;
                if (remaining > 0) { // nicht alles bezahlbar -> Schleife beenden
                    noMoney = true;
                    break;
                }
            } else {
                break;
            }
        }

        int bought = amount - remaining;
        if (bought > 0) {
            StringBuilder detail = new StringBuilder();
            if (fromServer > 0) detail.append(fromServer).append("x vom Server");
            if (fromPlayers > 0) {
                if (detail.length() > 0) detail.append(", ");
                detail.append(fromPlayers).append("x von Spielern (Abholen im Markt-Menü)");
            }
            msg(p, "&a" + bought + "x " + name(material) + " gekauft für &f$" + fmt(spent) + " &7(" + detail + ")");
        }
        if (remaining > 0) {
            if (noMoney) {
                msg(p, "&cDir fehlt Geld für " + remaining + "x " + name(material) + ".");
            } else {
                msg(p, "&cKein " + (bought > 0 ? "weiteres " : "") + "Angebot für " + name(material) + " verfügbar"
                        + (bought == 0 ? " &7- erstelle einen Kaufauftrag im Handelsmenü (Rechtsklick)." : "."));
            }
        }
        return bought > 0;
    }

    /** Kauft aus einem bestehenden Verkaufsangebot. */
    public boolean buyFromOffer(Player p, int offerId, int amount) {
        MarketOrder offer = repo.getOrder(offerId);
        if (offer == null || offer.buy()) {
            msg(p, "&cDieses Angebot gibt es nicht mehr.");
            return false;
        }
        EconomyManager eco = eco();
        if (eco == null) return false;
        UUID uuid = p.getUniqueId();
        if (offer.owner().equals(uuid)) {
            msg(p, "&cDu kannst nicht bei dir selbst kaufen.");
            return false;
        }
        int take = Math.min(Math.max(1, amount), offer.remaining());
        double cost = round2(take * offer.price());
        double fee = round2(cost * purchaseFeeRate());
        if (!eco.withdraw(uuid, cost + fee)) {
            msg(p, "&cDir fehlen &f$" + fmt(cost + fee - eco.getBalance(uuid)) + "&c (Preis $" + fmt(cost) + " + Gebühr $" + fmt(fee) + ").");
            return false;
        }
        eco.deposit(offer.owner(), cost); // Verkäufer bekommt den vollen Preis, die Gebühr geht an den Server
        repo.addPickup(uuid, offer.material(), take);
        repo.setRemaining(offer.id(), offer.remaining() - take);
        notifyOwner(offer.owner(), "&aDein Verkaufsangebot: &f" + take + "x " + name(offer.material()) + " &averkauft für &f$" + fmt(cost));
        msg(p, "&a" + take + "x " + name(offer.material()) + " gekauft für &f$" + fmt(cost + fee) + " &7(inkl. $" + fmt(fee) + " Gebühr, Abholen im Markt-Menü)");
        return true;
    }

    /** Verkauft Items aus dem Inventar in einen bestehenden Kaufauftrag. */
    public boolean sellToBuyOrder(Player p, int orderId, int amount) {
        MarketOrder order = repo.getOrder(orderId);
        if (order == null || !order.buy()) {
            msg(p, "&cDieser Auftrag existiert nicht mehr.");
            return false;
        }
        EconomyManager eco = eco();
        if (eco == null) return false;
        UUID uuid = p.getUniqueId();
        if (order.owner().equals(uuid)) {
            msg(p, "&cDu kannst nicht an dich selbst verkaufen.");
            return false;
        }
        int take = Math.min(Math.max(1, amount), order.remaining());
        take = Math.min(take, countPlain(p, order.material()));
        if (take <= 0) {
            msg(p, "&cDu hast kein &f" + name(order.material()) + " &c(ohne Verzauberung/Namen) im Inventar.");
            return false;
        }
        if (!removePlain(p, order.material(), take)) return false;
        double gain = round2(take * order.price());
        eco.deposit(uuid, gain);
        repo.addPickup(order.owner(), order.material(), take);
        repo.setRemaining(order.id(), order.remaining() - take);
        notifyOwner(order.owner(), "&aDein Kaufauftrag: &f" + take + "x " + name(order.material()) + " &agekauft für &f$" + fmt(gain)
                + " &7(Abholen im Markt-Menü)");
        msg(p, "&a" + take + "x " + name(order.material()) + " verkauft für &f$" + fmt(gain));
        return true;
    }

    /** Bricht einen eigenen Auftrag ab: Geld zurück bzw. Items ins Abholungs-Lager. */
    public boolean cancelOrder(Player p, int orderId) {
        MarketOrder order = repo.getOrder(orderId);
        if (order == null) {
            msg(p, "&cDieser Auftrag existiert nicht mehr.");
            return false;
        }
        if (!order.owner().equals(p.getUniqueId())) {
            msg(p, "&cDas ist nicht dein Auftrag.");
            return false;
        }
        repo.delete(orderId);
        if (order.buy()) {
            EconomyManager eco = eco();
            double refund = round2(order.remaining() * order.price() * (1.0 + purchaseFeeRate()));
            if (eco != null) eco.deposit(p.getUniqueId(), refund);
            msg(p, "&aKaufauftrag abgebrochen. Zurück: &f$" + fmt(refund));
        } else {
            repo.addPickup(p.getUniqueId(), order.material(), order.remaining());
            msg(p, "&aVerkaufsangebot abgebrochen. &f" + order.remaining() + "x " + name(order.material()) + " &aliegen zur Abholung bereit.");
        }
        return true;
    }

    // ------------------------------------------------------------------ Abholen

    /** @param only null = alles abholen. @return Anzahl der abgeholten Items */
    public int claim(Player p, Material only) {
        UUID uuid = p.getUniqueId();
        int total = 0;
        boolean full = false;
        for (Map.Entry<Material, Integer> entry : repo.getPickups(uuid).entrySet()) {
            if (only != null && entry.getKey() != only) continue;
            int given = giveToInventory(p, entry.getKey(), entry.getValue());
            if (given > 0) repo.removePickup(uuid, entry.getKey(), given);
            if (given < entry.getValue()) full = true;
            total += given;
        }
        if (total > 0) msg(p, "&a" + total + " Item(s) abgeholt.");
        if (full) msg(p, "&eDein Inventar ist voll - der Rest bleibt im Abholungs-Lager.");
        if (total == 0 && !full) msg(p, "&7Es liegt nichts zur Abholung bereit.");
        return total;
    }

    // ------------------------------------------------------------------ /sell, /sellall (Schnellverkauf)

    /** Ergebnis eines Schnellverkaufs. */
    public record SellResult(int sold, double earned) {
    }

    /**
     * Ankaufspreis pro Stück, zu dem der SERVER dem Spieler Items abkauft (0 = kauft nicht an).
     * Nur Items mit echtem Preis (config server-prices, shop.yml, Ableitung) - NICHT der Standardpreis.
     * Standard: markt.server-ankauf-percent % davon (50), pro Item überschreibbar in markt.ankauf-prices.
     */
    public double serverBuyPriceOf(Material material) {
        if (!cfg().getBoolean("markt.server-ankauf", true)) return 0.0;
        if (!shop.isTradable(material)) return 0.0;
        double own = cfg().getDouble("markt.ankauf-prices." + material.name());
        if (own > 0) return round2(own);
        if (cfg().getStringList("markt.ankauf-ausgeschlossen").contains(material.name())) return 0.0;
        double base = explicitPrice(material);
        if (base <= 0) base = derivedPrice(material, 0);
        if (base <= 0) return 0.0;
        double percent = cfg().getDouble("markt.server-ankauf-percent", 50.0);
        return round2(base * percent / 100.0);
    }

    /** Verkauft sofort an die höchsten Kaufaufträge, den Rest kauft der Server an. */
    public int quickSell(Player p, Material material, int amount) {
        return quickSell(p, material, amount, false).sold();
    }

    public SellResult quickSell(Player p, Material material, int amount, boolean quiet) {
        if (!shop.isTradable(material)) {
            if (!quiet) msg(p, "&cDieses Item kann nicht über den Markt gehandelt werden.");
            return new SellResult(0, 0);
        }
        EconomyManager eco = eco();
        if (eco == null) return new SellResult(0, 0);
        UUID uuid = p.getUniqueId();
        int toSell = Math.min(amount, countPlain(p, material));
        if (toSell <= 0) {
            if (!quiet) msg(p, "&cDu hast kein &f" + name(material) + " &c(ohne Verzauberung/Namen) im Inventar.");
            return new SellResult(0, 0);
        }
        if (!removePlain(p, material, toSell)) return new SellResult(0, 0);

        int remaining = toSell;
        double earned = 0;
        for (MarketOrder order : repo.getOrders(material, true)) {
            if (remaining <= 0) break;
            if (order.owner().equals(uuid)) continue;
            int take = Math.min(remaining, order.remaining());
            double gain = round2(take * order.price());
            eco.deposit(uuid, gain);
            repo.addPickup(order.owner(), material, take);
            repo.setRemaining(order.id(), order.remaining() - take);
            notifyOwner(order.owner(), "&aDein Kaufauftrag: &f" + take + "x " + name(material) + " &agekauft für &f$" + fmt(gain)
                    + " &7(Abholen im Markt-Menü)");
            earned += gain;
            remaining -= take;
        }

        // Rest: der Server kauft an (falls er für das Item einen Ankaufspreis hat)
        if (remaining > 0) {
            double unit = serverBuyPriceOf(material);
            if (unit > 0) {
                double gain = round2(remaining * unit);
                eco.deposit(uuid, gain);
                earned += gain;
                remaining = 0;
            }
        }

        int sold = toSell - remaining;
        if (remaining > 0) {
            int back = giveToInventory(p, material, remaining);
            if (back < remaining) repo.addPickup(uuid, material, remaining - back);
        }
        if (!quiet) {
            if (sold > 0) msg(p, "&a" + sold + "x " + name(material) + " verkauft für &f$" + fmt(earned));
            else msg(p, "&cFür &f" + name(material) + " &cgibt es gerade keine Kaufaufträge und keinen Server-Ankauf.");
        }
        return new SellResult(sold, earned);
    }

    /** /sellall: verkauft alle handelbaren Items im Inventar (ohne Verzauberung/Namen) auf einmal. */
    public void sellAll(Player p) {
        java.util.Set<Material> materials = new java.util.LinkedHashSet<>();
        for (ItemStack stack : p.getInventory().getStorageContents()) {
            if (stack != null && !stack.getType().isAir() && !stack.hasItemMeta() && shop.isTradable(stack.getType())) {
                materials.add(stack.getType());
            }
        }
        int items = 0;
        double total = 0;
        for (Material material : materials) {
            SellResult r = quickSell(p, material, countPlain(p, material), true);
            items += r.sold();
            total += r.earned();
        }
        if (items > 0) {
            msg(p, "&a" + items + " Item(s) verkauft für insgesamt &f$" + fmt(total) + "&a.");
        } else {
            msg(p, "&cDu hast nichts, was sich gerade verkaufen lässt.");
        }
    }
}
