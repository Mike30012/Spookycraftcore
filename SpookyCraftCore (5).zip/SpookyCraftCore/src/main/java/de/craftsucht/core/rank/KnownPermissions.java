package de.craftsucht.core.rank;

import org.bukkit.Bukkit;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * Zentrale Quelle für "alle bekannten Permission-Nodes auf dem Server" -
 * genutzt sowohl für die Tab-Completion bei /rank setpermission als auch
 * für die Auflösung des "*"-Wildcards (siehe RankManager#apply).
 */
public final class KnownPermissions {

    /**
     * Eigene Permission-Nodes, die im Code per hasPermission() geprüft werden,
     * aber NICHT in der plugin.yml als "permissions:" deklariert sind (Bukkit
     * kennt sie deswegen nicht über getPluginManager().getPermissions()).
     */
    private static final String[] UNDECLARED_OWN_PERMISSIONS = {
            "spookycraft.punish.ban", "spookycraft.punish.unban", "spookycraft.punish.tempban",
            "spookycraft.punish.warn", "spookycraft.punish.kick", "spookycraft.punish.mute",
            "spookycraft.punish.unmute", "spookycraft.punish.history",
            "skript.adminpanel", "spookycraft.crates.admin", "spookycraft.chat.ping", "item.sign", "item.changename", "item.lore", "freeze.use", "playersize.use", "vd.use",
            "chatclear.use", "fake.use", "code.create", "rang.set",
            "essentials.anvil", "essentials.grindstone", "essentials.loom", "essentials.cartographytable", "essentials.smithingtable",
            "essentials.stonecutter", "essentials.trash", "essentials.tp", "essentials.tpo", "essentials.tphere", "essentials.tpohere",
            "essentials.tpall", "essentials.tppos", "essentials.top", "essentials.god", "essentials.invsee", "essentials.clear",
            "essentials.ext", "essentials.burn", "essentials.smite", "essentials.lightning", "essentials.more", "essentials.enchant",
            "essentials.item", "essentials.sudo", "essentials.kickall", "essentials.time", "essentials.weather", "essentials.setspawn",
            "essentials.delwarp", "essentials.createkit", "essentials.suicide", "essentials.vanish.see", "essentials.playtime.others", "essentials.ignore.exempt", "essentials.kickall.exempt"
    };

    private KnownPermissions() {
    }

    /** Alle bekannten Permission-Nodes von JEDEM Plugin auf dem Server + unsere eigenen undeklarierten. */
    public static TreeSet<String> all() {
        TreeSet<String> all = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (org.bukkit.permissions.Permission perm : Bukkit.getPluginManager().getPermissions()) {
            all.add(perm.getName());
        }
        for (String p : UNDECLARED_OWN_PERMISSIONS) {
            all.add(p);
        }
        return all;
    }

    /** Für Tab-Completion: alle bekannten Nodes, gefiltert nach Präfix. */
    public static List<String> search(String prefix) {
        String lower = prefix.toLowerCase();
        List<String> result = new ArrayList<>();
        for (String perm : all()) {
            if (perm.toLowerCase().startsWith(lower)) {
                result.add(perm);
            }
        }
        return result;
    }
}
