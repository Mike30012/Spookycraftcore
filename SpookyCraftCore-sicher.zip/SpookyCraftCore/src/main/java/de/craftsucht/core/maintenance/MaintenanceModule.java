package de.craftsucht.core.maintenance;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

public class MaintenanceModule implements Module, CommandExecutor, Listener {

    private final SpookyCraftCore plugin;
    private boolean enabled;

    public MaintenanceModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "maintenance";
    }

    @Override
    public void enable() {
        this.enabled = plugin.getConfig().getBoolean("maintenance.enabled", false);
        plugin.getCommand("maintenance").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        if (!enabled) return;
        if (Bukkit.getOfflinePlayer(event.getUniqueId()).isOp()) return;
        String msg = plugin.getConfig().getString("maintenance.kick-message", "&5☠ &cDie Geister reparieren gerade ihr Schloss...\n&7Der Server ist im Wartungsmodus. Komm bald wieder!");
        event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, ChatColor.translateAlternateColorCodes('&', msg));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("spookycraft.core.admin")) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        enabled = !enabled;
        plugin.getConfig().set("maintenance.enabled", enabled);
        plugin.saveConfig();
        plugin.getMessageUtil().send(sender, enabled ? "&cDie Geister haben das Tor versiegelt – Wartungsmodus aktiviert." : "&aDas Tor der Geisterwelt ist wieder offen – Wartungsmodus aus.");
        return true;
    }
}
