package de.craftsucht.core.farmreset;

import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.EntityType;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;
import org.bukkit.loot.LootTables;

import java.util.Random;

/**
 * Versteckte Dungeons unter der Erde der Farmwelt: Raum ohne Eingang (man findet ihn beim Graben/Hoehlen),
 * Material passend zum Biom, fester Boss + Wächter (kein Spawner), Loot-Kisten, Spinnweben. Liegt komplett innerhalb des Chunks.
 */
public class DungeonPopulator extends BlockPopulator {

    /** Wahrscheinlichkeit pro Chunk (1 von N). */
    private static final int CHANCE = 22;
    private final FarmGenerator gen;

    public DungeonPopulator(FarmGenerator gen) {
        this.gen = gen;
    }

    @Override
    public void populate(WorldInfo info, Random rnd, int chunkX, int chunkZ, LimitedRegion region) {
        normalDungeon(info, rnd, chunkX, chunkZ, region);
        try {
            graveyard(info, rnd, chunkX, chunkZ, region);
        } catch (Exception ex) {
            // Friedhof ist nur Zusatz - Weltgenerierung darf nie daran scheitern
        }
    }

    private void normalDungeon(WorldInfo info, Random rnd, int chunkX, int chunkZ, LimitedRegion region) {
        if (rnd.nextInt(CHANCE) != 0) return;
        // Raumgroesse (Innenraum) 5..9 x 4 x 5..9, inkl. Wand max 11 -> passt in den Chunk (16)
        int sx = 5 + rnd.nextInt(3) * 2;
        int sz = 5 + rnd.nextInt(3) * 2;
        int ih = 4;
        int x0 = chunkX * 16 + rnd.nextInt(16 - (sx + 2) + 1);
        int z0 = chunkZ * 16 + rnd.nextInt(16 - (sz + 2) + 1);
        int cx = x0 + (sx + 2) / 2;
        int cz = z0 + (sz + 2) / 2;
        int surface = gen.height(cx, cz);
        int minY = info.getMinHeight();
        int top = Math.min(surface - 8, 50);
        int bottom = minY + 10;
        if (top - bottom < 6) return;
        int y0 = bottom + rnd.nextInt(top - bottom - ih - 1);   // Bodenhoehe (unterste Wandebene)
        if (y0 + ih + 2 >= surface - 4) return;
        if (!region.isInRegion(x0, y0, z0) || !region.isInRegion(x0 + sx + 1, y0 + ih + 1, z0 + sz + 1)) return;

        buildRoom(info, rnd, region, x0, y0, z0, sx, sz, ih, cx, cz);
        de.craftsucht.core.dungeon.DungeonRegistry.add(info.getName(), cx, y0, cz, false);
    }

    /** Baut den Dungeon-Raum (Huelle, Deko, Boss, Kisten). */
    private void buildRoom(WorldInfo info, Random rnd, LimitedRegion region, int x0, int y0, int z0, int sx, int sz, int ih, int cx, int cz) {
        org.bukkit.World world = org.bukkit.Bukkit.getWorld(info.getUID());
        Biome biome = gen.biomeAt(info.getSeed(), cx, y0, cz);
        Material[] wall = wallMaterials(biome, y0, info);
        boolean jungle = biome == Biome.JUNGLE || biome == Biome.SWAMP || biome == Biome.DARK_FOREST;

        // Huelle + Innenraum
        for (int x = 0; x < sx + 2; x++) {
            for (int z = 0; z < sz + 2; z++) {
                for (int y = 0; y < ih + 2; y++) {
                    boolean edge = x == 0 || z == 0 || x == sx + 1 || z == sz + 1 || y == 0 || y == ih + 1;
                    int wx = x0 + x, wy = y0 + y, wz = z0 + z;
                    if (edge) {
                        Material m = wall[rnd.nextInt(wall.length)];
                        if (jungle && rnd.nextInt(3) == 0) m = Material.MOSSY_STONE_BRICKS;
                        region.setType(wx, wy, wz, m);
                    } else {
                        region.setType(wx, wy, wz, Material.AIR);
                    }
                }
            }
        }
        // Spinnweben + Knochen/Deko
        for (int i = 0; i < 10; i++) {
            int wx = x0 + 1 + rnd.nextInt(sx), wz = z0 + 1 + rnd.nextInt(sz);
            region.setType(wx, y0 + ih, wz, Material.COBWEB);
        }
        // Sockel in der Mitte + fester Boss (KEIN Spawner -> keine Mobfarm)
        int mx = x0 + 1 + sx / 2, mz = z0 + 1 + sz / 2;
        region.setType(mx, y0 + 1, mz, wall[0]);
        try {
            spawnMob(world, region, mx + 0.5, y0 + 2, mz + 0.5, rnd, true);
            // 3-5 normale Wächter im Raum
            int n = 3 + rnd.nextInt(3);
            for (int i = 0; i < n; i++) {
                spawnMob(world, region, x0 + 1.5 + rnd.nextInt(sx), y0 + 1, z0 + 1.5 + rnd.nextInt(sz), rnd, false);
            }
        } catch (Exception ignored) {
            // Mobs sind nur Deko - der Raum bleibt auch ohne sie bestehen
        }
        // 2 Kisten an den Wänden (mit Dungeon-Loot)
        int chests = 2;
        for (int i = 0; i < chests; i++) {
            boolean alongX = rnd.nextBoolean();
            int wx, wz;
            BlockFace face;
            if (alongX) {
                wx = x0 + 1 + rnd.nextInt(sx);
                boolean north = rnd.nextBoolean();
                wz = north ? z0 + 1 : z0 + sz;
                face = north ? BlockFace.SOUTH : BlockFace.NORTH;
            } else {
                wz = z0 + 1 + rnd.nextInt(sz);
                boolean west = rnd.nextBoolean();
                wx = west ? x0 + 1 : x0 + sx;
                face = west ? BlockFace.EAST : BlockFace.WEST;
            }
            if (wx == mx && wz == mz) continue;
            region.setType(wx, y0 + 1, wz, Material.CHEST);
            org.bukkit.block.data.BlockData data = region.getBlockData(wx, y0 + 1, wz);
            if (data instanceof Directional d) {
                d.setFacing(face);
                region.setBlockData(wx, y0 + 1, wz, d);
            }
            BlockState cs = region.getBlockState(wx, y0 + 1, wz);
            if (cs instanceof Chest c) {
                c.setLootTable(rnd.nextInt(4) == 0 ? LootTables.ABANDONED_MINESHAFT.getLootTable() : LootTables.SIMPLE_DUNGEON.getLootTable(), rnd.nextLong());
                c.update(true, false);
            }
        }
        // Fackeln an den Ecken (leicht beleuchtet, wirkt "echt")
        int[][] corners = {{1, 1}, {sx, 1}, {1, sz}, {sx, sz}};
        for (int[] c : corners) {
            if (rnd.nextInt(2) == 0) region.setType(x0 + c[0], y0 + 1, z0 + c[1], Material.COBWEB);
        }
    }



    /** Friedhof mit Gruft-Eingang an der Oberfläche: Leiter-Schacht fuehrt in einen Dungeon-Raum. */
    private static final int GRAVE_CHANCE = 45;

    private void graveyard(WorldInfo info, Random rnd, int chunkX, int chunkZ, LimitedRegion region) {
        if (rnd.nextInt(GRAVE_CHANCE) != 0) return;
        int sx = 7, sz = 7, ih = 4;
        int x0 = chunkX * 16 + 2 + rnd.nextInt(5);
        int z0 = chunkZ * 16 + 2 + rnd.nextInt(5);
        int shx = x0 + 1, shz = z0 + 1;                  // Schacht in der Raum-Ecke
        int surface = gen.height(shx, shz);
        int minY = info.getMinHeight();
        if (surface <= 66 || surface > 118) return;
        int y0 = Math.max(minY + 10, surface - 22 - rnd.nextInt(8));
        if (y0 + ih + 6 >= surface) return;
        if (!region.isInRegion(x0 - 3, y0, z0 - 3) || !region.isInRegion(x0 + sx + 3, surface + 8, z0 + sz + 3)) return;
        int cx = x0 + (sx + 2) / 2, cz = z0 + (sz + 2) / 2;

        buildRoom(info, rnd, region, x0, y0, z0, sx, sz, ih, cx, cz);
        de.craftsucht.core.dungeon.DungeonRegistry.add(info.getName(), shx, y0, shz, true);

        int floorY = surface;
        // Schacht: Decke oeffnen, Fuellung, Leiter an der Nordwand
        for (int y = y0 + ih + 1; y <= floorY; y++) {
            region.setType(shx, y, shz, Material.AIR);
            if (y > y0 + ih + 1) {
                region.setType(shx - 1, y, shz, Material.STONE_BRICKS);
                region.setType(shx + 1, y, shz, Material.STONE_BRICKS);
                region.setType(shx, y, shz - 1, Material.STONE_BRICKS);
                region.setType(shx, y, shz + 1, Material.STONE_BRICKS);
            }
        }
        for (int y = y0 + 1; y <= floorY; y++) {
            region.setType(shx, y, shz, Material.LADDER);
            org.bukkit.block.data.BlockData d = region.getBlockData(shx, y, shz);
            if (d instanceof Directional dd) {
                dd.setFacing(BlockFace.SOUTH);
                region.setBlockData(shx, y, shz, dd);
            }
        }

        // Gruft-Haus (5x5) um den Schacht
        for (int x = shx - 2; x <= shx + 2; x++) {
            for (int z = shz - 2; z <= shz + 2; z++) {
                int colH = gen.height(x, z);
                for (int y = Math.min(colH, floorY) - 3; y <= floorY; y++) {
                    if (x == shx && z == shz) continue;
                    region.setType(x, y, z, Material.COBBLESTONE);
                }
                for (int y = floorY + 1; y <= floorY + 7; y++) region.setType(x, y, z, Material.AIR);
                boolean edge = x == shx - 2 || x == shx + 2 || z == shz - 2 || z == shz + 2;
                if (edge) {
                    for (int y = floorY + 1; y <= floorY + 3; y++) {
                        region.setType(x, y, z, rnd.nextInt(3) == 0 ? Material.MOSSY_STONE_BRICKS : Material.STONE_BRICKS);
                    }
                }
                region.setType(x, floorY + 4, z, edge ? Material.STONE_BRICK_SLAB : Material.STONE_BRICKS);
            }
        }
        // Eingang an der Suedseite (2 hoch) + Fackel-Laternen
        region.setType(shx, floorY + 1, shz + 2, Material.AIR);
        region.setType(shx, floorY + 2, shz + 2, Material.AIR);
        region.setType(shx - 1, floorY + 3, shz + 2, Material.SOUL_LANTERN);
        region.setType(shx + 1, floorY + 3, shz + 2, Material.SOUL_LANTERN);
        // Schacht-Oeffnung im Hausdach freilassen ist unnoetig - das Dach liegt hoeher als der Schacht

        // Grabsteine rund um die Gruft
        int stones = 6 + rnd.nextInt(5);
        for (int i = 0; i < stones; i++) {
            int gx = chunkX * 16 + 1 + rnd.nextInt(14);
            int gz = chunkZ * 16 + 1 + rnd.nextInt(14);
            if (Math.abs(gx - shx) <= 3 && Math.abs(gz - shz) <= 3) continue;
            int gh = gen.height(gx, gz);
            if (gh <= 63) continue;
            region.setType(gx, gh, gz, Material.COARSE_DIRT);
            region.setType(gx, gh + 1, gz, Material.STONE_BRICK_WALL);
            region.setType(gx, gh + 2, gz, Material.STONE_BRICK_SLAB);
            int dx = gx + rnd.nextInt(3) - 1, dz = gz + rnd.nextInt(3) - 1;
            int dh = gen.height(dx, dz);
            if (dh > 63 && (dx != gx || dz != gz)) {
                region.setType(dx, dh, dz, Material.PODZOL);
                region.setType(dx, dh + 1, dz, rnd.nextBoolean() ? Material.DEAD_BUSH : Material.COBWEB);
            }
        }
    }

    private static void spawnMob(org.bukkit.World world, LimitedRegion region, double x, double y, double z, Random rnd, boolean boss) {
        EntityType[] normal = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.HUSK};
        EntityType type = boss ? EntityType.WITHER_SKELETON : normal[rnd.nextInt(normal.length)];
        org.bukkit.entity.Entity e = region.spawnEntity(new org.bukkit.Location(world, x, y, z), type);
        if (e == null) return;
        if (e instanceof org.bukkit.entity.LivingEntity le) {
            le.setPersistent(true);
            le.setRemoveWhenFarAway(false);
            if (boss) {
                le.setCustomName("§c§lDungeon-Wächter");
                le.setCustomNameVisible(true);
                var hp = le.getAttribute(de.craftsucht.core.util.Compat.attr("max_health"));
                if (hp != null) { hp.setBaseValue(80.0); le.setHealth(80.0); }
            }
        }
    }

    private static Material[] wallMaterials(Biome b, int y, WorldInfo info) {
        if (y < 0) return new Material[]{Material.DEEPSLATE_BRICKS, Material.CRACKED_DEEPSLATE_BRICKS, Material.DEEPSLATE_TILES};
        if (b == Biome.DESERT || b == Biome.SAVANNA || b == Biome.BEACH)
            return new Material[]{Material.SANDSTONE, Material.CUT_SANDSTONE, Material.SMOOTH_SANDSTONE};
        if (b == Biome.SNOWY_PLAINS || b == Biome.SNOWY_TAIGA || b == Biome.FROZEN_PEAKS || b == Biome.SNOWY_SLOPES || b == Biome.SNOWY_BEACH)
            return new Material[]{Material.STONE_BRICKS, Material.PACKED_ICE, Material.CRACKED_STONE_BRICKS};
        if (b == Biome.JUNGLE || b == Biome.SWAMP || b == Biome.DARK_FOREST)
            return new Material[]{Material.MOSSY_COBBLESTONE, Material.COBBLESTONE, Material.MOSSY_STONE_BRICKS};
        return new Material[]{Material.COBBLESTONE, Material.MOSSY_COBBLESTONE, Material.STONE_BRICKS, Material.CRACKED_STONE_BRICKS};
    }
}
