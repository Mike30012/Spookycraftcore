package de.craftsucht.core.booster;

import de.craftsucht.core.SpookyCraftCore;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Holzfäller-Äxte: Beim Abbauen eines Baumstamms fällt der ganze Baum (alle zusammenhängenden Stämme).
 * Die Axt-Items haben das Spezial-Tag "fell_<max Stämme>" (fell_64 = Stufe I, fell_256 = II, fell_1024 = III).
 * Jede Stufe hat eine eigene Abklingzeit (tree-feller.cooldown-seconds), die in der Aktionsleiste angezeigt wird. Einstellungen: "tree-feller:" in der config.yml.
 */
public class TreeFellerListener implements Listener {

    private final SpookyCraftCore plugin;

    /** Ende der Abklingzeit pro Spieler (Millisekunden). */
    private final java.util.Map<java.util.UUID, Long> cooldownEnd = new java.util.HashMap<>();
    private org.bukkit.scheduler.BukkitTask hudTask;

    public TreeFellerListener(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    /** Anzeige der Abklingzeit in der Aktionsleiste (über der Hotbar), solange eine Holzfäller-Axt in der Hand ist. */
    public void start() {
        hudTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) showHud(p);
        }, 10L, 5L);
    }

    public void stop() {
        if (hudTask != null) hudTask.cancel();
        cooldownEnd.clear();
    }

    /** Verzauberungsstufe 1-3 aus der Axt (fell_64 = I, fell_256 = II, fell_1024 = III). */
    private int level(ItemStack tool) {
        int n = maxLogs(tool);
        if (n <= 0) return 0;
        return n <= 64 ? 1 : n <= 256 ? 2 : 3;
    }

    private int cooldownSeconds(int level) {
        List<Integer> l = plugin.getConfig().getIntegerList("tree-feller.cooldown-seconds");
        if (l.size() < 3) l = List.of(45, 20, 8);
        return Math.max(0, l.get(Math.min(level, 3) - 1));
    }

    private static String roman(int level) {
        return level == 1 ? "I" : level == 2 ? "II" : "III";
    }

    private void showHud(Player p) {
        ItemStack tool = p.getInventory().getItemInMainHand();
        int lvl = level(tool);
        if (lvl <= 0) return;
        long left = cooldownEnd.getOrDefault(p.getUniqueId(), 0L) - System.currentTimeMillis();
        String name = "§5§l☠ §dHolzfäller " + roman(lvl) + " §8| ";
        if (left <= 0) {
            p.sendActionBar(net.kyori.adventure.text.Component.text(name + "§a§lBereit"));
            return;
        }
        int total = Math.max(1, cooldownSeconds(lvl) * 1000);
        int filled = (int) Math.round(10.0 * (total - left) / total);
        filled = Math.max(0, Math.min(10, filled));
        StringBuilder bar = new StringBuilder("§d");
        for (int i = 0; i < 10; i++) {
            if (i == filled) bar.append("§8");
            bar.append("█");
        }
        p.sendActionBar(net.kyori.adventure.text.Component.text(name + bar + " §c" + (int) Math.ceil(left / 1000.0) + "s"));
    }

    private int maxLogs(ItemStack tool) {
        if (tool == null || !tool.hasItemMeta()) return 0;
        // Verzauberungs-Buch "Holzfäller I-III" (/holzfäller): I = 64, II = 256, III = 1024 Stämme
        int book = de.craftsucht.core.cenchant.CustomEnchantModule.levelOf(plugin, tool, "holzfaeller");
        if (book > 0) return book == 1 ? 64 : book == 2 ? 256 : 1024;
        String special = tool.getItemMeta().getPersistentDataContainer()
                .get(SpecialItemsListener.keySpecial(plugin), PersistentDataType.STRING);
        if (special == null || !special.startsWith("fell_")) return 0;
        try {
            return Integer.parseInt(special.substring(5));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static boolean isLog(Block b) {
        return Tag.LOGS.isTagged(b.getType());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (AreaMiningListener.isExtraBreak()) return;
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        int limit = maxLogs(tool);
        if (limit <= 0) return;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        FileConfiguration cfg = plugin.getConfig();
        if (player.isSneaking() && cfg.getBoolean("tree-feller.sneak-disables", true)) return;
        List<String> worlds = cfg.getStringList("tree-feller.worlds");
        if (!worlds.isEmpty() && !worlds.contains(player.getWorld().getName())) return;

        Block start = event.getBlock();
        if (!isLog(start)) return;
        int lvl = level(tool);
        long left = cooldownEnd.getOrDefault(player.getUniqueId(), 0L) - System.currentTimeMillis();
        if (left > 0) {
            showHud(player);   // Abklingzeit läuft: normaler Abbau, nur 1 Stamm
            return;
        }
        limit = Math.min(limit, Math.max(1, cfg.getInt("tree-feller.max-logs", 1024)));

        // Alle zusammenhängenden Stämme suchen (inkl. Diagonalen, damit Äste/Dark-Oak-Stämme mitkommen)
        Set<Block> found = new HashSet<>();
        ArrayDeque<Block> queue = new ArrayDeque<>();
        found.add(start);
        queue.add(start);
        boolean leaves = false;
        while (!queue.isEmpty() && found.size() < limit + 1) {
            Block b = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block n = b.getRelative(dx, dy, dz);
                        if (isLog(n)) {
                            if (found.size() < limit + 1 && found.add(n)) queue.add(n);
                        } else if (!leaves && Tag.LEAVES.isTagged(n.getType())
                                && n.getBlockData() instanceof org.bukkit.block.data.type.Leaves l && !l.isPersistent()) {
                            leaves = true;   // natürliche Blätter = echter Baum, kein Holzhaus
                        }
                    }
                }
            }
        }
        if (cfg.getBoolean("tree-feller.require-leaves", true) && !leaves) return;
        found.remove(start);   // der angeklickte Stamm wird ganz normal abgebaut
        if (found.isEmpty()) return;
        int cd = cooldownSeconds(lvl);
        if (cd > 0) cooldownEnd.put(player.getUniqueId(), System.currentTimeMillis() + cd * 1000L);

        List<Block> logs = new ArrayList<>(found);
        logs.sort(Comparator.comparingInt(Block::getY).reversed());
        final int perTick = Math.max(5, cfg.getInt("tree-feller.blocks-per-tick", 40));
        final boolean toInventory = cfg.getBoolean("tree-feller.drops-to-inventory", false);
        final ItemStack toolCopy = tool.clone();
        final Block center = start;

        new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                AreaMiningListener.setExtraBreak(true);
                try {
                    int done = 0;
                    while (index < logs.size() && done < perTick) {
                        Block block = logs.get(index++);
                        done++;
                        if (!isLog(block)) continue;
                        BlockBreakEvent extra = new BlockBreakEvent(block, player);
                        Bukkit.getPluginManager().callEvent(extra);
                        if (extra.isCancelled()) continue;
                        if (extra.isDropItems()) {
                            Collection<ItemStack> drops = block.getDrops(toolCopy, player);
                            block.setType(Material.AIR, false);
                            for (ItemStack drop : drops) {
                                if (toInventory) {
                                    for (ItemStack left : player.getInventory().addItem(drop).values()) {
                                        center.getWorld().dropItemNaturally(center.getLocation().add(0.5, 0.5, 0.5), left);
                                    }
                                } else {
                                    block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), drop);
                                }
                            }
                        } else {
                            block.setType(Material.AIR, false);
                        }
                    }
                } finally {
                    AreaMiningListener.setExtraBreak(false);
                }
                if (index >= logs.size()) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
