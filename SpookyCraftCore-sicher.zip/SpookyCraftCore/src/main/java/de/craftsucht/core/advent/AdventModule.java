package de.craftsucht.core.advent;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.crates.CratesModule;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Weihnachts-Event: Adventskalender (/adventskalender) mit 24 Türchen, die ab dem 1. Dezember Tag für Tag aufgehen,
 * plus leichter Schnee um die Spieler. Alles lässt sich in der config unter "advent:" steuern.
 * Geöffnete Türchen stehen pro Spieler und Jahr in advent.yml.
 */
public class AdventModule implements Module, CommandExecutor, Listener {

    private static class Holder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;
    private File file;
    private YamlConfiguration data;
    private BukkitTask snowTask;

    public AdventModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "advent";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "advent.yml");
        data = YamlConfiguration.loadConfiguration(file);
        plugin.getCommand("adventskalender").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
        if (plugin.getConfig().getBoolean("advent.snow", true)) {
            snowTask = Bukkit.getScheduler().runTaskTimer(plugin, this::snow, 40L, 20L);
        }
    }

    @Override
    public void disable() {
        if (snowTask != null) snowTask.cancel();
        HandlerList.unregisterAll((Listener) this);
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("advent.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ Datum

    /** Heutiger Kalendertag 1-24, 0 = noch nicht Dezember, 25 = nach dem 24. */
    private int today() {
        if (plugin.getConfig().getBoolean("advent.always-open", false)) return 24;
        LocalDate d = LocalDate.now();
        if (d.getMonthValue() != 12) return 0;
        return Math.min(25, d.getDayOfMonth());
    }

    private boolean eventTime() {
        return today() >= 1 || plugin.getConfig().getBoolean("advent.always-open", false);
    }

    private String path(Player p) {
        return p.getUniqueId() + "." + LocalDate.now().getYear();
    }

    private boolean claimed(Player p, int day) {
        return data.getIntegerList(path(p)).contains(day);
    }

    // ------------------------------------------------------------------ Befehl + Menü

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur im Spiel.");
            return true;
        }
        if (today() == 0 && !p.isOp()) {
            LocalDate now = LocalDate.now();
            LocalDate first = LocalDate.of(now.getMonthValue() == 12 ? now.getYear() + 1 : now.getYear(), 12, 1);
            long days = java.time.temporal.ChronoUnit.DAYS.between(now, first);
            plugin.getMessageUtil().send(p, "&c❄ &fDer Adventskalender öffnet erst am &a1. Dezember&f. Noch &e" + days + " Tage&f!");
            return true;
        }
        open(p);
        return true;
    }

    private int slotOf(int day) {
        int i = day - 1;
        return (i / 8 + 1) * 9 + (i % 8);
    }

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(new Holder(), 54, GuiUtil.c("&c&l❄ &f&lAdventskalender &8» &a" + LocalDate.now().getYear()));
        for (int i = 0; i < 54; i++) {
            inv.setItem(i, GuiUtil.item(i % 2 == 0 ? Material.RED_STAINED_GLASS_PANE : Material.GREEN_STAINED_GLASS_PANE, " "));
        }
        int today = today();
        boolean catchUp = plugin.getConfig().getBoolean("advent.catch-up", true);
        for (int day = 1; day <= 24; day++) {
            ItemStack it;
            if (claimed(p, day)) {
                it = GuiUtil.item(Material.LIME_STAINED_GLASS_PANE, "&aTürchen " + day, "&7Schon geöffnet", rewardText(day));
            } else if (day > today) {
                it = GuiUtil.item(Material.BARRIER, "&cTürchen " + day, "&7Öffnet am &f" + day + ". Dezember");
            } else if (day == today || catchUp) {
                it = GuiUtil.item(day == today ? Material.CHEST : Material.ENDER_CHEST, (day == today ? "&e&l" : "&6") + "Türchen " + day,
                        day == today ? "&aHeute dran!" : "&7Verpasst - noch abholbar", "", "&eKlicke zum Öffnen");
            } else {
                it = GuiUtil.item(Material.GRAY_STAINED_GLASS_PANE, "&7Türchen " + day, "&8Verpasst");
            }
            it.setAmount(Math.max(1, day));
            inv.setItem(slotOf(day), it);
        }
        int open = data.getIntegerList(path(p)).size();
        inv.setItem(4, GuiUtil.item(Material.SNOWBALL, "&f&l❄ Frohe Weihnachten! ❄", "&7Geöffnet: &a" + open + "&7/24",
                eventTime() ? "&7Heute ist der &f" + Math.min(24, today) + ". Dezember" : "&7Der Kalender öffnet am &f1. Dezember"));
        p.openInventory(inv);
    }

    private String rewardText(int day) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("advent.rewards." + day);
        if (s == null) return "";
        List<String> parts = new ArrayList<>();
        if (s.getLong("money") > 0) parts.add(s.getLong("money") + "$");
        if (s.getLong("crystals") > 0) parts.add(s.getLong("crystals") + " Kristalle");
        if (s.getString("limited") != null) parts.add("★ Limitiertes Item");
        if (s.getString("item") != null) parts.add(s.getInt("amount", 1) + "x " + s.getString("item"));
        return "&8" + String.join(", ", parts);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        for (int day = 1; day <= 24; day++) {
            if (slotOf(day) == slot) {
                claim(p, day);
                return;
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private void claim(Player p, int day) {
        int today = today();
        if (claimed(p, day)) {
            plugin.getMessageUtil().send(p, "&7Dieses Türchen hast du schon geöffnet.");
            return;
        }
        if (day > today) {
            plugin.getMessageUtil().send(p, "&cDas Türchen &f" + day + " &cöffnet erst am &f" + day + ". Dezember&c.");
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.7f);
            return;
        }
        if (day != today && !plugin.getConfig().getBoolean("advent.catch-up", true)) {
            plugin.getMessageUtil().send(p, "&cDieses Türchen ist verpasst.");
            return;
        }
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("advent.rewards." + day);
        List<Integer> list = new ArrayList<>(data.getIntegerList(path(p)));
        list.add(day);
        data.set(path(p), list);
        save();
        StringBuilder got = new StringBuilder();
        if (s != null) {
            long money = s.getLong("money");
            if (money > 0 && plugin.getModuleManager().get("economy") instanceof EconomyModule em && em.getManager() != null) {
                em.getManager().deposit(p.getUniqueId(), money);
                got.append("&e").append(money).append("$ ");
            }
            long crystals = s.getLong("crystals");
            if (crystals > 0 && plugin.getModuleManager().get("crates") instanceof CratesModule cm && cm.getCrystals() != null) {
                cm.getCrystals().add(p.getUniqueId(), crystals);
                got.append("&d").append(crystals).append(" Kristalle ");
            }
            String limited = s.getString("limited");
            if (limited != null) {
                ItemStack special = limitedItem(limited, p);
                if (special != null) {
                    for (ItemStack left : p.getInventory().addItem(special).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
                    got.append("&6★ ").append(special.getItemMeta().getDisplayName()).append(" ");
                }
            }
            String itemName = s.getString("item");
            Material mat = itemName == null ? null : Material.matchMaterial(itemName);
            if (mat != null) {
                int amount = Math.max(1, s.getInt("amount", 1));
                for (ItemStack left : p.getInventory().addItem(new ItemStack(mat, amount)).values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), left);
                }
                got.append("&f").append(amount).append("x ").append(mat.name().toLowerCase().replace('_', ' ')).append(" ");
            }
        }
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.3f);
        p.spawnParticle(Particle.FIREWORK, p.getLocation().add(0, 1.5, 0), 25, 0.5, 0.5, 0.5, 0.05);
        plugin.getMessageUtil().send(p, "&c❄ &fTürchen &a" + day + " &fgeöffnet! &7Du bekommst: " + got.toString().trim());
        open(p);
    }

    // ------------------------------------------------------------------ Limitierte, signierte Items

    /** Muster der limitierten Items (ohne Nummer/Besitzer), z.B. für die Item-Datenbank (/db). */
    public List<ItemStack> sampleItems() {
        List<ItemStack> out = new ArrayList<>();
        for (String id : new String[]{"schneekugel", "elfen_muetze", "zuckerstangen_schwert", "weihnachtsmann_muetze", "lebkuchen_spitzhacke",
                "lebkuchen_helm", "lebkuchen_brustplatte", "lebkuchen_hose", "lebkuchen_stiefel", "elfen_stiefel", "weihnachtsmann_mantel", "weihnachtsmann_hose", "weihnachtsmann_stiefel", "rentier_geweih", "eiszapfen_bogen", "lebkuchen_mann"}) {
            ItemStack it = limitedItem(id, null);
            if (it != null) out.add(it);
        }
        return out;
    }

    private ItemStack limitedItem(String id, Player p) {
        Material mat;
        String name;
        String signer;
        int color = -1;
        java.util.Map<String, Integer> ench = new java.util.LinkedHashMap<>();
        List<String> desc = new ArrayList<>();
        switch (id) {
            case "elfen_stiefel" -> {
                mat = Material.LEATHER_BOOTS; name = "&a&lElfen-Stiefel"; signer = "&a&lElf Jingle"; color = 0x1E9A3C;
                ench.put("feather_falling", 4); ench.put("unbreaking", 4);
                desc.add("&7Leise Schritte, bimmelnde Glöckchen.");
            }
            case "weihnachtsmann_mantel" -> {
                mat = Material.LEATHER_CHESTPLATE; name = "&c&lWeihnachtsmann-Mantel"; signer = "&c&lWeihnachtsmann"; color = 0xC81E1E;
                ench.put("protection", 3); ench.put("unbreaking", 4);
                desc.add("&7Warm gefüttert, mit weißem Fell.");
            }
            case "weihnachtsmann_hose" -> {
                mat = Material.LEATHER_LEGGINGS; name = "&c&lWeihnachtsmann-Hose"; signer = "&c&lWeihnachtsmann"; color = 0xC81E1E;
                ench.put("protection", 3); ench.put("unbreaking", 4);
                desc.add("&7Passt zum Mantel.");
            }
            case "weihnachtsmann_stiefel" -> {
                mat = Material.LEATHER_BOOTS; name = "&c&lWeihnachtsmann-Stiefel"; signer = "&c&lWeihnachtsmann"; color = 0x2A1A10;
                ench.put("protection", 3); ench.put("unbreaking", 4);
                desc.add("&7Schwarz, glänzend, schneefest.");
            }
            case "rentier_geweih" -> {
                mat = Material.LEATHER_HELMET; name = "&6&lRentier-Geweih"; signer = "&6&lRudolph"; color = 0x8B5A2B;
                ench.put("unbreaking", 5);
                desc.add("&7Mit leuchtend roter Nase.");
            }
            case "eiszapfen_bogen" -> {
                mat = Material.BOW; name = "&b&lEiszapfen-Bogen"; signer = "&b&lFrosty"; 
                ench.put("power", 4); ench.put("unbreaking", 3);
                desc.add("&7Eiskalt getroffen.");
            }
            case "lebkuchen_mann" -> {
                mat = Material.COOKIE; name = "&6&lLebkuchen-Mann"; signer = "&b&lElf Pip";
                desc.add("&7Ein Sammlerstück. Sieht lecker aus,");
                desc.add("&7aber nicht aufessen!");
            }
            case "lebkuchen_helm" -> {
                mat = Material.LEATHER_HELMET; name = "&6&lLebkuchen-Helm"; signer = "&c&lWeihnachtsmann";
                ench.put("protection", 4); ench.put("unbreaking", 4);
                desc.add("&7Frisch gebacken und mit Zuckerguss verziert.");
            }
            case "lebkuchen_brustplatte" -> {
                mat = Material.LEATHER_CHESTPLATE; name = "&6&lLebkuchen-Brustplatte"; signer = "&c&lWeihnachtsmann";
                ench.put("protection", 4); ench.put("unbreaking", 4);
                desc.add("&7Mit Zuckerguss-Knöpfen.");
            }
            case "lebkuchen_hose" -> {
                mat = Material.LEATHER_LEGGINGS; name = "&6&lLebkuchen-Hose"; signer = "&c&lWeihnachtsmann";
                ench.put("protection", 4); ench.put("unbreaking", 4);
                desc.add("&7Knusprig und warm.");
            }
            case "lebkuchen_stiefel" -> {
                mat = Material.LEATHER_BOOTS; name = "&6&lLebkuchen-Stiefel"; signer = "&c&lWeihnachtsmann";
                ench.put("protection", 4); ench.put("unbreaking", 4);
                desc.add("&7Mit Zuckerguss-Rand.");
            }
            case "weihnachtsmann_muetze" -> {
                mat = Material.LEATHER_HELMET; name = "&c&lWeihnachtsmann-Mütze"; signer = "&c&lWeihnachtsmann"; color = 0xC81E1E;
                ench.put("unbreaking", 5);
                desc.add("&7Ein Original aus der Werkstatt am Nordpol.");
            }
            case "elfen_muetze" -> {
                mat = Material.LEATHER_HELMET; name = "&a&lElfen-Mütze"; signer = "&a&lElf Jingle"; color = 0x1E9A3C;
                ench.put("unbreaking", 5);
                desc.add("&7Spitz, grün und ziemlich selten.");
            }
            case "zuckerstangen_schwert" -> {
                mat = Material.IRON_SWORD; name = "&f&lZuckerstangen-&c&lSchwert"; signer = "&c&lRudolph";
                ench.put("sharpness", 4); ench.put("unbreaking", 3);
                desc.add("&7Süß, aber scharf.");
            }
            case "schneekugel" -> {
                mat = Material.SNOWBALL; name = "&b&lWichtel-Schneekugel"; signer = "&b&lElf Pip";
                desc.add("&7Ein Sammlerstück. Bitte nicht werfen!");
            }
            case "lebkuchen_spitzhacke" -> {
                mat = Material.NETHERITE_PICKAXE; name = "&6&lLebkuchen-Spitzhacke"; signer = "&c&lWeihnachtsmann";
                ench.put("efficiency", 6); ench.put("unbreaking", 5); ench.put("fortune", 3);
                desc.add("&7Das große Geschenk des Weihnachtsmanns.");
            }
            default -> {
                return null;
            }
        }
        ItemStack it = new ItemStack(mat);
        org.bukkit.inventory.meta.ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(GuiUtil.c(name));
        int serial = p == null ? 0 : data.getInt("serials." + id, 0) + 1;
        if (p != null) {
            data.set("serials." + id, serial);
            save();
        }
        List<String> lore = new ArrayList<>();
        for (String d : desc) lore.add(GuiUtil.c(d));
        lore.add("");
        lore.add(GuiUtil.c("&7Signiert von " + signer));
        lore.add(GuiUtil.c("&6★ &eLimitierte Edition &fWeihnachten " + LocalDate.now().getYear()));
        lore.add(GuiUtil.c(p == null ? "&8Nr. ? &8· &8Besitzer: -" : "&8Nr. " + serial + " &8· &8Besitzer: " + p.getName()));
        meta.setLore(lore);
        for (java.util.Map.Entry<String, Integer> en : ench.entrySet()) {
            org.bukkit.enchantments.Enchantment e = org.bukkit.Registry.ENCHANTMENT.get(org.bukkit.NamespacedKey.minecraft(en.getKey()));
            if (e != null) meta.addEnchant(e, en.getValue(), true);
        }
        if (ench.isEmpty()) {
            org.bukkit.enchantments.Enchantment glow = org.bukkit.Registry.ENCHANTMENT.get(org.bukkit.NamespacedKey.minecraft("unbreaking"));
            if (glow != null) {
                meta.addEnchant(glow, 1, true);
                meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
            }
        }
        if (color >= 0 && meta instanceof org.bukkit.inventory.meta.LeatherArmorMeta lm) {
            lm.setColor(org.bukkit.Color.fromRGB(color));
            meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_DYE);
        }
        Integer extraCmd = switch (id) {
            case "weihnachtsmann_muetze", "weihnachtsmann_mantel", "weihnachtsmann_hose", "weihnachtsmann_stiefel" -> 2305;
            case "elfen_muetze", "elfen_stiefel" -> 2306;
            case "rentier_geweih" -> 2307;
            case "lebkuchen_spitzhacke" -> 2311;
            case "eiszapfen_bogen" -> 2312;
            default -> null;
        };
        if (extraCmd != null) meta.setCustomModelData(extraCmd);
        if (id.equals("zuckerstangen_schwert")) meta.setCustomModelData(2201);   // Textur im Resource-Pack (iron_sword.json)
        if (id.startsWith("lebkuchen_") && !id.equals("lebkuchen_spitzhacke") && !id.equals("lebkuchen_mann")) {
            int cmd = switch (id) {
                case "lebkuchen_helm" -> 2301;
                case "lebkuchen_brustplatte" -> 2302;
                case "lebkuchen_hose" -> 2303;
                default -> 2304;
            };
            meta.setCustomModelData(cmd);
            wornLook(meta, mat);   // Trage-Optik aus dem Resource-Pack (equipment/lebkuchen.json)
        }
        meta.getPersistentDataContainer().set(new org.bukkit.NamespacedKey(plugin, "advent_limited"),
                org.bukkit.persistence.PersistentDataType.STRING, id + ":" + serial);
        it.setItemMeta(meta);
        return it;
    }

    /** Setzt die Trage-Optik "spookycraft:lebkuchen" per Reflection (EquippableComponent, Paper 1.21.3+). */
    private void wornLook(org.bukkit.inventory.meta.ItemMeta meta, Material mat) {
        try {
            Class<?> ec = Class.forName("org.bukkit.inventory.meta.components.EquippableComponent");
            Object comp = org.bukkit.inventory.meta.ItemMeta.class.getMethod("getEquippable").invoke(meta);
            org.bukkit.inventory.EquipmentSlot slot = mat == Material.LEATHER_HELMET ? org.bukkit.inventory.EquipmentSlot.HEAD
                    : mat == Material.LEATHER_CHESTPLATE ? org.bukkit.inventory.EquipmentSlot.CHEST
                    : mat == Material.LEATHER_LEGGINGS ? org.bukkit.inventory.EquipmentSlot.LEGS : org.bukkit.inventory.EquipmentSlot.FEET;
            ec.getMethod("setSlot", org.bukkit.inventory.EquipmentSlot.class).invoke(comp, slot);
            ec.getMethod("setModel", org.bukkit.NamespacedKey.class).invoke(comp, new org.bukkit.NamespacedKey("spookycraft", "lebkuchen"));
            org.bukkit.inventory.meta.ItemMeta.class.getMethod("setEquippable", ec).invoke(meta, comp);
        } catch (Throwable t) {
            plugin.getLogger().warning("Lebkuchen-Trage-Optik nicht möglich: " + t);
        }
    }

    // ------------------------------------------------------------------ Schnee + Erinnerung

    private void snow() {
        if (!eventTime()) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : Bukkit.getOnlinePlayers()) {
            for (int i = 0; i < 6; i++) {
                p.spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(r.nextDouble(-6, 6), r.nextDouble(1.5, 5), r.nextDouble(-6, 6)), 1, 0, -0.05, 0, 0.02);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        int today = today();
        if (today < 1 || today > 24 || claimed(p, today)) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) plugin.getMessageUtil().send(p, "&c❄ &fDein Adventskalender wartet! Türchen &a" + today + " &fist offen &8(/adventskalender)");
        }, 60L);
    }
}
