package de.craftsucht.core.staffutils;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.util.GuiUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Ersatz für das StaffUtils-Plugin: AdminSpy (/spy) und Ticket-System (/ticket, /tickets, /taccept, /tclose).
 * Tickets liegen in tickets.yml.
 */
public class StaffUtilsModule implements Module, CommandExecutor, TabCompleter, Listener {

    private static class TicketHolder implements InventoryHolder {
        final List<Integer> ids = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;
    private final Set<UUID> spies = new HashSet<>();
    private File file;
    private YamlConfiguration data;

    public StaffUtilsModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "staffutils";
    }

    @Override
    public void enable() {
        file = new File(plugin.getDataFolder(), "tickets.yml");
        data = YamlConfiguration.loadConfiguration(file);
        for (String cmd : new String[]{"spy", "ticket", "tickets", "taccept", "tclose"}) {
            if (plugin.getCommand(cmd) != null) {
                plugin.getCommand(cmd).setExecutor(this);
                plugin.getCommand(cmd).setTabCompleter(this);
            }
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        spies.clear();
        save();
    }

    private void save() {
        if (data == null) return;
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("tickets.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private boolean isStaff(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin") || s.hasPermission("spookycraft.core.staffchat")
                || s.hasPermission("staffutils.ticket.manage");
    }

    private boolean canSpy(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.core.admin") || s.hasPermission("staffutils.spy");
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "spy" -> spy(sender);
            case "ticket" -> ticket(sender, args);
            case "tickets" -> {
                if (!(sender instanceof Player p)) {
                    msg(sender, "&cNur im Spiel.");
                } else if (!isStaff(p)) {
                    msg(p, "&cDas dürfen nur Teammitglieder.");
                } else {
                    openList(p);
                }
            }
            case "taccept" -> accept(sender, args);
            case "tclose" -> close(sender, args);
            default -> {
            }
        }
        return true;
    }

    private void spy(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            msg(sender, "&cNur im Spiel.");
            return;
        }
        if (!canSpy(p)) {
            msg(p, "&cDas darfst du nicht.");
            return;
        }
        if (spies.remove(p.getUniqueId())) msg(p, "&7AdminSpy &causgeschaltet&7.");
        else {
            spies.add(p.getUniqueId());
            msg(p, "&7AdminSpy &aeingeschaltet&7. Du siehst jetzt die Befehle der Spieler.");
        }
    }

    private void ticket(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            msg(sender, "&cNur im Spiel.");
            return;
        }
        if (args.length == 0) {
            msg(p, "&cNutzung: /ticket <Grund>  &7(z.B. /ticket Ich wurde gegrieft)");
            return;
        }
        int open = 0;
        ConfigurationSection sec = data.getConfigurationSection("tickets");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                if (p.getUniqueId().toString().equals(sec.getString(k + ".creator")) && !"CLOSED".equals(sec.getString(k + ".status"))) open++;
            }
        }
        int max = plugin.getConfig().getInt("tickets.max-open-per-player", 3);
        if (open >= max) {
            msg(p, "&cDu hast schon " + open + " offene Tickets. Warte, bis das Team sie bearbeitet hat.");
            return;
        }
        int id = data.getInt("next-id", 1);
        data.set("next-id", id + 1);
        String path = "tickets." + id;
        data.set(path + ".creator", p.getUniqueId().toString());
        data.set(path + ".creator-name", p.getName());
        data.set(path + ".reason", String.join(" ", args));
        data.set(path + ".time", new SimpleDateFormat("dd.MM.yyyy HH:mm").format(new Date()));
        data.set(path + ".status", "OPEN");
        data.set(path + ".world", p.getWorld().getName());
        data.set(path + ".x", p.getLocation().getBlockX());
        data.set(path + ".y", p.getLocation().getBlockY());
        data.set(path + ".z", p.getLocation().getBlockZ());
        save();
        msg(p, "&aTicket &f#" + id + " &aerstellt. Das Team meldet sich bei dir.");
        for (Player t : Bukkit.getOnlinePlayers()) {
            if (isStaff(t)) msg(t, "&5☠ &dNeues Ticket &f#" + id + " &7von &f" + p.getName() + "&7: &f" + String.join(" ", args) + " &8(/tickets)");
        }
    }

    private int parseId(CommandSender s, String[] args, String usage) {
        if (!isStaff(s)) {
            msg(s, "&cDas dürfen nur Teammitglieder.");
            return -1;
        }
        if (args.length < 1) {
            msg(s, "&cNutzung: " + usage);
            return -1;
        }
        try {
            int id = Integer.parseInt(args[0].replace("#", ""));
            if (!data.contains("tickets." + id)) {
                msg(s, "&cTicket #" + id + " gibt es nicht.");
                return -1;
            }
            return id;
        } catch (NumberFormatException e) {
            msg(s, "&cDas ist keine gültige Ticket-Nummer.");
            return -1;
        }
    }

    private void accept(CommandSender s, String[] args) {
        int id = parseId(s, args, "/taccept <ID>");
        if (id < 0) return;
        String path = "tickets." + id;
        if ("CLOSED".equals(data.getString(path + ".status"))) {
            msg(s, "&cDas Ticket ist schon geschlossen.");
            return;
        }
        data.set(path + ".status", "ACCEPTED");
        data.set(path + ".staff", s.getName());
        save();
        msg(s, "&aDu hast Ticket &f#" + id + " &aangenommen.");
        notifyCreator(id, "&aDein Ticket &f#" + id + " &awird von &f" + s.getName() + " &abearbeitet.");
    }

    private void close(CommandSender s, String[] args) {
        int id = parseId(s, args, "/tclose <ID> [Nachricht]");
        if (id < 0) return;
        String path = "tickets." + id;
        data.set(path + ".status", "CLOSED");
        data.set(path + ".staff", s.getName());
        save();
        String note = args.length > 1 ? " &7Nachricht: &f" + String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "";
        msg(s, "&aTicket &f#" + id + " &ageschlossen.");
        notifyCreator(id, "&7Dein Ticket &f#" + id + " &7wurde von &f" + s.getName() + " &7geschlossen." + note);
    }

    private void notifyCreator(int id, String text) {
        try {
            Player c = Bukkit.getPlayer(UUID.fromString(data.getString("tickets." + id + ".creator", "")));
            if (c != null) msg(c, text);
        } catch (IllegalArgumentException ignored) {
            // kein gültiger Ersteller
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String n = command.getName().toLowerCase(Locale.ROOT);
        if ((n.equals("taccept") || n.equals("tclose")) && args.length == 1 && isStaff(sender)) {
            List<String> out = new ArrayList<>();
            ConfigurationSection sec = data.getConfigurationSection("tickets");
            if (sec != null) for (String k : sec.getKeys(false)) if (!"CLOSED".equals(sec.getString(k + ".status"))) out.add(k);
            return out;
        }
        return List.of();
    }

    // ------------------------------------------------------------------ Ticket-Menü

    private void openList(Player p) {
        TicketHolder h = new TicketHolder();
        Inventory inv = Bukkit.createInventory(h, 54, GuiUtil.c("&5&l☠ &d&lTickets &8» &7offen"));
        ConfigurationSection sec = data.getConfigurationSection("tickets");
        int slot = 0;
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                String status = sec.getString(k + ".status", "OPEN");
                if ("CLOSED".equals(status) || slot >= 45) continue;
                boolean accepted = "ACCEPTED".equals(status);
                List<String> lore = new ArrayList<>();
                lore.add("&7Von: &f" + sec.getString(k + ".creator-name"));
                lore.add("&7Zeit: &f" + sec.getString(k + ".time"));
                lore.add("&7Ort: &f" + sec.getString(k + ".world") + " " + sec.getInt(k + ".x") + " " + sec.getInt(k + ".y") + " " + sec.getInt(k + ".z"));
                lore.add("&7Grund: &f" + sec.getString(k + ".reason"));
                lore.add("");
                if (accepted) lore.add("&7Bearbeitet von: &a" + sec.getString(k + ".staff"));
                lore.add(accepted ? "&aBereits angenommen" : "&eLinksklick: annehmen");
                lore.add("&cRechtsklick: schließen");
                lore.add("&bShift-Klick: hinteleportieren");
                inv.setItem(slot, GuiUtil.item(accepted ? Material.WRITABLE_BOOK : Material.PAPER, (accepted ? "&a" : "&e") + "Ticket #" + k, lore));
                h.ids.add(Integer.parseInt(k));
                slot++;
            }
        }
        if (slot == 0) inv.setItem(22, GuiUtil.item(Material.LIME_DYE, "&aKeine offenen Tickets", "&7Alles erledigt!"));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof TicketHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot < 0 || slot >= h.ids.size() || !isStaff(p)) return;
        int id = h.ids.get(slot);
        if (e.getClick() == ClickType.SHIFT_LEFT || e.getClick() == ClickType.SHIFT_RIGHT) {
            String w = data.getString("tickets." + id + ".world");
            if (w != null && Bukkit.getWorld(w) != null) {
                p.teleport(new org.bukkit.Location(Bukkit.getWorld(w), data.getInt("tickets." + id + ".x") + 0.5,
                        data.getInt("tickets." + id + ".y"), data.getInt("tickets." + id + ".z") + 0.5));
            }
            return;
        }
        if (e.getClick().isRightClick()) close(p, new String[]{String.valueOf(id)});
        else accept(p, new String[]{String.valueOf(id)});
        openList(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof TicketHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ AdminSpy

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCommandSpy(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (spies.isEmpty() || p.hasPermission("staffutils.spy.bypass")) return;
        String msg = e.getMessage();
        String low = msg.toLowerCase(Locale.ROOT);
        // Passwörter und Spy-Befehle selbst nicht anzeigen
        if (low.startsWith("/spy") || low.startsWith("/login") || low.startsWith("/register")) return;
        for (UUID id : spies) {
            Player s = Bukkit.getPlayer(id);
            if (s != null && s.isOnline() && !s.equals(p)) {
                s.sendMessage(GuiUtil.c("&8[&5Spy&8] &7" + p.getName() + ": &f" + msg));
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!isStaff(p)) return;
        ConfigurationSection sec = data.getConfigurationSection("tickets");
        int n = 0;
        if (sec != null) for (String k : sec.getKeys(false)) if ("OPEN".equals(sec.getString(k + ".status"))) n++;
        if (n > 0) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> msg(p, "&5☠ &dEs gibt &f" + n + " &doffene Tickets &8(/tickets)"), 40L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        spies.remove(e.getPlayer().getUniqueId());
    }
}
