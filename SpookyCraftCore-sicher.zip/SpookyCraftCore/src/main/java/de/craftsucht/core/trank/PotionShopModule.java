package de.craftsucht.core.trank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyManager;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Lange Tränke (/tranke): Unsichtbarkeit, Nachtsicht, Feuerresistenz und Wasseratmung in drei Stufen
 * (15, 30 und 60 Minuten). Gekauft wird im Menü mit Server-Geld, getrunken wie ein normaler Trank.
 */
public class PotionShopModule implements Module, CommandExecutor, Listener {

    private record Kind(String id, String name, String color, String effect, Color rgb, String desc) {
    }

    private static final List<Kind> KINDS = List.of(
            new Kind("unsichtbarkeit", "Unsichtbarkeit", "&d", "invisibility", Color.fromRGB(0xB66BFF), "Du wirst für andere unsichtbar."),
            new Kind("nachtsicht", "Nachtsicht", "&9", "night_vision", Color.fromRGB(0x3A4DFF), "Du siehst im Dunkeln."),
            new Kind("feuerresistenz", "Feuerresistenz", "&6", "fire_resistance", Color.fromRGB(0xFF8A1F), "Feuer und Lava schaden dir nicht."),
            new Kind("wasseratmung", "Wasseratmung", "&b", "water_breathing", Color.fromRGB(0x2E9BFF), "Du kannst unter Wasser atmen."));

    private static final int[] MINUTES = {15, 30, 60};
    private static final String[] ROMAN = {"I", "II", "III"};

    private static class Holder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final SpookyCraftCore plugin;
    private NamespacedKey tagKey;
    /** Spieler, die gerade einen unserer Unsichtbarkeits-Tränke wirken lassen. */
    private final Set<UUID> invisible = new HashSet<>();

    public PotionShopModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "tranke";
    }

    @Override
    public void enable() {
        tagKey = new NamespacedKey(plugin, "langtrank");
        plugin.getCommand("tranke").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll((Listener) this);
        invisible.clear();
    }

    private static String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private int price(Kind k, int tier) {
        List<Integer> l = plugin.getConfig().getIntegerList("tranke.prices." + k.id());
        if (tier < l.size()) return l.get(tier);
        return 5000 * (tier + 1) * (tier + 1);
    }

    private PotionEffectType type(Kind k) {
        return PotionEffectType.getByKey(NamespacedKey.minecraft(k.effect()));
    }

    private ItemStack potion(Kind k, int tier) {
        ItemStack it = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) it.getItemMeta();
        meta.setDisplayName(c(k.color() + "&l" + k.name() + " " + ROMAN[tier] + " &8(" + MINUTES[tier] + " Min.)"));
        meta.setColor(k.rgb());
        PotionEffectType t = type(k);
        if (t != null) meta.addCustomEffect(new PotionEffect(t, MINUTES[tier] * 60 * 20, 0, false, true, true), true);
        meta.setLore(List.of(c("&7" + k.desc()), c("&7Dauer: &f" + MINUTES[tier] + " Minuten"), "", c("&5☠ &dSpookyCraft-Trank")));
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        meta.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, k.id());
        it.setItemMeta(meta);
        return it;
    }

    private EconomyManager eco() {
        return plugin.getModuleManager().get("economy") instanceof EconomyModule em ? em.getManager() : null;
    }

    // ------------------------------------------------------------------ Menü

    private void open(Player p) {
        Inventory inv = Bukkit.createInventory(new Holder(), 45, c("&5&l☠ &d&lSpookyCraft &8» &fTränke"));
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);
        for (int i = 0; i < 45; i++) inv.setItem(i, filler);
        for (int r = 0; r < KINDS.size(); r++) {
            for (int t = 0; t < 3; t++) {
                ItemStack it = potion(KINDS.get(r), t);
                ItemMeta m = it.getItemMeta();
                List<String> lore = new ArrayList<>(m.getLore());
                lore.add(0, c("&7Preis: &e" + String.format(Locale.GERMANY, "%,d", price(KINDS.get(r), t)) + "$"));
                lore.add(c("&aKlicke zum Kaufen"));
                m.setLore(lore);
                it.setItemMeta(m);
                inv.setItem(r * 9 + 2 + t * 2, it);
            }
        }
        EconomyManager eco = eco();
        ItemStack info = new ItemStack(Material.GOLD_INGOT);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(c("&eDein Geld: &f" + String.format(Locale.GERMANY, "%,.0f", eco == null ? 0 : eco.getBalance(p.getUniqueId())) + "$"));
        info.setItemMeta(im);
        inv.setItem(40, info);
        p.openInventory(inv);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur im Spiel.");
            return true;
        }
        open(p);
        return true;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        int row = slot / 9;
        int col = slot % 9;
        if (row < 0 || row >= KINDS.size() || col < 2 || col > 6 || col % 2 != 0) return;
        int tier = (col - 2) / 2;
        Kind k = KINDS.get(row);
        EconomyManager eco = eco();
        if (eco == null || !eco.withdraw(p.getUniqueId(), price(k, tier))) {
            plugin.getMessageUtil().send(p, "&cDeine Taschen sind zu leer – nicht genug Geld!");
            return;
        }
        for (ItemStack left : p.getInventory().addItem(potion(k, tier)).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
        p.playSound(p.getLocation(), "entity.witch.celebrate", 0.7f, 1.2f);
        plugin.getMessageUtil().send(p, "&5☠ &dTrank gekauft: &f" + k.name() + " " + ROMAN[tier] + " &7(" + MINUTES[tier] + " Min.)");
        open(p);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ Unsichtbarkeit

    @EventHandler
    public void onDrink(PlayerItemConsumeEvent e) {
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        String id = it.getItemMeta().getPersistentDataContainer().get(tagKey, PersistentDataType.STRING);
        if ("unsichtbarkeit".equals(id)) invisible.add(e.getPlayer().getUniqueId());
    }

    /** Wer mit dem langen Unsichtbarkeits-Trank angreift, wird wieder sichtbar (config: tranke.invisibility-breaks-on-attack). */
    @EventHandler
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !invisible.contains(p.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("tranke.invisibility-breaks-on-attack", true)) return;
        PotionEffectType inv = PotionEffectType.getByKey(NamespacedKey.minecraft("invisibility"));
        if (inv != null) p.removePotionEffect(inv);
        invisible.remove(p.getUniqueId());
        plugin.getMessageUtil().send(p, "&dDu bist durch den Angriff wieder sichtbar geworden.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        invisible.remove(e.getPlayer().getUniqueId());
    }
}
