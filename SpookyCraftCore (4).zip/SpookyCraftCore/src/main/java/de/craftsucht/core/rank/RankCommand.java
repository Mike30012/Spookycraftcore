package de.craftsucht.core.rank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.util.TabCompleteUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.*;

public class RankCommand implements CommandExecutor, TabCompleter {

    private final SpookyCraftCore plugin;
    private final RankManager manager;

    public RankCommand(SpookyCraftCore plugin, RankManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        boolean ownerRank = sender instanceof org.bukkit.entity.Player pl
                && "owner".equalsIgnoreCase(manager.getUserRank(pl.getUniqueId()));
        if (!(sender instanceof org.bukkit.command.ConsoleCommandSender) && !sender.isOp() && !ownerRank) {
            plugin.getMessageUtil().send(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (manager.usesLuckPerms()) {
            plugin.getMessageUtil().send(sender, "&5☠ &dRänge und Rechte verwalten jetzt die Geister von &fLuckPerms&d: &e/lp &7(z.B. /lp user <spieler> parent set <rang>)");
            return true;
        }
        if (args.length == 0) {
            plugin.getMessageUtil().send(sender, "&5☠ &7Zauberformeln: /rank create|delete|setprefix|setweight|setparent|setpermission|unsetpermission|addpermissions|createmany|preset|info|list|user");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> create(sender, args);
            case "createmany" -> createMany(sender, java.util.Arrays.copyOfRange(args, 1, args.length));
            case "preset" -> preset(sender, args);
            case "delete" -> delete(sender, args);
            case "setprefix" -> setPrefix(sender, args);
            case "setweight" -> setWeight(sender, args);
            case "setparent" -> setParent(sender, args);
            case "setpermission" -> setPermission(sender, args, true);
            case "unsetpermission" -> setPermission(sender, args, false);
            case "addpermissions" -> {
                if (args.length < 3) {
                    plugin.getMessageUtil().send(sender, "&cNutzung: /rank addpermissions <name> <perm1> <perm2> ...");
                } else if (manager.getRank(args[1]) == null) {
                    plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
                } else {
                    for (int i = 2; i < args.length; i++) manager.setPermission(args[1], args[i], true);
                    refreshOnlinePlayers();
                    plugin.getMessageUtil().send(sender, "&a" + (args.length - 2) + " Rechte hinzugefügt.");
                }
            }
            case "info" -> info(sender, args);
            case "list" -> list(sender);
            case "user" -> user(sender, args);
            default -> plugin.getMessageUtil().send(sender, "&cUnbekannter Unterbefehl.");
        }
        return true;
    }

    private void create(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank create <&farbe&lName, z.B. &4&lOwner> [gewicht]");
            return;
        }
        String prefix = args[1];
        String plainName = org.bukkit.ChatColor.stripColor(
                org.bukkit.ChatColor.translateAlternateColorCodes('&', prefix));
        if (plainName == null || plainName.isBlank()) {
            plugin.getMessageUtil().send(sender, "&cDer Rang braucht auch sichtbaren Text, nicht nur Farbcodes.");
            return;
        }
        int weight = args.length > 2 ? parseIntOr(args[2], 0) : 0;
        boolean ok = manager.createRank(plainName, prefix, weight, null);
        if (ok) {
            plugin.getMessageUtil().send(sender, "&aRang &r" + plugin.getMessageUtil().color(prefix) + " &aerstellt.");
            refreshVisuals();
        } else {
            plugin.getMessageUtil().send(sender, "&cRang existiert bereits.");
        }
    }

    private static final java.util.Map<String, String[]> PRESETS = new java.util.LinkedHashMap<>();

    static {
        PRESETS.put("geister", new String[]{"&7Spukling:10", "&fIrrlicht:20", "&bPoltergeist:30", "&3Phantom:40", "&5&lSchattenfürst:50", "&d&lGeisterkönig:60"});
        PRESETS.put("friedhof", new String[]{"&7Grabräuber:10", "&8Totengräber:20", "&2Nekromant:30", "&aGruftwächter:40", "&c&lTodesritter:50", "&4&lUnterweltherrscher:60"});
        PRESETS.put("monster", new String[]{"&2Zombie:10", "&7Skelett:20", "&8Spinne:30", "&5Hexe:40", "&0&lWither:50", "&d&lEnder-Lord:60"});
        PRESETS.put("nacht", new String[]{"&9Dämmerling:10", "&1Nachtwandler:20", "&3Mondschatten:30", "&5Sensenträger:40", "&d&lSeelenfürst:50", "&8&lEwigerSchatten:60"});
        PRESETS.put("kuerbis", new String[]{"&6Kürbiskopf:10", "&eVogelscheuche:20", "&cSpukmeister:30", "&aErntegeist:40", "&6&lKürbiskönig:50"});
    }

    /** /rank createmany &7Name:10 &bName2:20 ... - mehrere Ränge auf einmal (Format Prefix:Gewicht). */
    private void createMany(CommandSender sender, String[] entries) {
        if (entries.length == 0) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank createmany <&farbeName:gewicht> <&farbeName2:gewicht> ...  (z.B. &7Spukling:10 &fIrrlicht:20)");
            return;
        }
        int ok = 0;
        List<String> skipped = new ArrayList<>();
        for (String e : entries) {
            int i = e.lastIndexOf(':');
            String prefix = i > 0 ? e.substring(0, i) : e;
            int weight = i > 0 ? parseIntOr(e.substring(i + 1), 0) : 0;
            String plain = org.bukkit.ChatColor.stripColor(org.bukkit.ChatColor.translateAlternateColorCodes('&', prefix));
            if (plain == null || plain.isBlank()) {
                skipped.add(e);
                continue;
            }
            if (manager.createRank(plain, prefix, weight, null)) ok++;
            else skipped.add(plain);
        }
        refreshVisuals();
        plugin.getMessageUtil().send(sender, "&a" + ok + " Ränge erstellt." + (skipped.isEmpty() ? "" : " &7Übersprungen (gibt es schon/ungültig): &f" + String.join(", ", skipped)));
    }

    /** /rank preset <geister|friedhof|monster|nacht|kuerbis|alle> */
    private void preset(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank preset <geister|friedhof|monster|nacht|kuerbis|alle>");
            return;
        }
        String key = args[1].toLowerCase();
        List<String> entries = new ArrayList<>();
        if (key.equals("alle")) {
            for (String[] a : PRESETS.values()) entries.addAll(List.of(a));
        } else if (PRESETS.containsKey(key)) {
            entries.addAll(List.of(PRESETS.get(key)));
        } else {
            plugin.getMessageUtil().send(sender, "&cUnbekannte Leiter. Möglich: geister, friedhof, monster, nacht, kuerbis, alle");
            return;
        }
        createMany(sender, entries.toArray(new String[0]));
    }

    private void delete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank delete <name>");
            return;
        }
        manager.deleteRank(args[1]);
        plugin.getMessageUtil().send(sender, "&aRang gelöscht.");
        refreshVisuals();
    }

    private void setPrefix(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setprefix <name> <prefix>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        manager.updatePrefix(rank.name(), args[2]);
        plugin.getMessageUtil().send(sender, "&aPrefix gesetzt.");
        refreshVisuals();
    }

    private void setWeight(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setweight <name> <zahl>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        manager.updateRank(rank.name(), rank.prefix(), parseIntOr(args[2], rank.weight()), rank.parent());
        plugin.getMessageUtil().send(sender, "&aGewicht gesetzt.");
    }

    private void setParent(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setparent <name> <elternrang>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        manager.updateRank(rank.name(), rank.prefix(), rank.weight(), args[2].equalsIgnoreCase("none") ? null : args[2]);
        plugin.getMessageUtil().send(sender, "&aElternrang gesetzt.");
    }

    private void setPermission(CommandSender sender, String[] args, boolean set) {
        if (set && args.length < 4) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank setpermission <name> <permission> <true|false>");
            return;
        }
        if (!set && args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank unsetpermission <name> <permission>");
            return;
        }
        if (set) {
            manager.setPermission(args[1], args[2], Boolean.parseBoolean(args[3]));
        } else {
            manager.unsetPermission(args[1], args[2]);
        }
        refreshOnlinePlayers();
        plugin.getMessageUtil().send(sender, "&aErledigt.");
    }

    private void info(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank info <name>");
            return;
        }
        RankManager.RankData rank = manager.getRank(args[1]);
        if (rank == null) {
            plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
            return;
        }
        plugin.getMessageUtil().sendRaw(sender, "&8--- &bRang " + rank.name() + " &8---");
        plugin.getMessageUtil().sendRaw(sender, "&7Prefix: " + rank.prefix() + " &7Gewicht: &b" + rank.weight() + " &7Eltern: &b" + (rank.parent() != null ? rank.parent() : "-"));
        Map<String, Boolean> perms = manager.getOwnPermissions(rank.name());
        for (Map.Entry<String, Boolean> entry : perms.entrySet()) {
            plugin.getMessageUtil().sendRaw(sender, (entry.getValue() ? "&a+ " : "&c- ") + entry.getKey());
        }
    }

    private void list(CommandSender sender) {
        plugin.getMessageUtil().sendRaw(sender, "&8--- &bRänge &8---");
        for (RankManager.RankData rank : manager.listRanks()) {
            plugin.getMessageUtil().sendRaw(sender, rank.prefix() + rank.name() + " &7(Gewicht " + rank.weight() + ")");
        }
    }

    private void user(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.getMessageUtil().send(sender, "&cNutzung: /rank user <spieler> <set <rang>|info>");
            return;
        }
        OfflinePlayer target = resolveTarget(args[1]);
        if (args[2].equalsIgnoreCase("info")) {
            plugin.getMessageUtil().send(sender, "&7" + target.getName() + " hat Rang &b" + manager.getUserRank(target.getUniqueId())
                    + " &8(UUID " + target.getUniqueId() + ")");
            return;
        }
        if (args[2].equalsIgnoreCase("set")) {
            if (args.length < 4) {
                plugin.getMessageUtil().send(sender, "&cNutzung: /rank user <spieler> set <rang>");
                return;
            }
            if (manager.getRank(args[3]) == null) {
                plugin.getMessageUtil().send(sender, "&cRang existiert nicht.");
                return;
            }
            manager.setUserRank(target.getUniqueId(), args[3]);
            if (target.isOnline() && target.getPlayer() != null) {
                manager.apply(target.getPlayer());
            }
            plugin.getMessageUtil().send(sender, "&aRang gesetzt.");
            refreshVisuals();
        }
    }

    /**
     * Findet den Spieler auch bei Bedrock-Namen (Floodgate setzt einen Punkt davor, z.B. ".Tavrox12345"):
     * erst online (mit oder ohne Punkt), dann unter den bekannten Spielern, zuletzt wie bisher.
     * So landet der Rang bei der echten Bedrock-UUID und nicht bei einer errechneten Offline-UUID.
     */
    private OfflinePlayer resolveTarget(String input) {
        for (var p : Bukkit.getOnlinePlayers()) {
            String n = p.getName();
            if (n.equalsIgnoreCase(input) || n.equalsIgnoreCase("." + input) || (n.startsWith(".") && n.substring(1).equalsIgnoreCase(input))) {
                return p;
            }
        }
        for (OfflinePlayer op : Bukkit.getOfflinePlayers()) {
            String n = op.getName();
            if (n == null) continue;
            if (n.equalsIgnoreCase(input) || n.equalsIgnoreCase("." + input) || (n.startsWith(".") && n.substring(1).equalsIgnoreCase(input))) {
                return op;
            }
        }
        return Bukkit.getOfflinePlayer(input);
    }

    private void refreshOnlinePlayers() {
        for (var p : Bukkit.getOnlinePlayers()) {
            manager.apply(p);
        }
    }

    /** Aktualisiert Tabliste/Nametag/Scoreboard sofort, statt auf den nächsten Tick zu warten. */
    private void refreshVisuals() {
        de.craftsucht.core.module.Module m = plugin.getModuleManager().get("scoreboard");
        if (m instanceof de.craftsucht.core.scoreboard.ScoreboardModule sm) {
            sm.refreshNow();
        }
    }

    private int parseIntOr(String s, int fallback) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return TabCompleteUtil.filter(args[0], "create", "delete", "setprefix", "setweight", "setparent",
                    "setpermission", "unsetpermission", "addpermissions", "createmany", "preset", "info", "list", "user");
        }
        if (args.length == 2 && List.of("delete", "setprefix", "setweight", "setparent", "setpermission", "unsetpermission", "info").contains(args[0].toLowerCase())) {
            List<String> names = new ArrayList<>();
            for (RankManager.RankData r : manager.listRanks()) names.add(r.name());
            return names;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("preset")) {
            return TabCompleteUtil.filter(args[1], "geister", "friedhof", "monster", "nacht", "kuerbis", "alle");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("user")) {
            return TabCompleteUtil.onlinePlayers(args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("user")) {
            return TabCompleteUtil.filter(args[2], "set", "info");
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("user") && args[2].equalsIgnoreCase("set")) {
            List<String> names = new ArrayList<>();
            for (RankManager.RankData r : manager.listRanks()) names.add(r.name());
            return names;
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("setpermission") || args[0].equalsIgnoreCase("unsetpermission"))) {
            List<String> results = new ArrayList<>(KnownPermissions.search(args[2]));
            if ("*".startsWith(args[2])) results.add(0, "*");
            return results;
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("setpermission")) {
            return TabCompleteUtil.filter(args[3], "true", "false");
        }
        return Collections.emptyList();
    }
}
