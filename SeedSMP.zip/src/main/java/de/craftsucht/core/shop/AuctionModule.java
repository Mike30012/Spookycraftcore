package de.craftsucht.core.shop;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Auktionshaus mit Menue: /ah (durchstoebern + kaufen), /ah sell &lt;preis&gt; (Item in der Hand anbieten),
 * /ah meine (eigene Angebote zurueckziehen / abgelaufene abholen).
 * Items werden komplett (mit Meta/Enchants/Custom-Daten) gespeichert, nicht nur als Material.
 */
public class AuctionModule implements Module, CommandExecutor, org.bukkit.command.TabCompleter, Listener {

    private static final int PAGE_SIZE = 45;
    private static final int STATUS_ACTIVE = 0;
    private static final int STATUS_SOLD = 1;
    private static final int STATUS_CLAIMABLE = 2;
    private static final int STATUS_DONE = 3;

    private enum Type { BROWSE, MINE, CONFIRM }

    private static final class AhHolder implements InventoryHolder {
        final Type type;
        int page;
        long listingId;
        final Map<Integer, Long> slotIds = new HashMap<>();
        Inventory inventory;

        AhHolder(Type type) {
            this.type = type;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final SpookyCraftCore plugin;

    public AuctionModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "auction";
    }

    @Override
    public void enable() {
        try (Connection c = plugin.getDatabase().getConnection(); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS ah_listings (id INTEGER PRIMARY KEY AUTOINCREMENT, seller TEXT, "
                    + "seller_name TEXT, item TEXT, price REAL, created INTEGER, expires INTEGER, status INTEGER DEFAULT 0)");
        } catch (SQLException e) {
            plugin.getLogger().warning("Auktionshaus-Tabelle konnte nicht angelegt werden: " + e.getMessage());
        }
        plugin.getCommand("ah").setExecutor(this);
        plugin.getCommand("ah").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void disable() {
        org.bukkit.event.HandlerList.unregisterAll(this);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof AhHolder) p.closeInventory();
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return de.craftsucht.core.util.TabCompleteUtil.filter(args[0], "sell", "meine");
        }
        return java.util.Collections.emptyList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            openBrowse(p, 0);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "sell", "verkaufen" -> sell(p, args);
            case "meine", "mine", "my" -> openMine(p);
            default -> plugin.getMessageUtil().send(p, "&cNutzung: &e/ah &7(Menü) &e/ah sell <preis> &7| &e/ah meine");
        }
        return true;
    }

    // ------------------------------------------------------------------ Verkaufen

    private void sell(Player p, String[] args) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (args.length < 2 || hand == null || hand.getType().isAir()) {
            plugin.getMessageUtil().send(p, "&cHalte ein Item in der Hand: &e/ah sell <preis>");
            return;
        }
        double price = parsePrice(args[1]);
        if (price < 1 || price > 1_000_000_000_000.0) {
            plugin.getMessageUtil().send(p, "&cUngültiger Preis (mindestens 1, z.B. 500, 2.5k, 1m).");
            return;
        }
        expireOld();
        int max = plugin.getConfig().getInt("auction.max-listings", 20);
        if (countActive(p.getUniqueId()) >= max) {
            plugin.getMessageUtil().send(p, "&cDu hast schon &e" + max + " &cAngebote. Ziehe eins zurück: &e/ah meine");
            return;
        }
        long hours = plugin.getConfig().getLong("auction.duration-hours", 48);
        long now = System.currentTimeMillis();
        String data = Base64.getEncoder().encodeToString(hand.serializeAsBytes());
        String sql = "INSERT INTO ah_listings (seller, seller_name, item, price, created, expires, status) VALUES (?,?,?,?,?,?,0)";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            ps.setString(2, p.getName());
            ps.setString(3, data);
            ps.setDouble(4, price);
            ps.setLong(5, now);
            ps.setLong(6, now + hours * 3_600_000L);
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getMessageUtil().send(p, "&cFehler beim Anbieten.");
            plugin.getLogger().warning("AH sell: " + e.getMessage());
            return;
        }
        p.getInventory().setItemInMainHand(null);
        plugin.getMessageUtil().send(p, "&aDein Item steht für &e$" + money(price) + " &ain &e/ah &a(" + hours + " Stunden).");
    }

    private static double parsePrice(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).replace(",", ".").trim();
        double mult = 1;
        if (s.endsWith("k")) { mult = 1_000; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("m")) { mult = 1_000_000; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("b")) { mult = 1_000_000_000; s = s.substring(0, s.length() - 1); }
        try {
            double v = Double.parseDouble(s) * mult;
            return Double.isFinite(v) ? Math.floor(v * 100) / 100.0 : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String money(double v) {
        return String.format(Locale.GERMANY, "%,.2f", v);
    }

    // ------------------------------------------------------------------ DB-Helfer

    private void expireOld() {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE ah_listings SET status=? WHERE status=? AND expires<=?")) {
            ps.setInt(1, STATUS_CLAIMABLE);
            ps.setInt(2, STATUS_ACTIVE);
            ps.setLong(3, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("AH expire: " + e.getMessage());
        }
    }

    private int countActive(UUID uuid) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM ah_listings WHERE seller=? AND status=0")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            return 0;
        }
    }

    private record Listing(long id, String seller, String sellerName, ItemStack item, double price, long expires, int status) {}

    private Listing read(ResultSet rs) throws SQLException {
        ItemStack item;
        try {
            item = ItemStack.deserializeBytes(Base64.getDecoder().decode(rs.getString("item")));
        } catch (Exception e) {
            item = new ItemStack(Material.BARRIER);
        }
        return new Listing(rs.getLong("id"), rs.getString("seller"), rs.getString("seller_name"), item,
                rs.getDouble("price"), rs.getLong("expires"), rs.getInt("status"));
    }

    private Listing getListing(long id) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM ah_listings WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? read(rs) : null;
            }
        } catch (SQLException e) {
            return null;
        }
    }

    /** Setzt den Status nur, wenn er noch "von" ist (verhindert Doppel-Kauf). */
    private boolean changeStatus(long id, int from, int to) {
        try (Connection c = plugin.getDatabase().getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE ah_listings SET status=? WHERE id=? AND status=?")) {
            ps.setInt(1, to);
            ps.setLong(2, id);
            ps.setInt(3, from);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            plugin.getLogger().warning("AH status: " + e.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------------ Menues

    private ItemStack named(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(legacy(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(legacy(s));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    private static Component legacy(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack withLore(ItemStack base, List<String> extra) {
        ItemStack it = base.clone();
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        for (String s : extra) lore.add(legacy(s));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private static String timeLeft(long expires) {
        long ms = expires - System.currentTimeMillis();
        if (ms <= 0) return "abgelaufen";
        long min = ms / 60_000L;
        return (min / 60) + "h " + (min % 60) + "m";
    }

    private void openBrowse(Player p, int page) {
        expireOld();
        AhHolder holder = new AhHolder(Type.BROWSE);
        holder.page = Math.max(0, page);
        Inventory inv = Bukkit.createInventory(holder, 54, "§a§lSeedSMP §6§lAuktionshaus");
        holder.inventory = inv;
        boolean hasNext = false;
        String sql = "SELECT * FROM ah_listings WHERE status=0 ORDER BY created DESC LIMIT ? OFFSET ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, PAGE_SIZE + 1);
            ps.setInt(2, holder.page * PAGE_SIZE);
            try (ResultSet rs = ps.executeQuery()) {
                int slot = 0;
                while (rs.next()) {
                    if (slot >= PAGE_SIZE) { hasNext = true; break; }
                    Listing l = read(rs);
                    boolean own = l.seller().equals(p.getUniqueId().toString());
                    List<String> extra = new ArrayList<>();
                    extra.add("");
                    extra.add("&7Preis: &a$" + money(l.price()));
                    extra.add("&7Verkäufer: &f" + l.sellerName());
                    extra.add("&7Läuft ab in: &e" + timeLeft(l.expires()));
                    extra.add("");
                    extra.add(own ? "&8Das ist dein Angebot (&e/ah meine&8)" : "&eKlick: &7kaufen");
                    inv.setItem(slot, withLore(l.item(), extra));
                    holder.slotIds.put(slot, l.id());
                    slot++;
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("AH browse: " + e.getMessage());
        }
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = PAGE_SIZE; i < 54; i++) inv.setItem(i, filler);
        if (holder.page > 0) inv.setItem(45, named(Material.ARROW, "&e« Vorherige Seite"));
        inv.setItem(48, named(Material.CHEST, "&6Meine Angebote", "&7Zurückziehen & abgelaufene abholen"));
        inv.setItem(49, named(Material.PAPER, "&bSeite " + (holder.page + 1),
                "&7Verkaufen: &e/ah sell <preis>", "&7Item vorher in die Hand nehmen"));
        EconomyModule eco = (EconomyModule) plugin.getModuleManager().get("economy");
        if (eco != null) {
            inv.setItem(50, named(Material.GOLD_INGOT, "&6Dein Geld",
                    "&a$" + money(eco.getManager().getBalance(p.getUniqueId()))));
        }
        if (hasNext) inv.setItem(53, named(Material.ARROW, "&eNächste Seite »"));
        p.openInventory(inv);
    }

    private void openMine(Player p) {
        expireOld();
        AhHolder holder = new AhHolder(Type.MINE);
        Inventory inv = Bukkit.createInventory(holder, 54, "§8§lMeine Angebote");
        holder.inventory = inv;
        String sql = "SELECT * FROM ah_listings WHERE seller=? AND status IN (0,2) ORDER BY status DESC, created DESC LIMIT 45";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getUniqueId().toString());
            try (ResultSet rs = ps.executeQuery()) {
                int slot = 0;
                while (rs.next() && slot < PAGE_SIZE) {
                    Listing l = read(rs);
                    List<String> extra = new ArrayList<>();
                    extra.add("");
                    extra.add("&7Preis: &a$" + money(l.price()));
                    if (l.status() == STATUS_CLAIMABLE) {
                        extra.add("&cAbgelaufen");
                        extra.add("&eKlick: &7abholen");
                    } else {
                        extra.add("&7Läuft ab in: &e" + timeLeft(l.expires()));
                        extra.add("&eKlick: &7zurückziehen");
                    }
                    inv.setItem(slot, withLore(l.item(), extra));
                    holder.slotIds.put(slot, l.id());
                    slot++;
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("AH mine: " + e.getMessage());
        }
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = PAGE_SIZE; i < 54; i++) inv.setItem(i, filler);
        inv.setItem(49, named(Material.ARROW, "&e« Zurück zum Auktionshaus"));
        p.openInventory(inv);
    }

    private void openConfirm(Player p, Listing l) {
        AhHolder holder = new AhHolder(Type.CONFIRM);
        holder.listingId = l.id();
        Inventory inv = Bukkit.createInventory(holder, 27, "§8Kauf bestätigen");
        holder.inventory = inv;
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        inv.setItem(13, withLore(l.item(), List.of("", "&7Preis: &a$" + money(l.price()), "&7Verkäufer: &f" + l.sellerName())));
        inv.setItem(11, named(Material.LIME_STAINED_GLASS_PANE, "&a&lKaufen", "&7Für &a$" + money(l.price())));
        inv.setItem(15, named(Material.RED_STAINED_GLASS_PANE, "&c&lAbbrechen"));
        p.openInventory(inv);
    }

    // ------------------------------------------------------------------ Klicks

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof AhHolder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof AhHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        switch (holder.type) {
            case BROWSE -> {
                if (slot == 45 && holder.page > 0) { openBrowse(p, holder.page - 1); return; }
                if (slot == 53 && e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.ARROW) {
                    openBrowse(p, holder.page + 1);
                    return;
                }
                if (slot == 48) { openMine(p); return; }
                Long id = holder.slotIds.get(slot);
                if (id == null) return;
                Listing l = getListing(id);
                if (l == null || l.status() != STATUS_ACTIVE) {
                    plugin.getMessageUtil().send(p, "&cDas Angebot gibt es nicht mehr.");
                    openBrowse(p, holder.page);
                    return;
                }
                if (l.seller().equals(p.getUniqueId().toString())) {
                    plugin.getMessageUtil().send(p, "&cDas ist dein eigenes Angebot. Ziehe es zurück mit &e/ah meine&c.");
                    return;
                }
                openConfirm(p, l);
            }
            case MINE -> {
                if (slot == 49) { openBrowse(p, 0); return; }
                Long id = holder.slotIds.get(slot);
                if (id == null) return;
                Listing l = getListing(id);
                if (l == null || !l.seller().equals(p.getUniqueId().toString())) return;
                int from = l.status();
                if (from != STATUS_ACTIVE && from != STATUS_CLAIMABLE) return;
                if (!changeStatus(id, from, STATUS_DONE)) {
                    plugin.getMessageUtil().send(p, "&cDas Angebot wurde gerade verkauft oder ist nicht mehr da.");
                    openMine(p);
                    return;
                }
                give(p, l.item());
                plugin.getMessageUtil().send(p, from == STATUS_ACTIVE ? "&aAngebot zurückgezogen." : "&aItem abgeholt.");
                openMine(p);
            }
            case CONFIRM -> {
                if (slot == 15) { openBrowse(p, 0); return; }
                if (slot == 11) buy(p, holder.listingId);
            }
        }
    }

    private void give(Player p, ItemStack item) {
        for (ItemStack left : p.getInventory().addItem(item).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
    }

    private void buy(Player p, long id) {
        EconomyModule eco = (EconomyModule) plugin.getModuleManager().get("economy");
        if (eco == null) return;
        expireOld();
        Listing l = getListing(id);
        if (l == null || l.status() != STATUS_ACTIVE) {
            plugin.getMessageUtil().send(p, "&cDas Angebot gibt es nicht mehr.");
            openBrowse(p, 0);
            return;
        }
        if (l.seller().equals(p.getUniqueId().toString())) {
            plugin.getMessageUtil().send(p, "&cDu kannst dein eigenes Angebot nicht kaufen.");
            return;
        }
        if (!changeStatus(id, STATUS_ACTIVE, STATUS_SOLD)) {
            plugin.getMessageUtil().send(p, "&cDas hat gerade jemand anderes gekauft.");
            openBrowse(p, 0);
            return;
        }
        if (!eco.getManager().withdraw(p.getUniqueId(), l.price())) {
            changeStatus(id, STATUS_SOLD, STATUS_ACTIVE);
            plugin.getMessageUtil().send(p, "&cDu hast nicht genug Geld (&e$" + money(l.price()) + "&c).");
            return;
        }
        double tax = plugin.getConfig().getDouble("auction.tax-percent", 0.0);
        double payout = l.price() * (1.0 - Math.max(0, Math.min(100, tax)) / 100.0);
        UUID seller = UUID.fromString(l.seller());
        eco.getManager().deposit(seller, payout);
        give(p, l.item());
        p.playSound(p.getLocation(), "entity.experience_orb.pickup", 1f, 1.2f);
        plugin.getMessageUtil().send(p, "&aGekauft für &e$" + money(l.price()) + "&a!");
        Player sp = Bukkit.getPlayer(seller);
        if (sp != null && sp.isOnline()) {
            plugin.getMessageUtil().send(sp, "&a" + p.getName() + " hat dein Item im Auktionshaus gekauft: &e+$" + money(payout));
        }
        p.closeInventory();
    }
}
