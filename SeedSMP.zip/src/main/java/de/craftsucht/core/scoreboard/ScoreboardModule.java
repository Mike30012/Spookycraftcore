package de.craftsucht.core.scoreboard;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.rank.RankModule;
import de.craftsucht.core.jobs.JobsModule;
import de.craftsucht.core.jobs.PlayerData;
import de.craftsucht.core.module.Module;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Live sidebar scoreboard im Opsucht-artigen "»"-Bullet-Stil: Rang, Geld,
 * Server (aktuelle Multiverse-Welt). Synchronisiert außerdem pro Tick den
 * Rang-Prefix in Tabliste und Nametag über dem Kopf (per Scoreboard-Team),
 * damit ein neuer/angepasster Rang überall sofort sichtbar ist.
 */
public class ScoreboardModule implements Module {

    private final SpookyCraftCore plugin;
    private BukkitTask task;

    public ScoreboardModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "scoreboard";
    }

    @Override
    public void enable() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 20L, 40L);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        boards.clear();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            p.setPlayerListName(null);
        }
    }

    /** Erzwingt ein sofortiges Update (z.B. direkt nach Rang-Änderungen). */
    public void refreshNow() {
        updateAll();
    }

    /** Pro Spieler ein dauerhaftes Scoreboard - es werden nur geänderte Zeilen/Teams angefasst (spart TPS). */
    private static final class Board {
        final Scoreboard sb;
        final Objective obj;
        java.util.List<String> lines = new java.util.ArrayList<>();
        final Map<String, String> teamSig = new HashMap<>();
        final Map<String, String> teamNames = new HashMap<>();
        String tabName;

        Board(Scoreboard sb, Objective obj) {
            this.sb = sb;
            this.obj = obj;
        }
    }

    private final Map<java.util.UUID, Board> boards = new HashMap<>();

    private void updateAll() {
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        RankModule rankModule = (RankModule) plugin.getModuleManager().get("rank");
        JobsModule jobsModule = (JobsModule) plugin.getModuleManager().get("jobs");

        java.util.Collection<? extends Player> players = Bukkit.getOnlinePlayers();
        boards.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);

        Map<Player, String> prefixes = new HashMap<>();
        Map<Player, String> nameColorCodes = new HashMap<>();
        Map<Player, ChatColor> teamColors = new HashMap<>();
        final de.craftsucht.core.nickname.NicknameModule nickMod =
                plugin.getModuleManager().isEnabled("nickname")
                        && plugin.getModuleManager().get("nickname") instanceof de.craftsucht.core.nickname.NicknameModule nm ? nm : null;
        for (Player online : players) {
            prefixes.put(online, getRangPrefix(online, rankModule));
            nameColorCodes.put(online, getJobNameColorCode(online, jobsModule));
            teamColors.put(online, getLegacyTeamColor(online, jobsModule));
            if (rankModule != null && rankModule.getManager() != null && plugin.getModuleManager().isEnabled("rank")
                    && plugin.getConfig().getBoolean("rank.name-in-rank-color", true)) {
                String rc = rankModule.getManager().getNameColor(online.getUniqueId());
                if (!rc.isEmpty()) nameColorCodes.put(online, rc);
                ChatColor tc = rankModule.getManager().getNameTeamColor(online.getUniqueId());
                if (tc != null) teamColors.put(online, tc);
            }
        }

        for (Player p : players) {
            if (de.craftsucht.core.video.VideoModule.isActive(p)) continue;   // Video-Modus: Scoreboard bleibt aus
            Board b = boards.get(p.getUniqueId());
            if (b == null) {
                Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
                Objective obj = sb.registerNewObjective("bc", "dummy", "§a§lSeedSMP");
                obj.setDisplaySlot(DisplaySlot.SIDEBAR);
                // Blendet die Score-Zahl rechts neben jeder Zeile aus (Paper-API).
                obj.numberFormat(NumberFormat.blank());
                b = new Board(sb, obj);
                boards.put(p.getUniqueId(), b);
            }
            if (p.getScoreboard() != b.sb) p.setScoreboard(b.sb);

            String rang = prefixes.get(p);

            // --- Sidebar-Zeilen: nur neu schreiben, wenn sich etwas geändert hat
            java.util.List<String> newLines = new java.util.ArrayList<>();
            newLines.add("§8§m----------------");
            newLines.add("§8» §7Rang: " + (rang.isEmpty() ? "§7Spieler" : rang));
            if (economyModule != null) {
                double bal = economyModule.getManager().getBalance(p.getUniqueId());
                newLines.add("§8» §7Geld: §a$" + String.format(Locale.GERMANY, "%,.0f", bal));
            }
            if (plugin.getModuleManager().isEnabled("crates")
                    && plugin.getModuleManager().get("crates") instanceof de.craftsucht.core.crates.CratesModule cm && cm.getCrystals() != null) {
                newLines.add("§8» §7Kristalle: §b" + String.format(Locale.GERMANY, "%,d", cm.getCrystals().get(p.getUniqueId())));
            }
            newLines.add("§8» §7Online: §e" + onlineCount(p) + "§7/§e" + maxPlayers() + vanishNote(p));
            newLines.add("§8» §7Server: §b" + prettyWorldName(p.getWorld().getName()));
            newLines.add(" ");
            newLines.add("§8§m-----------------");
            if (!newLines.equals(b.lines)) {
                for (String old : b.lines) b.sb.resetScores(old);
                int line = 10;
                for (String l : newLines) b.obj.getScore(l).setScore(line--);
                b.lines = newLines;
            }

            // --- Teams (Nametag-Farbe/Prefix): ein Team pro Spieler, nur bei Änderung aktualisieren
            for (Player other : players) {
                String otherPrefix = prefixes.get(other);
                ChatColor otherTeamColor = teamColors.get(other);
                String otherNick = nickMod == null ? null : nickMod.getNick(other);
                String name = other.getName();
                // Tab-Sortierung: Der Client sortiert nach Teamname -> hoeheres Gewicht = kleinerer Praefix = weiter oben.
                String tn = String.format("%04d", 9999 - rankWeight(other, rankModule)) + name;
                String sig = otherPrefix + "|" + otherTeamColor + "|" + (otherNick != null) + "|" + tn;
                if (sig.equals(b.teamSig.get(name))) continue;
                String oldTn = b.teamNames.get(name);
                if (oldTn != null && !oldTn.equals(tn)) {
                    Team oldTeam = b.sb.getTeam(oldTn);
                    if (oldTeam != null) oldTeam.unregister();
                }
                Team team = b.sb.getTeam(tn);
                if (team == null) team = b.sb.registerNewTeam(tn);
                team.setPrefix(otherPrefix.isEmpty() ? "" : otherPrefix + "§r: ");
                // Team#setColor() kennt nur die 16 klassischen Farben (siehe getLegacyTeamColor).
                if (otherTeamColor != null) team.setColor(otherTeamColor);
                team.setAllowFriendlyFire(true);
                // Mit Nick: Vanilla-Nametag ausblenden, stattdessen zeigt ein TextDisplay den Nick.
                team.setOption(Team.Option.NAME_TAG_VISIBILITY,
                        otherNick != null ? Team.OptionStatus.NEVER : Team.OptionStatus.ALWAYS);
                if (!team.hasEntry(name)) team.addEntry(name);
                b.teamSig.put(name, sig);
                b.teamNames.put(name, tn);
            }
            // Teams von Spielern entfernen, die nicht mehr online sind
            final Scoreboard boardRef = b.sb;
            final Map<String, String> namesRef = b.teamNames;
            b.teamSig.keySet().removeIf(n -> {
                if (Bukkit.getPlayerExact(n) != null) return false;
                String tn2 = namesRef.remove(n);
                Team t = boardRef.getTeam(tn2 != null ? tn2 : n);
                if (t != null) t.unregister();
                return true;
            });

            // --- Tab-Name nur setzen, wenn er sich geändert hat
            String myColorCode = nameColorCodes.get(p);
            String myNick = nickMod == null ? null : nickMod.getNick(p);
            String shownName = myNick != null ? myNick : p.getName();
            String tab = (rang.isEmpty() ? "" : rang + "§r: ") + (myColorCode != null ? myColorCode : "") + shownName;
            if (nickMod != null) {
                nickMod.updateTag(p, myNick == null ? null
                        : (rang.isEmpty() ? "" : rang + "§r: ") + (myColorCode != null ? myColorCode : "§f") + myNick);
            }
            if (!tab.equals(b.tabName)) {
                p.setPlayerListName(tab);
                b.tabName = tab;
            }
        }
    }

    /** Maximale Spielerzahl fürs Scoreboard: scoreboard.max-players aus der config.yml (0 = Wert aus server.properties). */
    private int maxPlayers() {
        int cfg = plugin.getConfig().getInt("scoreboard.max-players", 10);
        return cfg > 0 ? cfg : Bukkit.getMaxPlayers();
    }

    /** Team sieht zusätzlich, wie viele gerade vanisht sind. */
    private String vanishNote(Player viewer) {
        if (plugin.getModuleManager().get("vanish") instanceof de.craftsucht.core.vanish.VanishModule vm
                && de.craftsucht.core.vanish.VanishModule.isStaff(viewer)) {
            int v = vm.vanishedCount();
            if (v > 0) return " §8(+" + v + " vanish)";
        }
        return "";
    }

    /** Spielerzahl aus Sicht von p - Vanish-Spieler werden für normale Spieler nicht mitgezählt. */
    private int onlineCount(Player viewer) {
        if (plugin.getModuleManager().get("vanish") instanceof de.craftsucht.core.vanish.VanishModule vm) {
            return vm.visibleCount(viewer);
        }
        return Bukkit.getOnlinePlayers().size();
    }

    /** Rang-Prefix aus dem eigenen Rang-System, sonst Fallback. */
    /** Gewicht des Rangs (hoeher = weiter oben im Tab); OP ohne Rang zaehlt als sehr hoch. */
    private int rankWeight(Player p, RankModule rankModule) {
        int w = p.isOp() ? 1000 : 0;
        if (rankModule != null && rankModule.getManager() != null && plugin.getModuleManager().isEnabled("rank")) {
            var mgr = rankModule.getManager();
            var data = mgr.getRank(mgr.getUserRank(p.getUniqueId()));
            if (data != null) w = data.weight();
        }
        return Math.max(0, Math.min(9999, w));
    }

    private String getRangPrefix(Player p, RankModule rankModule) {
        if (rankModule != null && rankModule.getManager() != null && plugin.getModuleManager().isEnabled("rank")) {
            String prefix = rankModule.getManager().getColoredPrefix(p.getUniqueId());
            if (!prefix.isEmpty()) {
                return prefix;
            }
        }
        return p.isOp() ? "§4§lOwner" : "";
    }

    /** Erster Buchstabe groß, Unterstriche zu Leerzeichen - aus "world_nether" wird "World Nether". */
    private String prettyWorldName(String raw) {
        String[] parts = raw.replace('_', ' ').split(" ");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    /**
     * Fertige Farbcode-Sequenz für Chat/Tabliste - Farbe des höchsten
     * erreichten Job-Titels. Leerer String = keine (kein Jobs-Modul, kein
     * Job, noch kein Titel-Level erreicht).
     */
    private String getJobNameColorCode(Player p, JobsModule jobsModule) {
        if (jobsModule == null) return "";
        PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return "";
        ChatColor color = jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
        return color != null ? color.toString() : "";
    }

    /** Nametag-Farbe (Scoreboard-Team) - dieselbe Job-Tier-Farbe, immer eine legacy ChatColor. */
    private ChatColor getLegacyTeamColor(Player p, JobsModule jobsModule) {
        if (jobsModule == null) return null;
        PlayerData data = jobsModule.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasJob()) return null;
        return jobsModule.getRewardManager().getTierColor(data.getCurrentJob(), data.getJobLevel());
    }
}
