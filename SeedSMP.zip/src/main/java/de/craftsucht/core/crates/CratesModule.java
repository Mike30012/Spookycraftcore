package de.craftsucht.core.crates;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.booster.BoosterModule;
import de.craftsucht.core.booster.ItemTemplate;
import de.craftsucht.core.economy.EconomyModule;
import de.craftsucht.core.module.Module;
import de.craftsucht.core.scoreboard.ScoreboardModule;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.Particle;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Kristalle + Kisten (Crates) wie auf OPSUCHT: Kisten stehen im Spawn, Rechtsklick öffnet sie für Kristalle,
 * Linksklick zeigt die Vorschau mit Gewinnchancen. Alles ingame per /crate verwaltbar, gespeichert in crates.yml.
 */
public class CratesModule implements Module, CommandExecutor, TabCompleter, Listener {

    // ------------------------------------------------------------------ Datenmodell

    /** type: item | money | crystals | citem | command */
    public record Reward(String type, int weight, ItemStack stack, double number, String text) {
    }

    public static class Crate {
        String id;
        String name;
        long price;
        int model; // custom_model_data des schwebenden Kisten-Modells (0 = keins)
        final List<Reward> rewards = new ArrayList<>();

        Crate(String id, String name, long price) {
            this.id = id;
            this.name = name;
            this.price = price;
        }

        int totalWeight() {
            int sum = 0;
            for (Reward r : rewards) sum += Math.max(0, r.weight());
            return sum;
        }
    }

    private enum HolderType { ROLL, PREVIEW }

    private static class CrateHolder implements InventoryHolder {
        final HolderType type;
        Inventory inventory;

        CrateHolder(HolderType type) {
            this.type = type;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static class Roll {
        Player player;
        Crate crate;
        Reward winner;
        List<Reward> sequence = new ArrayList<>();
        Inventory inventory;
        int step;
        BukkitTask task;
        boolean done;
        boolean usedKey;
    }

    private static final int SEQUENCE = 34;

    // ------------------------------------------------------------------ Zustand

    private final SpookyCraftCore plugin;
    private CrystalManager crystals;
    private File file;
    private YamlConfiguration data;
    private final Map<String, Crate> crates = new LinkedHashMap<>();
    /** "welt;x;y;z" -> Kisten-ID */
    private final Map<String, String> locations = new HashMap<>();
    private final Map<String, UUID> holograms = new HashMap<>();
    private final Map<UUID, Roll> rolls = new HashMap<>();
    private BukkitTask hologramTask;
    private final Map<String, UUID> itemDisplays = new HashMap<>();
    private double spinAngle;

    public CratesModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "crates";
    }

    public CrystalManager getCrystals() {
        return crystals;
    }

    // ------------------------------------------------------------------ Kisten-Schlüssel (z.B. 1 Vote-Kiste pro Vote)

    private File keysFile;
    private YamlConfiguration keysData;

    private void loadKeys() {
        keysFile = new File(plugin.getDataFolder(), "crate-keys.yml");
        keysData = YamlConfiguration.loadConfiguration(keysFile);
    }

    private void saveKeys() {
        try {
            plugin.getDataFolder().mkdirs();
            keysData.save(keysFile);
        } catch (IOException e) {
            plugin.getLogger().warning("crate-keys.yml speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    public int getKeys(UUID id, String crateId) {
        return keysData == null ? 0 : keysData.getInt(id + "." + crateId.toLowerCase(), 0);
    }

    /** Schenkt einem Spieler Kisten (Schlüssel): Rechtsklick auf den Kisten-Block öffnet sie ohne Kristalle. */
    public void addKeys(UUID id, String crateId, int amount) {
        if (keysData == null || amount == 0) return;
        String path = id + "." + crateId.toLowerCase();
        keysData.set(path, Math.max(0, keysData.getInt(path, 0) + amount));
        saveKeys();
    }

    private boolean takeKey(UUID id, String crateId) {
        if (getKeys(id, crateId) <= 0) return false;
        addKeys(id, crateId, -1);
        return true;
    }

    /** Preis einer Kiste in Kristallen, -1 wenn es die Kiste nicht gibt. */
    public long getCratePrice(String id) {
        Crate crate = crates.get(id.toLowerCase());
        return crate == null ? -1 : crate.price;
    }

    private String c(String s) {
        return plugin.getMessageUtil().color(s);
    }

    private void msg(CommandSender s, String text) {
        plugin.getMessageUtil().send(s, text);
    }

    // ------------------------------------------------------------------ Start / Stop

    @Override
    public void enable() {
        this.crystals = new CrystalManager(plugin);
        loadKeys();
        load();
        for (String name : new String[]{"kristalle", "crate"}) {
            if (plugin.getCommand(name) != null) {
                plugin.getCommand(name).setExecutor(this);
                plugin.getCommand(name).setTabCompleter(this);
            }
        }
        Bukkit.getPluginManager().registerEvents(this, plugin);
        hologramTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 20L);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (hologramTask != null) hologramTask.cancel();
        for (Roll roll : new ArrayList<>(rolls.values())) finish(roll);
        removeHolograms();
        save();
    }

    // ------------------------------------------------------------------ Laden / Speichern

    private void load() {
        file = new File(plugin.getDataFolder(), "crates.yml");
        crates.clear();
        locations.clear();
        if (!file.exists()) {
            seedDefaults();
            save();
        }
        data = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = data.getConfigurationSection("crates");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection cs = section.getConfigurationSection(id);
                if (cs == null) continue;
                Crate crate = new Crate(id, cs.getString("name", "&f" + id), cs.getLong("price", 100));
                crate.model = cs.getInt("model", 0);
                for (Map<?, ?> map : cs.getMapList("rewards")) {
                    Reward r = parseReward(map);
                    if (r != null) crate.rewards.add(r);
                }
                crates.put(id, crate);
            }
        }
        ConfigurationSection locs = data.getConfigurationSection("locations");
        if (locs != null) {
            for (String key : locs.getKeys(false)) {
                locations.put(key.replace('|', ';'), locs.getString(key));
            }
        }
        migration = data.getInt("migration", 0);
        if (migration < 2) {
            migrateV2();
            migration = 2;
            save();
        }
    }

    private int migration;

    /** Einmalig: Perk-Kiste löschen und mehr Gewinne in die anderen Kisten (danach alles wie gewohnt per /crate änderbar). */
    private void migrateV2() {
        Crate perk = crates.remove("perk");
        if (perk != null) {
            for (Iterator<Map.Entry<String, String>> it = locations.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<String, String> e = it.next();
                if (!"perk".equals(e.getValue())) continue;
                Location loc = blockLocation(e.getKey());
                if (loc != null && loc.getBlock().getType() == Material.BARRIER) loc.getBlock().setType(Material.AIR, false);
                it.remove();
            }
        }
        Crate c = crates.get("classic");
        if (c != null) {
            c.rewards.add(citem("bohrer_2x2", 4));
            c.rewards.add(citem("holzfaeller_axt_1", 2));
            c.rewards.add(money(5000, 6));
            c.rewards.add(crystalsReward(40, 2));
            c.rewards.add(new Reward("command", 8, null, 0, "give %player% experience_bottle 32"));
        }
        c = crates.get("normal");
        if (c != null) {
            c.rewards.add(citem("bohrer_4x4", 4));
            c.rewards.add(citem("holzfaeller_axt_2", 3));
            c.rewards.add(citem("frost_klinge", 1));
            c.rewards.add(money(100000, 2));
            c.rewards.add(crystalsReward(300, 3));
            c.rewards.add(new Reward("command", 10, null, 0, "give %player% golden_apple 8"));
        }
        c = crates.get("spooky");
        if (c != null) {
            c.rewards.add(citem("holzfaeller_axt_3", 4));
            c.rewards.add(citem("bohrer_8x8", 5));
            c.rewards.add(citem("geisterklinge", 3));
            c.rewards.add(citem("inferno_klinge", 3));
            c.rewards.add(citem("frost_klinge", 3));
            c.rewards.add(citem("schatten_klinge", 3));
            c.rewards.add(citem("koenigsklinge", 2));
            c.rewards.add(citem("speedschuhe", 4));
            c.rewards.add(citem("flugschuhe", 4));
            c.rewards.add(money(500000, 5));
            c.rewards.add(crystalsReward(4000, 2));
        }
        c = crates.get("vote");
        if (c != null) {
            c.rewards.add(citem("bohrer_2x2", 2));
            c.rewards.add(money(3000, 8));
            c.rewards.add(crystalsReward(25, 5));
            c.rewards.add(new Reward("command", 6, null, 0, "give %player% experience_bottle 16"));
        }
        plugin.getLogger().info("Kisten: Perk-Kiste entfernt und neue Gewinne hinzugefügt (einmalig).");
    }

    private Reward parseReward(Map<?, ?> map) {
        Object type = map.get("type");
        if (type == null) return null;
        int weight = map.get("weight") instanceof Number n ? n.intValue() : 1;
        ItemStack stack = map.get("stack") instanceof ItemStack is ? is : null;
        double number = map.get("value") instanceof Number n ? n.doubleValue() : 0;
        String text = map.get("text") != null ? String.valueOf(map.get("text")) : "";
        return new Reward(String.valueOf(type), weight, stack, number, text);
    }

    private void save() {
        YamlConfiguration out = new YamlConfiguration();
        for (Crate crate : crates.values()) {
            String base = "crates." + crate.id;
            out.set(base + ".name", crate.name);
            out.set(base + ".price", crate.price);
            out.set(base + ".model", crate.model);
            List<Map<String, Object>> list = new ArrayList<>();
            for (Reward r : crate.rewards) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("type", r.type());
                m.put("weight", r.weight());
                if (r.stack() != null) m.put("stack", r.stack());
                if (r.number() != 0) m.put("value", r.number());
                if (!r.text().isEmpty()) m.put("text", r.text());
                list.add(m);
            }
            out.set(base + ".rewards", list);
        }
        out.set("migration", migration);
        for (Map.Entry<String, String> e : locations.entrySet()) {
            out.set("locations." + e.getKey().replace(';', '|'), e.getValue());
        }
        try {
            plugin.getDataFolder().mkdirs();
            out.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("crates.yml speichern fehlgeschlagen: " + e.getMessage());
        }
    }

    private static Reward item(Material m, int amount, int weight) {
        return new Reward("item", weight, new ItemStack(m, amount), 0, "");
    }

    private static Reward money(double amount, int weight) {
        return new Reward("money", weight, null, amount, "");
    }

    private static Reward crystalsReward(long amount, int weight) {
        return new Reward("crystals", weight, null, amount, "");
    }

    private static Reward citem(String id, int weight) {
        return new Reward("citem", weight, null, 0, id);
    }

    /** Startwerte (Platzhalter nach OPSUCHT-Vorbild) - alles ingame mit /crate änderbar. */
    private void seedDefaults() {
        Crate classic = new Crate("classic", "&a&lClassic Kiste", 295);
        classic.rewards.add(item(Material.IRON_INGOT, 32, 30));
        classic.rewards.add(item(Material.GOLD_INGOT, 16, 20));
        classic.rewards.add(item(Material.REDSTONE, 64, 15));
        classic.rewards.add(item(Material.LAPIS_LAZULI, 32, 10));
        classic.rewards.add(item(Material.DIAMOND, 4, 10));
        classic.rewards.add(item(Material.EMERALD, 8, 8));
        classic.rewards.add(money(2500, 10));
        classic.rewards.add(money(10000, 3));
        classic.rewards.add(crystalsReward(20, 3));
        classic.rewards.add(citem("bohrer_3x3", 2));
        classic.model = 1;
        crates.put(classic.id, classic);

        Crate normal = new Crate("normal", "&6&lNormale Kiste", 1000);
        normal.rewards.add(item(Material.DIAMOND, 16, 25));
        normal.rewards.add(item(Material.EMERALD, 32, 15));
        normal.rewards.add(item(Material.NETHERITE_SCRAP, 4, 10));
        normal.rewards.add(item(Material.GOLD_BLOCK, 16, 10));
        normal.rewards.add(money(10000, 20));
        normal.rewards.add(money(40000, 5));
        normal.rewards.add(crystalsReward(150, 5));
        normal.rewards.add(citem("bohrer_5x5", 4));
        normal.rewards.add(citem("speedschuhe", 3));
        normal.rewards.add(citem("flugschuhe", 3));
        normal.model = 2;
        crates.put(normal.id, normal);

        Crate perk = new Crate("perk", "&d&lPerk Kiste", 4000);
        perk.rewards.add(item(Material.NETHERITE_INGOT, 2, 15));
        perk.rewards.add(item(Material.ENCHANTED_GOLDEN_APPLE, 4, 15));
        perk.rewards.add(item(Material.BEACON, 1, 5));
        perk.rewards.add(money(50000, 20));
        perk.rewards.add(money(150000, 5));
        perk.rewards.add(crystalsReward(600, 8));
        perk.rewards.add(citem("bohrer_7x7", 6));
        perk.rewards.add(citem("mining_pistole", 5));
        perk.rewards.add(citem("erz_wandler", 5));
        perk.rewards.add(citem("bedrock_brecher", 4));
        perk.rewards.add(citem("flugschuhe", 6));
        perk.model = 3;
        crates.put(perk.id, perk);

        Crate op = new Crate("spooky", "&5&lGeister Kiste", 2000);
        op.rewards.add(item(Material.NETHERITE_INGOT, 8, 25));
        op.rewards.add(item(Material.NETHER_STAR, 4, 16));
        op.rewards.add(money(250000, 20));
        op.rewards.add(crystalsReward(1500, 10));
        op.rewards.add(citem("mining_pistole", 10));
        op.rewards.add(citem("bohrer_10x10", 4));
        op.rewards.add(citem("bedrock_schwert", 3));
        op.rewards.add(citem("bedrock_helm", 3));
        op.rewards.add(citem("bedrock_brustplatte", 3));
        op.rewards.add(citem("bedrock_beinschutz", 3));
        op.rewards.add(citem("bedrock_stiefel", 3));
        op.model = 4;
        crates.put(op.id, op);

        // Vote-Kiste: wird NUR mit Kristallen geöffnet (wie alle Kisten) - Kristalle gibt es z.B. als Vote-Belohnung per /kristalle give
        Crate vote = new Crate("vote", "&b&lVote Kiste", 100);
        vote.rewards.add(item(Material.COAL, 64, 25));
        vote.rewards.add(item(Material.IRON_INGOT, 24, 25));
        vote.rewards.add(item(Material.GOLD_INGOT, 12, 15));
        vote.rewards.add(item(Material.DIAMOND, 2, 8));
        vote.rewards.add(money(1500, 15));
        vote.rewards.add(money(7500, 4));
        vote.rewards.add(crystalsReward(50, 3));
        vote.rewards.add(citem("bohrer_3x3", 1));
        vote.model = 5;
        crates.put(vote.id, vote);
    }

    // ------------------------------------------------------------------ Belohnungen

    private ItemStack citemStack(String id) {
        if (plugin.getModuleManager().get("booster") instanceof BoosterModule booster && booster.getItemRegistry() != null) {
            ItemTemplate template = booster.getItemRegistry().getTemplate(id);
            if (template != null) return booster.getItemRegistry().build(template);
        }
        return null;
    }

    private String format(double v) {
        return String.format(Locale.GERMANY, "%,.0f", v);
    }

    /** Anzeige-Item einer Belohnung (für Vorschau und Animation). */
    private ItemStack display(Reward r) {
        ItemStack stack;
        switch (r.type()) {
            case "item" -> stack = r.stack() != null ? r.stack().clone() : new ItemStack(Material.BARRIER);
            case "citem" -> {
                ItemStack built = citemStack(r.text());
                stack = built != null ? built : named(Material.BARRIER, "&cUnbekanntes Item: " + r.text());
            }
            case "money" -> stack = named(Material.GOLD_INGOT, "&6$" + format(r.number()));
            case "crystals" -> stack = named(Material.AMETHYST_SHARD, "&b" + format(r.number()) + " Kristalle");
            default -> stack = named(Material.PAPER, "&f" + (r.text().length() > 24 ? r.text().substring(0, 24) : r.text()));
        }
        return stack;
    }

    private ItemStack named(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(c(name));
        stack.setItemMeta(meta);
        return stack;
    }

    private String rewardName(Reward r) {
        ItemStack d = display(r);
        ItemMeta meta = d.getItemMeta();
        String base = meta != null && meta.hasDisplayName() ? meta.getDisplayName()
                : d.getType().name().toLowerCase().replace('_', ' ');
        return (r.type().equals("item") && d.getAmount() > 1 ? d.getAmount() + "x " : "") + base;
    }

    private boolean grant(Player player, Reward r) {
        switch (r.type()) {
            case "item", "citem" -> {
                ItemStack stack = r.type().equals("item") ? (r.stack() == null ? null : r.stack().clone()) : citemStack(r.text());
                if (stack == null) return false;
                for (ItemStack left : player.getInventory().addItem(stack).values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), left);
                }
            }
            case "money" -> {
                if (!(plugin.getModuleManager().get("economy") instanceof EconomyModule eco) || eco.getManager() == null) return false;
                eco.getManager().deposit(player.getUniqueId(), r.number());
            }
            case "crystals" -> crystals.add(player.getUniqueId(), (long) r.number());
            case "command" -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), r.text().replace("%player%", player.getName()));
            default -> {
                return false;
            }
        }
        return true;
    }

    private Reward pick(Crate crate) {
        int total = crate.totalWeight();
        if (total <= 0) return null;
        int roll = ThreadLocalRandom.current().nextInt(total);
        for (Reward r : crate.rewards) {
            roll -= Math.max(0, r.weight());
            if (roll < 0) return r;
        }
        return crate.rewards.get(crate.rewards.size() - 1);
    }

    private String chance(Crate crate, Reward r) {
        int total = crate.totalWeight();
        return total <= 0 ? "0" : String.format(Locale.GERMANY, "%.2f", 100.0 * r.weight() / total);
    }

    // ------------------------------------------------------------------ Öffnen mit Animation

    private void open(Player player, Crate crate) {
        if (rolls.containsKey(player.getUniqueId())) return;
        if (crate.rewards.isEmpty()) {
            msg(player, "&cIn dieser Kiste ist noch nichts drin.");
            return;
        }
        boolean usedKey = takeKey(player.getUniqueId(), crate.id);
        if (!usedKey && !crystals.take(player.getUniqueId(), crate.price)) {
            msg(player, "&cDir fehlen &b" + format(crate.price - crystals.get(player.getUniqueId())) + " Kristalle &cfür diese Kiste &7(oder ein Schlüssel, z.B. durch Voten)&c.");
            return;
        }
        if (usedKey) msg(player, "&7Du nutzt &b1 " + c(crate.name) + " &7(Schlüssel). Übrig: &b" + getKeys(player.getUniqueId(), crate.id));
        refreshScoreboard();

        Roll roll = new Roll();
        roll.usedKey = usedKey;
        roll.player = player;
        roll.crate = crate;
        roll.winner = pick(crate);
        for (int i = 0; i < SEQUENCE; i++) roll.sequence.add(pick(crate));
        roll.sequence.set(SEQUENCE - 5, roll.winner);

        CrateHolder holder = new CrateHolder(HolderType.ROLL);
        roll.inventory = Bukkit.createInventory(holder, 27, c(crate.name));
        holder.inventory = roll.inventory;
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        ItemStack pointer = named(Material.LIME_STAINED_GLASS_PANE, "&a&l▼ Gewinn ▼");
        for (int i = 0; i < 27; i++) roll.inventory.setItem(i, filler);
        roll.inventory.setItem(4, pointer);
        roll.inventory.setItem(22, named(Material.LIME_STAINED_GLASS_PANE, "&a&l▲ Gewinn ▲"));
        show(roll);
        rolls.put(player.getUniqueId(), roll);
        player.openInventory(roll.inventory);
        player.playSound(player.getLocation(), "block.chest.open", 1f, 1f);
        scheduleStep(roll);
    }

    private void show(Roll roll) {
        for (int i = 0; i < 9; i++) {
            roll.inventory.setItem(9 + i, display(roll.sequence.get(roll.step + i)));
        }
    }

    private void scheduleStep(Roll roll) {
        long delay = 1 + roll.step / 6;
        roll.task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (roll.done) return;
            if (roll.step >= SEQUENCE - 9) {
                finish(roll);
                return;
            }
            roll.step++;
            show(roll);
            roll.player.playSound(roll.player.getLocation(), "ui.button.click", 0.6f, 1.2f);
            scheduleStep(roll);
        }, delay);
    }

    private void finish(Roll roll) {
        if (roll.done) return;
        roll.done = true;
        if (roll.task != null) roll.task.cancel();
        rolls.remove(roll.player.getUniqueId());
        Player player = roll.player;
        Reward r = roll.winner;
        if (!grant(player, r)) {
            // Belohnung nicht möglich (z.B. gelöschtes Item): Kristalle zurück
            if (roll.usedKey) addKeys(player.getUniqueId(), roll.crate.id, 1);
            else crystals.add(player.getUniqueId(), roll.crate.price);
            msg(player, "&cDiese Belohnung ist gerade nicht verfügbar - du hast " + (roll.usedKey ? "deine Kiste" : "deine Kristalle") + " zurück.");
            refreshScoreboard();
            return;
        }
        roll.inventory.setItem(13, display(r));
        player.playSound(player.getLocation(), "entity.player.levelup", 1f, 1.2f);
        msg(player, "&aDu hast gewonnen: &f" + rewardName(r) + " &7(" + chance(roll.crate, r) + " %)");
        double threshold = plugin.getConfig().getDouble("crates.broadcast-below-percent", 3.0);
        double percent = 100.0 * r.weight() / Math.max(1, roll.crate.totalWeight());
        if (percent < threshold) {
            Bukkit.broadcastMessage(c("&8[&bKiste&8] &f" + player.getName() + " &7hat in der " + roll.crate.name + " &7gewonnen: &f"
                    + rewardName(r) + " &8(" + chance(roll.crate, r) + " %)"));
        }
        refreshScoreboard();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && player.getOpenInventory().getTopInventory() == roll.inventory) player.closeInventory();
        }, 30L);
    }

    private void preview(Player player, Crate crate) {
        CrateHolder holder = new CrateHolder(HolderType.PREVIEW);
        Inventory inv = Bukkit.createInventory(holder, 54, c(crate.name + " &8Vorschau"));
        holder.inventory = inv;
        List<Reward> sorted = new ArrayList<>(crate.rewards);
        sorted.sort(Comparator.comparingInt(Reward::weight).reversed());
        int slot = 0;
        for (Reward r : sorted) {
            if (slot >= 45) break;
            ItemStack stack = display(r);
            ItemMeta meta = stack.getItemMeta();
            List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
            lore.add("");
            lore.add(c("&7Chance: &e" + chance(crate, r) + " %"));
            meta.setLore(lore);
            stack.setItemMeta(meta);
            inv.setItem(slot++, stack);
        }
        inv.setItem(49, named(Material.AMETHYST_SHARD, "&b" + format(crate.price) + " Kristalle &7pro Öffnung"));
        player.openInventory(inv);
    }

    // ------------------------------------------------------------------ Hologramme

    private Location blockLocation(String key) {
        String[] p = key.split(";");
        if (p.length != 4) return null;
        org.bukkit.World world = Bukkit.getWorld(p[0]);
        if (world == null) return null;
        try {
            return new Location(world, Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String key(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    private int tickCounter;

    /** Jede Sekunde: Hologramme/Modelle bei Bedarf neu erzeugen, Kiste weiterdrehen, Partikel. */
    private void tick() {
        if (tickCounter++ % 5 == 0) refreshHolograms();
        spinAngle += Math.toRadians(90);
        float scale = (float) modelScale();
        float angle = isInsideMode() ? 0f : (float) spinAngle;
        for (Map.Entry<String, UUID> e : itemDisplays.entrySet()) {
            if (!(Bukkit.getEntity(e.getValue()) instanceof ItemDisplay id) || !id.isValid()) continue;
            id.setInterpolationDelay(0);
            id.setInterpolationDuration(20);
            id.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(angle, 0, 1, 0),
                    new Vector3f(scale, scale, scale), new AxisAngle4f()));
            Location at = id.getLocation();
            at.getWorld().spawnParticle(Particle.END_ROD, at.clone().add(0, isInsideMode() ? 0.8 : 0.2, 0), 2, 0.35, 0.3, 0.35, 0.01);
        }
    }

    /** "inside" = Modell sitzt direkt im Kisten-Block (ersetzt die Truhe optisch), "float" = schwebt drehend darüber. */
    private boolean isInsideMode() {
        return "inside".equalsIgnoreCase(plugin.getConfig().getString("crates.model-mode", "inside"));
    }

    private double modelHeight() {
        return isInsideMode() ? 0.5 : plugin.getConfig().getDouble("crates.model-height", 1.75);
    }

    private double modelScale() {
        return isInsideMode() ? plugin.getConfig().getDouble("crates.model-scale-inside", 1.0)
                : plugin.getConfig().getDouble("crates.model-scale", 0.85);
    }

    private void refreshHolograms() {
        for (Map.Entry<String, String> e : locations.entrySet()) {
            Location loc = blockLocation(e.getKey());
            Crate crate = crates.get(e.getValue());
            if (loc == null || crate == null) continue;
            if (!loc.getWorld().isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) continue;
            // Bedrock (Geyser/Floodgate, Name beginnt mit "."): kein Resource-Pack -> stattdessen echte Truhe nur fuer diese Spieler anzeigen
            for (Player bp : loc.getWorld().getPlayers()) {
                if (!bp.getName().startsWith(".")) continue;
                if (bp.getLocation().distanceSquared(loc) > 48 * 48) continue;
                bp.sendBlockChange(loc, Material.ENDER_CHEST.createBlockData());
            }
            double textHeight = crate.model > 0 ? (isInsideMode() ? 1.75 : modelHeight() + 0.95) : 1.7;

            UUID existing = holograms.get(e.getKey());
            if (existing == null || !(Bukkit.getEntity(existing) instanceof TextDisplay td0) || !td0.isValid()) {
                Location at = loc.clone().add(0.5, textHeight, 0.5);
                TextDisplay display = loc.getWorld().spawn(at, TextDisplay.class, td -> {
                    td.text(LegacyComponentSerializer.legacySection().deserialize(
                            c(crate.name + "\n&7Preis: &b" + format(crate.price) + " Kristalle\n&8Rechtsklick: öffnen\n&8Linksklick: Vorschau")));
                    td.setBillboard(Display.Billboard.CENTER);
                    td.setLineWidth(400);
                    td.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(),
                            new Vector3f(0.8f, 0.8f, 0.8f), new AxisAngle4f()));
                    td.setPersistent(false);
                });
                holograms.put(e.getKey(), display.getUniqueId());
            }

            if (crate.model > 0) {
                UUID model = itemDisplays.get(e.getKey());
                if (model == null || !(Bukkit.getEntity(model) instanceof ItemDisplay id0) || !id0.isValid()) {
                    ItemStack stack = new ItemStack(Material.NETHER_STAR);
                    ItemMeta meta = stack.getItemMeta();
                    meta.setCustomModelData(crate.model);
                    stack.setItemMeta(meta);
                    Location at = loc.clone().add(0.5, modelHeight(), 0.5);
                    ItemDisplay display = loc.getWorld().spawn(at, ItemDisplay.class, id -> {
                        id.setItemStack(stack);
                        id.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                        id.setBillboard(Display.Billboard.FIXED);
                        id.setPersistent(false);
                    });
                    itemDisplays.put(e.getKey(), display.getUniqueId());
                }
            }
        }
    }

    private void removeHolograms() {
        for (UUID id : holograms.values()) {
            org.bukkit.entity.Entity entity = Bukkit.getEntity(id);
            if (entity != null) entity.remove();
        }
        holograms.clear();
        for (UUID id : itemDisplays.values()) {
            org.bukkit.entity.Entity entity = Bukkit.getEntity(id);
            if (entity != null) entity.remove();
        }
        itemDisplays.clear();
    }

    private void rebuildHolograms() {
        removeHolograms();
        refreshHolograms();
    }

    private void refreshScoreboard() {
        if (plugin.getModuleManager().get("scoreboard") instanceof ScoreboardModule sb) sb.refreshNow();
    }

    // ------------------------------------------------------------------ Events

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getClickedBlock() == null) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.LEFT_CLICK_BLOCK) return;
        String crateId = locations.get(key(event.getClickedBlock()));
        if (crateId == null) return;
        Crate crate = crates.get(crateId);
        if (crate == null) return;
        event.setCancelled(true);
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) open(event.getPlayer(), crate);
        else preview(event.getPlayer(), crate);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof CrateHolder) event.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof CrateHolder) event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof CrateHolder holder) || holder.type != HolderType.ROLL) return;
        Roll roll = rolls.get(event.getPlayer().getUniqueId());
        if (roll != null && roll.inventory == event.getInventory() && !roll.done) {
            // ESC ueberspringt die Animation nicht: Kiste wieder oeffnen, bis der Gewinn feststeht.
            Player pl = roll.player;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!roll.done && pl.isOnline() && rolls.get(pl.getUniqueId()) == roll
                        && pl.getOpenInventory().getTopInventory() != roll.inventory) {
                    pl.openInventory(roll.inventory);
                }
            });
        }
    }

    /** Schickt das Kisten-Resource-Pack beim Join (config crates.resource-pack.url / sha1). */
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        String url = plugin.getConfig().getString("crates.resource-pack.url", "");
        if (url == null || url.isBlank()) return;
        String sha1 = plugin.getConfig().getString("crates.resource-pack.sha1", "");
        boolean force = plugin.getConfig().getBoolean("crates.resource-pack.force", false);
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            byte[] hash = null;
            if (sha1 != null && sha1.length() == 40) {
                try {
                    hash = new byte[20];
                    for (int i = 0; i < 20; i++) hash[i] = (byte) Integer.parseInt(sha1.substring(i * 2, i * 2 + 2), 16);
                } catch (NumberFormatException e) {
                    hash = null;
                }
            }
            player.setResourcePack(url, hash, LegacyComponentSerializer.legacySection().deserialize(
                    c("&6SeedSMP &7Kisten-Pack für schönere Kisten")), force);
        }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Roll roll = rolls.get(event.getPlayer().getUniqueId());
        if (roll != null) finish(roll);
        crystals.forget(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Job-Level-Belohnung

    /** Wird beim Job-Level-Up aufgerufen: alle X Level gibt es Kristalle (config crates.job-level-every / job-level-crystals). */
    public void onJobLevel(Player player, int level) {
        int every = plugin.getConfig().getInt("crates.job-level-every", 10);
        long amount = plugin.getConfig().getLong("crates.job-level-crystals", 20);
        if (every <= 0 || amount <= 0 || level % every != 0) return;
        crystals.add(player.getUniqueId(), amount);
        msg(player, "&b+" + amount + " Kristalle &7für Job-Level " + level + "!");
        refreshScoreboard();
    }

    // ------------------------------------------------------------------ Befehle

    /** Rang owner/admin im eigenen Rank-System. */
    private boolean isRankStaff(CommandSender s) {
        if (!(s instanceof Player p)) return false;
        if (!(plugin.getModuleManager().get("rank") instanceof de.craftsucht.core.rank.RankModule rm) || rm.getManager() == null) return false;
        String r = rm.getManager().getUserRank(p.getUniqueId());
        return r != null && (r.equalsIgnoreCase("owner") || r.equalsIgnoreCase("admin"));
    }

    private boolean isAdmin(CommandSender s) {
        return s.isOp() || s.hasPermission("spookycraft.crates.admin") || s.hasPermission("spookycraft.core.admin");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("kristalle")) return handleCrystals(sender, args);
        return handleCrate(sender, args);
    }

    private boolean handleCrystals(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                msg(sender, "&cNutzung: /kristalle <give|take|set> <spieler> <anzahl>");
                return true;
            }
            msg(p, "&7Du hast &b" + format(crystals.get(p.getUniqueId())) + " Kristalle&7.");
            StringBuilder keyText = new StringBuilder();
            for (Crate cr : crates.values()) {
                int k = getKeys(p.getUniqueId(), cr.id);
                if (k > 0) keyText.append(keyText.length() > 0 ? "&7, " : "").append(cr.name).append(" &fx").append(k);
            }
            if (keyText.length() > 0) msg(p, "&7Deine Kisten (zum Öffnen am Kisten-Block): " + keyText);
            return true;
        }
        String sub = args[0].toLowerCase();
        if (!List.of("give", "take", "set").contains(sub)) {
            OfflinePlayer other = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (other == null) {
                msg(sender, "&cDie Geister kennen diesen Spieler nicht.");
                return true;
            }
            msg(sender, "&f" + args[0] + " &7hat &b" + format(crystals.get(other.getUniqueId())) + " Kristalle&7.");
            return true;
        }
        if (!isAdmin(sender) && !isRankStaff(sender)) {
            msg(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        if (args.length < 3) {
            msg(sender, "&cNutzung: /kristalle " + sub + " <spieler|*> <anzahl>");
            return true;
        }
        if (args[1].equals("*")) {
            long amt;
            try {
                amt = Long.parseLong(args[2]);
            } catch (NumberFormatException e) {
                msg(sender, "&cDas ist keine gültige Zahl, Sterblicher.");
                return true;
            }
            if (amt < 0) {
                msg(sender, "&cDie Anzahl darf nicht negativ sein.");
                return true;
            }
            int n = 0;
            for (Player o : Bukkit.getOnlinePlayers()) {
                UUID oid = o.getUniqueId();
                switch (sub) {
                    case "give" -> crystals.add(oid, amt);
                    case "take" -> crystals.set(oid, Math.max(0, crystals.get(oid) - amt));
                    default -> crystals.set(oid, amt);
                }
                if (sub.equals("give")) msg(o, "&b+" + format(amt) + " Kristalle&7!");
                n++;
            }
            msg(sender, "&aKristalle (" + sub + " " + format(amt) + ") für &f" + n + " &aSpieler, die online sind.");
            refreshScoreboard();
            return true;
        }
        OfflinePlayer target = Bukkit.getPlayerExact(args[1]);
        if (target == null) target = Bukkit.getOfflinePlayerIfCached(args[1]);
        if (target == null) {
            msg(sender, "&cSpieler nicht gefunden (er muss schon einmal auf dem Server gewesen sein).");
            return true;
        }
        long amount;
        try {
            amount = Long.parseLong(args[2]);
        } catch (NumberFormatException e) {
            msg(sender, "&cDas ist keine gültige Zahl, Sterblicher.");
            return true;
        }
        if (amount < 0) {
            msg(sender, "&cDie Anzahl darf nicht negativ sein.");
            return true;
        }
        UUID id = target.getUniqueId();
        switch (sub) {
            case "give" -> crystals.add(id, amount);
            case "take" -> crystals.set(id, crystals.get(id) - amount);
            default -> crystals.set(id, amount);
        }
        msg(sender, "&aKristalle von &f" + args[1] + "&a: &b" + format(crystals.get(id)));
        if (target.isOnline() && target.getPlayer() != null && sub.equals("give")) {
            msg(target.getPlayer(), "&b+" + format(amount) + " Kristalle&7!");
        }
        refreshScoreboard();
        return true;
    }

    private Block targetBlock(Player p) {
        return p.getTargetBlockExact(6);
    }

    private boolean handleCrate(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            msg(sender, "&6Kisten:");
            for (Crate crate : crates.values()) {
                plugin.getMessageUtil().sendRaw(sender, " &8» " + crate.name + " &7- &b" + format(crate.price) + " Kristalle &8(" + crate.id + ")");
            }
            if (isAdmin(sender)) {
                plugin.getMessageUtil().sendRaw(sender, "&5☠ &7Zauberformeln: &e/crate create|delete|setprice|setname|place|remove|additem|addmoney|addcrystals|addcitem|addcommand|rewards|removereward|reload");
            }
            return true;
        }
        if (!isAdmin(sender)) {
            msg(sender, "&cDie Geister verwehren dir den Zutritt!");
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "reload" -> {
                removeHolograms();
                load();
                rebuildHolograms();
                msg(sender, "&acrates.yml neu geladen (" + crates.size() + " Kisten).");
            }
            case "create" -> {
                if (args.length < 3) return usage(sender, "/crate create <id> <preis>");
                String id = args[1].toLowerCase();
                if (crates.containsKey(id)) return fail(sender, "Diese Kiste gibt es schon.");
                Long price = parseLong(args[2]);
                if (price == null || price < 0) return fail(sender, "Ungültiger Preis.");
                crates.put(id, new Crate(id, "&f&l" + id, price));
                save();
                msg(sender, "&aKiste &f" + id + " &aerstellt. Name ändern: /crate setname " + id + " &6&lMeine Kiste &7| Items: /crate additem " + id + " <gewicht>");
            }
            case "delete" -> {
                if (args.length < 2) return usage(sender, "/crate delete <id>");
                Crate crate = crates.remove(args[1].toLowerCase());
                if (crate == null) return fail(sender, "Kiste nicht gefunden.");
                locations.values().removeIf(v -> v.equals(crate.id));
                save();
                rebuildHolograms();
                msg(sender, "&aKiste gelöscht.");
            }
            case "givekey" -> {
                Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[1]) : null;
                Crate crate = args.length >= 3 ? crates.get(args[2].toLowerCase()) : null;
                Long amount = args.length >= 4 ? parseLong(args[3]) : Long.valueOf(1);
                if (target == null || crate == null || amount == null || amount == 0) return usage(sender, "/crate givekey <spieler> <kiste> [anzahl]  (Spieler muss online sein)");
                addKeys(target.getUniqueId(), crate.id, amount.intValue());
                msg(sender, "&a" + target.getName() + " hat jetzt &f" + getKeys(target.getUniqueId(), crate.id) + " &a" + c(crate.name));
            }
            case "setprice" -> {
                Crate crate = args.length >= 3 ? crates.get(args[1].toLowerCase()) : null;
                Long price = args.length >= 3 ? parseLong(args[2]) : null;
                if (crate == null || price == null || price < 0) return usage(sender, "/crate setprice <id> <preis>");
                crate.price = price;
                save();
                rebuildHolograms();
                msg(sender, "&aPreis gesetzt: &b" + format(price) + " Kristalle");
            }
            case "setmodel" -> {
                Crate crate = args.length >= 3 ? crates.get(args[1].toLowerCase()) : null;
                Long nr = args.length >= 3 ? parseLong(args[2]) : null;
                if (crate == null || nr == null || nr < 0 || nr > 100) return usage(sender, "/crate setmodel <id> <0-5>  (0 = nur Schild, 1-5 = Modell aus dem Resource-Pack)");
                crate.model = nr.intValue();
                save();
                rebuildHolograms();
                msg(sender, "&aModell gesetzt: " + nr);
            }
            case "setname" -> {
                Crate crate = args.length >= 3 ? crates.get(args[1].toLowerCase()) : null;
                if (crate == null) return usage(sender, "/crate setname <id> <name mit &-Farben>");
                crate.name = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
                save();
                rebuildHolograms();
                msg(sender, "&aName gesetzt: " + crate.name);
            }
            case "place" -> {
                if (!(sender instanceof Player p)) return fail(sender, "Nur ingame.");
                Crate crate = args.length >= 2 ? crates.get(args[1].toLowerCase()) : null;
                if (crate == null) return usage(sender, "/crate place <id>  (schau dabei auf den Block, z.B. eine Truhe)");
                Block block = targetBlock(p);
                if (block == null || block.getType().isAir()) return fail(sender, "Schau auf einen Block (max. 6 Blöcke Entfernung).");
                if (isInsideMode() && block.getType() != Material.BARRIER) {
                    if (block.getState() instanceof org.bukkit.inventory.InventoryHolder holder) holder.getInventory().clear();
                    block.setType(Material.BARRIER, false);   // unsichtbarer Block: nur das Kisten-Modell ist zu sehen
                }
                locations.put(key(block), crate.id);
                save();
                rebuildHolograms();
                msg(sender, "&aDieser Block öffnet jetzt die Kiste &f" + crate.id + "&a.");
            }
            case "remove" -> {
                if (!(sender instanceof Player p)) return fail(sender, "Nur ingame.");
                Block block = targetBlock(p);
                if (block == null || locations.remove(key(block)) == null) return fail(sender, "Auf diesem Block liegt keine Kiste.");
                if (block.getType() == Material.BARRIER) block.setType(Material.AIR, false);
                save();
                rebuildHolograms();
                msg(sender, "&aKisten-Block entfernt.");
            }
            case "additem" -> {
                if (!(sender instanceof Player p)) return fail(sender, "Nur ingame.");
                Crate crate = args.length >= 3 ? crates.get(args[1].toLowerCase()) : null;
                Long weight = args.length >= 3 ? parseLong(args[2]) : null;
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (crate == null || weight == null || weight <= 0) return usage(sender, "/crate additem <id> <gewicht>  (Item in der Hand)");
                if (hand.getType().isAir()) return fail(sender, "Du hältst nichts in der Hand.");
                crate.rewards.add(new Reward("item", weight.intValue(), hand.clone(), 0, ""));
                save();
                msg(sender, "&aHinzugefügt (Gewicht " + weight + "). Je höher das Gewicht, desto häufiger.");
            }
            case "addmoney" -> {
                Crate crate = args.length >= 4 ? crates.get(args[1].toLowerCase()) : null;
                Long amount = args.length >= 4 ? parseLong(args[2]) : null;
                Long weight = args.length >= 4 ? parseLong(args[3]) : null;
                if (crate == null || amount == null || weight == null || weight <= 0) return usage(sender, "/crate addmoney <id> <betrag> <gewicht>");
                crate.rewards.add(money(amount, weight.intValue()));
                save();
                msg(sender, "&aGeld-Belohnung hinzugefügt.");
            }
            case "addcrystals" -> {
                Crate crate = args.length >= 4 ? crates.get(args[1].toLowerCase()) : null;
                Long amount = args.length >= 4 ? parseLong(args[2]) : null;
                Long weight = args.length >= 4 ? parseLong(args[3]) : null;
                if (crate == null || amount == null || weight == null || weight <= 0) return usage(sender, "/crate addcrystals <id> <anzahl> <gewicht>");
                crate.rewards.add(crystalsReward(amount, weight.intValue()));
                save();
                msg(sender, "&aKristall-Belohnung hinzugefügt.");
            }
            case "addcitem" -> {
                Crate crate = args.length >= 4 ? crates.get(args[1].toLowerCase()) : null;
                Long weight = args.length >= 4 ? parseLong(args[3]) : null;
                if (crate == null || weight == null || weight <= 0) return usage(sender, "/crate addcitem <id> <citem-id> <gewicht>");
                if (citemStack(args[2]) == null) return fail(sender, "Dieses Custom-Item gibt es nicht (siehe /citem list).");
                crate.rewards.add(citem(args[2], weight.intValue()));
                save();
                msg(sender, "&aCustom-Item hinzugefügt.");
            }
            case "addcommand" -> {
                Crate crate = args.length >= 4 ? crates.get(args[1].toLowerCase()) : null;
                Long weight = args.length >= 4 ? parseLong(args[2]) : null;
                if (crate == null || weight == null || weight <= 0) return usage(sender, "/crate addcommand <id> <gewicht> <befehl mit %player%>");
                String cmd = String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length));
                crate.rewards.add(new Reward("command", weight.intValue(), null, 0, cmd));
                save();
                msg(sender, "&aBefehl-Belohnung hinzugefügt.");
            }
            case "rewards" -> {
                Crate crate = args.length >= 2 ? crates.get(args[1].toLowerCase()) : null;
                if (crate == null) return usage(sender, "/crate rewards <id>");
                int i = 1;
                for (Reward r : crate.rewards) {
                    plugin.getMessageUtil().sendRaw(sender, " &8" + i++ + ". &f" + rewardName(r) + " &7(" + r.type() + ", Gewicht " + r.weight() + ", " + chance(crate, r) + " %)");
                }
            }
            case "removereward" -> {
                Crate crate = args.length >= 3 ? crates.get(args[1].toLowerCase()) : null;
                Long index = args.length >= 3 ? parseLong(args[2]) : null;
                if (crate == null || index == null || index < 1 || index > crate.rewards.size()) return usage(sender, "/crate removereward <id> <nummer>  (Nummern: /crate rewards <id>)");
                crate.rewards.remove((int) (index - 1));
                save();
                msg(sender, "&aBelohnung entfernt.");
            }
            default -> msg(sender, "&cUnbekannt. /crate list zeigt die Befehle.");
        }
        return true;
    }

    private boolean usage(CommandSender s, String text) {
        msg(s, "&cNutzung: " + text);
        return true;
    }

    private boolean fail(CommandSender s, String text) {
        msg(s, "&c" + text);
        return true;
    }

    private Long parseLong(String s) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (command.getName().equalsIgnoreCase("kristalle")) {
            if (args.length == 1) {
                if (isAdmin(sender) || isRankStaff(sender)) out.addAll(List.of("give", "take", "set"));
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            } else if (args.length == 2) {
                out.add("*");
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            }
        } else if (isAdmin(sender)) {
            if (args.length == 1) {
                out.addAll(List.of("list", "create", "delete", "givekey", "setprice", "setname", "setmodel", "place", "remove", "additem", "addmoney",
                        "addcrystals", "addcitem", "addcommand", "rewards", "removereward", "reload"));
            } else if (args.length == 2 && !args[0].equalsIgnoreCase("create") && !args[0].equalsIgnoreCase("remove")) {
                out.addAll(crates.keySet());
            }
        }
        String prefix = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        out.removeIf(s -> !s.toLowerCase().startsWith(prefix));
        return out;
    }
}
