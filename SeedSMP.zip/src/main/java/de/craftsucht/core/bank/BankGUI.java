package de.craftsucht.core.bank;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.economy.EconomyModule;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class BankGUI {

    private BankGUI() {
    }

    public static void open(SpookyCraftCore plugin, BankManager bankManager, Player player) {
        String titel = plugin.getConfig().getString("bank.gui-titel", "&a&lSeedSMP &6&lBank");
        int groesse = plugin.getConfig().getInt("bank.gui-groesse", 27);
        Inventory inv = Bukkit.createInventory(null, groesse, ChatColor.translateAlternateColorCodes('&', titel));

        double guthaben = bankManager.getGuthaben(player.getUniqueId());
        EconomyModule economyModule = (EconomyModule) plugin.getModuleManager().get("economy");
        double walletBalance = economyModule != null ? economyModule.getManager().getBalance(player.getUniqueId()) : 0.0;

        inv.setItem(4, makeItem(Material.GOLD_INGOT, "&6&lKontostand", List.of(
                "&7Bankguthaben: &e" + String.format("%.2f", guthaben) + "$",
                "&7In der Hand: &e" + String.format("%.2f", walletBalance) + "$")));
        inv.setItem(11, makeItem(Material.GREEN_STAINED_GLASS_PANE, "&a&lEinzahlen", List.of(
                "&7Klick: &aAlles einzahlen", "&7Shift-Klick: &eBetrag eingeben")));
        inv.setItem(15, makeItem(Material.RED_STAINED_GLASS_PANE, "&c&lAuszahlen", List.of(
                "&7Klick: &cAlles auszahlen", "&7Shift-Klick: &eBetrag eingeben")));

        ItemStack grau = makeItem(Material.GRAY_STAINED_GLASS_PANE, "&r", List.of());
        for (int i = 0; i < groesse; i++) {
            if (inv.getItem(i) == null) {
                inv.setItem(i, grau);
            }
        }
        player.openInventory(inv);
    }

    private static ItemStack makeItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) coloredLore.add(ChatColor.translateAlternateColorCodes('&', line));
        meta.setLore(coloredLore);
        item.setItemMeta(meta);
        return item;
    }
}
