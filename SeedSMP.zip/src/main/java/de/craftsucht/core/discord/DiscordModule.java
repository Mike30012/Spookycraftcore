package de.craftsucht.core.discord;

import de.craftsucht.core.SpookyCraftCore;
import de.craftsucht.core.module.Module;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/**
 * /discord: zeigt den klickbaren Einladungslink zum Discord-Server.
 * Link: config discord.invite, sonst der Ban-Screen-Link (/bccore discord <link>).
 */
public class DiscordModule implements Module, CommandExecutor {

    private final SpookyCraftCore plugin;

    public DiscordModule(SpookyCraftCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "discord";
    }

    @Override
    public void enable() {
        plugin.getCommand("discord").setExecutor(this);
    }

    @Override
    public void disable() {
    }

    private String link() {
        String url = plugin.getConfig().getString("discord.invite", "");
        if (url == null || url.isBlank()) url = plugin.getConfig().getString("punishment.ban-screen.discord", "");
        return url == null ? "" : url.trim();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String url = link();
        if (url.isEmpty()) {
            plugin.getMessageUtil().send(sender, "&cDer Discord-Link ist noch nicht gesetzt. &7Admin: &e/bccore discord <link>");
            return true;
        }
        sender.sendMessage(Component.text(""));
        sender.sendMessage(Component.text("☠ ", NamedTextColor.DARK_PURPLE)
                .append(Component.text("Der Geister-Discord von ", NamedTextColor.LIGHT_PURPLE))
                .append(Component.text("SeedSMP", NamedTextColor.GREEN, TextDecoration.BOLD)));
        sender.sendMessage(Component.text("▶ ", NamedTextColor.BLUE)
                .append(Component.text(url, NamedTextColor.AQUA, TextDecoration.UNDERLINED)
                        .clickEvent(ClickEvent.openUrl(url))));
        sender.sendMessage(Component.text("Komm zu uns – die Geister warten dort auf dich!", NamedTextColor.GRAY));
        sender.sendMessage(Component.text(""));
        return true;
    }
}
