package de.craftsucht.core.economy;

import de.craftsucht.core.SpookyCraftCore;

import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class EconomyManager {

    private final SpookyCraftCore plugin;
    private final double startingBalance;

    public EconomyManager(SpookyCraftCore plugin) {
        this.plugin = plugin;
        this.startingBalance = plugin.getConfig().getDouble("economy.starting-balance", 100.0);
    }

    // Guthaben liegen im Speicher (sonst SQL-Abfrage pro Spieler alle 2 Sekunden fürs Scoreboard auf dem Main-Thread).
    // Schreibzugriffe laufen nacheinander in einem eigenen Thread, damit der Server nicht auf die Festplatte wartet.
    private final java.util.concurrent.ConcurrentHashMap<UUID, Double> cache = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.ExecutorService writer =
            java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "SeedSMP-Economy-Writer");
                t.setDaemon(true);
                return t;
            });

    public double getBalance(UUID uuid) {
        Double cached = cache.get(uuid);
        if (cached != null) return cached;
        String sql = "SELECT balance FROM economy WHERE uuid = ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double bal = rs.getDouble("balance");
                    cache.put(uuid, bal);
                    return bal;
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Economy getBalance fehlgeschlagen: " + e.getMessage());
        }
        setBalance(uuid, startingBalance);
        return startingBalance;
    }

    public void setBalance(UUID uuid, double amount) {
        cache.put(uuid, amount);
        writer.execute(() -> {
            String sql = "INSERT INTO economy (uuid, balance) VALUES (?, ?) " +
                    "ON CONFLICT(uuid) DO UPDATE SET balance = excluded.balance";
            try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                ps.setDouble(2, amount);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().warning("Economy setBalance fehlgeschlagen: " + e.getMessage());
            }
        });
    }

    /** Wartet beim Abschalten, bis alle ausstehenden Guthaben-Schreibvorgänge fertig sind. */
    public void shutdown() {
        writer.shutdown();
        try {
            writer.awaitTermination(10, java.util.concurrent.TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    public boolean withdraw(UUID uuid, double amount) {
        double bal = getBalance(uuid);
        if (bal < amount) return false;
        setBalance(uuid, bal - amount);
        return true;
    }

    public void deposit(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) + amount);
    }

    public Map<String, Double> getTop(int limit) {
        Map<String, Double> result = new LinkedHashMap<>();
        String sql = "SELECT uuid, balance FROM economy ORDER BY balance DESC LIMIT ?";
        try (Connection c = plugin.getDatabase().getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String name = plugin.getServer().getOfflinePlayer(UUID.fromString(rs.getString("uuid"))).getName();
                    result.put(name != null ? name : rs.getString("uuid"), rs.getDouble("balance"));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Economy getTop fehlgeschlagen: " + e.getMessage());
        }
        return result;
    }
}
